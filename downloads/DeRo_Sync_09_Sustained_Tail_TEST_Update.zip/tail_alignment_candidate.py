"""Experimental end-of-song search planning; never edits a saved project."""
import math
from numbers import Real
import re


def normalize(word):
    return re.sub(r'[^\w]+', '', word.casefold(), flags=re.UNICODE)


def tail_plan(events, anchors, duration):
    """Include the last supported line and all unsupported trailing lines."""
    if not events or not math.isfinite(duration) or duration <= 0:
        return None
    counts = [len(e[2].split()) for e in events]
    supported = []
    offset = 0
    for count in counts:
        supported.append(any(i in anchors for i in range(offset, offset + count)))
        offset += count
    if not any(supported) or supported[-1]:
        return None
    first = max(i for i, yes in enumerate(supported) if yes)
    start = float(events[first][0])
    if not 0 <= start < duration:
        return None
    return {'first_line': first, 'counts': counts[first:],
            'segment': {'start': start, 'end': duration,
                        'text': ' '.join(e[2] for e in events[first:])}}


def split_tail(plan, returned):
    """Accept only complete, scored, ordered matches; no interpolation."""
    exact = plan['segment']['text'].split()
    words = [w for segment in returned for w in segment.get('words', [])
             if str(w.get('word', '')).strip()]
    if len(words) != len(exact):
        raise ValueError('Incomplete tail word output; keep existing timings.')
    output = []
    previous_end = plan['segment']['start']
    for token, word in zip(exact, words):
        if not normalize(token) or normalize(token) != normalize(str(word.get('word', ''))):
            raise ValueError('Tail text mismatch; keep existing timings.')
        a, b, score = word.get('start'), word.get('end'), word.get('score')
        if any(isinstance(v, bool) or not isinstance(v, Real) or not math.isfinite(v)
               for v in (a, b, score)):
            raise ValueError('Missing or invalid scored timestamp; keep existing timings.')
        if a < previous_end - .002 or b <= a or b > plan['segment']['end'] + .002 or not .15 <= score <= 1:
            raise ValueError('Unsupported or overlapping tail timing; keep existing timings.')
        output.append([float(round(a, 3)), float(round(b, 3)), token])
        previous_end = b
    lines = []
    offset = 0
    for count in plan['counts']:
        group = output[offset:offset + count]
        if not group:
            raise ValueError('Empty lyric line; keep existing timings.')
        lines.append(group)
        offset += count
    return lines


def realign_tail(segments, anchors, audio, align_callback, sample_rate=16000):
    """Align one unsupported tail group, retaining evidence for manual review."""
    from vocal_gap_guard import trim_gap_start
    events = [[s['start'], s['end'], s['text']] for s in segments]
    plan = tail_plan(events, anchors, len(audio) / sample_rate)
    if plan is None:
        return {}, {'status': 'not_needed'}
    returned = align_callback([plan['segment']]).get('segments', [])
    lines = split_tail(plan, returned)
    raw = [word for segment in returned for word in segment.get('words', [])
           if str(word.get('word', '')).strip()]
    replacements = {}
    changes = []
    offset = 0
    for i, line in enumerate(lines, plan['first_line']):
        words = []
        for start, end, text in line:
            proposed, evidence = trim_gap_start(audio, sample_rate, start, end)
            words.append({'word': text, 'start': proposed, 'end': end,
                          'score': float(raw[offset]['score'])})
            if evidence['changed']:
                changes.append({'line_index': i + 1, 'word': text, **evidence})
            offset += 1
        replacements[i] = {'start': words[0]['start'], 'end': words[-1]['end'],
                           'text': segments[i]['text'], 'words': words}
    from sustained_end_candidate import extend_line_end
    end_changes = []
    for i, segment in replacements.items():
        word = segment['words'][-1]
        next_start = replacements[i + 1]['start'] if i + 1 in replacements else None
        proposed, evidence = extend_line_end(audio, sample_rate,
                                            word['start'], word['end'], next_start)
        if evidence['changed']:
            word['end'] = proposed
            segment['end'] = proposed
            end_changes.append({'line_index': i + 1, 'word': word['word'], **evidence})
    return replacements, {'status': 'forced_alignment_requires_review',
                          'first_line_index': plan['first_line'] + 1,
                          'search_start': plan['segment']['start'],
                          'search_end': plan['segment']['end'],
                          'gap_start_proposals': changes,
                          'sustained_end_proposals': end_changes}
