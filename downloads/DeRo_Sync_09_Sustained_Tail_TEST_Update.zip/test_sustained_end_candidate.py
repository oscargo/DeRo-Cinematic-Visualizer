import unittest
import numpy as np
from sustained_end_candidate import extend_line_end

class SustainedEndTests(unittest.TestCase):
 def audio(self):
  sr=16000;t=np.arange(3*sr)/sr
  amp=np.where(t<1.,.2,np.where(t<1.4,.2*(1.4-t)/.4,0.))
  return np.sin(2*np.pi*220*t)*amp
 def test_sustained_release_is_extended(self):
  end,info=extend_line_end(self.audio(),16000,.3,1.)
  self.assertGreater(end,1.2);self.assertLess(end,1.5)
  self.assertTrue(info['requires_listening_review'])
  self.assertIs(type(end),float)
 def test_gain_scaling_keeps_same_proposal(self):
  values=[extend_line_end(self.audio()*gain,16000,.3,1.)[0] for gain in [.01,1.,2.]]
  self.assertEqual(min(values),max(values))
 def test_cannot_extend_into_next_word(self):
  end,_=extend_line_end(self.audio(),16000,.3,1.,1.15)
  self.assertEqual(end,1.)
 def test_immediate_silence_is_not_extended(self):
  audio=self.audio();audio[16000:]=0
  self.assertEqual(extend_line_end(audio,16000,.3,1.)[0],1.)
 def test_no_release_inside_search_limit_keeps_old_end(self):
  t=np.arange(3*16000)/16000;audio=.2*np.sin(2*np.pi*220*t)
  self.assertEqual(extend_line_end(audio,16000,.3,1.)[0],1.)
 def test_silence_does_not_create_a_sustain(self):
  self.assertEqual(extend_line_end(np.zeros(3*16000),16000,.3,1.)[0],1.)
 def test_invalid_input_is_rejected(self):
  for sr,start,end in [(0,.3,1.),(16000,1.,.3),(16000,float('nan'),1.)]:
   with self.assertRaises(ValueError):extend_line_end(self.audio(),sr,start,end)

if __name__=='__main__':unittest.main()
