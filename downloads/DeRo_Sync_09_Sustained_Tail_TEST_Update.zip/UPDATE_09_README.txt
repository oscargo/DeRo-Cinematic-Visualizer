DeRo Sync STABILIZATION-09-TEST: recovered-tail sustained ending candidate.

Close DeRo Sync. COPY the complete working 08 app folder to DeRo_Sync_09_TEST. Extract all files from this update into that copy beside the main Python app file, replacing matching files. Run Launch_DeRo_Sync.bat there; confirm STABILIZATION-09-TEST in the title.

Uses the existing vocal stem to estimate held-word release after a model endpoint. Applies ONLY to the final word of each recovered trailing lyric line, never to the entire song. Search is capped at 0.8 seconds and before the following word/line. Immediate silence, missing energy contrast or no detectable release retains the original endpoint. Recovered lines remain PARTIAL and require listening review; release can include reverberation. Existing project overwrite confirmations remain in place. Algorithm cache identity is updated.

130 local regression tests pass. Offline replay of an existing real WhisperX result against a supplied vocal stem reduced mean boundary error from 159 to 85 ms over seven tail words. This is one song, not general accuracy proof. One endpoint is approximately 263 ms later than the manual reference. Fresh end-to-end Windows 09 alignment remains unverified. This is TEST, not Stable.

Keep your manually corrected project as the reference. Never replace it with automatic timing output. Test only in a separate project copy. No additional separation is needed. No dependencies are installed. This ZIP contains only app/source/tests, manifest, and these instructions; no audio, projects, user reports, or personal paths.
