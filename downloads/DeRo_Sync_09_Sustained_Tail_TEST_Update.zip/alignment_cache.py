"""Crash-safe, fingerprinted full-song alignment cache for short batch test exports."""
import hashlib
import json
import os
from pathlib import Path

FIELDS=('events','word_timings','ai_word_timings','alignment_status','word_scores','sync_inspector','manual_overrides','reviewed_lines')

def _fingerprint(path):
    path=Path(path).resolve(strict=True)
    st=path.stat()
    if not path.is_file() or st.st_size<44:raise ValueError('Missing or invalid cache input: '+str(path))
    return {'path':str(path),'size':st.st_size,'mtime_ns':st.st_mtime_ns}

def make_identity(source, lyrics, stems, demucs_model, whisper_model, language):
    identity={'schema':1,'source':_fingerprint(source),'vocals':_fingerprint(Path(stems)/'vocals.wav'),
              'instrumental':_fingerprint(Path(stems)/'no_vocals.wav'),
              'lyrics_sha256':hashlib.sha256(lyrics.encode('utf-8')).hexdigest(),
              'demucs_model':demucs_model,'whisper_model':whisper_model,'language':language,
              'algorithm':'DeRoSync-v0210_43-tail-group-gap-sustain-v3'}
    key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()[:24]
    return {'key':key,'identity':identity}

def _cache_path(folder, identity):
    return Path(folder)/'.DeRo_Sync_Alignment_Cache'/('alignment_'+identity['key']+'.json')

def load_cached_alignment(folder, identity):
    path=_cache_path(folder,identity)
    if not path.is_file():return None
    try:
        data=json.loads(path.read_text(encoding='utf-8'))
        if data.get('identity')!=identity['identity']:return None
        payload=data.get('project',{})
        if not all(payload.get(k) for k in ('events','word_timings','alignment_status')):return None
        return dict(payload,alignment_diagnostics=data.get('alignment_diagnostics',{}))
    except (OSError,ValueError,TypeError):return None

def save_cached_alignment(folder, identity, project, diagnostics):
    payload={k:project.get(k) for k in FIELDS if k in project}
    if not all(payload.get(k) for k in ('events','word_timings','alignment_status')):
        raise ValueError('Refusing to cache incomplete alignment')
    path=_cache_path(folder,identity)
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp')
    try:
        with temp.open('x',encoding='utf-8') as f:
            json.dump({'identity':identity['identity'],'project':payload,'alignment_diagnostics':diagnostics},f,ensure_ascii=False)
            f.flush();os.fsync(f.fileno())
        os.replace(temp,path)
    finally:
        if temp.exists():temp.unlink()
    return path
