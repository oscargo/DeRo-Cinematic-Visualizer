"""Experimental line-ending release estimate from isolated-vocal energy.

Energy can include reverberation or stem leakage. Proposals require listening
review and must never be treated as word recognition or overwrite manual edits.
"""
import math
import numpy as np


def extend_line_end(audio, sample_rate, start, end, next_start=None):
    if isinstance(sample_rate, bool) or not isinstance(sample_rate, (int, float)) or not math.isfinite(sample_rate) or sample_rate <= 0:
        raise ValueError('Invalid sample rate')
    start, end = float(start), float(end)
    info = {'changed': False, 'original_end': end, 'proposed_end': end}
    if not (math.isfinite(start) and math.isfinite(end) and 0 <= start < end):
        raise ValueError('Invalid word interval')
    limit = min(len(audio) / sample_rate, end + .8)
    if next_start is not None:
        limit = min(limit, float(next_start) - .02)
    if limit - end < .16 or end - start < .12:
        return end, info
    hop = max(1, round(sample_rate * .02))
    # A fixed frame grid keeps proposals stable across overlapping windows.
    first = max(0, math.floor(max(start, end - .12) * sample_rate / hop))
    last = min(len(audio) // hop, math.floor(limit * sample_rate / hop))
    if last <= first + 8:
        return end, info
    samples = np.asarray(audio[first * hop:last * hop], dtype=np.float64)
    rms = np.sqrt(np.mean(samples.reshape(-1, hop) ** 2, axis=1))
    db = 20. * np.log10(np.maximum(rms, 1.e-12))
    times = (first + np.arange(len(db))) * hop / sample_rate
    before = db[(times >= end - .10) & (times < end)]
    after = db[times >= end]
    if len(before) < 2 or len(after) < 8:
        return end, info
    level = float(np.median(before))
    floor = float(np.percentile(after, 10))
    if level - floor < 16.:
        return end, info
    threshold = max(level - 20., floor + 10.)
    quiet = db <= threshold
    run = 0
    release = None
    for i in np.flatnonzero(times >= end):
        run = run + 1 if quiet[i] else 0
        if run >= 4:  # 80 ms sustained drop, rather than a syllable notch.
            release = float(times[i - 3])
            break
    if release is None or release - end < .10:
        return end, info
    proposed = float(round(min(limit, release + .06), 3))
    if proposed - end < .12:
        return end, info
    info.update(changed=True, proposed_end=proposed,
                extension_seconds=round(proposed - end, 3),
                threshold_db=round(threshold, 2),
                requires_listening_review=True)
    return proposed, info
