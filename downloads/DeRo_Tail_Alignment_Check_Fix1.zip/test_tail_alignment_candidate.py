import unittest
from tail_alignment_candidate import tail_plan, split_tail

class TailTests(unittest.TestCase):
    def test_unrecognized_tail_searches_remaining_audio(self):
        p=tail_plan([[10,11,'last word'],[11,11.3,'again'],[11.3,11.6,'again']],{0:(10,10.4),1:(10.5,11)},30.)
        self.assertEqual(p['segment'],{'start':10.,'end':30.,'text':'last word again again'})
        words=[dict(word=t,start=a,end=b,score=.8) for t,a,b in [('last',10,10.4),('word',10.5,13),('again',20,21),('again',28,29)]]
        out=split_tail(p,[{'words':words}]);self.assertEqual([g[0][0] for g in out],[10,20,28])
    def test_no_tail_or_no_anchors_does_not_change_plan(self):
        e=[[1,2,'hello']]
        self.assertIsNone(tail_plan(e,{0:(1,2)},4))
        self.assertIsNone(tail_plan(e,{},4))
    def test_missing_repeated_word_is_rejected(self):
        p=tail_plan([[1,2,'hey'],[2,3,'hey']],{0:(1,2)},10)
        with self.assertRaises(ValueError):split_tail(p,[{'words':[dict(word='hey',start=1,end=2,score=.8)]}])
    def test_unscored_or_reused_occurrence_is_rejected(self):
        p=tail_plan([[1,2,'hey'],[2,3,'hey']],{0:(1,2)},10)
        for last in [dict(word='hey',start=1,end=2,score=.8),dict(word='hey',start=8,end=9),dict(word='wrong',start=8,end=9,score=.8)]:
            with self.assertRaises(ValueError):split_tail(p,[{'words':[dict(word='hey',start=1,end=2,score=.8),last]}])

class ReportSerializationTests(unittest.TestCase):
    def test_actual_numpy_boolean_and_nested_alignment_values_save(self):
        import json
        import tempfile
        from pathlib import Path
        import numpy as np
        from Check_Tail_Alignment import write_comparison
        report={'candidate_improved_mean_boundary_error':np.bool_(True),
                'raw_alignment':[{'word':'¡Tonta!', 'start':np.float32(173.731),
                                  'score':np.float64(.8), 'index':np.int64(3)}],
                'diagnostic_array':np.array([1.,2.],dtype=np.float32)}
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'Tail_Comparison.json'
            write_comparison(path,report)
            saved=json.loads(path.read_text(encoding='utf-8'))
        self.assertIs(saved['candidate_improved_mean_boundary_error'],True)
        self.assertEqual(saved['raw_alignment'][0]['word'],'¡Tonta!')
        self.assertEqual(saved['diagnostic_array'],[1.,2.])

    def test_numpy_timestamp_and_score_are_accepted_without_losing_checks(self):
        import numpy as np
        p=tail_plan([[1,2,'hey'],[2,3,'hey']],{0:(1,2)},10)
        words=[dict(word='hey',start=np.float32(a),end=np.float32(b),score=np.float32(.8))
               for a,b in [(1,2),(8,9)]]
        result=split_tail(p,[{'words':words}])
        self.assertIs(type(result[1][0][0]),float)
        self.assertEqual(result[1][0][:2],[8.,9.])
        words[1]['start']=np.bool_(True)
        with self.assertRaises(ValueError):split_tail(p,[{'words':words}])

if __name__=='__main__':unittest.main()
