@echo off
setlocal
cd /d "%~dp0"
py -3.12 "%~dp0Windows_Acceptance_Kit\acceptance_check.py" --app-dir "%~dp0DeRo_Sync_Stabilization_07_TEST" --output "%~dp0Acceptance_Results" --regression --gpu
if errorlevel 1 (
 echo Some checks failed or are unavailable. Read Automatic_Results.json in the results folder.
 echo This does not mean CUDA/PyTorch needs reinstalling. See START_HERE.txt for media-tool help.
) else (
 echo Automatic checks completed. Manual acceptance is still pending.
)
if exist "%~dp0Acceptance_Results" start "" "%~dp0Acceptance_Results"
echo Send Automatic_Results.json and regression.log back for review.
pause
