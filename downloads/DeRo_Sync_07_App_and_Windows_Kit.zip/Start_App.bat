@echo off
call "%~dp0DeRo_Sync_Stabilization_07_TEST\Launch_DeRo_Sync.bat"
