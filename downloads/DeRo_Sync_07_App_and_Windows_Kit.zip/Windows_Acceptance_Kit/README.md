# Windows acceptance kit — candidate 07 TEST

The app has 112 passing Linux/offscreen regression checks. This kit collects the remaining machine-specific evidence; it does not remotely control the machine, install packages, download models, or upload results.

1. Extract the candidate app and this kit to separate folders. Keep the untouched baseline and back up projects with manual timings.
2. From a terminal in this kit, run:

   `py -3.12 acceptance_check.py --app-dir "C:\path\DeRo_Sync_Stabilization_06_TEST" --output "C:\path\Acceptance_Results" --regression --gpu`

3. Launch the app with its existing launcher and complete `Manual_Results.json` in the results folder. Use PASS/FAIL/BLOCKED only after observing each item. Package metadata proves presence, not import/runtime compatibility. A one-frame NVENC probe is not a full GPU export test.
4. Verify each actual MP4 with the requested settings, for example:

   `py -3.12 acceptance_check.py --app-dir "C:\path\DeRo_Sync_Stabilization_06_TEST" --output "C:\path\Acceptance_Results\range-export" --verify "C:\path\range.mp4" --width 1920 --height 1080 --fps 60 --seconds 30`

   Verification requires ffprobe on PATH or beside the discovered FFmpeg. Duration tolerance follows the app's current 0.1-second/two-frame rule; sample-accurate endpoints and audible lyric accuracy require separate review.

5. For each song, preserve a BEFORE project, connect the genuine existing paired stems, and align a separate copy. Do not use the synthetic test tones as song stems. Export the AFTER karaoke/Sync Inspector JSON, then run:

   `py -3.12 compare_timings.py "C:\path\before.karaoke.json" "C:\path\after.karaoke.json" --output "C:\path\Acceptance_Results\word_changes.csv"`

   Every word moving over 150 ms, missing word, or changed text is flagged. Flags indicate movement, not whether a change is correct. The app's workflow-duration `.timing.json` files are not word-timing ground truth. Listen to repeated phrases, estimated/partial lines, fast Spanish passages and sustained English notes.

The original song stem archives exceeded this session's 32 MiB input-transfer limit. Real stems must be available on the Windows machine for fresh alignment. No separation or ASR was run here. Original twelve progress-design identities still need authoritative reference confirmation.

Reports contain local paths and error messages; review them before sharing. Keep automatic and manual evidence together. Candidate 07 remains TEST until these checks are accepted.

Candidate07 discovers existing FFmpeg/ffprobe beyond PATH and temporarily makes them available to tests. It does not install tools or alter permanent PATH. Optional --ffmpeg and --ffprobe arguments select existing executables. Full regression.log is retained rather than a truncated error tail.
