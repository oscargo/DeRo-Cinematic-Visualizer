"""Local acceptance evidence collector. No installs, model downloads, or uploads."""
import argparse,datetime,hashlib,importlib.metadata,json,os,platform,shutil,subprocess,sys
from pathlib import Path

def command(args,timeout=30):
    env=os.environ.copy();env['PYTHONIOENCODING']='utf-8'
    try:
        result=subprocess.run(args,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout,env=env)
        return {'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    except (OSError,subprocess.TimeoutExpired) as exc:return {'error':str(exc)}

def collect(a,root,out,tool_info):
    report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host':platform.platform(),'windows_host':sys.platform=='win32','python':sys.version,'app_version':(root/'VERSION').read_text(encoding='utf-8-sig').strip(),'package_presence':{},'tool_discovery':tool_info,'checks':{},'manual_acceptance':'PENDING: automatic checks do not certify GUI/audio/sync accuracy'}
    for name in ['PySide6','numpy','Pillow','psutil','mutagen','imageio-ffmpeg','torch','torchaudio','demucs','whisperx']:
        try:report['package_presence'][name]={'installed_version':importlib.metadata.version(name),'runtime_readiness':'not established by metadata'}
        except importlib.metadata.PackageNotFoundError:report['package_presence'][name]={'installed':False}
    for tool in ['ffmpeg','ffprobe']:
        binary=shutil.which(tool);version=command([binary,'-version']) if binary else None
        report['checks'][tool]={'path':binary,'source_path':tool_info['found'].get(tool),'result':'PASS' if version and version.get('exit_code')==0 else 'FAIL','version':version}
    manifest=root/'RELEASE_MANIFEST.json'
    if manifest.is_file():
        mismatches=[]
        for item in json.loads(manifest.read_text(encoding='utf-8')):
            path=(root/item['path']).resolve()
            if not path.is_relative_to(root) or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:mismatches.append(item['path'])
        report['checks']['source_manifest']={'result':'FAIL' if mismatches else 'PASS','mismatched_files':mismatches}
    else:report['checks']['source_manifest']={'result':'WARNING','note':'Release manifest missing; use an extracted release ZIP.'}
    report['checks']['python312']={'result':'PASS' if sys.version_info[:2]==(3,12) else 'FAIL','observed':platform.python_version()}
    report['checks']['required_imports']=command([sys.executable,'-c','import PySide6,numpy,PIL,psutil,mutagen; print("Required application imports passed")'])
    report['checks']['release_metadata']=command([sys.executable,str(root/'validate_release.py'),str(root)])
    if a.regression:
        result=command([sys.executable,str(root/'run_regression_tests.py')],timeout=240)
        (out/'regression.log').write_text(result.get('stdout','')+'\n'+result.get('stderr',result.get('error','')),encoding='utf-8')
        report['checks']['regression']=result
    if a.gpu:
        ffmpeg=shutil.which('ffmpeg')
        report['checks']['nvenc_encode']=command([ffmpeg,'-v','error','-f','lavfi','-i','color=s=1920x1080:r=60','-frames:v','1','-c:v','h264_nvenc','-f','null','-']) if ffmpeg else {'error':'FFmpeg missing; GPU encoding not tested'}
        report['checks']['torch_cuda']=command([sys.executable,'-c',"import json,torch; ok=torch.cuda.is_available(); print(json.dumps({'cuda_available':ok,'torch':torch.__version__,'cuda_build':torch.version.cuda,'gpu':torch.cuda.get_device_name(0) if ok else None}))"])
    if a.verify:
        from export_audit import verify_mp4
        report['checks']['selected_mp4']=verify_mp4(a.verify,shutil.which('ffmpeg'),expected_duration=a.seconds,expected_resolution=(a.width,a.height),expected_fps=a.fps)
    if tool_info['missing']:report['media_tool_help']='If discovery still misses a tool, put existing ffmpeg.exe and ffprobe.exe in the app tools/ffmpeg/bin folder or use --ffmpeg/--ffprobe. A complete FFmpeg distribution includes both. Do not reinstall Torch/CUDA for this issue.'
    (out/'Automatic_Results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    manual=out/'Manual_Results.json'
    if not manual.exists():shutil.copyfile(Path(__file__).with_name('Manual_Results.json'),manual)
    print('Evidence saved to',out);print('Windows host:',report['windows_host']);print('Manual acceptance remains pending.')
    return 1 if any(x.get('error') or x.get('exit_code',0)!=0 or x.get('result') in ('FAIL','WARNING') for x in report['checks'].values()) else 0

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--app-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--regression',action='store_true');p.add_argument('--gpu',action='store_true');p.add_argument('--verify',type=Path);p.add_argument('--width',type=int,default=1920);p.add_argument('--height',type=int,default=1080);p.add_argument('--fps',type=float,default=60);p.add_argument('--seconds',type=float);p.add_argument('--ffmpeg',type=Path);p.add_argument('--ffprobe',type=Path);a=p.parse_args()
    root=a.app_dir.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
    if not (root/'VERSION').is_file():p.error('--app-dir must contain the extracted app VERSION file')
    sys.path.insert(0,str(root))
    from media_tools import media_tool_session
    with media_tool_session(root,{'ffmpeg':a.ffmpeg,'ffprobe':a.ffprobe}) as tools:return collect(a,root,out,tools)
if __name__=='__main__':sys.exit(main())
