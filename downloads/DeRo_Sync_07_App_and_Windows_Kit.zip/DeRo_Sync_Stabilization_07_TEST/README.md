# Current test candidate: STABILIZATION-07-TEST

See STABILIZATION_07_README.md for current behavior, tests and limitations. The historical notes below predate this candidate.

# DeRo Sync v0.2.0.80 — Export Status Fix

Based on v0.2.0.79. Preserves the Recent Music Folders browser, Lyrics next-action emphasis, Play Next Word, waveform clipboard/handle improvements, and earlier lyric export fixes.

## Changes in v0.2.0.80
- Fixed the main project-step indicator for **06 EXPORT**.
- After a successful MP4 export, the Export step now receives the green completion checkmark.
- If project or export settings change after export, the Export step changes to a warning instead of incorrectly remaining complete.
- Failed or cancelled exports do not receive a completion checkmark.

## Preserved features
- Recent Music Folders browser and song selection.
- Lyrics next-action emphasis.
- Play Next Word.
- Waveform clipboard and handle improvements.
- Existing lyric export regression fix and prior workflow features.

## Launch
Run `Launch_DeRo_Sync.bat`. The launcher uses Python 3.12.

## Verification
- Python syntax compilation passed.
- Automated regression tests passed.
- ZIP integrity and version/launcher consistency checked.
- Actual Windows GUI export was not run in this environment; verify with a test MP4 on Windows.


## v0.2.1.37 export history
See TEST_INSTRUCTIONS_v0210_37.txt. Export audit logs are saved alongside MP4 outputs.
