"""A mixed-result batch must never trigger the all-success celebration."""
import ast,unittest,types
from pathlib import Path

class BatchCompletionPolicyTests(unittest.TestCase):
 def finish(self,statuses):
  source=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py');tree=ast.parse(source.read_text(encoding='utf-8-sig'));main=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Main');node=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='_batch_next_song');ns={};exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns)
  class Button:
   def setEnabled(self,value):self.enabled=value
  log=[];events=[];celebrations=[]
  ws=types.SimpleNamespace(songs=[{'batch_status':s} for s in statuses],start_batch_button=Button(),section_process_button=Button(),section_settings_button=Button(),refresh=lambda **kw:None,process_log=types.SimpleNamespace(appendPlainText=log.append),open_folder=types.SimpleNamespace(isChecked=lambda:False))
  widget=types.SimpleNamespace(_batch_running=True,_batch_index=len(statuses)-1,_batch_test_indices=list(range(len(statuses))),_batch_section_mode=False,batch_page=ws,_batch_audit=types.SimpleNamespace(record=lambda event,**values:events.append((event,values))),celebrate_success=lambda *args:celebrations.append(args))
  ns['_batch_next_song'](widget);return widget,events,celebrations
 def test_mixed_failure_suppresses_success_celebration(self):
  widget,events,celebrations=self.finish(['completed','failed','completed']);self.assertFalse(widget._batch_running);self.assertEqual(events[-1][1]['exported'],2);self.assertEqual(events[-1][1]['failed'],1);self.assertFalse(celebrations)
 def test_complete_success_celebrates_once(self):
  widget,events,celebrations=self.finish(['completed','completed']);self.assertFalse(widget._batch_running);self.assertEqual(events[-1][1]['failed'],0);self.assertEqual(len(celebrations),1);self.assertEqual(celebrations[0][0],'batch')
