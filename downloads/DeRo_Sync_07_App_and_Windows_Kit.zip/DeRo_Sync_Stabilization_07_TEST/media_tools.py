"""Discover existing media tools and expose them only for this process/session."""
from contextlib import contextmanager
from pathlib import Path
import importlib,os,shutil,subprocess,tempfile


def discover_media_tools(app_dir,overrides=None):
    root=Path(app_dir).resolve();overrides=overrides or {};found={};tried={}
    directories=[root,root/'bin',root/'tools'/'ffmpeg'/'bin',root/'ffmpeg'/'bin']
    for parent in list(root.parents)[:2]:directories.extend([parent/'bin',parent/'ffmpeg'/'bin',parent/'tools'/'ffmpeg'/'bin'])
    if os.name=='nt':
        local=os.environ.get('LOCALAPPDATA')
        if local:
            directories.append(Path(local)/'Microsoft'/'WinGet'/'Links')
            packages=Path(local)/'Microsoft'/'WinGet'/'Packages'
            if packages.is_dir():
                for package in packages.glob('*FFmpeg*'):
                    directories.extend([package/'bin',*package.glob('*/bin'),*package.glob('*/*/bin')])
        directories.extend([Path('C:/ffmpeg/bin'),Path(os.environ.get('ProgramFiles','C:/Program Files'))/'ffmpeg'/'bin',Path('C:/ProgramData/chocolatey/bin')])
    suffix='.exe' if os.name=='nt' else ''
    for name in ('ffmpeg','ffprobe'):
        candidates=[]
        explicit=overrides.get(name) or os.environ.get('DERO_'+name.upper())
        if explicit:candidates.append(str(explicit))
        on_path=shutil.which(name)
        if on_path:candidates.append(on_path)
        if name=='ffprobe' and found.get('ffmpeg'):candidates.append(str(Path(found['ffmpeg']).with_name('ffprobe'+suffix)))
        candidates.extend(str(folder/(name+suffix)) for folder in directories)
        if name=='ffmpeg':
            try:candidates.append(importlib.import_module('imageio_ffmpeg').get_ffmpeg_exe())
            except (ImportError,RuntimeError,OSError):pass
        tried[name]=[];seen=set()
        for candidate in candidates:
            binary=shutil.which(candidate) or (str(Path(candidate).expanduser()) if Path(candidate).expanduser().is_file() else None)
            if not binary:continue
            binary=str(Path(binary).resolve())
            if binary in seen:continue
            seen.add(binary)
            try:
                result=subprocess.run([binary,'-version'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=10,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                valid=result.returncode==0 and name+' version' in (result.stdout+result.stderr).lower()
                tried[name].append({'path':binary,'usable':valid})
                if valid:found[name]=binary;break
            except (OSError,subprocess.TimeoutExpired) as exc:tried[name].append({'path':binary,'error':str(exc)})
    return {'found':found,'checked_existing_files':tried,'missing':[name for name in ('ffmpeg','ffprobe') if name not in found]}


@contextmanager
def media_tool_session(app_dir,overrides=None):
    info=discover_media_tools(app_dir,overrides);old_path=os.environ.get('PATH','')
    with tempfile.TemporaryDirectory(prefix='dero-existing-media-tools-') as temp:
        paths=[temp];aliases={}
        for name,binary in info['found'].items():
            source=Path(binary);paths.append(str(source.parent));expected=name+('.exe' if os.name=='nt' else '')
            if source.name.casefold()!=expected.casefold():
                alias=Path(temp)/expected
                try:os.link(source,alias)
                except OSError:shutil.copy2(source,alias)
                aliases[name]=str(alias)
        info['temporary_aliases']=aliases
        os.environ['PATH']=os.pathsep.join(dict.fromkeys(paths+[old_path]))
        try:yield info
        finally:os.environ['PATH']=old_path
