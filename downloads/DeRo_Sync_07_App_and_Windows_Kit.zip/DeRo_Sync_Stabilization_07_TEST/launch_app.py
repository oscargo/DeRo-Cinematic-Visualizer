"""Launch with discovered existing FFmpeg tools; never install or change system PATH."""
from pathlib import Path
import subprocess,sys
from media_tools import media_tool_session
root=Path(__file__).resolve().parent
with media_tool_session(root) as tools:
    if tools['missing']:print('Media tools not found: '+', '.join(tools['missing'])+'. Editing remains available; verified export requires FFmpeg and ffprobe.',flush=True)
    raise SystemExit(subprocess.call([sys.executable,str(root/'DeRo_Sync_v0210_43_Popper_Direction_Fix.py')]))
