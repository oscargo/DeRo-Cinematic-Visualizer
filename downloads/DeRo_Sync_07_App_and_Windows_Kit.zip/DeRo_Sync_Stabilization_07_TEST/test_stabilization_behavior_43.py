"""Behavioral regressions for omitted choruses and early resize callbacks."""
import ast,difflib,math
from pathlib import Path
import unittest
SOURCE=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')
def load_matching():
 tree=ast.parse(SOURCE.read_text(encoding='utf-8-sig'));node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='reconcile_alignment_segments')
 ns={'math':math,'difflib':difflib};exec(compile(ast.Module(body=[node],type_ignores=[]),str(SOURCE),'exec'),ns)
 return ns['reconcile_alignment_segments']
class OccurrenceMatchingTests(unittest.TestCase):
 def test_omitted_first_chorus_does_not_steal_second(self):
  inputs=[dict(text='hey now',start=1,end=3),dict(text='hey now',start=21,end=23)];later=dict(text='hey now',start=21.1,end=22.9)
  self.assertEqual(load_matching()(inputs,[later],str.casefold),[None,later])
 def test_unrelated_hallucination_remains_unassigned(self):
  self.assertEqual(load_matching()([dict(text='hey now',start=1,end=3)],[dict(text='subscribe to my channel',start=1,end=3)],str.casefold),[None])
 def test_duplicate_at_wrong_time_remains_unassigned(self):
  self.assertEqual(load_matching()([dict(text='hey now',start=1,end=3)],[dict(text='hey now',start=40,end=42)],str.casefold),[None])
 def test_missing_timestamps_can_use_text_in_order(self):
  inputs=[dict(text='first'),dict(text='last')];returned=[dict(text='first'),dict(text='last')]
  self.assertEqual(load_matching()(inputs,returned,str.casefold),returned)
 def test_partial_output_keeps_intervening_gap(self):
  inputs=[dict(text=t,start=i*10,end=i*10+3) for i,t in enumerate(['one','two','one'])];returned=[inputs[0].copy(),inputs[2].copy()]
  self.assertEqual(load_matching()(inputs,returned,str.casefold),[returned[0],None,returned[1]])
class EarlyResizeTests(unittest.TestCase):
 def test_resize_before_success_label_is_attached(self):
  tree=ast.parse(SOURCE.read_text(encoding='utf-8-sig'));cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DoublePopperCelebration');fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='resizeEvent')
  class Base:
   def resizeEvent(self,event):pass
  cls=ast.ClassDef(name='Widget',bases=[ast.Name(id='Base',ctx=ast.Load())],keywords=[],body=[fn],decorator_list=[])
  ns={'Base':Base};exec(compile(ast.fix_missing_locations(ast.Module(body=[cls],type_ignores=[])),str(SOURCE),'exec'),ns)
  widget=ns['Widget']();widget.height=lambda:56;widget.resizeEvent(None)

class ProjectValidationTests(unittest.TestCase):
 def validate(self,data):
  tree=ast.parse(SOURCE.read_text(encoding='utf-8-sig'));node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='validate_project_payload')
  ns={'math':math};exec(compile(ast.Module(body=[node],type_ignores=[]),str(SOURCE),'exec'),ns);return ns['validate_project_payload'](data)
 def test_invalid_word_timestamp_rejected(self):
  with self.assertRaises(ValueError):self.validate({'format':'KaraokeStudioProject','events':[[0,1,'one']],'word_timings':{'0':[[float('nan'),1,'one']]}})
 def test_non_project_json_rejected(self):
  with self.assertRaises(ValueError):self.validate([])
 def test_valid_unknown_metadata_is_preserved(self):
  data={'format':'KaraokeStudioProject','events':[[0,1,'one']],'word_timings':{'0':[[0,1,'one']]},'future_metadata':{'keep':True}}
  self.assertIs(self.validate(data),data)

class CelebrationClockTests(unittest.TestCase):
 def test_elapsed_clock_drives_six_second_stop(self):
  import types
  tree=ast.parse(SOURCE.read_text(encoding='utf-8-sig'));cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DoublePopperCelebration');fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='tick')
  now=[3.];stopped=[];ns={'time':types.SimpleNamespace(monotonic=lambda:now[0])}
  exec(compile(ast.Module(body=[fn],type_ignores=[]),str(SOURCE),'exec'),ns)
  widget=types.SimpleNamespace(started=0.,frame=0,persistent=True,timer=types.SimpleNamespace(stop=lambda:stopped.append(True)),update=lambda:None)
  ns['tick'](widget);self.assertEqual(widget.frame,180);self.assertFalse(stopped)
  now[0]=6.;ns['tick'](widget);self.assertEqual(widget.frame,360);self.assertTrue(stopped)
