@echo off
setlocal
cd /d "%~dp0"
set "PY=py -3.12"
%PY% -c "import sys; assert sys.version_info[:2] == (3,12)" >nul 2>&1
if errorlevel 1 (
 echo Python 3.12 is required. Install Python 3.12 or configure the launcher to use your existing Python 3.12 environment.
 pause
 exit /b 1
)
%PY% -c "import PySide6, numpy, PIL, psutil, mutagen" >nul 2>&1
if errorlevel 1 (
 echo Missing required Python packages in the selected Python 3.12 environment.
 echo Use your existing permanent dependency environment if configured, or install dependencies with:
 echo   py -3.12 -m pip install PySide6 -r requirements-visualizer.txt
 echo No packages have been installed automatically.
 pause
 exit /b 1
)
%PY% "%~dp0launch_app.py"
if errorlevel 1 pause
