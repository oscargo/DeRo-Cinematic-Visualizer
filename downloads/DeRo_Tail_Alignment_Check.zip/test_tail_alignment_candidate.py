import unittest
from tail_alignment_candidate import tail_plan, split_tail

class TailTests(unittest.TestCase):
    def test_unrecognized_tail_searches_remaining_audio(self):
        p=tail_plan([[10,11,'last word'],[11,11.3,'again'],[11.3,11.6,'again']],{0:(10,10.4),1:(10.5,11)},30.)
        self.assertEqual(p['segment'],{'start':10.,'end':30.,'text':'last word again again'})
        words=[dict(word=t,start=a,end=b,score=.8) for t,a,b in [('last',10,10.4),('word',10.5,13),('again',20,21),('again',28,29)]]
        out=split_tail(p,[{'words':words}]);self.assertEqual([g[0][0] for g in out],[10,20,28])
    def test_no_tail_or_no_anchors_does_not_change_plan(self):
        e=[[1,2,'hello']]
        self.assertIsNone(tail_plan(e,{0:(1,2)},4))
        self.assertIsNone(tail_plan(e,{},4))
    def test_missing_repeated_word_is_rejected(self):
        p=tail_plan([[1,2,'hey'],[2,3,'hey']],{0:(1,2)},10)
        with self.assertRaises(ValueError):split_tail(p,[{'words':[dict(word='hey',start=1,end=2,score=.8)]}])
    def test_unscored_or_reused_occurrence_is_rejected(self):
        p=tail_plan([[1,2,'hey'],[2,3,'hey']],{0:(1,2)},10)
        for last in [dict(word='hey',start=1,end=2,score=.8),dict(word='hey',start=8,end=9),dict(word='wrong',start=8,end=9,score=.8)]:
            with self.assertRaises(ValueError):split_tail(p,[{'words':[dict(word='hey',start=1,end=2,score=.8),last]}])

if __name__=='__main__':unittest.main()
