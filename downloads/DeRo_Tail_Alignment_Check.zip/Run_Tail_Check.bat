@echo off
setlocal
cd /d "%~dp0"
set "PATH=C:\ffmpeg\bin;%PATH%"
py -3.12 Check_Tail_Alignment.py
pause
