"""Run one isolated forced-alignment experiment using existing cached models."""
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback
from tail_alignment_candidate import tail_plan, split_tail


def pick(title, pattern):
    from PySide6.QtWidgets import QFileDialog
    value, _ = QFileDialog.getOpenFileName(None, title, '', pattern)
    if not value:
        raise RuntimeError('Cancelled; no project files were changed.')
    return Path(value)


def run():
    from PySide6.QtWidgets import QApplication
    qt = QApplication.instance() or QApplication(sys.argv)
    before_path = pick('1. Select BEFORE corrections Sync Lyrics JSON', 'JSON (*.json)')
    corrected_path = pick('2. Select CORRECTED Sync Lyrics JSON', 'JSON (*.json)')
    audio_path = pick('3. Select the original vocals.wav', 'Audio (*.wav *.mp3 *.flac)')
    before = json.loads(before_path.read_text(encoding='utf-8-sig'))
    corrected = json.loads(corrected_path.read_text(encoding='utf-8-sig'))
    events = before['final_events']
    reference = corrected['final_events']
    if [e[2] for e in events] != [e[2] for e in reference]:
        raise ValueError('These JSON files contain different lyrics; comparison stopped.')
    support = before['sync_inspector']['direct_anchor_counts']
    indices = set()
    offset = 0
    for i, event in enumerate(events):
        if int(support.get(str(i), 0)) > 0:
            indices.add(offset)
        offset += len(event[2].split())
    ffmpeg = shutil.which('ffmpeg')
    if not ffmpeg and Path('C:/ffmpeg/bin/ffmpeg.exe').is_file():
        ffmpeg = 'C:/ffmpeg/bin/ffmpeg.exe'
    if not ffmpeg:
        raise RuntimeError('Existing FFmpeg not found. Nothing was installed.')
    import numpy as np
    print('Decoding vocal stem; no separation or transcription will run.', flush=True)
    pcm = subprocess.run([ffmpeg, '-v', 'error', '-i', str(audio_path), '-vn',
                          '-ac', '1', '-ar', '16000', '-f', 'f32le', '-'],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    audio = np.frombuffer(pcm.stdout, dtype='<f4').copy()
    plan = tail_plan(events, indices, len(audio) / 16000.)
    if plan is None:
        raise RuntimeError('No unsupported trailing lyrics found; no experiment needed.')
    # Use only the model cache populated by the existing application. No downloads.
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    import torch
    import whisperx
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    language = before['sync_inspector'].get('language', 'es')
    print('Loading existing cached '+language+' alignment model on '+device+'.', flush=True)
    model, metadata = whisperx.load_align_model(language_code=language, device=device)
    print('Aligning only the final lyric group across the remaining audio.', flush=True)
    result = whisperx.align([plan['segment']], model, metadata, audio, device,
                            return_char_alignments=False)
    output = Path(__file__).resolve().parent / ('Tail_Results_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    output.mkdir()
    report = {'experimental': True, 'project_files_modified': False,
              'device': device, 'language': language, 'search_plan': plan,
              'raw_alignment': result.get('segments', []),
              'note': 'Forced alignment only, using the recorded recognition support. This does not validate a fresh full-song recognition pass.'}
    try:
        lines = split_tail(plan, result.get('segments', []))
        comparison = []
        for i, words in enumerate(lines, plan['first_line']):
            expected = corrected['final_word_timings'][str(i)]
            prior = before['final_word_timings'][str(i)]
            for old, new, ref in zip(prior, words, expected):
                comparison.append({'line': i + 1, 'word': new[2], 'before': old[:2],
                                   'candidate': new[:2], 'manual_reference': ref[:2],
                                   'candidate_start_error_seconds': round(new[0] - ref[0], 3),
                                   'candidate_end_error_seconds': round(new[1] - ref[1], 3)})
        before_mae = sum(abs(r['before'][j]-r['manual_reference'][j]) for r in comparison for j in (0,1))/(2*len(comparison))
        after_mae = sum(abs(r['candidate'][j]-r['manual_reference'][j]) for r in comparison for j in (0,1))/(2*len(comparison))
        report.update(validation='COMPLETE_SCORED_OUTPUT', comparison=comparison,
                      before_mean_boundary_error_seconds=round(before_mae, 3),
                      candidate_mean_boundary_error_seconds=round(after_mae, 3),
                      candidate_improved_mean_boundary_error=after_mae < before_mae)
    except ValueError as exc:
        report.update(validation='REJECTED_KEEP_MANUAL_TIMINGS', reason=str(exc))
    dest = output / 'Tail_Comparison.json'
    dest.write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    print('Finished. Your projects are unchanged. Results: '+str(dest), flush=True)
    if sys.platform == 'win32':
        os.startfile(str(output))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(run())
    except Exception:
        traceback.print_exc()
        print('Stopped. No saved project was modified and no packages were installed. If the cached model is unavailable, keep this error for review.', flush=True)
        raise SystemExit(1)
