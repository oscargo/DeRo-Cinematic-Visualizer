import unittest
import numpy as np
from vocal_gap_guard import trim_gap_start

class GapGuardTests(unittest.TestCase):
    def tone(self,seconds,gain=.2):
        t=np.arange(round(seconds*16000))/16000
        return gain*np.sin(2*np.pi*220*t)
    def test_long_gap_trims_to_later_activity_and_keeps_end_out_of_scope(self):
        x=np.r_[self.tone(.4),np.zeros(3*16000),self.tone(1.)]
        for gain in [.01,1.,2.]:
            start,evidence=trim_gap_start(x*gain,16000,0,4.4)
            self.assertAlmostEqual(start,3.36,places=2)
            self.assertIs(type(start),float)
            self.assertTrue(evidence['requires_listening_review'])
    def test_sustained_note_is_preserved(self):
        self.assertEqual(trim_gap_start(self.tone(4),16000,0,4)[0],0)
    def test_silence_does_not_invent_a_word(self):
        self.assertEqual(trim_gap_start(np.zeros(4*16000),16000,0,4)[0],0)
    def test_short_internal_syllable_gap_is_preserved(self):
        x=np.r_[self.tone(1.5),np.zeros(3200),self.tone(1.5)]
        self.assertEqual(trim_gap_start(x,16000,0,3.2)[0],0)
    def test_short_word_is_preserved(self):
        x=np.r_[np.zeros(16000),self.tone(.8)]
        self.assertEqual(trim_gap_start(x,16000,0,1.8)[0],0)

if __name__=='__main__':unittest.main()
