import unittest
import copy
import numpy as np
from tail_alignment_candidate import tail_plan, split_tail, realign_tail

class TailTests(unittest.TestCase):

    def test_unrecognized_tail_searches_remaining_audio(self):
        p = tail_plan([[10, 11, 'last word'], [11, 11.3, 'again'], [11.3, 11.6, 'again']], {0: (10, 10.4), 1: (10.5, 11)}, 30.0)
        self.assertEqual(p['segment'], {'start': 10.0, 'end': 30.0, 'text': 'last word again again'})
        words = [dict(word=t, start=a, end=b, score=0.8) for t, a, b in [('last', 10, 10.4), ('word', 10.5, 13), ('again', 20, 21), ('again', 28, 29)]]
        out = split_tail(p, [{'words': words}])
        self.assertEqual([g[0][0] for g in out], [10, 20, 28])

    def test_no_tail_or_no_anchors_does_not_change_plan(self):
        e = [[1, 2, 'hello']]
        self.assertIsNone(tail_plan(e, {0: (1, 2)}, 4))
        self.assertIsNone(tail_plan(e, {}, 4))

    def test_missing_repeated_word_is_rejected(self):
        p = tail_plan([[1, 2, 'hey'], [2, 3, 'hey']], {0: (1, 2)}, 10)
        with self.assertRaises(ValueError):
            split_tail(p, [{'words': [dict(word='hey', start=1, end=2, score=0.8)]}])

    def test_unscored_or_reused_occurrence_is_rejected(self):
        p = tail_plan([[1, 2, 'hey'], [2, 3, 'hey']], {0: (1, 2)}, 10)
        for last in [dict(word='hey', start=1, end=2, score=0.8), dict(word='hey', start=8, end=9), dict(word='wrong', start=8, end=9, score=0.8)]:
            with self.assertRaises(ValueError):
                split_tail(p, [{'words': [dict(word='hey', start=1, end=2, score=0.8), last]}])

class TailIntegrationTests(unittest.TestCase):
 def test_grouped_alignment_trims_gap_and_keeps_word_end(self):
  segments=[dict(start=1.,end=2.,text='last'),dict(start=2.,end=2.3,text='hey'),dict(start=2.3,end=2.6,text='hey')]
  original=copy.deepcopy(segments)
  audio=np.zeros(12*16000)
  for a,b in [(1,2),(4,5),(9,9.5)]:
   t=np.arange(round((b-a)*16000))/16000
   audio[round(a*16000):round(b*16000)]=.2*np.sin(2*np.pi*220*t)
  calls=[]
  def align(plan):
   calls.append(plan)
   return {'segments':[{'words':[dict(word=w,start=a,end=b,score=.8) for w,a,b in [('last',1,2),('hey',4,5),('hey',5.01,9.5)]]}]}
  replacements,audit=realign_tail(segments,{0:(1,2)},audio,align)
  self.assertEqual(len(calls),1)
  self.assertEqual(calls[0][0]['end'],12.)
  self.assertAlmostEqual(replacements[2]['words'][0]['start'],8.96,places=2)
  self.assertEqual(replacements[2]['words'][0]['end'],9.5)
  self.assertEqual(audit['status'],'forced_alignment_requires_review')
  self.assertEqual(segments,original)
 def test_missing_model_word_does_not_publish_partial_replacements(self):
  segments=[dict(start=1.,end=2.,text='last'),dict(start=2.,end=2.3,text='hey')]
  with self.assertRaises(ValueError):
   realign_tail(segments,{0:(1,2)},np.zeros(12*16000),lambda plan:{'segments':[]})
