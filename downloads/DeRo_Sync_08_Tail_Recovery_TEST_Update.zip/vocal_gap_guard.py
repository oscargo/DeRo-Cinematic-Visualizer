"""Conservative candidate onset trim for long words containing a vocal gap.

Energy is not word recognition. This guard never extends words or invents
new occurrences; it only proposes trimming a long low-energy gap within an
already aligned word. Proposals still require listening review.
"""
import math
import numpy as np


def trim_gap_start(audio, sample_rate, start, end, threshold_offset_db=0.):
    start, end = float(start), float(end)
    evidence = {'changed': False, 'original_start': start, 'proposed_start': start}
    if not (math.isfinite(start) and math.isfinite(end) and 0 <= start < end):
        raise ValueError('Invalid word interval')
    if end - start < 2.:
        return start, evidence
    hop = max(1, round(sample_rate * .02))
    first = max(0, math.floor(start * sample_rate / hop))
    last = min(len(audio) // hop, math.ceil(end * sample_rate / hop))
    samples = np.asarray(audio[first * hop:last * hop], dtype=np.float64)
    if not samples.size:
        return start, evidence
    rms = np.sqrt(np.mean(samples.reshape(-1, hop) ** 2, axis=1))
    db = 20. * np.log10(np.maximum(rms, 1.e-12))
    low, high = np.percentile(db, [20, 95])
    if high - low < 20.:
        return start, evidence
    threshold = max(low + 12., high - 35.) + threshold_offset_db
    active = db > threshold
    # Ignore tiny activity bursts; then bridge only short within-word gaps.
    def runs(mask):
        change = np.diff(np.r_[False, mask, False].astype(np.int8))
        return zip(np.flatnonzero(change == 1), np.flatnonzero(change == -1))
    for a, b in list(runs(active)):
        if (b - a) * hop / sample_rate < .12:
            active[a:b] = False
    for a, b in list(runs(~active)):
        if a and b < len(active) and (b - a) * hop / sample_rate <= .12:
            active[a:b] = True
    gaps = [(a, b) for a, b in runs(~active)
            if b < len(active) and (b - a) * hop / sample_rate >= .75]
    if not gaps:
        return start, evidence
    a, b = gaps[-1]
    proposed = max(start, (first + b) * hop / sample_rate - .04)
    # Keep room for the existing word, and require a substantial removed gap.
    if proposed - start < .75 or end - proposed < .15:
        return start, evidence
    evidence.update(changed=True, proposed_start=round(proposed, 3),
                    removed_seconds=round(proposed - start, 3),
                    detected_gap_seconds=round((b - a) * hop / sample_rate, 3),
                    threshold_db=round(float(threshold), 2),
                    requires_listening_review=True)
    return float(round(proposed, 3)), evidence
