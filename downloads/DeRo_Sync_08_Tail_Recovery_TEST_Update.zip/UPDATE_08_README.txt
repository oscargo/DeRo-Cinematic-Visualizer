DeRo Sync STABILIZATION-08-TEST update for the existing 07 app.

1. Close DeRo Sync. Make a COPY of your complete working 07 app folder; name the copy DeRo_Sync_08_TEST.
2. Extract this ZIP into that copied folder beside DeRo_Sync_v0210_43_Popper_Direction_Fix.py. Replace matching files; keep all existing files.
3. Run Launch_DeRo_Sync.bat in the copied folder. The window title should say STABILIZATION-08-TEST.

This is an app update, not the isolated Tail Check. No new installations are needed. Keep your manually corrected project unchanged; do not rerun auto-sync on that reference. Test new automatic alignment only in a separate project/copy when needed.

Changes: when the final lyrics lack recognized anchors, align their exact text as one ordered group with the preceding supported line through the actual end of the audio. Reject incomplete, unscored, or mismatched results. Propose onset trimming only for long aligned words containing a long low-energy gap. Recovered lines remain PARTIAL and require listening review. Word ends are not extended. Cached results from the old algorithm are not reused. Existing overwrite confirmations still apply.

123 local regression tests pass. Integration was replayed against supplied real model output and a vocal stem; a fresh end-to-end Windows 08 alignment is not yet accepted. Audio energy cannot establish word identity. This remains TEST, not Stable. No songs, projects, user results, or private reports are included.
