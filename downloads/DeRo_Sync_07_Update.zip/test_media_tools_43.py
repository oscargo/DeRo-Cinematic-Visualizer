"""Discovery finds existing binaries without changing permanent configuration."""
import os,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
from media_tools import discover_media_tools,media_tool_session
class MediaToolsTests(unittest.TestCase):
 def fake_version(self,args,**kwargs):
  name='ffprobe' if 'ffprobe' in str(args[0]) else 'ffmpeg'
  return types.SimpleNamespace(returncode=0,stdout=name+' version test',stderr='')
 def test_app_local_tools_are_found_without_path(self):
  with tempfile.TemporaryDirectory() as tmp:
   folder=Path(tmp)/'tools'/'ffmpeg'/'bin';folder.mkdir(parents=True);suffix='.exe' if os.name=='nt' else ''
   for name in ['ffmpeg','ffprobe']:(folder/(name+suffix)).write_bytes(b'fixture')
   with patch('media_tools.shutil.which',return_value=None),patch('media_tools.subprocess.run',side_effect=self.fake_version),patch('media_tools.importlib.import_module',side_effect=ImportError):
    result=discover_media_tools(tmp)
   self.assertEqual(result['missing'],[]);self.assertTrue(Path(result['found']['ffmpeg']).parent.samefile(folder),'Discovered tool must belong to the app-local folder, allowing Windows short/long path aliases')
 def test_versioned_existing_binary_gets_session_alias_and_path_is_restored(self):
  with tempfile.TemporaryDirectory() as tmp:
   versioned=Path(tmp)/'ffmpeg-versioned.exe';versioned.write_bytes(b'fixture');before=os.environ.get('PATH','')
   with patch('media_tools.shutil.which',return_value=None),patch('media_tools.subprocess.run',side_effect=self.fake_version),patch('media_tools.importlib.import_module',side_effect=ImportError):
    with media_tool_session(tmp,{'ffmpeg':versioned}) as result:
     alias=Path(result['temporary_aliases']['ffmpeg']);self.assertTrue(alias.is_file());self.assertEqual(alias.read_bytes(),b'fixture');self.assertIn(str(alias.parent),os.environ['PATH'])
    self.assertFalse(alias.exists())
   self.assertEqual(os.environ.get('PATH',''),before)
 def test_broken_executable_not_reported_usable(self):
  with tempfile.TemporaryDirectory() as tmp:
   binary=Path(tmp)/('ffmpeg.exe' if os.name=='nt' else 'ffmpeg');binary.write_bytes(b'fixture')
   with patch('media_tools.shutil.which',return_value=None),patch('media_tools.subprocess.run',return_value=types.SimpleNamespace(returncode=1,stdout='',stderr='bad binary')),patch('media_tools.importlib.import_module',side_effect=ImportError):result=discover_media_tools(tmp)
   self.assertIn('ffmpeg',result['missing']);self.assertNotIn('ffmpeg',result['found'])
