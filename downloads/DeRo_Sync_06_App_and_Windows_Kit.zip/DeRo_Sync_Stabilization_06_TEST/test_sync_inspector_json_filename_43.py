import ast
from pathlib import Path
import unittest

SOURCE=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py').read_text(encoding='utf-8-sig')

class SyncInspectorJSONFilenameTests(unittest.TestCase):
 def test_source_parses(self):
  ast.parse(SOURCE)
 def test_song_artist_filename(self):
  self.assertIn("basename=safe_song_filename(artist,song,'Untitled Song')",SOURCE)
  self.assertIn("basename+' - Sync Lyrics.json'",SOURCE)
 def test_reuses_last_export_directory(self):
  self.assertIn("Path(previous).expanduser().parent if previous else Path.home()",SOURCE)
 def test_metadata_fallback(self):
  self.assertIn("self.project.get('artist','')",SOURCE)
  self.assertIn("self.project.get('song','')",SOURCE)
