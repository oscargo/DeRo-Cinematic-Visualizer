# DeRo Sync v0.2.1.43 — Confetti orientation and sparkles TEST

- All four poppers retain the 🎉 emoji centerpiece.
- Right-side emoji is horizontally mirrored to face inward.
- Confetti uses the same geometry as its popper: every particle starts at the popper's mouth rather than at an unrelated location.
- Added subtle twinkling sparkles to the top notification-area widget only.
- Upper notification pair remains visible after animation; lower overlay pair retains existing hide-after-animation behavior.
- Existing export diagnostics changes retained from previous test build.

Validation: Python compilation and 13 focused Python regression tests passed in Linux. Native Windows Segoe UI Emoji rendering, exact visual placement, and GUI behavior still require testing on Windows. The test suite does not validate popper pixel output.

Test: extract to a fresh folder, launch Launch_DeRo_Sync.bat, click Replay Celebration and inspect both pairs. Do not replace the known-good version.
