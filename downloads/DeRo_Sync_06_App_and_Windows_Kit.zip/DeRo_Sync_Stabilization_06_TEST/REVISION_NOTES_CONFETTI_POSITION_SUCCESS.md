# Confetti placement and export-success messaging — test revision

- Lower-right overlay popper retains its existing placement and behavior.
- Lower-left overlay popper is moved upward and inward into the compact area above the song controls. Its emitted particles are clipped to a matching local region.
- Upper notification displays a congratulatory success message only on a verified export or completed batch, not when Replay Celebration is clicked.
- Upper poppers and sparkles remain; lower poppers continue to disappear.
- Code syntax validated. Exact Windows geometry/emoji appearance must be checked in the running app.
