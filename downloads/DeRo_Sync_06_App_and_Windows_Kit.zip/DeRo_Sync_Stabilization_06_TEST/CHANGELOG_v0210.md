# v0.2.1.00 — Integrated Visualizer (first build)
- Replaced the Video Designer navigation label/page with a native Qt Visualizer settings page.
- Added bridge from Sync events/word timings to Visualizer LyricDocument.
- Added Qt settings mapped to the original Visualizer Settings dataclass.
- Routed final MP4 export through the original Visualizer v0.1.45 single-pass exporter.
- Preserved 1080p/60 default, 384 bands, 130 dust particles, and 100%/20% stem defaults.
- Added per-export diagnostics and corrected the integrated diagnostics version label.
- Original baseline archives remain unchanged.
