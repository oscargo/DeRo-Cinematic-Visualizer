# DeRo Sync v0.2.1.12 — Batch Favorite Lyrics Sites

- Added Favorite Lyrics Sites button to Batch > Lyrics header.
- Opens the original, shared Favorite Lyrics Sites dialog, including Search current song, Open website, Copy artist + song again, Add, Edit, Remove, reorder, and Close.
- Searches/copies the currently selected Batch song artist/title, never stale single-song project fields.
- Shares the existing favorites persistence file and list; no duplicate settings or recreated dialog.
- Existing single-song Lyrics button behavior preserved.
- No batch processing/export enabled; no original audio modified or deleted.
