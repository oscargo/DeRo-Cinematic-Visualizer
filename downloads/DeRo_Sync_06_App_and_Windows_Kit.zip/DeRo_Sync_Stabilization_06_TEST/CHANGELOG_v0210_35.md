# v0.2.1.35
Centered the Start Batch Processing and Open Output Folder buttons as one group by adding balanced stretch spacers. No processing or visualizer logic changed.
