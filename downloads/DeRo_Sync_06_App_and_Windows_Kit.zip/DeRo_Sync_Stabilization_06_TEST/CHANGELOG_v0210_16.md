# v0.2.1.16 — Batch foundation (not an exporter)

- Corrected VERSION, application version/build, entrypoint and launcher to 0.2.1.16.
- Added persistent shuffle-bag history for approved backgrounds across sessions.
- Added background_for_song(index), assigning a background once and reusing it on retries.
- Retained original v0.2.1.15 selection/checkmark implementation.
- Start Batch Processing remains intentionally disabled; separation, alignment, and export orchestration are NOT implemented in this release.
- Windows GUI and end-to-end export NOT tested.
