from pathlib import Path
p=Path(__file__).parent
source=(p/'DeRo_Sync_v0210_43_Popper_Direction_Fix.py').read_text(encoding='utf-8')
batch=(p/'batch_workspace.py').read_text(encoding='utf-8')
assert "'06  BATCH','07  EXPORT'" in source
assert 'self.pages.insertWidget(5,self.batch_page)' in source
assert 'self.particles.setChecked(True)' in batch
assert 'self.visualizer.setChecked(False)' in batch
assert 'self.start_batch_button=QPushButton(' in batch
assert 'ws.start_batch_button.setEnabled(False)' in source
assert 'ws.start_batch_button.setEnabled(True)' in source
assert 'self.songs.pop(self.selected)' in batch
assert 'unlink(' not in batch and 'os.remove(' not in batch
print('Batch static safety checks passed')
