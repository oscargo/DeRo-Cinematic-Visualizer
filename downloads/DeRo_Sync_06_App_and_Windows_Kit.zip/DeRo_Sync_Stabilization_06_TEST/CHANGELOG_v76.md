# DeRo Sync v0.2.0.76

- Waveform context menu: Copy selected words, Cut selected words, Paste words here.
- Timeline-focused Ctrl+C / Ctrl+X / Ctrl+V shortcuts.
- Multi-selection retains relative word timing when pasted at a chosen waveform position.
- Paste refuses overlap with existing word blocks and prevents extending past known song duration.
- Cut/paste use existing project snapshots and word-text synchronization for Undo/Redo.
- Close START/END handles are visually staggered, without changing timestamp positions.
- Original v0.2.0.75 launcher filename and tests retained for compatibility; application version updated to v0200_76.

Note: waveform clipboard edits lyric words and their timestamps, not audio samples. Right-click empty waveform space to set paste location.
