"""Windows 1080p60 studio-export benchmark; invokes v43 production command builder.
Run: py -3.12 benchmark_windows_1080p43.py --seconds 30 --runs 3 --warmup 1
No app source files are modified. Results are written to a JSON file.
"""
import argparse, json, shutil, subprocess, tempfile, time, statistics, platform, types, os
from pathlib import Path
from test_studio_export_pipeline_43 import load_export_method, StudioExportPipelineTests

class Encoder:
    def __init__(self, nvenc): self.nvenc=nvenc
    def currentIndex(self): return 1 if self.nvenc else 0

def find_binary(name, explicit=None):
    """Find existing tools without modifying Windows PATH or installing anything."""
    candidates=[]
    if explicit: candidates.append(explicit)
    env=os.environ.get('DERO_'+name.upper())
    if env: candidates.append(env)
    on_path=shutil.which(name)
    if on_path: candidates.append(on_path)
    here=Path(__file__).resolve().parent
    for parent in (here, *list(here.parents)[:4]):
        for folder in (parent, parent/'bin', parent/'ffmpeg'/'bin', parent/'tools'/'ffmpeg'/'bin'):
            candidates.append(str(folder/(name+'.exe' if os.name=='nt' else name)))
    if name=='ffmpeg':
        try:
            import imageio_ffmpeg
            candidates.append(imageio_ffmpeg.get_ffmpeg_exe())
        except (ImportError, RuntimeError, OSError):
            pass
    for candidate in candidates:
        path=shutil.which(candidate) or (str(Path(candidate).expanduser()) if Path(candidate).expanduser().is_file() else None)
        if path:
            try:
                r=subprocess.run([path,'-version'],capture_output=True,timeout=10)
                if r.returncode==0:return path
            except (OSError,subprocess.TimeoutExpired):pass
    return None

def verify_output(ffmpeg, ffprobe, target):
    if ffprobe:
        probe=subprocess.run([ffprobe,'-v','error','-show_entries','stream=codec_type,width,height,avg_frame_rate','-of','json',str(target)],capture_output=True,text=True,check=True,timeout=30)
        streams=json.loads(probe.stdout).get('streams',[])
        return {'valid': {'video','audio'} <= {s.get('codec_type') for s in streams}, 'streams':streams,'method':'ffprobe'}
    # imageio-ffmpeg usually includes FFmpeg but not FFprobe. Decode both
    # streams to ensure the file is usable and both streams exist.
    probe=subprocess.run([ffmpeg,'-hide_banner','-v','error','-i',str(target),'-map','0:v:0','-map','0:a:0','-f','null',os.devnull],capture_output=True,text=True,timeout=120)
    return {'valid':probe.returncode==0,'streams':[],'method':'ffmpeg decode both streams','error':probe.stderr[-1000:] if probe.returncode else ''}

def run(args):
    ffmpeg=find_binary('ffmpeg',args.ffmpeg)
    ffprobe=find_binary('ffprobe',args.ffprobe)
    if not ffmpeg:
        raise RuntimeError('FFmpeg not found. DeRo Sync may use imageio-ffmpeg: run py -3.12 -m pip show imageio-ffmpeg, or supply --ffmpeg "C:\\path\\to\\ffmpeg.exe"')
    print('Using FFmpeg:',ffmpeg,flush=True)
    print('Using FFprobe:',ffprobe or '(not found; will verify with FFmpeg decoding)',flush=True)
    method=load_export_method(); settings=StudioExportPipelineTests().settings
    report={'system':platform.platform(),'scope':'Production studio_export_command synthetic 1080p60 export, not full GUI/actual song export','size':[args.width,args.height],'seconds':args.seconds,'runs':args.runs,'warmup_runs':args.warmup,'results':[],'ffmpeg':ffmpeg,'ffprobe':ffprobe}
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); audio=root/'tone.wav'; ass=root/'lyrics.ass'
        subprocess.run([ffmpeg,'-hide_banner','-loglevel','error','-y','-f','lavfi','-i',f'sine=frequency=440:duration={args.seconds}',str(audio)],check=True,capture_output=True,timeout=60)
        ass.write_text(f'''[Script Info]
ScriptType: v4.00+
PlayResX: {args.width}
PlayResY: {args.height}
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,70,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,0,5,10,10,10,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:00.00,0:00:{args.seconds:05.2f},Default,,0,0,0,,Benchmark lyric
''',encoding='utf-8')
        configs=[('x264',False,False,False),('x264',False,True,False),('nvenc',False,False,True),('nvenc',False,True,True)]
        if args.include_visualizer:
            configs += [('x264',True,False,False),('x264',True,True,False),('nvenc',True,False,True),('nvenc',True,True,True)]
        for codec,visual,particles,nvenc in configs:
            for index in range(-args.warmup, args.runs):
                target=root/f'{codec}_v{int(visual)}_p{int(particles)}_{index}.mp4'
                fake=types.SimpleNamespace(encoder=Encoder(nvenc),project={})
                command=method(fake,ffmpeg,ass,str(audio),str(target),args.width,args.height,args.seconds,settings(visual,particles))
                start=time.perf_counter()
                try:
                    result=subprocess.run(command,capture_output=True,text=True,timeout=args.timeout)
                    elapsed=round(time.perf_counter()-start,3)
                    if result.returncode:
                        row={'codec':codec,'visualizer':visual,'particles':particles,'run':index+1,'warmup':index<0,'status':'failed','seconds':elapsed,'error':result.stderr[-1800:]}
                    else:
                        verification=verify_output(ffmpeg,ffprobe,target)
                        row={'codec':codec,'visualizer':visual,'particles':particles,'run':index+1,'warmup':index<0,'status':'ok' if verification['valid'] else 'invalid','seconds':elapsed,'bytes':target.stat().st_size,'verification':verification}
                except subprocess.TimeoutExpired:
                    row={'codec':codec,'visualizer':visual,'particles':particles,'run':index+1,'warmup':index<0,'status':'timeout','seconds':args.timeout}
                
                if index >= 0: report['results'].append(row)
                print(codec,'visualizer',visual,'particles',particles,'warmup' if index<0 else 'run',index+1,row['status'],row['seconds'],'s',flush=True)
                Path(args.output).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    groups={}
    for r in report['results']:
        if r['status']=='ok': groups.setdefault((r['codec'],r['visualizer'],r['particles']),[]).append(r['seconds'])
    report['medians']=[{'codec':k[0],'visualizer':k[1],'particles':k[2],'median_seconds':statistics.median(v)} for k,v in groups.items()]
    Path(args.output).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print('Results saved:',Path(args.output).resolve())

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--width',type=int,default=1920);p.add_argument('--height',type=int,default=1080)
    p.add_argument('--seconds',type=float,default=30);p.add_argument('--runs',type=int,default=3);p.add_argument('--warmup',type=int,default=1)
    p.add_argument('--ffmpeg',help='Optional full path to existing ffmpeg.exe');p.add_argument('--ffprobe',help='Optional full path to existing ffprobe.exe');p.add_argument('--timeout',type=int,default=180);p.add_argument('--include-visualizer',action='store_true')
    p.add_argument('--output',default='WINDOWS_30S_BENCHMARK.json')
    a=p.parse_args()
    if a.width<16 or a.height<16 or a.seconds<=0 or a.runs<1 or a.warmup<0: p.error('Invalid dimensions, duration or runs')
    run(a)
