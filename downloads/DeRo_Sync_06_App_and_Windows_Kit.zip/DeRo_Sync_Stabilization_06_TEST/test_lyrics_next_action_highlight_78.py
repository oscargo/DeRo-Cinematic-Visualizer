from pathlib import Path
import ast

SOURCE = Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')


def test_lyrics_action_highlight_is_wired_to_text_changes_and_initial_state():
    source = SOURCE.read_text(encoding='utf-8')
    tree = ast.parse(source)
    methods = {
        node.name: node
        for cls in tree.body if isinstance(cls, ast.ClassDef)
        for node in cls.body if isinstance(node, ast.FunctionDef)
    }
    assert 'update_lyrics_action_buttons' in methods
    assert 'self.update_lyrics_action_buttons()' in ast.get_source_segment(source, methods['build_lyrics'])
    assert 'self.update_lyrics_action_buttons()' in ast.get_source_segment(source, methods['on_lyrics_changed'])
    updater = ast.get_source_segment(source, methods['update_lyrics_action_buttons'])
    assert 'bool(self.lyrics.toPlainText().strip())' in updater
    assert 'self.auto_sync_button.setEnabled(has_lyrics)' in updater
    assert 'self.auto_sync_button.setStyleSheet(prominent if has_lyrics else secondary)' in updater
    assert 'self.favorite_sites_button.setStyleSheet(secondary if has_lyrics else prominent)' in updater
