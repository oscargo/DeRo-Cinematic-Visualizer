"""Cancellation must interrupt blocked process reads and serialize publication."""
import sys,tempfile,threading,subprocess,unittest
from pathlib import Path
from standard_export_control import run_controlled_export
from visualizer_engine.export_control import ExportControl,ExportCancelled
from visualizer_engine.media_validation import verify_mp4
from unittest.mock import patch
class StandardCancelTests(unittest.TestCase):
 def test_canceled_before_start_does_not_create_file(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'started';control=ExportControl();control.cancel()
   with self.assertRaises(ExportCancelled):run_controlled_export([sys.executable,'-c',f'open({str(p)!r},"w").close()'],lambda message:None,control)
   self.assertFalse(p.exists());self.assertEqual(control.pids(),[])
 def test_cancel_interrupts_blocked_ffmpeg_style_output_read(self):
  ready=threading.Event();control=ExportControl();errors=[]
  def worker():
   try:run_controlled_export([sys.executable,'-u','-c','import time;print("time=ready",flush=True);time.sleep(30)'],lambda message:ready.set() if 'time=ready' in message else None,control)
   except Exception as exc:errors.append(exc)
  thread=threading.Thread(target=worker);thread.start()
  try:
   self.assertTrue(ready.wait(3),'child did not start');control.cancel();thread.join(3)
   self.assertFalse(thread.is_alive());self.assertEqual(control.pids(),[]);self.assertEqual(len(errors),1);self.assertIsInstance(errors[0],ExportCancelled)
  finally:control.cancel();thread.join(3)
 def test_nonzero_exit_is_failure(self):
  with self.assertRaisesRegex(RuntimeError,'code 7'):run_controlled_export([sys.executable,'-c','raise SystemExit(7)'],lambda message:None,ExportControl())
 def test_cancel_before_publication_never_calls_replace(self):
  control=ExportControl();control.cancel();called=[]
  with self.assertRaises(ExportCancelled):control.commit(lambda:called.append(True))
  self.assertFalse(called)
 def test_late_cancel_cannot_reclassify_published_success(self):
  control=ExportControl();called=[];control.commit(lambda:called.append(True))
  self.assertTrue(called);self.assertFalse(control.cancel());self.assertFalse(control.event.is_set())
 def test_probe_cancel_is_not_reported_as_warning(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'video.mp4';p.write_bytes(b'x'*2048);control=ExportControl()
   def interrupted(*args,**kwargs):control.cancel();control.check()
   with patch('visualizer_engine.media_validation.shutil.which',return_value='ffprobe'),patch.object(control,'run',side_effect=interrupted):
    with self.assertRaises(ExportCancelled):verify_mp4(p,cancel=control)

class CancelStatusTests(unittest.TestCase):
 def test_legacy_status_router_keeps_cancel_visible(self):
  import ast,types
  source=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py');tree=ast.parse(source.read_text());main=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Main');node=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='show_status_at_top')
  class Label:
   def setText(self,value):self.text=value
  class Bar:
   def setRange(self,*args):pass
   def setValue(self,value):self.value=value
  widget=types.SimpleNamespace(activity_started=None,activity_title=Label(),activity_detail=Label(),activity_bar=Bar());ns={};exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns)
  ns['show_status_at_top'](widget,'MP4 export cancelled')
  self.assertEqual(widget.activity_title.text,'CANCELLED — MP4 export');self.assertEqual(widget.activity_bar.value,0)

class PublicationOrderingTests(unittest.TestCase):
 def test_cancel_racing_a_committing_publication_loses_cleanly(self):
  control=ExportControl();entered=threading.Event();release=threading.Event();results=[]
  def operation():entered.set();release.wait(3)
  publisher=threading.Thread(target=lambda:control.commit(operation));publisher.start()
  canceler=threading.Thread(target=lambda:results.append(control.cancel()))
  try:
   self.assertTrue(entered.wait(2));canceler.start();self.assertFalse(control.event.is_set())
  finally:
   release.set();publisher.join(3)
   if canceler.ident is not None:canceler.join(3)
  self.assertFalse(publisher.is_alive());self.assertFalse(canceler.is_alive());self.assertEqual(results,[False]);self.assertTrue(control.committed)

class AuditFailureTests(unittest.TestCase):
 def test_cancel_does_not_validate_a_previous_export(self):
  import ast,types,time,datetime,json
  source=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py');tree=ast.parse(source.read_text());main=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Main');node=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='finish_export_audit')
  ns={'time':time,'datetime':datetime,'json':json,'Path':Path};exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns)
  with tempfile.TemporaryDirectory() as tmp:
   target=Path(tmp)/'previous.mp4';target.write_bytes(b'previous completed file')
   def inspect(path):raise AssertionError('Old video must not be verified as the new attempt')
   widget=types.SimpleNamespace(export_audit_history=[],inspect_export_mp4=inspect);audit={'target':str(target),'requested':{'resolution':'1280x720'}}
   ns['finish_export_audit'](widget,audit,time.monotonic(),error='Export canceled',canceled=True)
   self.assertEqual(audit['status'],'canceled');self.assertTrue(audit['actual']['not_inspected']);self.assertIsNone(audit['verification']['resolution_match'])

class LegacyStudioSettingsTests(unittest.TestCase):
 def test_saved_settings_survive_absent_legacy_widgets(self):
  import ast,types
  source=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py');tree=ast.parse(source.read_text());main=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Main');node=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='persist_video_settings');ns={};exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns)
  saved={'visualizer':False};widget=types.SimpleNamespace(project={'studio_video':saved.copy()});ns['persist_video_settings'](widget)
  self.assertEqual(widget.project['studio_video'],saved)
