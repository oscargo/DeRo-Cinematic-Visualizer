# v0.2.1.18 — Batch duration detection fix

- Batch audio duration now uses Mutagen metadata, SoundFile, ffprobe when available, then bundled FFmpeg output.
- No longer requires ffprobe on PATH for valid audio files.
- Preserves v0.2.1.17 batch processing pipeline and no-overwrite behavior.
- Windows real-song export has not been verified.
