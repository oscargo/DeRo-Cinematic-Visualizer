"""Stream FFmpeg progress while ExportControl owns cancellation and process cleanup."""
from pathlib import Path
import subprocess

def run_controlled_export(command,emit,control):
    control.check()
    emit('Starting: '+Path(str(command[0])).name)
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT,text=True,encoding='utf-8',
                             errors='replace',bufsize=1,creationflags=flags)
    tail=[]
    with control.process(process):
        for line in process.stdout:
            control.check();line=line.strip()
            if line:
                tail.append(line);tail=tail[-20:]
                if 'time=' in line or 'error' in line.lower():emit(line[:180])
        code=process.wait();control.check()
        if code:raise RuntimeError(f'FFmpeg exited with code {code}: '+'\n'.join(tail[-12:]))
    return tail
