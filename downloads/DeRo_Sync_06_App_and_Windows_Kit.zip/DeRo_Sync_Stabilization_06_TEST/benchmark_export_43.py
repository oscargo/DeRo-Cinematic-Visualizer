"""Repeatable short export benchmark; measures production studio_export_command, not full GUI export."""
import argparse, json, shutil, subprocess, tempfile, time, types, statistics
from pathlib import Path
from test_studio_export_pipeline_43 import load_export_method, StudioExportPipelineTests, Encoder

def main():
 p=argparse.ArgumentParser(); p.add_argument('--runs',type=int,default=3); p.add_argument('--width',type=int,default=640); p.add_argument('--height',type=int,default=360); p.add_argument('--seconds',type=float,default=1.0); p.add_argument('--output',default='EXPORT_BENCHMARK_RESULTS.json'); a=p.parse_args()
 if a.runs<1 or a.seconds<=0: p.error('runs and seconds must be positive')
 ffmpeg=shutil.which('ffmpeg'); ffprobe=shutil.which('ffprobe')
 if not ffmpeg or not ffprobe: p.error('ffmpeg and ffprobe required')
 method=load_export_method(); tests=StudioExportPipelineTests(); rows=[]
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp); audio=root/'audio.wav'; ass=root/'lyrics.ass'
  subprocess.run([ffmpeg,'-hide_banner','-loglevel','error','-y','-f','lavfi','-i',f'sine=frequency=440:duration={a.seconds}',str(audio)],check=True,capture_output=True,timeout=60)
  ass.write_text('[Script Info]\nScriptType: v4.00+\nPlayResX: 640\nPlayResY: 360\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Default,Arial,32,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,10,10,10,1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:00.00,0:00:00.90,Default,,0,0,0,,Benchmark lyric\n',encoding='utf-8')
  for visual,particles in [(False,False),(False,True)]:
   for run in range(a.runs):
    output=root/f'v{int(visual)}p{int(particles)}_{run}.mp4'
    fake=types.SimpleNamespace(encoder=Encoder(),project={})
    cmd=method(fake,ffmpeg,ass,str(audio),str(output),a.width,a.height,a.seconds,tests.settings(visual,particles))
    start=time.perf_counter(); completed=subprocess.run(cmd,capture_output=True,text=True,timeout=120); elapsed=time.perf_counter()-start
    if completed.returncode: raise RuntimeError(f'FFmpeg failed rc={completed.returncode} for {visual=} {particles=}: {completed.stderr[-2000:]} CMD={cmd}')
    probe=subprocess.run([ffprobe,'-v','error','-show_entries','stream=codec_type','-of','csv=p=0',str(output)],capture_output=True,text=True,check=True,timeout=15)
    if not {'video','audio'}.issubset(set(probe.stdout.split())): raise RuntimeError(f'Missing stream: {probe.stdout}')
    rows.append(dict(visualizer=visual,particles=particles,run=run+1,elapsed_seconds=round(elapsed,4),bytes=output.stat().st_size))
 result={'scope':'Production studio_export_command, short synthetic audio/ASS, software encoder selected by app; not full GUI/NVENC benchmark','dimensions':f'{a.width}x{a.height}','duration_seconds':a.seconds,'runs_per_configuration':a.runs,'ffmpeg':subprocess.run([ffmpeg,'-version'],capture_output=True,text=True).stdout.splitlines()[0],'measurements':rows,'summary':[dict(visualizer=v,particles=p,median_seconds=round(statistics.median(x['elapsed_seconds'] for x in rows if x['visualizer']==v and x['particles']==p),4)) for v,p in [(False,False),(False,True)]]}
 Path(a.output).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8'); print(json.dumps(result['summary'],indent=2))
if __name__=='__main__': main()
