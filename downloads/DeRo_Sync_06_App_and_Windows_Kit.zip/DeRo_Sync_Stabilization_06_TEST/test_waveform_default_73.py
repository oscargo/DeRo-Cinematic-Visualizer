"""Guard against default waveform regressing to Classic."""
from pathlib import Path
import unittest
S=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py').read_text(encoding='utf-8')
class WaveformDefaultTests(unittest.TestCase):
 def test_blue_renderer_default(self):
  self.assertIn("self.wave_style='high_detail';self.song_duration",S)
 def test_selector_defaults_to_blue_before_callback(self):
  a=S.index("self.wave_style_select.addItems(['Classic (original)','High Detail (blue PCM)'])")
  b=S.index('self.wave_style_select.setCurrentIndex(1)',a)
  c=S.index('self.wave_style_select.currentIndexChanged.connect',a)
  self.assertLess(a,b);self.assertLess(b,c)
 def test_classic_still_selectable(self):
  self.assertIn("'high_detail' if index==1 else 'classic'",S)
