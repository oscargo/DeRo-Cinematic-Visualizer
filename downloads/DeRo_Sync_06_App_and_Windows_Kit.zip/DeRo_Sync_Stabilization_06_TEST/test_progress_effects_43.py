"""Real Qt checks: appearance must not change authoritative task progress."""
import importlib.util,sys,unittest
from pathlib import Path
from unittest.mock import patch
try:
 from PySide6.QtWidgets import QApplication
 HAVE_QT=True
except ImportError:HAVE_QT=False

@unittest.skipUnless(HAVE_QT,'PySide6 required for appearance behavior checks')
class ProgressEffectsTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.qt=QApplication.instance() or QApplication([])
  path=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')
  spec=importlib.util.spec_from_file_location('progress_effects_test_app',path);cls.m=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.m)
 def setUp(self):
  self.bar=self.m.ThemedProgressBar();self.bar.setRange(0,100);self.bar.setValue(0)
 def tearDown(self):self.bar._effect_timer.stop();self.bar.close()
 def theme(self,**changes):
  data=self.m.progress_theme_defaults();data.update(changes);self.bar.apply_theme(data)
 def test_default_is_instant_and_never_fades(self):
  self.bar.setValue(100);self.assertEqual(self.bar.value(),100);self.assertEqual(self.bar.display_value,100);self.assertEqual(self.bar.fade,1);self.assertFalse(self.bar._effect_timer.isActive())
 def test_animation_keeps_real_progress_exact(self):
  self.theme(animation_steps=60)
  with patch.object(self.m.time,'monotonic',return_value=10.):self.bar.setValue(100)
  self.assertEqual(self.bar.value(),100);self.assertEqual(self.bar.display_value,0)
  with patch.object(self.m.time,'monotonic',return_value=10.5):self.bar._tick_effects()
  self.assertAlmostEqual(self.bar.display_value,50);self.assertEqual(self.bar.value(),100)
 def test_fade_occurs_only_after_completion(self):
  self.theme(fade_out=1000)
  self.bar.setValue(50);self.assertIsNone(self.bar._fade_started)
  with patch.object(self.m.time,'monotonic',return_value=10.):self.bar.setValue(100)
  with patch.object(self.m.time,'monotonic',return_value=10.5):self.bar._tick_effects()
  self.assertAlmostEqual(self.bar.fade,.5);self.assertEqual(self.bar.value(),100)
  with patch.object(self.m.time,'monotonic',return_value=11.):self.bar._tick_effects()
  self.assertEqual(self.bar.fade,0);self.assertFalse(self.bar._effect_timer.isActive())
 def test_new_busy_task_restores_visibility(self):
  self.theme(fade_out=1000)
  with patch.object(self.m.time,'monotonic',return_value=10.):self.bar.setValue(100)
  with patch.object(self.m.time,'monotonic',return_value=12.):self.bar._tick_effects()
  self.bar.setRange(0,0);self.assertEqual(self.bar.fade,1);self.assertIsNone(self.bar._fade_started);self.assertFalse(self.bar._effect_timer.isActive())
 def test_positive_and_negative_offsets_do_not_clip_bar(self):
  self.bar.resize(300,18);self.theme(position=20);self.assertEqual(self.bar.progress_rect().height(),18);self.assertEqual(self.bar.progress_rect().top(),40)
  self.theme(position=-20);self.assertEqual(self.bar.progress_rect().height(),18);self.assertEqual(self.bar.progress_rect().top(),0)
 def test_glow_can_be_enabled_and_removed(self):
  self.theme(glow=24);self.assertEqual(self.bar.graphicsEffect().blurRadius(),24)
  self.theme(glow=0);self.assertIsNone(self.bar.graphicsEffect())
 def test_retheme_cancels_old_animation(self):
  self.theme(animation_steps=60);self.bar.setValue(75);self.theme(animation_steps=1)
  self.assertEqual(self.bar.display_value,75);self.assertIsNone(self.bar._motion);self.assertFalse(self.bar._effect_timer.isActive())
 def test_fade_waits_for_fill_animation(self):
  self.theme(animation_steps=60,fade_out=1000)
  with patch.object(self.m.time,'monotonic',return_value=10.):self.bar.setValue(100)
  self.assertIsNone(self.bar._fade_started)
  with patch.object(self.m.time,'monotonic',return_value=11.):self.bar._tick_effects()
  self.assertEqual(self.bar.fade,1);self.assertEqual(self.bar._fade_started,11.)
