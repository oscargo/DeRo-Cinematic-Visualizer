# DeRo Sync v0.2.1.05
- Remember the last successfully selected background folder across application restarts using existing QSettings.
- Share this remembered folder between Visualizer and Video background file pickers.
- Preserve selected project backgrounds and existing export behavior.
