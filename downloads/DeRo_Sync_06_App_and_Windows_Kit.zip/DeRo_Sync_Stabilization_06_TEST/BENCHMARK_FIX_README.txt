Benchmark fix: locate existing FFmpeg via PATH, nearby folders, or imageio_ffmpeg (same fallback as DeRo Sync). FFprobe optional: when missing, decode both streams with FFmpeg. No app source changes.
Run: py -3.12 benchmark_windows_1080p43.py --seconds 5 --runs 2
