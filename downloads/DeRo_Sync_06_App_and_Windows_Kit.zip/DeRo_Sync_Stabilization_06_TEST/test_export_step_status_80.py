from pathlib import Path

SOURCE = Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')
TEXT = SOURCE.read_text(encoding="utf-8")

def test_export_completion_targets_export_step_not_video_designer():
    assert "if 4 in self.step_snapshots and states[6]=='idle':states[6]='done'" in TEXT
    assert "states[4]=='idle'" not in TEXT

def test_export_snapshot_mismatch_still_warns():
    assert "elif step==4:states[6]='warn'" in TEXT

def test_failed_or_cancelled_export_not_marked_done_by_completion_snapshot():
    # The done state is applied only when the step is still idle; warning/failure
    # states are therefore not overwritten by the completion fallback.
    assert "and states[6]=='idle'" in TEXT
