from pathlib import Path
"""Static regression checks for approved v0.2.0.72 toolbar configuration."""
import ast
import pathlib
import unittest
ROOT=pathlib.Path(__file__).parent
SOURCE=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py').read_text(encoding='utf-8')
class ToolbarTests(unittest.TestCase):
 def test_order(self):
  a=SOURCE.index("compact('Fit Song',self.fit_song)")
  b=SOURCE.index("compact('Fit Line',self.fit_line)")
  c=SOURCE.index("compact('Fit Word',self.fit_word)")
  d=SOURCE.index("self.focus_button=compact('Full Screen',self.toggle_focus_mode)")
  self.assertTrue(a<b<c<d)
  play=SOURCE.index("self.waveform_play_button=compact('▶ Play / Pause'")
  line=SOURCE.index("self.waveform_play_line_button=compact('▶ Play Line'")
  word=SOURCE.index("compact('▶ Play Word',self.play_selected_word,bottom)")
  nextline=SOURCE.index("compact('▶ Play Next Line',self.play_next_line,bottom)")
  self.assertTrue(play<line<word<nextline)
  self.assertNotIn("compact('▶ Play Next Line',self.play_next_line,top)",SOURCE)
 def test_colors(self):
  for color in ('#414535','#A39A62','#F2E5AD'):
   self.assertIn(color,SOURCE)
 def test_parses(self): ast.parse(SOURCE)
if __name__=='__main__':unittest.main()
