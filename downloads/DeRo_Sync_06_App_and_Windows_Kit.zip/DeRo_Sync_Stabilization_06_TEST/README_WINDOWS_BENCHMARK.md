# DeRo Sync v0.2.1.43 — Windows 1080p60 benchmark

This is a development/benchmark package, not an application upgrade. No production source changes.

## On the Windows RTX 4080 laptop

1. Extract the ZIP to a local folder.
2. Open a terminal in the extracted folder (the folder containing `benchmark_windows_1080p43.py`).
3. Ensure `ffmpeg` and `ffprobe` work in the terminal and Python 3.12 is installed.
4. Run: `py -3.12 benchmark_windows_1080p43.py --seconds 5 --runs 2`
5. Optional visualizer stress test: `py -3.12 benchmark_windows_1080p43.py --seconds 5 --runs 2 --include-visualizer`
6. Results are written to `WINDOWS_1080P60_BENCHMARK.json` in that folder. Share that one JSON file for interpretation.

This runs short synthetic exports using the real v43 `studio_export_command` code. It compares x264 and h264_nvenc with particles off/on, and optionally visualizer on. It checks audio/video stream presence. Each job is limited to 180 seconds by default. It does not replace testing real-song GUI exports, nor measure the integrated separate visualizer renderer.

## Environment verification performed here

- Python compile of new benchmark: PASS.
- 63/63 bundled regression tests: PASS (4.030 seconds).
- Low-resolution x264 smoke tests with particles off/on: PASS.
- NVENC low-resolution tests: FAILED in this environment; no NVIDIA GPU available. These are **not** Windows GPU results.
- Windows 1080p60 NVENC benchmark: NOT RUN; requires user's RTX 4080 laptop.

Original v0.2.1.43 remains the rollback baseline. No changes were made to application code.
