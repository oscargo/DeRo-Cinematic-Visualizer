# DeRo Sync v0.2.1.04
- Validate Background Studio handoff schema version 1 and PNG path before import.
- Check Python 3.12 and required startup dependencies in launcher, with no automatic installs.
- Provide standalone regression runner that discovers both unittest cases and plain test functions without pytest.
- Preserve renderer, lyrics, audio export, and original Visualizer effects.
