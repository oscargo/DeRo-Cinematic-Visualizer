"""Shared non-destructive FFprobe validation for app and standalone engine."""
import json,math,os,shutil,subprocess
from pathlib import Path

def verify_mp4(path,ffmpeg=None,expected_duration=None,expected_resolution=(1920,1080),expected_fps=60,cancel=None):
 """Non-destructive container/stream audit; no claims about visual or lyric correctness."""
 path=Path(path);result={'result':'PASS','issues':[],'file':str(path),'bytes':0,'streams':[]}
 if not path.is_file():return {**result,'result':'FAIL','issues':['MP4 missing']}
 result['bytes']=path.stat().st_size
 if result['bytes']<1024:return {**result,'result':'FAIL','issues':['MP4 is too small']}
 probe=shutil.which('ffprobe')
 if not probe and ffmpeg:
  possible=Path(str(ffmpeg)).with_name('ffprobe.exe' if os.name=='nt' else 'ffprobe')
  if possible.is_file():probe=str(possible)
 if not probe:return {**result,'result':'WARNING','issues':['ffprobe unavailable: stream validation not performed']}
 try:
  command=[probe,'-v','error','-show_entries','format=duration:stream=codec_type,codec_name,width,height,r_frame_rate','-of','json',str(path)]
  proc=(cancel.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=20) if cancel is not None else subprocess.run(command,capture_output=True,text=True,timeout=20))
  if proc.returncode:raise ValueError(proc.stderr.strip()[:300] or 'ffprobe failed')
  data=json.loads(proc.stdout);streams=data.get('streams',[])
  result['streams']=streams
  videos=[x for x in streams if x.get('codec_type')=='video'];audios=[x for x in streams if x.get('codec_type')=='audio']
  if not videos:result['issues'].append('Missing video stream')
  if not audios:result['issues'].append('Missing audio stream')
  if videos:
   v=videos[0]
   result['resolution']=[v.get('width'),v.get('height')]
   result['frame_rate']=v.get('r_frame_rate')
   if expected_resolution is not None and (v.get('width'),v.get('height'))!=tuple(expected_resolution):result['issues'].append('Resolution differs from expected '+str(tuple(expected_resolution)))
   try:
    a,b=map(float,v.get('r_frame_rate','0/1').split('/'))
    if not math.isfinite(a) or not math.isfinite(b) or b==0 or (expected_fps is not None and abs(a/b-float(expected_fps))>0.01):result['issues'].append('Frame rate differs from expected '+str(expected_fps)+' fps')
   except (ValueError,ZeroDivisionError):result['issues'].append('Frame rate could not be determined')
  duration=float(data.get('format',{}).get('duration',0))
  result['duration_seconds']=round(duration,3)
  if not math.isfinite(duration) or duration<=0:result['issues'].append('Invalid MP4 duration')
  if expected_duration is not None and abs(duration-float(expected_duration))>max(.10,2/float(expected_fps or 60)):
   result['issues'].append('MP4 duration differs from source audio by more than tolerance')
  if not videos or not audios or not math.isfinite(duration) or duration<=0:result['result']='FAIL'
  elif result['issues']:result['result']='FAIL'
 except Exception as exc:
  if cancel is not None:cancel.check()
  result['result']='WARNING';result['issues'].append('ffprobe check unavailable: '+str(exc)[:250])
 return result


def require_verified_mp4(path,ffmpeg=None,expected_duration=None,expected_resolution=(1920,1080),expected_fps=60,cancel=None):
 """Refuse a verified-success claim unless the requested streams were probed."""
 result=verify_mp4(path,ffmpeg,expected_duration,expected_resolution,expected_fps,cancel=cancel)
 if result['result']!='PASS':
  raise RuntimeError('MP4 verification failed: '+'; '.join(result['issues'])+'. Install ffprobe alongside FFmpeg if unavailable.')
 return result
