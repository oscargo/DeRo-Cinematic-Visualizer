"""One cinematic renderer plus the same libass overlay for previews and export."""
from contextlib import contextmanager
from dataclasses import replace
from io import BytesIO
import os
from pathlib import Path
import subprocess
import tempfile
from PIL import Image
from export_control import ExportControl
from lyric_model import LyricDocument
from lyric_ass import ass_file

class IdentityRenderer:
    """Keep the background playing and dissolve title/artist before lyrics enter.

    The same wrapper is used for the live layout, exact-frame previews, and MP4
    export, so the identity fade cannot diverge between those render paths.
    """
    TITLE_FADE_SECONDS = 0.6

    def __init__(self, renderer, document):
        self.renderer = renderer
        self.document = document

    def _background_frame(self, seconds):
        renderer = self.renderer
        settings = renderer.s
        try:
            renderer.s = replace(settings, title='', artist='')
            return renderer.render(seconds)
        finally:
            renderer.s = settings

    def render(self, seconds):
        doc = self.document
        renderer = self.renderer
        if doc.style['show_identity'] or not doc.style['enabled'] or not doc.events:
            return renderer.render(seconds)
        # The shorter of the user-defined intro and the first lyric's onset.
        # Fade the identity *before* that boundary rather than cutting at it.
        cutoff = max(0., min(float(doc.events[0][0]), float(doc.style['identity_intro_seconds'])))
        fade = min(self.TITLE_FADE_SECONDS, cutoff)
        if seconds >= cutoff:
            return self._background_frame(seconds)
        if fade <= 0 or seconds <= cutoff - fade:
            return renderer.render(seconds)
        opacity = max(0., min(1., (cutoff - seconds) / fade))
        # Both images are drawn for the same song time; only title/artist differ.
        # Keeping spectrum/particles/background untouched avoids a scene cut.
        background = self._background_frame(seconds)
        identity = renderer.render(seconds)
        return Image.blend(background.convert('RGB'), identity.convert('RGB'), opacity)

@contextmanager
def lyric_overlay(document,settings,ffmpeg='ffmpeg',control=None):
    doc=LyricDocument(document)
    if not doc.style['enabled'] or not doc.events:
        yield None;return
    control=control or ExportControl()
    result=control.run([ffmpeg,'-hide_banner','-filters'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
    if result.returncode or not any(line.split()[1:2]==[b'ass'] for line in result.stdout.splitlines()):
        raise RuntimeError('This FFmpeg build needs the libass ASS filter to render lyrics. Install a full FFmpeg build.')
    with tempfile.TemporaryDirectory(prefix='dero-lyrics-') as folder:
        ass_file(doc.ass_project(),Path(folder)/'lyrics.ass',settings.width,settings.height)
        yield folder

def ass_filter(seconds):
    # Raw cinematic frames start at zero; lyric timestamps use absolute song time.
    return f'setpts=PTS+{float(seconds):.6f}/TB,ass=lyrics.ass,setpts=PTS-STARTPTS'

def exact_frame(renderer,seconds,document,ffmpeg='ffmpeg',control=None):
    control=control or ExportControl();doc=LyricDocument(document)
    frame=IdentityRenderer(renderer,doc).render(seconds).convert('RGB')
    with lyric_overlay(doc.snapshot(),renderer.s,ffmpeg,control) as folder:
        if folder is None:return frame
        result=control.run([ffmpeg,'-hide_banner','-loglevel','error','-filter_threads','1',
            '-f','rawvideo','-pix_fmt','rgb24','-s',f'{frame.width}x{frame.height}','-r',str(renderer.s.fps),
            '-i','pipe:0','-vf',ass_filter(seconds),'-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1'],
            input=frame.tobytes(),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=folder,timeout=60)
        if result.returncode:raise RuntimeError(result.stderr.decode('utf-8','replace')[-2000:])
        return Image.open(BytesIO(result.stdout)).convert('RGB')
