## v0.2.1.03
- Updated regression test source paths to the current entrypoint.
- Added explicit Use Background Studio button in Visualizer. Validates PNG and preserves existing selection until clicked.
- Kept legacy Video Designer and Visualizer rendering behavior unchanged.
