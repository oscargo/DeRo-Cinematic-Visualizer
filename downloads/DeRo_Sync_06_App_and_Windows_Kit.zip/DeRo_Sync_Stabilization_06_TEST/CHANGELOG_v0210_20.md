# v0.2.1.20 — Batch Start Button State

- Start Batch Processing is green and prominent while available.
- When clicked and processing begins, the existing batch controller disables the button; it becomes visibly muted gray.
- On batch completion, the existing controller re-enables the button and green styling returns.
- No changes to processing pipeline or file deletion behavior.
- Windows GUI rendering and actual export remain unverified.
