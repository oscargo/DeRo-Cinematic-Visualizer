"""Discover unittest cases and plain pytest-style test functions without pytest."""
import importlib.util
from pathlib import Path
import sys
import unittest

def main():
    root = Path(__file__).resolve().parent
    suite = unittest.TestSuite()
    loader = unittest.TestLoader()
    count = 0
    for path in sorted(root.glob('test_*.py')):
        spec = importlib.util.spec_from_file_location(path.stem, path)
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)
        except Exception as exc:
            import traceback
            failure = traceback.format_exc()
            def make_failure(filename, details):
                class ImportFailure(unittest.TestCase):
                    def runTest(self):
                        self.fail(f'{filename} could not load:\n{details}')
                return ImportFailure()
            suite.addTest(make_failure(path.name, failure))
            count += 1
            continue
        tests = loader.loadTestsFromModule(module)
        suite.addTests(tests)
        count += tests.countTestCases()
        for name in sorted(vars(module)):
            obj = getattr(module, name)
            if name.startswith('test_') and callable(obj) and getattr(obj, '__module__', None) == module.__name__:
                suite.addTest(unittest.FunctionTestCase(obj, description=f'{path.name}::{name}'))
                count += 1
    if not count:
        print('ERROR: No regression tests discovered.', file=sys.stderr)
        return 1
    print(f'Discovered {count} regression tests', flush=True)
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    return 0 if result.wasSuccessful() else 1

if __name__ == '__main__':
    sys.exit(main())
