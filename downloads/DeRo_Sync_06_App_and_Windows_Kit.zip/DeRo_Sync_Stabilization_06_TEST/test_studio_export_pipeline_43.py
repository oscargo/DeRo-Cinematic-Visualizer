"""Exercise the actual studio_export_command method with FFmpeg, without a Qt window."""
import ast
from pathlib import Path
import shutil
import subprocess
import tempfile
import types
import unittest

SOURCE = Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')

def load_export_method():
    tree = ast.parse(SOURCE.read_text(encoding='utf-8-sig'))
    main = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Main')
    method = next(n for n in main.body if isinstance(n, ast.FunctionDef) and n.name == 'studio_export_command')
    module = ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[]))
    ns = {'Path': Path}
    exec(compile(module, str(SOURCE), 'exec'), ns)
    return ns['studio_export_command']

class Encoder:
    def currentIndex(self): return 0

class StudioExportPipelineTests(unittest.TestCase):
    def settings(self, visual=False, particles=False):
        return dict(visualizer=visual, particles=particles, background='', background_color='#081329', bars=32,
                    spectrum_height=100, spectrum_color='#0088ff', particle_count=2, particle_color='#ffffff',
                    title_enabled=False, title_seconds=0, outro_enabled=False, outro_seconds=0)

    def command(self, ass, audio, target, settings):
        fake = types.SimpleNamespace(encoder=Encoder(), project={})
        return load_export_method()(fake, 'ffmpeg', ass, str(audio), str(target), 320, 180, 0.4, settings)

    def test_visualizer_and_particles_are_independent(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); ass=root/'test.ass'; ass.write_text('', encoding='utf-8')
            for visual, particles in [(False,False),(True,False),(False,True),(True,True)]:
                with self.subTest(visual=visual, particles=particles):
                    cmd=self.command(ass,root/'audio.wav',root/'out.mp4',self.settings(visual,particles))
                    graph=cmd[cmd.index('-filter_complex')+1]
                    self.assertEqual('showfreqs=' in graph, visual)
                    self.assertEqual('overlay=x=' in graph, particles)
                    self.assertIn('ass=filename=', graph)

    def test_actual_studio_export_with_lyrics_and_audio(self):
        ffmpeg=shutil.which('ffmpeg'); ffprobe=shutil.which('ffprobe')
        if not ffmpeg or not ffprobe: self.skipTest('FFmpeg and FFprobe unavailable')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); audio=root/'audio.wav'; ass=root/'lyrics.ass'; output=root/'out.mp4'
            subprocess.run([ffmpeg,'-hide_banner','-loglevel','error','-y','-f','lavfi','-i','sine=frequency=440:duration=0.5',str(audio)],check=True,capture_output=True,timeout=20)
            ass.write_text('[Script Info]\nScriptType: v4.00+\nPlayResX: 320\nPlayResY: 180\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Default,Arial,28,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,10,10,10,1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:00.00,0:00:00.40,Default,,0,0,0,,Test lyric\n',encoding='utf-8')
            cmd=self.command(ass,audio,output,self.settings())
            cmd[0]=ffmpeg
            subprocess.run(cmd,check=True,capture_output=True,timeout=35)
            self.assertGreater(output.stat().st_size,1000)
            probe=subprocess.run([ffprobe,'-v','error','-show_entries','stream=codec_type','-of','csv=p=0',str(output)],capture_output=True,text=True,check=True,timeout=10)
            self.assertIn('video',probe.stdout)
            self.assertIn('audio',probe.stdout)
