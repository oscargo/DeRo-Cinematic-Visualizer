# v0.2.1.19 — Batch navigation top

- Move Setup Select Output Folder and Next: Lyrics controls to the top of Batch Settings.
- Move Lyrics Status Next: Processing and Back: Setup controls directly below lyrics count, above the progress bar.
- Make both Next buttons green with hover and pressed states.
- Keep existing batch engine, visualizer/particle toggles, and file-safety behavior unchanged.
- Source compilation only; Windows GUI not tested.
