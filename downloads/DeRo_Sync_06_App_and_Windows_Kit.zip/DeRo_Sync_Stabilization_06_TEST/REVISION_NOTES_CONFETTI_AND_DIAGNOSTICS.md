# DeRo Sync v0.2.1.43 — Celebration / Diagnostics Test Revision

This is a development build based on the Windows 30s Benchmark package, not a verified Windows release.

- Both celebration instances use the Windows Segoe UI Emoji party-popper glyph (🎉) in place of the previous simple Qt polygon cone.
- Small notification-area pair persists after its existing burst animation ends; large overlay pair still hides at the original time.
- Original particle burst timing, paths, counts, fades, and triggering are preserved.
- Standard MP4 `.export-diagnostics.json` now also includes total elapsed time and the `.export-audit.json` path. The detailed `.export-audit.json` already existed and is retained.
- The standard MP4 export and the visualizer/studio export are separate paths. This patch does not add timing instrumentation to the visualizer/studio pipeline.

## Verification

- Python syntax compilation: passed.
- Existing `run_regression_tests.py`: 63/63 passed on Linux in this workspace.
- Windows emoji color rendering, widget sizing, and real UI behavior: **not yet verified**. Segoe UI Emoji behavior depends on Qt and Windows font rendering. Test via the existing replay celebration button.
- Real-song export and performance timing: **not rerun**.

## Manual Windows checks

1. Launch app and use replay celebration test.
2. Verify two party-popper glyphs remain in READY / Saved notification area after 9 seconds.
3. Verify the two larger party-popper glyphs disappear after 9 seconds.
4. Confirm all four look like 🎉 on your Windows display; if not, replace glyphs with an explicit bundled image asset rather than altering timing.
5. Run a standard MP4 export and check `.export-diagnostics.json` and `.export-audit.json` beside output.
