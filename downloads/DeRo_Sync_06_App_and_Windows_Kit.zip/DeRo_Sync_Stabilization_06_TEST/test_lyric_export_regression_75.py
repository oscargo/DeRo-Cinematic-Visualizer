import ast, pathlib, tempfile, unittest
p=pathlib.Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')
module=ast.parse(p.read_text(encoding='utf-8'))
fn=next(x for x in module.body if isinstance(x,ast.FunctionDef) and x.name=='shift_ass_dialogues')
namespace={'Path':pathlib.Path}
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(p),'exec'),namespace)
class Regression(unittest.TestCase):
 def test_clip_clock(self):
  with tempfile.TemporaryDirectory() as d:
   src=pathlib.Path(d)/'a.ass';dst=pathlib.Path(d)/'b.ass'
   src.write_text('[Events]\nDialogue: 0,0:01:29.00,0:01:33.00,Active,,0,0,0,,first\nDialogue: 0,0:01:40.00,0:01:42.00,Active,,0,0,0,,second\n')
   namespace['shift_ass_dialogues'](src,dst,90,12)
   result=dst.read_text(encoding='utf-8-sig');self.assertIn('0:00:00.00,0:00:03.00',result);self.assertIn('0:00:10.00',result);self.assertIn('second',result)
 def test_full_song_uses_original_ass(self):
  source=p.read_text(encoding='utf-8');self.assertIn('vf=f"ass=filename=',source);self.assertNotIn('setpts=PTS+{clip_start:.3f}/TB,ass=',source)
if __name__=='__main__':unittest.main()
