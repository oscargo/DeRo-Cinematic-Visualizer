# DeRo Sync v0.2.1.40 — Export Audit + Celebration Visibility

- Visualizer standalone MP4 export now calls the same finished export audit writer as the classic MP4 export, generating an adjacent `.export-audit.json` file.
- Last completed standalone export path is persisted in QSettings so a diagnostics report from a fresh app session can find its export audit.
- Diagnostics `export_history` falls back to the persisted latest audit when current-session history is empty.
- Original two-popper confetti is unchanged in appearance, but has a taller 86px display and remains active ~6 seconds for better visibility. Existing four-note WAV retained.
- Existing batch/section completion rules remain unchanged; no new celebration on test-section exports.
- No automatic sync algorithm changes. The 53 estimated lines in Mrs. Officer still require separate investigation.
- Windows launcher stored as UTF-8 without BOM to avoid `∩╗┐@echo` command error.
- Source syntax checked; Windows PySide6 rendering and audio playback not tested here.
