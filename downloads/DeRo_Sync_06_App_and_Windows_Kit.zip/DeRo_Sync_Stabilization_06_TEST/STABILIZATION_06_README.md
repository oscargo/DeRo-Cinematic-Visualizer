# DeRo Sync stabilization 06 — TEST candidate

Public version remains v0.2.1.43; APP_BUILD identifies STABILIZATION-06-TEST. Not certified Stable. See the accompanying Validation_Report.md and Outstanding_Issues.md.

Launch with the existing Windows Python 3.12 launcher. Dependencies: PySide6 and requirements-visualizer.txt. Verified export success additionally requires ffprobe (from the FFmpeg distribution) on PATH or beside FFmpeg. Existing audio/stem/project files remain external to this package.

71 original + 38 new behavioral regression tests pass on Linux/Python 3.12. Offscreen UI checks used Qt 6.8.3. Windows audio/GPU behavior remains unverified. Source_Changes.patch and the untouched baseline allow review/reversal of every substantive change.

Candidate 04 completes glow, signed vertical position, paint-only fill animation, and completion fade for progress bars, with JSON persistence and live replay. Standard MP4 export now verifies a temporary file on the destination filesystem before replacing the target. Standard export now supports Stop and cancel-on-close with process/probe cancellation and serialized atomic publication.

Historical Stage 1 documents are retained for provenance; this README and the current validation report supersede their feature-status claims. Original approved style identities remain unrecovered.

Candidate 05 adds cancellable standard export and hardens Studio cancellation/publication ordering. A failed/canceled audit does not treat an older destination as output from the new attempt. Standard and plain Studio success/cancel/failure/repeat/close checks passed through actual Qt workers. The separate enhanced Studio FFT spectrum + particles graph memory failure observed in candidate 05 is fixed and retested in candidate 06. The normal original-DeRo-Visualizer short exports passed.

Candidate 06 resolves the enhanced spectrum branch memory failure by trimming the spectrum immediately after fps conversion. All 30 decoded frames in a .5-second before/after comparison match exactly. The previously failing 720p spectrum + 10-particle Qt job passes. The adaptive waveform QThread timestamp field no longer shadows start(). Full-song saved-timing exports passed at 640x360/30; a synthetic mixed batch passed with 2 exports and 1 intentional missing-input failure. This does not certify fresh ASR alignment or Windows/GPU/audio behavior.
