# v0.2.1.21 — Per-process ETA

- Shows elapsed time and ETA on the existing global processing activity panel for separation, WhisperX alignment, and Visualizer export, including batch stages.
- Uses reported Demucs percent or measured Visualizer frames for progress-based estimates; otherwise uses the last successful run duration saved in QSettings.
- Displays “estimating” when there is no trustworthy estimate. All ETAs are approximate and can change with audio length, hardware load, and processing stage.
- No changes to audio separation, lyric alignment, particle rendering, or export output.
- Static checks only; Windows GUI and actual media execution not verified.
