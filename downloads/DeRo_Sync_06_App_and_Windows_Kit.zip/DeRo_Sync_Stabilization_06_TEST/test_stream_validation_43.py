"""Real-container validation must use requested settings and reject mismatches."""
import unittest,tempfile,subprocess,shutil
from pathlib import Path
from unittest.mock import patch
from export_audit import verify_mp4,require_verified_mp4
class StreamValidationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):raise unittest.SkipTest('FFmpeg and ffprobe required')
  cls.tmp=tempfile.TemporaryDirectory();cls.path=Path(cls.tmp.name)/'sample.mp4'
  subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=s=320x180:r=30:d=0.5','-f','lavfi','-i','sine=duration=0.5','-c:v','mpeg4','-c:a','aac','-shortest',str(cls.path)],check=True,capture_output=True,timeout=20)
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def test_requested_settings_pass(self):
  self.assertEqual(require_verified_mp4(self.path,expected_duration=.5,expected_resolution=(320,180),expected_fps=30)['result'],'PASS')
 def test_wrong_resolution_fails(self):
  self.assertEqual(verify_mp4(self.path,expected_resolution=(1920,1080),expected_fps=30)['result'],'FAIL')
 def test_wrong_rate_fails(self):
  self.assertEqual(verify_mp4(self.path,expected_resolution=(320,180),expected_fps=60)['result'],'FAIL')
 def test_truncated_duration_fails(self):
  self.assertEqual(verify_mp4(self.path,expected_duration=2,expected_resolution=(320,180),expected_fps=30)['result'],'FAIL')
 def test_unavailable_probe_cannot_claim_verified_success(self):
  with patch('export_audit.shutil.which',return_value=None):
   with self.assertRaisesRegex(RuntimeError,'ffprobe unavailable'):require_verified_mp4(self.path)
