"""Characterization tests for the production ASS lyric renderer (no Qt window)."""
import ast
import math
from pathlib import Path
import re
import tempfile
import unittest

SOURCE=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')

class QColorStub:
    def __init__(self, value):
        value=str(value)
        self.rgb=value if re.fullmatch(r'#[0-9a-fA-F]{6}',value) else '#FFFFFF'
    def isValid(self): return True
    def red(self): return int(self.rgb[1:3],16)
    def green(self): return int(self.rgb[3:5],16)
    def blue(self): return int(self.rgb[5:7],16)

def production_renderer():
    tree=ast.parse(SOURCE.read_text(encoding='utf-8-sig'))
    names={'ass_file','safe_ass','ass_timestamp'}
    nodes=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in names]
    assert len(nodes)==3
    ns={'Path':Path,'math':math,'re':re,'QColor':QColorStub}
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(SOURCE),'exec'),ns)
    return ns['ass_file']

class AssWordTimingRuntimeTests(unittest.TestCase):
    def render(self, words, lyric='Hello world', start=1.0, end=3.0):
        project={'events':[[start,end,lyric]],'word_timings':{'0':words},'lyric_display_mode':'single',
                 'lyric_countdown':False,'opening_progress_enabled':False}
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'lyrics.ass'
            production_renderer()(project,path,640,360)
            return path.read_text(encoding='utf-8-sig')

    def test_progressive_tags_follow_word_onsets(self):
        ass=self.render([[1.0,2.2,'Hello'],[1.7,2.8,'world']])
        self.assertIn(r'{\kf70}Hello ',ass)
        self.assertIn(r'{\kf130}world',ass)

    def test_delayed_first_word_preserves_offset(self):
        ass=self.render([[1.25,1.5,'Hello'],[2.0,2.5,'world']])
        self.assertIn(r'{\k25}\h',ass)
        self.assertIn(r'{\kf75}Hello ',ass)

    def test_mismatched_word_text_does_not_apply_wrong_timing(self):
        ass=self.render([[1.0,1.5,'Different'],[2.0,2.5,'words']])
        self.assertNotIn(r'{\kf',ass)
        self.assertIn('Hello world',ass)

if __name__=='__main__': unittest.main()
