# v0.2.1.36 — Alignment Validator (report-only)

- Adds a pure-Python diagnostic module to inspect karaoke project JSON.
- During batch alignment, writes `<output MP4 stem>_alignment_report.json` to the batch output folder.
- Reports compressed lines, implausibly long short lines, overlaps, gaps, invalid word spans and estimated-line proportion.
- No changes to WhisperX alignment, fallback estimates, export approval, visuals, layout, or audio.
- Thresholds are exploratory diagnostics, not proof of audible timing accuracy.
- Reports are generated after successful alignment only. A failed alignment before that point will not produce a report.
- This release has not been tested in the Windows PySide6 GUI.
