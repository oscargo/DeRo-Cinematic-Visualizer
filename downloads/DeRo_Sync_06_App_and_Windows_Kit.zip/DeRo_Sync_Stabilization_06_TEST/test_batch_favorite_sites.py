from pathlib import Path
root=Path(__file__).parent
main=(root/'DeRo_Sync_v0210_43_Popper_Direction_Fix.py').read_text(encoding='utf-8')
batch=(root/'batch_workspace.py').read_text(encoding='utf-8')
assert 'favorite_sites_callback=self.show_favorite_sites' in main
assert 'def show_favorite_sites(self, search_provider=None):' in main
assert 'QTimer.singleShot(450,search_provider)' in main
assert "self.favorite_sites_button=button('Favorite Lyrics Sites',self.open_favorite_sites)" in batch
assert 'self.favorite_sites_callback(search_provider=self.copy_selected_song_search)' in batch
assert "('artist','title')" in batch
assert 'self.start_batch_button=QPushButton(' in batch
assert 'ws.start_batch_button.setEnabled(False)' in main
assert 'ws.start_batch_button.setEnabled(True)' in main
assert 'unlink(' not in batch and 'os.remove(' not in batch
print('Batch favorite lyrics integration static checks passed')
