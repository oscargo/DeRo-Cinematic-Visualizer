DeRo Sync v0.2.1.43 Windows 1080p60 benchmark

Run from this folder:
py -3.12 benchmark_windows_1080p43.py --seconds 30 --runs 3 --warmup 1

Output: WINDOWS_30S_BENCHMARK.json

Four configurations are measured. Each receives one warmup (excluded) and three timed runs. This can take several minutes.
Visualizer is OFF in the default comparisons; particles ON does not necessarily mean particles are rendered when the visualizer is OFF.
Optional --include-visualizer adds four configurations; this may be much slower and may not exercise the full interactive visualizer pipeline.
This is synthetic generated content, not a real song or full GUI export. It does not modify production source.
If an export fails, the JSON includes its status and error.
