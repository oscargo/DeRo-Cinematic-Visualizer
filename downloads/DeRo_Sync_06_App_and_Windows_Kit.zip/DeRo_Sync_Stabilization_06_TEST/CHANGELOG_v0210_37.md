# v0.2.1.37 — Persistent Export History and MP4 Audit

- Records append-only JSONL history to `DeRo_Export_History.jsonl` in output folder, with flush/fsync for recovery.
- Records batch start/end, song start/failure, alignment counts, export start/finish and throttled frame checkpoints.
- Checks MP4 size and ffprobe streams, dimensions, FPS and duration; reports PASS/WARNING/FAIL.
- Audit reports are observational only: no changes to synchronization, visualizer, particles, or batch decisions.
- Records single-song Visualizer export starts/completions/failures.
- A machine sleep event cannot be distinguished from a stalled renderer by a single checkpoint; gaps in timestamps provide evidence, not proof.
- Windows GUI/real GPU execution not tested in this environment.
- Legacy `run_regression_tests.py` could not complete: pre-existing `test_assured_fixes.py` refers to a missing `DeRo_Sync_v0210_08_Exact_Frame_Preview.py` file. Syntax checks and standalone audit smoke tests passed; no full GUI verification is claimed.
