# DeRo Sync v0.2.1.43 — Phase 1 baseline audit

Date: 2026-11-04. Source: `DeRo_Sync_v0.2.1.43_Popper_Direction_Fix(1).zip`.

SHA-256 (original ZIP): `d57eb4f4bb3b62fa858d95e0b43aa0d6d1f6fb812b62ef3e1df22000757827b7`.

## Verified findings

- Main file `DeRo_Sync_v0210_43_Popper_Direction_Fix.py`: 6,355 physical lines; `Main` is 4,673 lines and contains 271 direct methods (AST parsed).
- `APP_VERSION='v0210_43'` (main file line 16), but `VERSION` contains `v0.2.1.37`. **Confirmed release metadata defect.** Root cause in release tooling not established.
- `alignment_cache.py` still includes `DeRoSync-v0210_38-unaltered`. **Potential future invalidation risk, not a confirmed current stale-cache bug.** Source comparison with historical versions not completed.
- Main source has 17 single-line `except Exception:pass` occurrences (lines 214, 274, 286, 1625, 4286, 4293, 4305, 4315, 4968, 5021, 5030, 5041, 5050, 5233, 5242, 5250, 6350). Other multiline silent handlers require separate semantic review. These are not automatically defects.
- Ten `test_*.py` files exist. All ten reference missing old main-script filenames (`v0210_08` or `v0210_12`). This makes the tests non-portable as packaged. The provided regression runner aborts during test-module import before running tests (FileNotFoundError in `test_assured_fixes.py:14`). **No tests passed in this attempt.**
- All 18 top-level Python files in the ZIP passed AST parsing under Python 3.13. This does not establish runtime compatibility with the user's Python 3.12 environment or functional correctness.

## Recommended remediation, in order

1. Repair the release process to synchronize `VERSION`, entrypoint, launcher, ZIP name and changelog. Add a non-mutating validation gate.
2. Repair test portability *without silently changing the test assertions*: inspect each old-source assertion for relevance to v43, then adapt tests to current source and rerun.
3. Characterize critical behaviors (alignment cache keys, waveform interactions, export range/frame accuracy, independent particles/visualizer, stem mix defaults) before changes.
4. Review silent handlers in context; add logging only where failures should not be suppressed.
5. Profile actual bottlenecks with representative song projects before any performance changes.
6. Reformat/extract subsystems in small, separately validated changes.

## Limits

No GUI launch, Windows/PySide6 functional test, GPU test, Demucs/WhisperX test, or video export was executed. This audit cannot certify v43 as release-ready. No original source was overwritten.
