"""DeRo Sync v0.2.1.43: integrated karaoke workflow and Visualizer export."""
import random
import sys, json, re, copy, hashlib, os, tempfile, subprocess, shutil, math, struct, wave, logging, threading, traceback, time, difflib, platform, zipfile, datetime, importlib.metadata, urllib.request, urllib.parse, urllib.error
from pathlib import Path
from batch_workspace import BatchWorkspace
from alignment_validator import save_report as save_alignment_report
from export_audit import ExportAudit, verify_mp4, require_verified_mp4
from visualizer_engine.export_control import ExportControl, ExportCancelled
from standard_export_control import run_controlled_export
from PySide6.QtCore import Qt, QUrl, QRectF, QPoint, QPointF, Signal, QThread, QTimer, QSettings, QEvent
from PySide6.QtGui import QColor, QPainter, QPen, QFont, QIcon, QShortcut, QKeySequence, QDesktopServices, QPixmap, QPainterPath, QTextDocument
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QPushButton,
 QLineEdit,QPlainTextEdit,QLabel,QFileDialog,QMessageBox,QListWidget,QListWidgetItem,QDoubleSpinBox,QSlider,
 QFrame,QStackedWidget,QSplitter,QFormLayout,QComboBox,QProgressBar,QCheckBox,QScrollArea,QGridLayout,QSizePolicy,QTextEdit,QMenu,QInputDialog,QDialog,QTableWidget,QTableWidgetItem,QHeaderView,QProgressDialog,QColorDialog,QFontComboBox,QListView,QAbstractItemView,QStyledItemDelegate,QStyle,QDialog,QGroupBox,QStyleOptionProgressBar,QGraphicsDropShadowEffect)
from PySide6.QtMultimedia import QMediaPlayer,QAudioOutput

APP_BUILD='0.2.1.43-STABILIZATION-06-TEST'
APP_VERSION='v0210_43'

STYLE='''QWidget{background:#0b1224;color:#eaf0ff;font-family:Segoe UI;font-size:13px}
QFrame#panel{background:#131f36;border:1px solid #2b3a58;border-radius:14px}
QLabel{background:transparent;border:none;padding:0px}
QPushButton{background:#273653;border:1px solid #3c4b6a;border-radius:9px;padding:9px 13px;font-weight:600}
QPushButton:hover{background:#394d76} QPushButton:checked{background:#5b48a5;border-color:#ad92ff} QPushButton#primary{background:#765be2;border:0}
QPushButton#primary:hover{background:#9179f2} QPushButton#favoriteLyrics{background:#765be2;color:#ffffff;border:0} QPushButton#favoriteLyrics:hover{background:#9179f2} QLineEdit,QPlainTextEdit,QListWidget,QDoubleSpinBox,QComboBox{background:#101a2f;border:1px solid #354562;border-radius:8px;padding:7px;selection-background-color:#765be2}
QComboBox{min-height:27px;padding:3px 9px} QComboBox QAbstractItemView{background:#101a2f;color:#eaf0ff}
QListWidget::item{padding:9px} QListWidget::item:selected{background:#5446a1}
QLabel#muted{color:#aab9d7} QSlider::groove:horizontal{height:5px;background:#34435e;border-radius:2px} QSlider::handle:horizontal{background:#a78bfa;width:13px;margin:-5px 0;border-radius:6px}'''


# Export progress theme editor. Qt-only; does not affect rendering or timing.
PROGRESS_PRESETS = {
 'Legacy':('#6b83b6','#263a50'), 'Ocean':('#38bdf8','#112b48'),
 'Emerald':('#34d399','#12392e'), 'Violet':('#a78bfa','#292044'),
 'Amber':('#fbbf24','#423015'), 'Ruby':('#fb7185','#401d2b'),
 'Ice':('#bae6fd','#243c52'), 'Neon Blue':('#22d3ee','#10283e'),
 'Mint':('#6ee7b7','#1a3a35'), 'Sunset':('#fb923c','#3e2431'),
 'Rose':('#f9a8d4','#42263b'), 'Silver':('#cbd5e1','#303b4b'),
 'Lime':('#a3e635','#2d3a20')
}

def progress_theme_defaults():
 return dict(preset='Legacy', foreground='#6b83b6', background='#263a50',
             thickness=12, width=100, opacity=100, radius=4, border=0, glow=0,
             position=0, animation_steps=1, fade_out=0)

def normalize_progress_theme(data):
 if not isinstance(data,dict):raise ValueError('Progress theme must be a JSON object.')
 result=progress_theme_defaults()
 result.update({k:v for k,v in data.items() if k in result})
 for key in ('foreground','background'):
  if not isinstance(result[key],str) or not re.fullmatch(r'#[0-9A-Fa-f]{6}',result[key]):
   raise ValueError(key+' must be a #RRGGBB color.')
 for key,(low,high) in {'thickness':(6,35),'width':(30,100),'opacity':(10,100),'radius':(0,30),'border':(0,8),'glow':(0,100),'position':(-100,100),'animation_steps':(1,100),'fade_out':(0,60000)}.items():
  value=result[key]
  if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not low<=value<=high:
   raise ValueError('Invalid progress theme '+key+': expected '+str(low)+' to '+str(high)+'.')
  result[key]=int(value)
 if result['preset'] not in PROGRESS_PRESETS:raise ValueError('Unknown progress palette.')
 return result

def progress_theme_css(t):
 from PySide6.QtGui import QColor
 def color(name):
  c=QColor(str(t.get(name, '#6b83b6')))
  if not c.isValid():c=QColor('#6b83b6')
  c.setAlpha(round(255*max(0,min(100,int(t.get('opacity',100))))/100))
  return 'rgba(%d,%d,%d,%d)'%(c.red(),c.green(),c.blue(),c.alpha())
 r=max(0,min(30,int(t.get('radius',4))))
 b=max(0,min(8,int(t.get('border',0))))
 return ('QProgressBar{background:%s;border:%dpx solid #51617a;border-radius:%dpx;}'
         'QProgressBar::chunk{background:%s;border-radius:%dpx;}')%(color('background'),b,r,color('foreground'),r)

class ThemedProgressBar(QProgressBar):
 """Theme animation changes only painting; the real progress value stays exact."""
 def __init__(self,parent=None):
  super().__init__(parent)
  self.theme=progress_theme_defaults()
  self.display_value=float(self.value());self.fade=1.
  self._motion=None;self._fade_started=None
  self._effect_timer=QTimer(self);self._effect_timer.setInterval(16)
  self._effect_timer.timeout.connect(self._tick_effects)
  self.valueChanged.connect(self._progress_changed)
 def apply_theme(self,theme):
  self.theme=normalize_progress_theme(theme)
  self._motion=None;self._fade_started=None;self.fade=1.
  self.display_value=float(self.value());self._effect_timer.stop()
  self.setStyleSheet(progress_theme_css(self.theme))
  self.setFixedHeight(max(12,self.theme['thickness']+6)+2*abs(self.theme['position']))
  if self.theme['glow']:
   effect=QGraphicsDropShadowEffect(self)
   effect.setOffset(0,0);effect.setBlurRadius(self.theme['glow'])
   effect.setColor(QColor(self.theme['foreground']));self.setGraphicsEffect(effect)
  else:self.setGraphicsEffect(None)
  self.update()
 def setRange(self,minimum,maximum):
  self._effect_timer.stop();self._motion=None;self._fade_started=None;self.fade=1.
  super().setRange(minimum,maximum)
  self.display_value=float(self.value());self.update()
 def _progress_changed(self,value):
  now=time.monotonic();self.fade=1.;self._fade_started=None
  steps=self.theme['animation_steps']
  if steps>1 and self.maximum()>self.minimum() and self.display_value>=self.minimum():
   self._motion=(now,self.display_value,float(value),steps/60.)
   self._effect_timer.start()
  else:
   self.display_value=float(value);self._motion=None
   self._begin_fade(now)
  self.update()
 def _begin_fade(self,now):
  if self.maximum()>self.minimum() and self.value()==self.maximum() and self.theme['fade_out']:
   self._fade_started=now;self._effect_timer.start()
  elif self._motion is None:self._effect_timer.stop()
 def _tick_effects(self):
  now=time.monotonic()
  if self._motion is not None:
   began,a,b,duration=self._motion;fraction=min(1.,max(0.,(now-began)/duration))
   self.display_value=a+(b-a)*fraction
   if fraction>=1.:self._motion=None;self._begin_fade(now)
  if self._fade_started is not None:
   self.fade=max(0.,1.-(now-self._fade_started)/(self.theme['fade_out']/1000.))
   if self.fade<=0.:self._effect_timer.stop()
  self.update()
 def progress_rect(self):
  offset=self.theme['position'];rectangle=self.rect()
  return rectangle.adjusted(0,abs(offset)+offset,0,-(abs(offset)-offset))
 def paintEvent(self,event):
  option=QStyleOptionProgressBar();self.initStyleOption(option)
  option.rect=self.progress_rect()
  if self.maximum()>self.minimum():option.progress=round(self.display_value)
  painter=QPainter(self);painter.setOpacity(self.fade)
  self.style().drawControl(QStyle.CE_ProgressBar,option,painter,self)
  painter.end()

class ProgressThemeDialog(QDialog):
 def __init__(self,parent,settings,apply_callback):
  super().__init__(parent)
  self.setWindowTitle('Export progress appearance')
  self.resize(520,700)
  self.settings=settings
  self.apply_callback=apply_callback
  self.theme=progress_theme_defaults()
  try:
   saved=json.loads(settings.value('progress/theme_json','{}'))
   if isinstance(saved,dict):self.theme=normalize_progress_theme(saved)
  except (TypeError,ValueError):pass
  layout=QVBoxLayout(self)
  layout.addWidget(QLabel('Progress theme (affects application bars, not exported MP4)'))
  self.preset=QComboBox();self.preset.addItems(PROGRESS_PRESETS)
  self.preset.setCurrentText(str(self.theme.get('preset','Legacy')))
  layout.addWidget(self.preset)
  self.preview=ThemedProgressBar();self.preview.setRange(0,100);self.preview.setValue(67)
  layout.addWidget(self.preview)
  self.controls={}
  form=QFormLayout();layout.addLayout(form)
  for key,title,low,high in [('thickness','Thickness (px)',6,35),('width','Width (%)',30,100),('opacity','Opacity (%)',10,100),('radius','Corner rounding',0,30),('border','Border width',0,8),('glow','Glow radius (px)',0,100),('position','Vertical offset (px)',-100,100),('animation_steps','Animation frames (1 = instant)',1,100),('fade_out','Fade on completion (ms)',0,60000)]:
   spin=QDoubleSpinBox();spin.setDecimals(0);spin.setRange(low,high);spin.setValue(float(self.theme.get(key,low)))
   self.controls[key]=spin;form.addRow(title,spin);spin.valueChanged.connect(self.refresh)
  colors=QHBoxLayout();layout.addLayout(colors)
  for key,label in [('foreground','Fill color'),('background','Track color')]:
   b=QPushButton(label);b.clicked.connect(lambda _=False,k=key:self.pick_color(k));colors.addWidget(b)
  buttons=QHBoxLayout();layout.addLayout(buttons)
  for label,action in [('Save theme JSON',self.save_theme),('Load theme JSON',self.load_theme),('Reset',self.reset_theme)]:
   b=QPushButton(label);b.clicked.connect(action);buttons.addWidget(b)
  replay=QPushButton('Replay progress preview');replay.clicked.connect(self.replay_preview);layout.addWidget(replay)
  note=QLabel('Positive vertical offsets move the bar down; negative offsets move it up. Animation affects the displayed fill only. Fade begins after completion. Existing presets are color palettes.')
  note.setWordWrap(True);layout.addWidget(note)
  close=QPushButton('Apply and close');close.clicked.connect(self.accept);layout.addWidget(close)
  self.preset.currentTextChanged.connect(self.change_preset)
  self.refresh()
 def change_preset(self,name):
  if name in PROGRESS_PRESETS:
   self.theme['preset']=name
   self.theme['foreground'],self.theme['background']=PROGRESS_PRESETS[name]
  self.refresh()
 def pick_color(self,key):
  c=QColorDialog.getColor(QColor(str(self.theme.get(key,'#6b83b6'))),self,'Choose '+key)
  if c.isValid():self.theme[key]=c.name();self.refresh()
 def refresh(self,*_):
  for k,w in self.controls.items():self.theme[k]=int(w.value())
  self.preview.apply_theme(self.theme)
  self.preview.setMaximumWidth(max(1,round((self.width()-40)*self.theme['width']/100)))
  self.apply_callback(dict(self.theme))
  self.settings.setValue('progress/theme_json',json.dumps(self.theme))
 def replay_preview(self):
  self.preview.setRange(0,100);self.preview.setValue(0);self.preview.setValue(100)
 def save_theme(self):
  path,_=QFileDialog.getSaveFileName(self,'Save progress theme','DeRo_Progress_Theme.json','JSON (*.json)')
  if path:
   try:Path(path).write_text(json.dumps(self.theme,indent=2),encoding='utf-8')
   except OSError as e:QMessageBox.warning(self,'Save failed',str(e))
 def load_theme(self):
  path,_=QFileDialog.getOpenFileName(self,'Load progress theme','','JSON (*.json)')
  if path:
   try:
    data=json.loads(Path(path).read_text(encoding='utf-8-sig'))
    if not isinstance(data,dict):raise ValueError('Expected a JSON object')
    proposal=normalize_progress_theme(data)
    self.theme=proposal
    for k,w in self.controls.items():
     w.blockSignals(True);w.setValue(float(self.theme[k]));w.blockSignals(False)
    self.preset.blockSignals(True);self.preset.setCurrentText(str(self.theme['preset']));self.preset.blockSignals(False)
    self.refresh()
   except (OSError,ValueError,TypeError) as e:QMessageBox.warning(self,'Load failed',str(e))
 def reset_theme(self):
  self.theme=progress_theme_defaults()
  for k,w in self.controls.items():
   w.blockSignals(True);w.setValue(float(self.theme[k]));w.blockSignals(False)
  self.preset.blockSignals(True);self.preset.setCurrentText('Legacy');self.preset.blockSignals(False)
  self.refresh()

class DoublePopperCelebration(QWidget):
 """Two inward-facing poppers with confetti emitted from their actual mouths."""
 def __init__(self,parent=None,persistent=False):
  super().__init__(parent)
  self.persistent=persistent
  self.anchor_positions=None  # Local centers supplied by the main window's live layout.
  self.setMinimumWidth(180 if persistent else 0)
  if persistent:self.setFixedHeight(56)
  else:self.setMinimumHeight(0)  # Full-window overlay must not be clipped to 56 px.
  self.setAttribute(Qt.WA_TransparentForMouseEvents)
  self.setAttribute(Qt.WA_TranslucentBackground)
  self.setVisible(False)
  self.frame=0
  self.pieces=[]
  self.timer=QTimer(self)
  self.timer.setInterval(16)
  self.timer.timeout.connect(self.tick)

 def resizeEvent(self,event):
  super().resizeEvent(event)
  # A resize can arrive before the parent attaches the success label.
  label=getattr(self,'congratulations_label',None)
  if label is None:return
  left=self._geometry(0)[0]
  right=self._geometry(1)[0]
  margin=max(22,int(self.height()*.48))
  label.setGeometry(int(left+margin),0,max(1,int(right-left-2*margin)),self.height())

 def _geometry(self,side):
  # Same geometry drives the popper, its mouth, and every particle origin.
  w,h=self.width(),self.height()
  size=max(24,min(55,int(h*.66))) if self.persistent else max(42,min(90,int(h*.29)))
  # Keep the approved lower-right position. Place the lower-left cone in
  # the compact area above the song controls, rather than over the form.
  if not self.persistent and self.anchor_positions is not None:
   center_x,center_y=self.anchor_positions[side]
  else:
   center_x=w*(.075 if side==0 else .925)
   center_y=h*(.55 if self.persistent else .52)
  direction=1 if side==0 else -1
  # Emoji glyph is drawn at this center; mouth is its upper/inward tip.
  mouth_x=center_x+direction*size*.32
  mouth_y=center_y-size*.24
  return center_x,center_y,size,mouth_x,mouth_y,direction

 def start(self):
  rng=random.Random()
  self.pieces=[]
  for side,delay in ((0,0),(1,0 if self.persistent else 21)):
   for _ in range(90):
    self.pieces.append((side,delay,rng.uniform(.32,1.35),rng.uniform(-1.1,.65),
                        rng.uniform(.6,1.35),rng.randrange(5),rng.uniform(0,6.28)))
  self.frame=0
  self.started=time.monotonic()
  self.show()
  self.timer.start()
  self.update()

 def tick(self):
  self.frame=min(360,int(max(0.,time.monotonic()-self.started)*60))
  if self.frame>=360:
   self.timer.stop()
   if not self.persistent:self.hide()
   else:self.update()
  else:self.update()

 def paintEvent(self,event):
  if not self.isVisible():return
  p=QPainter(self)
  p.setRenderHint(QPainter.Antialiasing)
  w,h=self.width(),self.height()
  colors=['#f8ce5b','#ba8aff','#55cfff','#ff83c2','#70df91']
  for side,delay,vx,vy,speed,c,rot in self.pieces:
   age=self.frame-delay
   if age<0:continue
   t=age/60.
   if t>=6.:continue
   cx,cy,size,ox,oy,direction=self._geometry(side)
   # Travel starts at the actual mouth, in the direction the popper faces.
   distance=(size*.14+vx*size*1.6)*t*speed
   x=ox+direction*distance
   y=oy+vy*size*1.3*t+size*.32*t*t
   opacity=max(0.,1.-max(0.,t-2.)/4.)
   if not (0<=x<=w and 0<=y<=h):continue
   # Keep each lower burst with its popper, even after the window resizes.
   if not self.persistent:
    if not (cx-115<=x<=cx+115 and cy-85<=y<=cy+115):continue
   p.save()
   p.setOpacity(opacity)
   p.translate(x,y)
   p.rotate(rot*57.3+t*100)
   unit=max(3,min(9,int(size*.11)))
   p.fillRect(-unit//2,-unit//2,unit,unit+2,QColor(colors[c]))
   p.restore()
  for side,delay in ((0,0),(1,0 if self.persistent else 21)):
   if self.frame<delay:continue
   cx,cy,size,ox,oy,direction=self._geometry(side)
   font=QFont('Segoe UI Emoji');font.setPixelSize(size)
   p.save()
   p.translate(cx,cy)
   # Both poppers point into the widget; right-hand emoji is mirrored.
   if side==1:p.scale(-1,1)
   p.setFont(font)
   p.drawText(QRectF(-size*.75,-size*.7,size*1.5,size*1.4),Qt.AlignCenter,'🎉')
   p.restore()
  p.end()

class ExactVisualizerStillWorker(QThread):
 ready=Signal(object,str)
 def __init__(self,project,settings,audio_path,ffmpeg,seconds):
  super().__init__()
  self.project=project;self.settings=settings;self.audio_path=audio_path
  self.ffmpeg=ffmpeg;self.seconds=seconds
 def run(self):
  try:
   import numpy as np
   from visualizer_sync_bridge import make_settings,make_lyric_document
   from visualizer_engine.visualizer_core import Renderer,audio_features
   from visualizer_engine.audio_io import load_audio
   from visualizer_engine.lyric_render import exact_frame
   values=self.settings
   settings=make_settings(values,self.project.get('song',''),self.project.get('artist',''))
   # Analyze real song audio with the same extraction routine as export.
   rate=44100 if settings.frequency_max>10584 else 22050
   samples,sample_rate=load_audio(self.audio_path,sample_rate=rate,ffmpeg=self.ffmpeg)
   features=audio_features(samples,sample_rate,settings.fps,settings.bars,
       settings.frequency_min,settings.frequency_max,settings.frequency_scale,settings.spectrum_mapping)
   renderer=Renderer(settings,features)
   doc=make_lyric_document(self.project)
   frame=exact_frame(renderer,self.seconds,doc.snapshot(),self.ffmpeg)
   self.ready.emit(frame, '')
  except Exception as exc:
   self.ready.emit(None,str(exc))

class AspectPreviewLabel(QLabel):
 """Aspect-correct background preview with a non-exported static lyric sample."""
 def __init__(self, text='', parent=None):
  super().__init__(text,parent)
  self._source_pixmap=QPixmap()
  self._sample_lines=[]
 def setPreviewImage(self,pixmap):
  self._source_pixmap=pixmap
  self.update()
 def setSampleLyrics(self,lines):
  self._sample_lines=list(lines[:2])
  self.update()
 def paintEvent(self,event):
  if self._source_pixmap.isNull():
   super().paintEvent(event)
   return
  painter=QPainter(self)
  painter.setRenderHint(QPainter.SmoothPixmapTransform,True)
  painter.setRenderHint(QPainter.Antialiasing,True)
  bounds=self.contentsRect()
  fitted=self._source_pixmap.size().scaled(bounds.size(),Qt.KeepAspectRatio)
  image_rect=QRectF(bounds.x()+(bounds.width()-fitted.width())/2,
                    bounds.y()+(bounds.height()-fitted.height())/2,
                    fitted.width(),fitted.height())
  painter.drawPixmap(image_rect,self._source_pixmap,QRectF(self._source_pixmap.rect()))
  if self._sample_lines:
   painter.setRenderHint(QPainter.TextAntialiasing,True)
   # Keep the sample centered in the image, never the surrounding letterbox.
   font=QFont('Arial')
   font.setBold(True)
   font.setPixelSize(max(13,min(40,int(image_rect.height()*.068))))
   painter.setFont(font)
   metrics=painter.fontMetrics()
   line_height=metrics.height()*1.18
   center_y=image_rect.center().y()
   for index,line in enumerate(self._sample_lines):
    # Scale text down for long lyric lines rather than clipping.
    text=line
    available=image_rect.width()*.92
    while metrics.horizontalAdvance(text)>available and font.pixelSize()>12:
     font.setPixelSize(font.pixelSize()-1)
     painter.setFont(font)
     metrics=painter.fontMetrics()
    baseline=center_y+(index-(len(self._sample_lines)-1)/2)*line_height+metrics.ascent()/3
    x=image_rect.center().x()-metrics.horizontalAdvance(text)/2
    path=QPainterPath()
    path.addText(x,baseline,font,text)
    painter.setPen(QPen(QColor(0,0,0,225),max(2,font.pixelSize()*.095)))
    painter.setBrush(QColor('#EAF3FF'))
    painter.drawPath(path)
  painter.end()

class SafeValueSpin(QDoubleSpinBox):
 def wheelEvent(self,event):
  event.ignore()

class SafeValueCombo(QComboBox):
 def wheelEvent(self,event):
  event.ignore()

class SafeFontCombo(QFontComboBox):
 def wheelEvent(self,event):
  event.ignore()

def btn(text, callback, primary=False):
 b=QPushButton(text); b.clicked.connect(callback)
 if primary:b.setObjectName('primary')
 return b

def panel():
 f=QFrame();f.setObjectName('panel');return f

def find_ffmpeg():
 """Find a standalone decoder; Qt Multimedia's internal FFmpeg is not an executable."""
 exe=shutil.which('ffmpeg')
 if exe:return exe
 try:
  import imageio_ffmpeg
  exe=imageio_ffmpeg.get_ffmpeg_exe()
  if exe and Path(exe).is_file():return exe
 except Exception:pass
 for base in (Path.home()/'AppData/Local/Microsoft/WinGet/Links',Path('C:/ffmpeg/bin'),Path('C:/Program Files/ffmpeg/bin')):
  candidate=base/'ffmpeg.exe'
  if candidate.is_file():return str(candidate)
 return None


def prepare_whisperx_ffmpeg():
 """Make the already-discovered FFmpeg executable visible to WhisperX subprocesses.

 WhisperX invokes the literal command `ffmpeg`, unlike the waveform decoder,
 which invokes an absolute executable path. imageio-ffmpeg often ships a binary
 with a versioned filename, so put a named copy in an application cache folder.
 """
 exe=find_ffmpeg()
 if not exe or not Path(exe).is_file():
  raise RuntimeError('FFmpeg executable not found. Install FFmpeg or run: py -3.12 -m pip install imageio-ffmpeg')
 source=Path(exe).resolve()
 if source.name.lower()=='ffmpeg.exe':
  folder=source.parent
 else:
  import hashlib
  key=hashlib.sha256(str(source).encode('utf-8')).hexdigest()[:12]
  folder=Path(tempfile.gettempdir())/'karaoke-maker-lite-ffmpeg'/key
  folder.mkdir(parents=True,exist_ok=True)
  target=folder/'ffmpeg.exe'
  if not target.is_file() or target.stat().st_size!=source.stat().st_size or target.stat().st_mtime_ns!=source.stat().st_mtime_ns:
   shutil.copy2(source,target)
 # Check the exact command that WhisperX will invoke, rather than merely
 # assuming that an absolute-path decoder is enough.
 os.environ['PATH']=str(folder)+os.pathsep+os.environ.get('PATH','')
 try:
  result=subprocess.run(['ffmpeg','-version'],capture_output=True,text=True,timeout=12,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 except (OSError,subprocess.TimeoutExpired) as exc:
  raise RuntimeError('WhisperX cannot launch FFmpeg: '+str(exc)) from exc
 if result.returncode!=0:
  raise RuntimeError('FFmpeg was found but failed its startup check: '+result.stderr[:400])
 return str(folder/'ffmpeg.exe')

def safe_song_filename(artist, title, fallback='Untitled Song'):
 """Create an Artist - Title basename without altering displayed metadata."""
 artist=str(artist or '').strip()
 title=str(title or '').strip()
 parts=[p for p in (artist,title) if p]
 name=' - '.join(parts) if parts else fallback
 name=re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
 name=re.sub(r'\s+', ' ', name).strip(' .')
 if not name:name=fallback
 reserved={'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}
 if name.split('.')[0].upper() in reserved:name='_'+name
 return name[:160].rstrip(' .') or fallback

def metadata_from_audio(path):
 p=Path(path);title='';artist=''
 try:
  from mutagen import File as MutagenFile
  tags=MutagenFile(str(p),easy=True)
  if tags:
   title=str((tags.get('title') or [''])[0]).strip()
   artist=str((tags.get('artist') or [''])[0]).strip()
 except Exception:pass
 if not title or not artist:
  ffprobe=shutil.which('ffprobe')
  if ffprobe:
   try:
    result=subprocess.run([ffprobe,'-v','error','-show_entries','format_tags:stream_tags','-of','json',str(p)],capture_output=True,text=True,timeout=8,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if result.returncode==0:
     data=json.loads(result.stdout)
     for tags in [data.get('format',{}).get('tags',{})]+[x.get('tags',{}) for x in data.get('streams',[])]:
      lower={str(k).lower():str(v) for k,v in tags.items()}
      title=title or lower.get('title','').strip()
      artist=artist or lower.get('artist','').strip()
   except Exception:pass
 if not title:
  stem=re.sub(r'^\s*\d+\s*[-._]\s*','',p.stem).strip()
  if ' - ' in stem and not artist:
   artist,title=[x.strip() for x in stem.split(' - ',1)]
  else:title=stem
 return title,artist


def proper_song_case(value, *, artist=False):
 """Conservative display formatting, never a claim about official spelling.

 Preserve mixed-case artist branding (AC/DC, blink-182) and apostrophes.
 Song title sentence case only when the incoming value is entirely uppercase;
 artist names use word caps only when entirely uppercase. A MusicBrainz
 match, when available, supplies the official punctuation and accents.
 """
 value=re.sub(r'\s+', ' ', str(value or '')).strip()
 if not value or value.upper()!=value or not any(c.isalpha() for c in value):return value
 if artist:
  tokens=value.split(' ')
  protected={'AC/DC','ABBA','R.E.M.','U2','BTS','INXS','ZZ TOP','N.W.A','NSYNC'}
  def artist_token(token):
   if token in protected:return token
   return re.sub(r"[^\W\d_]+(?:['’][^\W\d_]+)*",lambda m:m.group(0)[0].upper()+m.group(0)[1:].lower(),token)
  return ' '.join(artist_token(w) for w in tokens)
 # Sentence case is a safe default for Spanish and English song titles;
 # preserve all-uppercase acronyms inside a mixed-case title unchanged.
 words=value.split(' ')
 minor={'a','an','the','and','or','but','of','in','on','at','to','for','from','with','by','el','la','los','las','de','del','y','en','al','un','una'}
 def title_token(token):
  return re.sub(r"[^\W\d_]+(?:['’][^\W\d_]+)*",lambda m:m.group(0)[0].upper()+m.group(0)[1:].lower(),token)
 return ' '.join(title_token(w) if i==0 or w.lower() not in minor else w.lower() for i,w in enumerate(words))


def suggest_song_information(title, artist, path):
 """Suggest cleanup without replacing an existing artist based on title text."""
 title=str(title or '').strip();artist=str(artist or '').strip()
 title=re.sub(r'(?i)\s*[\[(]\s*(?:official (?:music )?video|official audio|lyrics? video|visualizer|hd)\s*[\])]\s*$', '', title).strip()
 title=re.sub(r'^\s*\d{1,3}\s*[-._]\s*','',title).strip()
 if ' - ' in title:
  prefix,remainder=title.split(' - ',1)
  if prefix.strip() and remainder.strip() and (not artist or prefix.casefold()==artist.casefold()):
   if not artist:artist=prefix.strip()
   title=remainder.strip()
 return proper_song_case(title),proper_song_case(artist,artist=True)


def recover_line_timings(exact, candidates, line_start, line_end, normalize):
 """Preserve only text-matched WhisperX timestamps; estimate gaps explicitly."""
 n=len(exact)
 if not n:return [],[],0,0
 usable=[]
 for w in candidates:
  try:
   a=float(w['start']);b=float(w['end'])
   if math.isfinite(a) and math.isfinite(b) and b>a and normalize(w.get('word','')):
    usable.append((w,a,b))
  except (KeyError,TypeError,ValueError):continue
 pairs=difflib.SequenceMatcher(None,[normalize(t) for t in exact],[normalize(w[0]['word']) for w in usable],autojunk=False)
 anchors={}
 for block in pairs.get_matching_blocks():
  for k in range(block.size):
   idx=block.a+k;w,a,b=usable[block.b+k]
   anchors[idx]=(a,b,w.get('score'))
 result=[None]*n;scores=[None]*n
 for idx,(a,b,score) in anchors.items():
  result[idx]=(a,b)
  scores[idx]=score if isinstance(score,(int,float)) and math.isfinite(score) else None
 # Interpolate only the unmatched tokens; preserve matched timings unchanged.
 for i in range(n):
  if result[i] is not None:continue
  left=max((j for j in anchors if j<i),default=None)
  right=min((j for j in anchors if j>i),default=None)
  if left is not None and right is not None:
   lo=anchors[left][1];hi=anchors[right][0]
   if hi>lo:
    width=(hi-lo)/(right-left)
    a=lo+width*(i-left-1);b=a+width
   else:
    a=lo;b=lo+.02
  elif left is not None:
   a=anchors[left][1]+.18*(i-left-1);b=a+.18
  elif right is not None:
   b=max(0,anchors[right][0]-.18*(right-i-1));a=max(0,b-.18)
  else:
   width=max(.02,(line_end-line_start)/n);a=line_start+i*width;b=a+width
  result[i]=(max(0,a),max(max(0,a)+.02,b))
 words=[[round(a,3),round(max(a+.02,b),3),exact[i]] for i,(a,b) in enumerate(result)]
 return words,scores,len(anchors),len(usable)

def estimate_line_timings(exact,line_start,line_end):
 """Distribute words across a trusted line window for a safe fallback."""
 if not exact:return []
 start=max(0.,float(line_start));end=max(start+.02*len(exact),float(line_end));width=(end-start)/len(exact)
 return [[round(start+i*width,3),round(start+(i+1)*width,3),token] for i,token in enumerate(exact)]

def forced_alignment_quality(exact,words,scores):
 """Reject forced-alignment output that is too compressed or unsupported."""
 if not exact or len(words)!=len(exact):return False,'incomplete_word_timing_output'
 try:span=float(words[-1][1])-float(words[0][0])
 except (IndexError,TypeError,ValueError):return False,'invalid_word_timing_output'
 if not math.isfinite(span) or span<=0:return False,'invalid_word_timing_span'
 if check_word_timing_integrity({'word_timings':{'0':words}}):
  return False,'invalid_or_overlapping_word_timings'
 if len(exact)>=2 and span<.16*len(exact):return False,'implausibly_compressed_word_timing'
 numeric=[float(score) for score in scores if isinstance(score,(int,float)) and math.isfinite(score)]
 # No scored WhisperX word matches means the recovered word positions are
 # interpolated guesses. Never label those guesses as a reliable alignment.
 if not numeric:return False,'no_scored_whisperx_word_anchors'
 if numeric:
  average=sum(numeric)/len(numeric);low_fraction=sum(score<.10 for score in numeric)/len(numeric)
  if average<.15:return False,'very_low_alignment_confidence'
  if len(numeric)==len(exact) and low_fraction>=.5:return False,'mostly_low_confidence_words'
 return True,'forced_alignment_accepted'

def interpolate_anchor_timings(token_count,anchors):
 """Fill missing token spans while preserving real monotonic word anchors."""
 if token_count<=0:return []
 valid={int(i):(float(v[0]),float(v[1])) for i,v in anchors.items() if 0<=int(i)<token_count and math.isfinite(float(v[0])) and math.isfinite(float(v[1])) and float(v[1])>float(v[0])}
 if not valid:raise ValueError('At least one valid word anchor is required')
 known=sorted(valid);starts=[None]*token_count;ends=[None]*token_count
 for i,(a,b) in valid.items():starts[i]=max(0.,a);ends[i]=max(starts[i]+.02,b)
 for i in range(token_count):
  if starts[i] is not None:continue
  left=max((j for j in known if j<i),default=None);right=min((j for j in known if j>i),default=None)
  if left is not None and right is not None:starts[i]=starts[left]+(starts[right]-starts[left])*(i-left)/(right-left)
  elif left is not None:starts[i]=starts[left]+(i-left)*.22
  else:starts[i]=max(0.,starts[right]-(right-i)*.22)
 for i in range(token_count):
  if ends[i] is not None:continue
  next_start=starts[i+1] if i+1<token_count else None
  ends[i]=next_start if next_start is not None and next_start>starts[i] else starts[i]+.22
 return [(float(starts[i]),float(ends[i])) for i in range(token_count)]

def monotonic_word_anchors(pasted_tokens,recognized_words,normalize):
 """Match repeated lyrics to recognized words without jumping song sections."""
 left=[normalize(token) for token in pasted_tokens];right=[normalize(item[0]) for item in recognized_words]
 n=len(left);m=len(right)
 if not n or not m:return {}
 # Needleman-Wunsch alignment considers the complete song order. Unlike
 # SequenceMatcher, it cannot gain a large match by moving one repeated chorus
 # to a later occurrence and abandoning everything between the two choruses.
 gap=-1;match=3;mismatch=-2
 previous=[j*gap for j in range(m+1)];moves=[bytearray(m+1) for _ in range(n+1)]
 for j in range(1,m+1):moves[0][j]=2
 for i in range(1,n+1):
  current=[i*gap]+[0]*m;moves[i][0]=1
  for j in range(1,m+1):
   diagonal=previous[j-1]+(match if left[i-1] and left[i-1]==right[j-1] else mismatch)
   delete=previous[j]+gap;insert=current[j-1]+gap;best=max(diagonal,delete,insert);current[j]=best
   if diagonal==best and left[i-1] and left[i-1]==right[j-1]:moves[i][j]=0
   elif delete==best:moves[i][j]=1
   elif insert==best:moves[i][j]=2
   else:moves[i][j]=0
  previous=current
 anchors={};i=n;j=m
 while i or j:
  move=moves[i][j]
  if move==0:
   if i and j and left[i-1] and left[i-1]==right[j-1]:
    try:
     start=float(recognized_words[j-1][1]);end=float(recognized_words[j-1][2])
     if math.isfinite(start) and math.isfinite(end) and end>start:anchors[i-1]=(start,end)
    except (IndexError,TypeError,ValueError):pass
   i-=1;j-=1
  elif move==1:i-=1
  else:j-=1
 return anchors

def prepare_alignment_windows(line_token_counts,anchors):
 """Build local lyric-line windows and discard cross-occurrence anchor jumps."""
 filtered={};offset=0
 for count in line_token_counts:
  entries=[(index,anchors[index]) for index in range(offset,offset+count) if index in anchors]
  clusters=[]
  for entry in entries:
   if not clusters or entry[1][0]-clusters[-1][-1][1][1]>6.0:clusters.append([entry])
   else:clusters[-1].append(entry)
  if clusters:
   chosen=max(clusters,key=lambda group:(len(group),-(group[-1][1][1]-group[0][1][0])))
   filtered.update(chosen)
  offset+=count
 fallback=interpolate_anchor_timings(sum(line_token_counts),filtered)
 windows=[];offset=0
 for count in line_token_counts:
  entries=[(index-offset,filtered[index]) for index in range(offset,offset+count) if index in filtered]
  if entries:
   first_index,(first_start,_)=entries[0];last_index,(_,last_end)=entries[-1]
   start=max(0.,first_start-min(1.5,.22*first_index))
   end=last_end+min(1.5,.22*max(0,count-1-last_index))+.15
  else:
   spans=fallback[offset:offset+count];start=min(x[0] for x in spans);end=max(x[1] for x in spans)+.15
  windows.append((start,max(start+.1,end)));offset+=count
 return windows,filtered

def reconcile_alignment_segments(inputs,returned,normalize):
 """Match lyric occurrences in order, using time windows to disambiguate repeats.

 Missing or hallucinated output may be skipped. Text alone must not pull a
 later chorus into an earlier occurrence with the same words.
 """
 n,m=len(inputs),len(returned)
 mapped=[None]*n
 if not n or not m:return mapped
 def span(item):
  try:
   a,b=float(item['start']),float(item['end'])
   return (a,b) if math.isfinite(a) and math.isfinite(b) and 0<=a<b else None
  except (KeyError,ValueError,TypeError):return None
 left=[normalize(str(x.get('text',''))) for x in inputs]
 right=[normalize(str(x.get('text',''))) for x in returned]
 times_left=[span(x) for x in inputs];times_right=[span(x) for x in returned]
 previous=[0.]*(m+1);moves=[bytearray(m+1) for _ in range(n+1)]
 for i in range(1,n+1):
  current=[0.]*(m+1)
  for j in range(1,m+1):
   # Skip either side at no cost; only supported pairs earn a reward.
   best=previous[j];move=1
   if current[j-1]>best:best=current[j-1];move=2
   score=None
   if left[i-1] and right[j-1]:
    similarity=difflib.SequenceMatcher(None,left[i-1],right[j-1],autojunk=False).ratio()
    if similarity>=.5:
     a,b=times_left[i-1],times_right[j-1]
     if a is None or b is None:score=similarity
     else:
      overlap=max(0.,min(a[1],b[1])-max(a[0],b[0]))
      gap=max(a[0]-b[1],b[0]-a[1],0.)
      if gap<=.25:
       score=similarity+2*overlap/max(.1,max(a[1],b[1])-min(a[0],b[0]))
   if score is not None and previous[j-1]+score>best:
    best=previous[j-1]+score;move=3
   current[j]=best;moves[i][j]=move
  previous=current
 i,j=n,m
 while i and j:
  move=moves[i][j]
  if move==3:mapped[i-1]=returned[j-1];i-=1;j-=1
  elif move==1:i-=1
  else:j-=1
 return mapped

def validate_project_payload(data):
 """Reject malformed saved timings before replacing the current project."""
 if not isinstance(data,dict) or data.get('format')!='KaraokeStudioProject':
  raise ValueError('Not a KaraokeStudioProject file')
 events=data.get('events',[]);wordmap=data.get('word_timings',{})
 if not isinstance(events,list) or not isinstance(wordmap,dict):raise ValueError('Malformed project timing data.')
 def check(entry,label):
  if not isinstance(entry,(list,tuple)) or len(entry)!=3 or not isinstance(entry[2],str):raise ValueError(label+': expected start, end, text.')
  a,b=entry[:2]
  if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in (a,b)) or a<0 or b<=a:
   raise ValueError(label+': timestamps must be finite, non-negative, and end after start.')
 for i,event in enumerate(events):check(event,'Line '+str(i+1))
 for key,words in wordmap.items():
  if not isinstance(key,str) or not key.isdigit() or str(int(key))!=key or int(key)>=len(events) or not isinstance(words,list):
   raise ValueError('Word timing references an unknown line.')
  for j,word in enumerate(words):check(word,'Line '+str(int(key)+1)+', word '+str(j+1))
 return data

def flatten_song_words(word_timings):
 """Return every valid timed word with its source line and word indexes."""
 flattened=[]
 for line_key,words in word_timings.items():
  try:line_index=int(line_key)
  except (TypeError,ValueError):continue
  if not isinstance(words,list):continue
  for word_index,entry in enumerate(words):
   try:
    start,end,text=entry;start=float(start);end=float(end)
    if not math.isfinite(start) or not math.isfinite(end) or end<=start:continue
    flattened.append((start,end,str(text),line_index,word_index))
   except (TypeError,ValueError):continue
 flattened.sort(key=lambda item:(item[0],item[3],item[4]));return flattened

def shift_ass_dialogues(source, target, offset, duration):
 """Shift ASS Dialogue times onto clip-local timeline; preserve text/styles/word tags."""
 def parse_stamp(value):
  h,m,sec=value.split(':');return int(h)*3600+int(m)*60+float(sec)
 def stamp(value):
  centis=max(0,round(value*100));hours,rem=divmod(centis,360000);minutes,rem=divmod(rem,6000);seconds,cs=divmod(rem,100)
  return f'{hours}:{minutes:02d}:{seconds:02d}.{cs:02d}'
 result=[]
 for line in Path(source).read_text(encoding='utf-8-sig').splitlines(keepends=True):
  if not line.startswith('Dialogue: '):result.append(line);continue
  parts=line[len('Dialogue: '):].split(',',3)
  if len(parts)<4:result.append(line);continue
  try:start=parse_stamp(parts[1]);end=parse_stamp(parts[2])
  except (ValueError,IndexError):result.append(line);continue
  a=max(0.,start-offset);b=min(duration,end-offset)
  if b<=a+.005:continue
  parts[1]=stamp(a);parts[2]=stamp(b)
  result.append('Dialogue: '+','.join(parts))
 Path(target).write_text(''.join(result),encoding='utf-8-sig')

class ExportRangeBar(QWidget):
 """Two draggable time handles and a movable range; no changes to lyric data."""
 changed=Signal(float,float)
 def __init__(self,parent=None):
  super().__init__(parent);self.duration=1.;self.start=0.;self.end=1.;self.drag=None;self.origin=None
  self.setMinimumHeight(55);self.setMouseTracking(True);self.setToolTip('Drag either yellow handle to resize; drag the middle to move the selection.')
 def set_duration(self,seconds):
  seconds=max(.1,float(seconds));old=self.duration
  full=self.start<.001 and abs(self.end-old)<.05
  self.duration=seconds
  if full:self.start=0.;self.end=seconds
  else:self.start=min(self.start,seconds-.1);self.end=min(seconds,max(self.start+.1,self.end))
  self.changed.emit(self.start,self.end);self.update()
 def set_range(self,a,b):
  self.start=max(0.,min(float(a),self.duration-.1));self.end=max(self.start+.1,min(float(b),self.duration))
  self.changed.emit(self.start,self.end);self.update()
 def _x(self,t):return 15.+(self.width()-30.)*t/max(.1,self.duration)
 def _t(self,x):return max(0.,min(self.duration,(x-15.)/max(1.,self.width()-30.)*self.duration))
 def paintEvent(self,event):
  q=QPainter(self);q.setRenderHint(QPainter.Antialiasing)
  y=self.height()/2.;x1=self._x(self.start);x2=self._x(self.end)
  q.setPen(Qt.NoPen);q.setBrush(QColor('#354562'));q.drawRoundedRect(QRectF(15,y-6,self.width()-30,12),6,6)
  q.setBrush(QColor('#5b70c8'));q.drawRoundedRect(QRectF(x1,y-6,max(1,x2-x1),12),5,5)
  q.setBrush(QColor('#f5c84b'))
  for x in (x1,x2):q.drawRoundedRect(QRectF(x-6,y-17,12,34),4,4)
  q.end()
 def mousePressEvent(self,e):
  if e.button()!=Qt.LeftButton:return
  x=e.position().x();a=self._x(self.start);b=self._x(self.end)
  self.drag='left' if abs(x-a)<=11 else 'right' if abs(x-b)<=11 else 'move' if a<x<b else None
  self.origin=(self._t(x),self.start,self.end)
 def mouseMoveEvent(self,e):
  x=e.position().x();a=self._x(self.start);b=self._x(self.end)
  if self.drag and self.origin:
   t=self._t(x);old_t,old_a,old_b=self.origin
   if self.drag=='left':self.set_range(min(t,self.end-.1),self.end)
   elif self.drag=='right':self.set_range(self.start,max(t,self.start+.1))
   else:
    d=max(-old_a,min(self.duration-old_b,t-old_t));self.set_range(old_a+d,old_b+d)
  else:self.setCursor(Qt.SizeHorCursor if min(abs(x-a),abs(x-b))<=11 else Qt.OpenHandCursor if a<x<b else Qt.ArrowCursor)
 def mouseReleaseEvent(self,e):self.drag=None;self.origin=None

class WaveformWorker(QThread):
 ready=Signal(object,float,str)
 def __init__(self,path,resolution=100):
  super().__init__();self.path=path;self.resolution=int(resolution);self.detail_peaks=[]
 def run(self):
  # Decode to low-rate mono PCM using ffmpeg; read WAV natively if ffmpeg unavailable.
  peaks=[];detail=[];duration=0.0;error=''
  try:
   exe=find_ffmpeg()
   if exe:
    cmd=[exe,'-hide_banner','-nostats','-loglevel','error','-i',self.path,'-map','0:a:0','-vn','-sn','-dn','-ac','1','-ar','12000','-f','s16le','pipe:1']
    p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    count=0; peak_index=0
    try:
     while True:
      # Fractional block boundaries keep 700/900 peaks per second exact on average.
      block=((peak_index+1)*12000//self.resolution)-(peak_index*12000//self.resolution)
      raw=p.stdout.read(2*max(1,block))
      if not raw:break
      n=len(raw)//2
      if n:
       vals=struct.unpack('<'+str(n)+'h',raw[:n*2]);peaks.append(max(abs(x) for x in vals)/32768.0);detail.append((min(vals)/32768.0,max(vals)/32768.0));count+=n;peak_index+=1
     duration=count/12000.0
    except BaseException:
     if p.poll() is None:p.kill()
     p.wait(timeout=5)
     raise
    p.wait(timeout=10)
    decoder_error=p.stderr.read().decode('utf-8',errors='replace').strip() if p.stderr else ''
    if p.returncode not in (0,None):raise RuntimeError(f'FFmpeg decoder failed (exit {p.returncode}): {decoder_error[:350]}')
   elif Path(self.path).suffix.lower()=='.wav':
    with wave.open(self.path,'rb') as f:
     rate=f.getframerate();channels=f.getnchannels();width=f.getsampwidth();duration=f.getnframes()/max(1,rate)
     if width!=2:raise RuntimeError('This WAV needs FFmpeg for waveform decoding')
     peak_index=0
     while True:
      block=((peak_index+1)*rate//self.resolution)-(peak_index*rate//self.resolution)
      raw=f.readframes(max(1,block))
      if not raw:break
      n=len(raw)//2;vals=struct.unpack('<'+str(n)+'h',raw[:n*2]);peaks.append(max(abs(x) for x in vals)/32768.0);detail.append((min(vals)/32768.0,max(vals)/32768.0));peak_index+=1
   else:raise RuntimeError('Standalone FFmpeg decoder missing. Run: py -3.12 -m pip install imageio-ffmpeg')
  except Exception as exc:error=str(exc)
  # Cap the number of bars for fast rendering of long songs.
  if len(peaks)>120000:
   step=math.ceil(len(peaks)/120000);peaks=[max(peaks[i:i+step]) for i in range(0,len(peaks),step)];detail=[(min(x[0] for x in detail[i:i+step]),max(x[1] for x in detail[i:i+step])) for i in range(0,len(detail),step)]
  self.detail_peaks=detail
  self.ready.emit(peaks,duration,error)

class AdaptivePcmWindowWorker(QThread):
 """Decode only a short visible region at 48 kHz; keep project times intact."""
 ready=Signal(object,object,str)
 RATE=48000
 BUCKET=8  # 6,000 signed min/max buckets/s (0.167 ms per bucket).
 def __init__(self, path, key, start, end):
  super().__init__();self.path=str(path);self.key=key;self.window_start=max(0.,float(start));self.window_end=max(self.window_start+.01,float(end))
 def run(self):
  try:
   ffmpeg=find_ffmpeg()
   if not ffmpeg:raise RuntimeError('FFmpeg required for adaptive detail')
   duration=min(30.,self.window_end-self.window_start)
   cmd=[ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-ss',f'{self.window_start:.6f}', '-i',self.path,'-t',f'{duration:.6f}', '-map','0:a:0','-vn','-ac','1','-ar',str(self.RATE),'-f','s16le','pipe:1']
   output=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=35,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   if output.returncode:raise RuntimeError(output.stderr.decode('utf-8','replace')[-250:])
   import array
   samples=array.array('h');samples.frombytes(output.stdout[:len(output.stdout)//2*2])
   if sys.byteorder!='little':samples.byteswap()
   detail=[]
   for i in range(0,len(samples),self.BUCKET):
    section=samples[i:i+self.BUCKET]
    detail.append((min(section)/32768.,max(section)/32768.))
   self.ready.emit(self.key,(self.window_start,self.window_start+len(samples)/self.RATE,detail),'')
  except Exception as exc:self.ready.emit(self.key,None,str(exc))

class JobWorker(QThread):
 progress=Signal(str)
 completed=Signal(object,str)
 def __init__(self,func):
  super().__init__();self.func=func
 def run(self):
  try:self.completed.emit(self.func(self.progress.emit),'')
  except Exception as exc:self.completed.emit(None,str(exc)+'\n'+traceback.format_exc(limit=3))

def safe_ass(s):
 return str(s).replace('\\', r'\\').replace('{','(').replace('}',')').replace('\n',' ')

def progressive_word_html(word,current,start,end,sung,unsung):
 """Render a character-level live approximation of ASS progressive fill."""
 from html import escape
 text=str(word);a=float(start);b=max(a+.001,float(end));fraction=max(0.,min(1.,(float(current)-a)/(b-a)))
 cut=max(0,min(len(text),round(len(text)*fraction)))
 before=escape(text[:cut]);after=escape(text[cut:])
 return (f'<span style="color:{sung}">{before}</span>' if before else '')+(f'<span style="color:{unsung}">{after}</span>' if after else '')

def ass_timestamp(seconds):
 cs=max(0,round(float(seconds)*100));return f'{cs//360000}:{cs//6000%60:02d}:{cs//100%60:02d}.{cs%100:02d}'

def check_word_timing_integrity(project):
 """Return non-destructive warnings for review; keep overlapping data unchanged."""
 warnings=[]
 for key,words in project.get('word_timings',{}).items():
  prev=None
  for i,entry in enumerate(words):
   try:
    start,end,_=entry;start=float(start);end=float(end)
    if not all(map(math.isfinite,(start,end))) or start<0 or end<=start:
     warnings.append(f'Line {key}, word {i+1}: invalid start/end')
    if prev is not None and start<prev-.001:
     warnings.append(f'Line {key}, word {i+1}: starts before preceding word ends')
    prev=end
   except (ValueError,TypeError,IndexError):warnings.append(f'Line {key}, word {i+1}: malformed timing')
 return warnings

def ass_file(project,filename,width=1920,height=1080):
 """Render single, preview, or alternating lyrics with exclusive time slots."""
 events=project.get('events',[]);timings=project.get('word_timings',{})
 lead=max(0.,min(5.,float(project.get('lyric_lead_seconds',2))))
 mode=project.get('lyric_display_mode')
 if mode not in ('single','preview','alternating','classic_flow'):
  mode='preview' if project.get('lyric_read_ahead',False) else 'single'
 ahead=mode!='single'
 flow=mode=='classic_flow'
 flow_lines=max(2,min(3,int(project.get('classic_flow_lines',3))))
 flow_fade_in=max(0,min(1500,int(project.get('classic_flow_fade_in',300))))
 flow_fade_out=max(0,min(2000,int(project.get('classic_flow_fade_out',400))))
 final_fade=max(0,min(5000,int(project.get('lyric_final_fade_out',2000))))
 break_bar=bool(project.get('silence_progress_enabled',False))
 break_threshold=max(1.,min(60.,float(project.get('silence_progress_threshold',5.))))
 flow_hold=max(0.,min(1.,float(project.get('lyric_exit_delay',150))/1000.))
 progress_enabled=bool(project.get('opening_progress_enabled',project.get('lyric_countdown',True)))
 progress_length=max(0.5,min(20.,float(project.get('opening_progress_duration',5.))))
 progress_before=max(0.,min(30.,float(project.get('opening_progress_before',5.))))
 fontsize=max(24,min(120,int(project.get('lyric_font_size',72))))
 fontname=str(project.get('lyric_font_family','Arial')).replace(',','').replace('\n','').strip() or 'Arial'
 bold_ass=-1 if project.get('lyric_font_bold',True) else 0
 outline=max(0,min(8,int(project.get('lyric_outline',3))))
 vertical=max(12,min(88,int(project.get('lyric_vertical_percent',53))))
 center_y=round(height*vertical/100)
 row_gap=round(fontsize*1.55)
 top_y=max(fontsize,center_y-row_gap//2) if ahead else center_y
 bottom_y=min(height-fontsize,center_y+row_gap//2)
 # ASS uses AABBGGRR color ordering. Primary is sung; Secondary is unsung.
 def ass_color(hex_color):
  c=QColor(str(hex_color))
  if not c.isValid():c=QColor('#FFFFFF')
  return f'&H00{c.blue():02X}{c.green():02X}{c.red():02X}'
 color_white=ass_color(project.get('lyric_unsung_color','#EAF3FF'))
 color_pink=ass_color(project.get('lyric_sung_color','#31B9FF'))
 header=f"""[Script Info]
Title: Karaoke Maker Lite - Configurable Lyric Rows
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Active,{fontname},{fontsize},{color_pink},{color_white},&H00000000,&H80000000,{bold_ass},0,0,0,100,100,0,0,1,{outline},1,5,90,90,0,1
Style: Next,{fontname},{fontsize},{color_white},{color_white},&H00000000,&H80000000,{bold_ass},0,0,0,100,100,0,0,1,{outline},1,5,90,90,0,1
Style: Progress,Arial,18,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
 out=[header]
 parsed=[]
 for i,event in enumerate(events):
  try:
   a,b,t=event;a=float(a);b=float(b)
   if b<=a or not str(t).strip():continue
   parsed.append((i,a,b,str(t)))
  except (TypeError,ValueError):continue
 parsed.sort(key=lambda x:(x[1],x[0]))
 if not parsed:
  Path(filename).write_text(header,encoding='utf-8-sig');return
 opening_bar_end=(min(parsed[0][1],max(0.,parsed[0][1]-progress_before)+progress_length) if progress_enabled and progress_before>0 else -1.)
 def add(a,b,style,lyric,layer=0,y=None):
  if b>a+.01:
   prefix=r'{\an5\pos('+str(width//2)+','+str(y if y is not None else top_y)+')}'
   out.append(f'Dialogue: {layer},{ass_timestamp(a)},{ass_timestamp(b)},{style},,0,0,0,,{prefix}{lyric}\n')
 def text_units(value):return sum(.35 if ch.isspace() else .95 if ch in 'MW@#%&' else .58 for ch in str(value))
 def line_layout(text):
  """Preserve the chosen font size by wrapping once before shrinking."""
  words=str(text).split();available=max(160.,width-180.)
  if not words:return fontsize,(),words
  total=text_units(' '.join(words))
  if total*fontsize<=available:return fontsize,(),words
  if len(words)==1:return max(24,min(fontsize,int(available/max(1.,total)))),(),words
  choices=[]
  for split in range(1,len(words)):
   left=text_units(' '.join(words[:split]));right=text_units(' '.join(words[split:]))
   choices.append((max(left,right),abs(left-right),split))
  largest,_imbalance,split=min(choices)
  fitted=max(24,min(fontsize,int(available/max(1.,largest))))
  return fitted,(split,),words
 def line_override(text):
  fitted,_breaks,_words=line_layout(text);return r'{\q2\fs'+str(fitted)+'}'
 def plain_text(text):
  fitted,breaks,words=line_layout(text)
  if not words:return r'{\q2\fs'+str(fitted)+'}'
  rendered=[]
  for position,word in enumerate(words,1):
   rendered.append(safe_ass(word))
   if position<len(words):rendered.append(r'\N' if position in breaks else ' ')
  return r'{\q2\fs'+str(fitted)+'}'+''.join(rendered)
 def layout_rows(text):
  fitted,breaks,_words=line_layout(text);return fitted,len(breaks)+1
 def stack_positions(texts):
  metrics=[layout_rows(text) for text in texts]
  heights=[max(1,round(size*1.18*rows)) for size,rows in metrics]
  gap=round(fontsize*.48);total=sum(heights)+gap*max(0,len(heights)-1)
  top=max(10.,min(height-total-10.,center_y-total/2));positions=[];cursor=top
  for block_height in heights:
   positions.append(round(cursor+block_height/2));cursor+=block_height+gap
  return positions
 def word_text(idx,a,b,text):
  """ASS progressive fills follow absolute word ONSETS, not summed word lengths.

  ASS karaoke-tag durations are sequential. Duration-to-next-onset preserves the saved
  word start positions even when a word's stored end overlaps the next word.
  Sequential karaoke tags cannot show simultaneous words;
  the next onset takes precedence and overlapping intervals are flagged in QA.
  """
  ww=timings.get(str(idx),[])
  if not ww:return plain_text(text)
  clean=[]
  for entry in ww:
   try:
    wa,wb,word=entry
    wa=float(wa);wb=float(wb)
    if not math.isfinite(wa) or not math.isfinite(wb) or not str(word).strip():continue
    clean.append((max(a,min(b,wa)),str(word)))
   except (TypeError,ValueError):continue
  if not clean:return plain_text(text)
  expected=[re.sub(r'[^\w]+','',token.casefold(),flags=re.UNICODE) for token in str(text).split()]
  timed=[re.sub(r'[^\w]+','',word.casefold(),flags=re.UNICODE) for _,word in clean]
  if expected!=timed:return plain_text(text)
  # No reordering of lyrics. Invalid out-of-order onsets are clamped forward.
  starts=[];last=a;display_words=str(text).split()
  for (wa,_timed_word),display_word in zip(clean,display_words):
   last=max(last,wa);starts.append((last,display_word))
  fitted,breaks,_words=line_layout(text);pieces=[r'{\q2\fs'+str(fitted)+'}']
  if starts[0][0]>a+.005:
   # A zero-duration spacer delays the first highlight without displaying text.
   pieces.append(r'{\k'+str(max(0,round((starts[0][0]-a)*100)))+'}'+r'\h')
  for j,(onset,word) in enumerate(starts):
   next_onset=starts[j+1][0] if j+1<len(starts) else b
   centiseconds=max(0,round((max(onset,next_onset)-onset)*100))
   separator=r'\N' if j+1 in breaks else ' '
   pieces.append(r'{\kf'+str(centiseconds)+'}'+safe_ass(word)+(separator if j+1<len(starts) else ''))
  return ''.join(pieces) or plain_text(text)
 def add_opening_progress_bar():
  """One centered ASS vector progress bar, shown only before first sung lyric.

  Duration and start-before-first-lyric are independent settings. A bar that
  would extend into singing is truncated to avoid covering active lyrics.
  """
  if not progress_enabled or not parsed or progress_before<=0:return
  first_start=max(0.,float(parsed[0][1]))
  begin=max(0.,first_start-progress_before)
  end=min(first_start,begin+progress_length)
  if end<=begin+.02:return
  bar_width=max(120,int(width*.48));bar_height=max(13,int(height*.022))
  left=(width-bar_width)//2;right=left+bar_width
  top=(height-bar_height)//2;bottom=top+bar_height
  def rect(x1,y1,x2,y2):
   return f'm {x1} {y1} l {x2} {y1} {x2} {y2} {x1} {y2}'
  def shape(a,b,layer,fill,geometry):
   # ASS drawing mode: use screen-space coordinates and top-left origin.
   tags=r'{\an7\pos(0,0)\bord0\shad0\1c&H'+fill+r'&\p1}'
   out.append(f'Dialogue: {layer},{ass_timestamp(a)},{ass_timestamp(b)},Progress,,0,0,0,,{tags}{geometry}'+r'{\p0}'+'\n')
  # Dark track and colored fill. Step count is bounded to avoid excessive events.
  shape(begin,end,5,'334158',rect(left-4,top-4,right+4,bottom+4))
  shape(begin,end,6,'18121E',rect(left,top,right,bottom))
  count=max(2,min(100,int((end-begin)*20)))
  for step in range(count):
   a=begin+(end-begin)*step/count
   b=begin+(end-begin)*(step+1)/count
   fill_end=left+max(1,round(bar_width*(step+1)/count))
   shape(a,b,7,'FFB975',rect(left,top,fill_end,bottom))
 def add_silence_progress_bars():
  # Simple, non-numeric progress fill during eligible gaps between vocal phrases.
  if not break_bar or len(parsed)<2:return
  bar_width=max(120,int(width*.48));bar_height=max(10,int(height*.018))
  left=(width-bar_width)//2;top=(height-bar_height)//2
  def rect(x1,y1,x2,y2):return f'm {x1} {y1} l {x2} {y1} {x2} {y2} {x1} {y2}'
  def shape(a,b,layer,fill,geometry):
   if b<=a+.015:return
   tags=r'{\an7\pos(0,0)\bord0\shad0\1c&H'+fill+r'&\p1}'
   out.append(f'Dialogue: {layer},{ass_timestamp(a)},{ass_timestamp(b)},Progress,,0,0,0,,{tags}{geometry}'+r'{\p0}'+'\n')
  for pos in range(len(parsed)-1):
   idx,a,b,_=parsed[pos];next_start=parsed[pos+1][1]
   ends=[]
   for entry in timings.get(str(idx),[]):
    try:
     end=float(entry[1])
     if math.isfinite(end):ends.append(end)
    except (TypeError,ValueError,IndexError):pass
   sung_end=max(ends) if ends else b
   begin=max(0.,sung_end+flow_hold+min(flow_fade_out/1000.,.5))
   finish=next_start
   if finish-sung_end<break_threshold or finish-begin<=.08:continue
   shape(begin,finish,5,'334158',rect(left-4,top-4,left+bar_width+4,top+bar_height+4))
   shape(begin,finish,6,'18121E',rect(left,top,left+bar_width,top+bar_height))
   count=max(2,min(160,int((finish-begin)*15)))
   for step in range(count):
    ta=begin+(finish-begin)*step/count;tb=begin+(finish-begin)*(step+1)/count
    shape(ta,tb,7,'FFB975',rect(left,top,left+max(1,round(bar_width*(step+1)/count)),top+bar_height))
 # Classic Flow: fixed lyric pages that remain until the page's final word,
 # then fade as one screen before the next page appears.
 if flow:
  spacing=round(fontsize*1.55)
  first_y=max(fontsize+12, min(height-fontsize*3,center_y-spacing))
  def dialogue_flow(a,b,style,content,y,layer=0,fade_in=0,fade_out=0,move=False):
   if b<=a+.02:return
   duration_ms=int((b-a)*1000)
   fi=min(fade_in,duration_ms//3);fo=min(fade_out,duration_ms//2)
   # ASS \move animation is a short, subtle vertical settle on entry.
   effect=(r'{\an5\move('+str(width//2)+','+str(y+round(fontsize*.18))+','+str(width//2)+','+str(y)+',0,'+str(min(300,duration_ms//2))+')}') if move else (r'{\an5\pos('+str(width//2)+','+str(y)+')}')
   if fi or fo:effect+=r'{\fad('+str(fi)+','+str(fo)+')}'
   out.append(f'Dialogue: {layer},{ass_timestamp(a)},{ass_timestamp(b)},{style},,0,0,0,,{effect}{content}\n')
  def line_sung_end(idx,fallback):
   ends=[]
   for entry in timings.get(str(idx),[]):
    try:
     value=float(entry[1])
     if math.isfinite(value):ends.append(value)
    except (TypeError,ValueError,IndexError):pass
   return max(ends) if ends else float(fallback)
  previous_page_end=0.
  for page_pos in range(0,len(parsed),flow_lines):
   page=parsed[page_pos:page_pos+flow_lines]
   page_start=max(0.,page[0][1]-lead,previous_page_end,opening_bar_end if page_pos==0 else 0.)
   sung_ends=[line_sung_end(item[0],item[2]) for item in page]
   last_word_end=max(sung_ends)
   this_fade=final_fade if page_pos+flow_lines>=len(parsed) else flow_fade_out
   page_end=max(page_start+.03,last_word_end)+flow_hold+this_fade/1000.
   page_fade_in=min(flow_fade_in,int((page_end-page_start)*1000)//3)
   page_fade_out=min(this_fade,int((page_end-page_start)*1000)//2)
   positions=stack_positions([item[3] for item in page]);first_y=positions[0]
   for row,(idx,a,b,lyric) in enumerate(page):
    y=positions[row];sung_end=max(a+.02,sung_ends[row])
    if a>page_start:
     dialogue_flow(page_start,min(a,page_end),'Next',plain_text(lyric),y,1,page_fade_in,0,True)
    active_start=max(page_start,a)
    if page_end>active_start:
     dialogue_flow(active_start,page_end,'Active',word_text(idx,active_start,sung_end,lyric),y,3,page_fade_in if active_start==page_start else 0,page_fade_out)
   previous_page_end=page_end
  add_opening_progress_bar()
  add_silence_progress_bars()
  Path(filename).write_text(''.join(out),encoding='utf-8-sig')
  return
 # Each line owns a disjoint time slot ending when the next starts.
 # The upcoming line is exclusively the following line, never an independently active third row.
 for pos,(idx,a,b,text) in enumerate(parsed):
  previous_end=min(parsed[pos-1][2],a) if pos else 0.
  next_start=parsed[pos+1][1] if pos+1<len(parsed) else float('inf')
  slot_start=max(0.,a-lead,previous_end,opening_bar_end if pos==0 else 0.)
  slot_end=min(b,next_start)
  if slot_end<=slot_start:continue
  if ahead and pos+1<len(parsed):
   pair_positions=stack_positions([text,parsed[pos+1][3]]);active_y,next_y=pair_positions
   if mode=='alternating' and pos%2:active_y,next_y=next_y,active_y
  else:active_y=center_y;next_y=bottom_y
  if slot_start<a:add(slot_start,min(a,slot_end),'Active',plain_text(text),1,active_y)
  if slot_end>a:add(a,slot_end,'Active',word_text(idx,a,b,text),1,active_y)
  if ahead and pos+1<len(parsed):
   next_text=parsed[pos+1][3]
   add(slot_start,slot_end,'Next',plain_text(next_text),0,next_y)
 add_opening_progress_bar()
 add_silence_progress_bars()
 Path(filename).write_text(''.join(out),encoding='utf-8-sig')

def run_command(command,emit,cwd=None):
 emit('Starting: '+Path(str(command[0])).name)
 flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
 process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,text=True,encoding='utf-8',errors='replace',bufsize=1,cwd=cwd,creationflags=flags)
 tail=[]
 for line in process.stdout:
  line=line.strip()
  if line:
   tail.append(line);tail=tail[-20:]
   if 'time=' in line or 'error' in line.lower() or 'separat' in line.lower() or 'model' in line.lower():emit(line[:180])
 code=process.wait()
 if code:raise RuntimeError(f'Process exited with code {code}: '+ '\n'.join(tail[-12:]))
 return tail

def workflow_begin(project, origin='song selected', now=None):
 if 'workflow_timing' not in project:
  project['workflow_timing']={'started_at':time.time() if now is None else now,
   'origin':origin,'first_export_at':None,'runs':[],'milestones':{}}
 return project['workflow_timing']

def workflow_elapsed(project, now=None):
 clock=project.get('workflow_timing')
 if not clock:return 0.
 end=clock.get('first_export_at')
 if end is None:end=time.time() if now is None else now
 return max(0.,float(end)-float(clock['started_at']))

def workflow_duration(seconds):
 seconds=max(0,int(seconds));return f'{seconds//3600:02d}:{seconds//60%60:02d}:{seconds%60:02d}'

def workflow_milestone(project, name, now=None):
 clock=workflow_begin(project,'tracking started',now)
 if name not in clock['milestones']:
  clock['milestones'][name]=max(0.,(time.time() if now is None else now)-clock['started_at'])

def sync_review_colors(project, line_index):
 key=str(line_index)
 status=project.get('alignment_status',{}).get(key,'unknown')
 if project.get('manual_overrides',{}).get(key,False):status='manual'
 return {
  'aligned':('#17362d','#dae4f8','#77d4b0'),
  'partial':('#493819','#ffe4a3','#ffce72'),
  'estimated':('#492536','#ffd1da','#ff8c9d'),
  'failed':('#4a2027','#ffd0d0','#ff6868'),
  'manual':('#153e3b','#b5fff1','#66dfc7'),
 }.get(status,('#101a2f','#dae4f8','#77d4b0' if status=='aligned' else '#a8c5de'))

class LyricWordDelegate(QStyledItemDelegate):
 """Render word selection in its lyric row without changing the underlying lyrics."""
 def sizeHint(self,option,index):
  # Compact one-line lyric rows; keep the font and word hit testing unchanged.
  from PySide6.QtCore import QSize
  return QSize(0,34)
 def paint(self,painter,option,index):
  owner=self.parent()
  text=str(index.data(Qt.DisplayRole) or '')
  selected=index.row()==owner.currentRow()
  painter.save()
  painter.setClipRect(option.rect)
  project=getattr(owner.window(),'project',{})
  bg,fg,accent=sync_review_colors(project,index.row())
  status=project.get('alignment_status',{}).get(str(index.row()),'unknown')
  if project.get('manual_overrides',{}).get(str(index.row()),False):status='manual'
  row_bg=QColor('#101a2f');row_fg='#e2eafa'
  if status in ('partial','estimated'):
   # Blend the original solid shade 80% with the neutral background 20%.
   row_bg=QColor('#3e321d' if status=='partial' else '#3e2335')
   row_fg=fg
   painter.fillRect(option.rect,row_bg.lighter(145) if selected else row_bg)
  else:
   painter.fillRect(option.rect,row_bg.lighter(140) if selected else row_bg)
   if status!='aligned':
    tint=QColor(accent);tint.setAlpha(38 if selected else 18)
    painter.fillRect(option.rect,tint)
  painter.fillRect(QRectF(option.rect.left(),option.rect.top(),4,option.rect.height()),QColor(accent))
  if selected:
   painter.setPen(QPen(QColor('#ffffff'),1));painter.drawRect(option.rect.adjusted(0,0,-1,-1))
  painter.setFont(option.font)
  fm=option.fontMetrics
  x=option.rect.left()+8
  baseline=option.rect.top()+(option.rect.height()+fm.ascent()-fm.descent())//2
  prefix,words=owner.split_display_text(text)
  prefix_width=fm.horizontalAdvance(prefix)
  painter.setPen(QColor(row_fg))
  painter.drawText(x,baseline,prefix)
  x+=prefix_width
  active=owner.active_word if index.row()==owner.active_row else -1
  for i,word in enumerate(words):
   if i:
    x+=fm.horizontalAdvance(' ')
   w=fm.horizontalAdvance(word)
   if i==active:
    painter.fillRect(QRectF(x-2,option.rect.top()+3,w+4,max(2,option.rect.height()-6)),QColor('#f1c15b'))
    painter.setPen(QColor('#142037'))
   else:painter.setPen(QColor(row_fg))
   painter.drawText(x,baseline,word)
   x+=w
  painter.restore()

class LyricWordList(QListWidget):
 """Clickable lyric words: the same font metrics drive drawing and hit testing."""
 wordClicked=Signal(int,int)
 wordDoubleClicked=Signal(int,int)
 lineDoubleClicked=Signal(int)
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs)
  self.active_row=-1;self.active_word=-1
  self.setItemDelegate(LyricWordDelegate(self))
  self.setMouseTracking(True)
 def split_display_text(self,text):
  """Find the actual lyric suffix. Manual rows contain no time separator."""
  marker=text.find('   ')
  if marker>=0:
   return text[:marker+3],re.findall(r'\S+',text[marker+3:])
  # All manual/review status rows have a closing bracket before their lyric.
  status_end=text.find('] ')
  if status_end>=0:
   prefix=text[:status_end+2]
   return prefix,re.findall(r'\S+',text[status_end+2:])
  return '',re.findall(r'\S+',text)
 def word_at_position(self,pos):
  row=self.indexAt(pos).row()
  if row<0:return -1,-1
  item=self.item(row)
  if item is None:return -1,-1
  rect=self.visualItemRect(item)
  prefix,words=self.split_display_text(item.text())
  fm=self.fontMetrics()
  x=rect.left()+8+fm.horizontalAdvance(prefix)
  click_x=pos.x()
  for i,word in enumerate(words):
   if i:x+=fm.horizontalAdvance(' ')
   width=fm.horizontalAdvance(word)
   if x-2<=click_x<=x+width+2:return row,i
   x+=width
  return row,-1
 def set_active_word(self,row,word):
  old=self.active_row
  self.active_row=int(row);self.active_word=int(word)
  for i in {old,self.active_row}:
   if 0<=i<self.count():self.viewport().update(self.visualItemRect(self.item(i)))
 def mousePressEvent(self,event):
  row,word=self.word_at_position(event.pos()) if event.button()==Qt.LeftButton else (-1,-1)
  super().mousePressEvent(event)
  if row>=0 and word>=0:self.wordClicked.emit(row,word)
 def mouseDoubleClickEvent(self,event):
  if event.button()!=Qt.LeftButton:return super().mouseDoubleClickEvent(event)
  row,word=self.word_at_position(event.pos())
  if row<0:return
  # Do not call QListWidget's double-click handler: it plays the entire line.
  if word>=0:self.wordDoubleClicked.emit(row,word)
  else:self.lineDoubleClicked.emit(row)
  event.accept()

class Timeline(QWidget):
 viewRangeChanged=Signal(float)
 changed=Signal(int,float,float)
 sharedBoundaryChanged=Signal(int,float)
 selectedChanged=Signal()
 wordActivated=Signal(int,int)
 groupShiftRequested=Signal(float)
 wordDoubleClicked=Signal(int,int)
 playRequested=Signal(float)
 dragFinished=Signal()
 seekRequested=Signal(float)
 scrubStarted=Signal(float)
 scrubMoved=Signal(float)
 scrubEnded=Signal(float)
 def __init__(self):
  super().__init__();self.words=[];self.multi_selected=set();self.group_drag_origin=None;self.group_last_delta=0.;self.all_words=[];self.show_all_words=True;self.active_line=0;self.selected=0;self.drag=None;self.shared_pair=None;self.shared_origin=None;self.hover_shared=None;self.duration=8.0
  self.view_start=0.0;self.view_end=8.0;self.playhead=0.0;self.peaks=[];self.detail_peaks=[];self.adaptive_detail=None;self.wave_style='high_detail';self.song_duration=0.0
  self.pan_origin=None;self.pan_moved=False;self.scrubbing=False;self.snap_enabled=False;self.mode="hand";self.space_hand=False;self.locked=set();self.setCursor(Qt.OpenHandCursor)
  self.setMinimumHeight(135);self.setFocusPolicy(Qt.StrongFocus);self.setMouseTracking(True)
 def set_mode(self,mode):
  self.mode=mode;self.setCursor(Qt.OpenHandCursor if mode=="hand" else Qt.ArrowCursor);self.update()
 def set_waveform(self,peaks,duration):
  self.peaks=peaks;self.song_duration=duration;self.adaptive_detail=None;self.update()
 def set_detail_waveform(self,detail):
  self.detail_peaks=list(detail);self.adaptive_detail=None;self.update()
 def set_adaptive_detail(self,start,end,envelopes):
  self.adaptive_detail=(float(start),float(end),envelopes);self.update()
 def set_wave_style(self,style):
  self.wave_style=style if style in ('classic','high_detail') else 'classic';self.update()
 def set_words(self,words):
  self.words=words;self.selected=min(self.selected,max(0,len(words)-1))
  self.multi_selected={i for i in self.multi_selected if i<len(words)}
  self.update()
 def set_all_words(self,words,active_line=None):
  self.all_words=list(words)
  if active_line is not None:self.active_line=int(active_line)
  self.update()
 def set_show_all_words(self,enabled):
  self.show_all_words=bool(enabled);self.update()
 def set_active_line(self,line):
  self.active_line=int(line);self.update()
 def displayed_words(self):
  return self.all_words if self.show_all_words and self.all_words else [(a,b,word,self.active_line,i) for i,(a,b,word) in enumerate(self.words)]
 def word_at(self,x,y):
  """Return the visible word under the pointer, including other lyric lines."""
  h=self.height()
  if not (h-88<=y<=h-20):return None
  hits=[]
  for entry in self.displayed_words():
   start,end,_word,_line,_index=entry;left=self.x_for(float(start));right=self.x_for(float(end))
   if right<24 or left>self.width()-24:continue
   if left-5<=x<=right+5:hits.append(entry)
  if not hits:return None
  return min(hits,key=lambda entry:abs(x-(self.x_for(float(entry[0]))+self.x_for(float(entry[1])))/2))
 def show_range(self,a,b):
  a=max(0.0,float(a));b=max(a+0.3,float(b));self.view_start=a;self.view_end=b;self.update();self.viewRangeChanged.emit(b-a)
 def zoom(self,factor):
  current=max(.3,self.view_end-self.view_start)
  span=max(.35,min(120.0,current*factor))
  # Anchor the selected word 25% from the left while zooming, including
  # slider-driven zoom. Use the playhead if no valid word is selected.
  if self.words and 0<=self.selected<len(self.words):
   a,b,_=self.words[self.selected];anchor=(float(a)+float(b))/2
  else:anchor=float(self.playhead)
  if not math.isfinite(anchor):anchor=self.view_start
  start=max(0.0,anchor-.25*span)
  if self.song_duration>0:start=min(start,max(0.0,self.song_duration-span))
  self.show_range(start,start+span)
 def x_for(self,t):return 24+(self.width()-48)*(t-self.view_start)/max(.001,self.view_end-self.view_start)
 def t_for(self,x):return self.view_start+(x-24)*max(.001,self.view_end-self.view_start)/max(1,self.width()-48)
 def neighbor_limits(self,word_index):
  """Return chronological word boundaries surrounding the active word."""
  entries=sorted(self.all_words,key=lambda entry:(float(entry[0]),float(entry[1]),int(entry[3]),int(entry[4])))
  position=next((i for i,entry in enumerate(entries) if int(entry[3])==self.active_line and int(entry[4])==word_index),None)
  if position is None:
   return (float(self.words[word_index-1][1]) if word_index>0 else 0.0,
           float(self.words[word_index+1][0]) if word_index+1<len(self.words) else None)
  previous_end=max((float(entry[1]) for entry in entries[:position]),default=0.0)
  next_start=min((float(entry[0]) for entry in entries[position+1:]),default=None)
  return previous_end,next_start
 def constrain_word(self,word_index,a,b,operation='both'):
  """Keep an edited word between its neighbors; touching is allowed, overlap is not."""
  a=max(0.0,float(a));b=max(a+.02,float(b));previous_end,next_start=self.neighbor_limits(word_index)
  lower=max(0.0,previous_end)
  upper=float(next_start) if next_start is not None else max(b,self.song_duration or b)
  if upper<lower+.02:return float(self.words[word_index][0]),float(self.words[word_index][1])
  if operation=='move':
   length=min(b-a,upper-lower);a=max(lower,min(upper-length,a));b=a+length
  elif operation=='start':a=max(lower,min(b-.02,a));b=min(upper,b)
  elif operation=='end':a=max(lower,a);b=max(a+.02,min(upper,b))
  else:
   a=max(lower,min(upper-.02,a));b=max(a+.02,min(upper,b))
  return a,b
 def shared_boundary_candidates(self):
  """Only consecutive words in the current lyric line; never infer a link from pixels."""
  if self.mode!='edit':return []
  candidates=[]
  for i in range(len(self.words)-1):
   try:
    a,b,_=self.words[i];c,d,_=self.words[i+1]
    b=float(b);c=float(c)
    # Actual timestamps, not the drawn word-box distance.
    if abs(c-b)<=.05 and float(a)+.02<=min(b,c) and max(b,c)+.02<=float(d):
     candidates.append((i,self.x_for((b+c)/2)))
   except (ValueError,TypeError,IndexError):pass
  return candidates
 def shared_boundary_hit(self,x,y):
  # Dedicated grip above the two word boxes, avoiding their ordinary edge handles.
  if not (self.height()-110<=y<=self.height()-84):return None
  hits=[(abs(x-pos),i) for i,pos in self.shared_boundary_candidates() if abs(x-pos)<=11]
  return min(hits)[1] if hits else None
 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);p.fillRect(self.rect(),QColor('#101a2f'))
  w=self.width();h=self.height();span=self.view_end-self.view_start
  for i in range(9):
   t=self.view_start+span*i/8;x=self.x_for(t)
   p.setPen(QPen(QColor('#2c3d5c'),1));p.drawLine(int(x),23,int(x),h-14)
   p.setPen(QColor('#9badcb'));p.drawText(int(x)+3,17,f'{t:.1f}s')
  if self.wave_style=='high_detail' and self.detail_peaks and self.song_duration:
   # Draw PCM min/max per screen column, recomputed from the available
   # signed sample envelopes (never scale a pre-rendered waveform image).
   # An automatically selected 1000 peaks/s gives fine display resolution.
   xleft=24;xright=max(xleft+1,w-24)
   # Prefer freshly decoded 48 kHz visible-window PCM over the song-wide
   # 12 kHz envelope. Never stretch or interpolate a bitmap.
   use_adaptive=(self.adaptive_detail is not None and
                 self.adaptive_detail[0]<=self.view_start+0.001 and
                 self.adaptive_detail[1]>=self.view_end-0.001 and
                 bool(self.adaptive_detail[2]))
   if use_adaptive:
    source_start,source_end,detail=self.adaptive_detail
   else:
    source_start,source_end,detail=0.,self.song_duration,self.detail_peaks
   count=len(detail);step=max(.0000001,(source_end-source_start)/count)
   baseline=(35.0+h-90.0)/2
   halfheight=max(14.,(h-125.)/2.)
   envelopes=[]
   for x in range(xleft,xright):
    ia=max(0,min(count-1,int((self.t_for(x)-source_start)/step)))
    ib=max(ia+1,min(count,int((self.t_for(x+1)-source_start)/step)+1))
    chunk=detail[ia:ib]
    envelopes.append((min(v[0] for v in chunk),max(v[1] for v in chunk)))
   amplitudes=sorted(max(abs(lo),abs(hi)) for lo,hi in envelopes if max(abs(lo),abs(hi))>.001)
   ref=amplitudes[min(len(amplitudes)-1,int(.95*len(amplitudes)))] if amplitudes else 1.0
   gain=1.0/max(.04,ref)
   p.fillRect(QRectF(xleft,35.,xright-xleft,max(1.,h-125.)),QColor('#03060b'))
   p.setPen(QPen(QColor('#24507a'),1))
   p.drawLine(xleft,int(baseline),xright,int(baseline))
   p.setPen(QPen(QColor('#169dff'),1))
   for j,(lo,hi) in enumerate(envelopes):
    topy=baseline-min(1.,max(0.,hi*gain))*halfheight
    bottomy=baseline-min(1.,max(0.,-lo*gain))*-halfheight
    p.drawLine(xleft+j,int(round(topy)),xleft+j,int(round(bottomy)))
  elif self.peaks and self.song_duration:
   # Large single-sided waveform, inspired by the reference editor.
   # Auto-gain uses the visible range so quiet recordings remain readable.
   # Word blocks are drawn separately beneath the waveform baseline.
   step=self.song_duration/len(self.peaks)
   xleft=24;xright=max(xleft+1,w-24)
   amplitudes=[]
   for x in range(xleft,xright):
    ia=max(0,int(self.t_for(x)/step))
    ib=min(len(self.peaks),max(ia+1,int(self.t_for(x+1)/step)+1))
    amplitudes.append(max(self.peaks[ia:ib],default=0.0) if ia<len(self.peaks) else 0.0)
   nonzero=sorted(v for v in amplitudes if v>0.001)
   # Use the 95th percentile rather than the absolute max; isolated clicks
   # shouldn't make the rest of the waveform look tiny.
   reference=nonzero[min(len(nonzero)-1,int(len(nonzero)*.95))] if nonzero else 1.0
   gain=1.0/max(.04,reference)
   baseline=h-90.0
   top=35.0
   available=max(20.0,baseline-top)
   from PySide6.QtGui import QPainterPath,QLinearGradient
   shape=QPainterPath();shape.moveTo(float(xleft),float(baseline))
   for j,amp in enumerate(amplitudes):
    height=min(available,amp*gain*available*.96)
    shape.lineTo(float(xleft+j),float(baseline-height))
   shape.lineTo(float(xright-1),float(baseline));shape.closeSubpath()
   gradient=QLinearGradient(0,top,0,baseline)
   gradient.setColorAt(0,QColor('#a46aff'))
   gradient.setColorAt(1,QColor('#6b3bb5'))
   p.setPen(Qt.NoPen);p.setBrush(gradient);p.drawPath(shape)
   p.setPen(QPen(QColor('#a579ed'),1));p.drawLine(xleft,int(baseline),xright,int(baseline))
  else:
   p.setPen(QColor('#8796b8'));p.drawText(30,int(h*.32),'Waveform appears after loading audio (FFmpeg or WAV)')
  project=getattr(self.window(),'project',{})
  for line_index,(a,b,_text) in enumerate(project.get('events',[])):
   left=max(24.,self.x_for(float(a)));right=min(w-24.,self.x_for(float(b)))
   if right<=left:continue
   bg,fg,accent=sync_review_colors(project,line_index)
   tint=QColor(accent);tint.setAlpha(24)
   p.fillRect(QRectF(left,26,right-left,max(2,h-116)),tint)
   p.fillRect(QRectF(left,26,right-left,5),QColor(accent))
  for start,end,word,line_index,word_index in self.displayed_words():
   x1=self.x_for(float(start));x2=self.x_for(float(end))
   if x2<24 or x1>w-24:continue
   rect=QRectF(max(24,x1),h-78.0,max(3,min(w-24,x2)-max(24,x1)),48)
   selected=line_index==self.active_line and (word_index==self.selected or word_index in self.multi_selected)
   active=line_index==self.active_line
   bg,fg,accent=sync_review_colors(project,line_index)
   p.setPen(QPen(QColor('#ffffff') if selected else QColor(accent),3 if selected else 2 if active else 1))
   p.setBrush(QColor(bg).lighter(170 if selected else 135 if active else 115));p.drawRoundedRect(rect,5,5)
   p.setPen(QColor('#ffffff'));p.drawText(rect.adjusted(3,0,-3,0),Qt.AlignCenter,str(word)[:18])
   if selected:
    # Large visible grab bars match the enlarged invisible edge hit targets.
    for n,(xpos,color) in enumerate(((max(24,x1),'#52e0ad'),(min(w-24,x2),'#ffc071'))):
     # Short words: offset grips vertically, without changing actual timing.
     yoffset=(-13 if n==0 else 13) if x2-x1<28 else 0
     handle=QRectF(xpos-6,h-84+yoffset,12,60)
     p.setPen(QPen(QColor('#ffffff'),1));p.setBrush(QColor(color));p.drawRoundedRect(handle,4,4)
  # Dedicated linked divider: above the blocks so individual edge grips stay usable.
  if self.mode=='edit':
   for pair,xpos in self.shared_boundary_candidates():
    if not (28<=xpos<=w-28):continue
    highlighted=(pair==self.hover_shared or pair==self.shared_pair)
    grip=QRectF(xpos-7,h-108,14,20)
    p.setPen(QPen(QColor('#e9fff6') if highlighted else QColor('#8ee9cb'),1.5))
    p.setBrush(QColor('#20bd8f') if highlighted else QColor('#237d70'))
    p.drawRoundedRect(grip,4,4)
    p.setPen(QPen(QColor('#ffffff'),1))
    p.drawLine(int(xpos-2),int(h-103),int(xpos-2),int(h-94))
    p.drawLine(int(xpos+2),int(h-103),int(xpos+2),int(h-94))
  # Start/end guides use SAVED timings, not inferred waveform peaks.
  if self.words and 0 <= self.selected < len(self.words):
   start,end,word=self.words[self.selected]
   xa=self.x_for(float(start));xb=self.x_for(float(end))
   xa=max(24,min(w-24,xa));xb=max(24,min(w-24,xb))
   if xb>xa:
    p.fillRect(QRectF(xa,26,xb-xa,max(2,h-112)),QColor(66,157,245,32))
   for xpos,color,text in ((xa,'#52e0ad',f'START {float(start):.3f}s'),(xb,'#ffc071',f'END {float(end):.3f}s')):
    if 24 <= xpos <= w-24:
     p.setPen(QPen(QColor(color),2));p.drawLine(int(xpos),25,int(xpos),h-20)
     p.setPen(QColor(color))
     p.drawText(int(max(26,min(w-125,xpos+4))),int(h-8),text)
  x=self.x_for(self.playhead)
  if 24<=x<=w-24:
   p.setPen(QPen(QColor('#fbbf71'),2));p.drawLine(int(x),25,int(x),h-12)
  p.end()
 def scrub_at(self,x):
  at=max(0.,min(self.song_duration or self.view_end,self.t_for(max(24.,min(self.width()-24.,float(x))))))
  self.playhead=at;self.update();return at
 def mousePressEvent(self,e):
  self.setFocus()
  x=e.position().x();h=self.height()
  if e.button()!=Qt.LeftButton:return
  # Editing handles always win over playback gestures. This restores the green
  # shared-boundary grip even when the orange playhead crosses the same X position.
  pair=self.shared_boundary_hit(x,e.position().y())
  if pair is not None:
   self.shared_pair=pair
   self.shared_origin=(self.t_for(x),float(self.words[pair][1]),float(self.words[pair+1][0]))
   self.drag='shared';self.selected=pair
   self.selectedChanged.emit();self.update();e.accept();return
  # Only the orange playhead itself starts audio scrubbing. The previous version
  # treated the ENTIRE waveform as a scrub target, stealing hand-tool panning.
  # Limit hit-testing to the waveform region, not the word boxes or edit handles.
  waveform_area=25 <= e.position().y() < h-90
  near_playhead=abs(x-self.x_for(self.playhead))<=11 and 24<=x<=self.width()-24
  if waveform_area and near_playhead and not (e.modifiers() & Qt.ShiftModifier):
   self.scrubbing=True;self.setCursor(Qt.SizeHorCursor)
   self.scrubStarted.emit(self.scrub_at(x));e.accept();return
  hit=self.word_at(x,e.position().y())
  if hit is not None:
   start,end,_word,line_index,word_index=hit
   if line_index!=self.active_line:self.multi_selected.clear()
   self.active_line=line_index
   mods=e.modifiers()
   if mods & Qt.ControlModifier:
    if word_index in self.multi_selected:self.multi_selected.remove(word_index)
    else:
     if not self.multi_selected and 0<=self.selected<len(self.words):self.multi_selected.add(self.selected)
     self.multi_selected.add(word_index)
    self.selected=word_index
    self.wordActivated.emit(line_index,word_index)
    self.selectedChanged.emit();self.update();e.accept();return
   if mods & Qt.ShiftModifier:
    anchor=self.selected if 0<=self.selected<len(self.words) else word_index
    self.multi_selected.update(range(min(anchor,word_index),max(anchor,word_index)+1))
    self.selected=word_index
    self.wordActivated.emit(line_index,word_index)
    self.selectedChanged.emit();self.update();e.accept();return
   if word_index not in self.multi_selected:self.multi_selected={word_index}
   self.selected=word_index
   self.wordActivated.emit(line_index,word_index)
   if word_index in self.locked:self.selectedChanged.emit();self.update();return
   if len(self.multi_selected)>1:
    self.drag='group';self.group_drag_origin=self.t_for(x);self.group_last_delta=0.
    self.selectedChanged.emit();self.update();e.accept();return
   left=self.x_for(float(start));right=self.x_for(float(end));edge_radius=20
   left_distance=abs(x-left);right_distance=abs(x-right)
   if min(left_distance,right_distance)<=edge_radius:self.drag='start' if left_distance<=right_distance else 'end'
   else:self.drag='move'
   self.origin=(self.t_for(x),float(start),float(end));self.selectedChanged.emit();self.update();e.accept();return
  if self.mode=="hand" or (e.modifiers() & Qt.ShiftModifier) or e.position().y()<h-90.0:
   self.pan_origin=(x,self.view_start,self.view_end);self.pan_moved=False
   self.setCursor(Qt.ClosedHandCursor);e.accept();return
  for i,(a,b,_) in enumerate(self.words):
   l=self.x_for(a);r=self.x_for(b)
   if l-7<=x<=r+7 and e.position().y()<h-78.0+55:
    if i in self.locked:return
    self.selected=i;self.drag='start' if abs(x-l)<10 else 'end' if abs(x-r)<10 else 'move'
    self.origin=(self.t_for(x),a,b);self.selectedChanged.emit();self.update();return
 def mouseMoveEvent(self,e):
  if self.scrubbing:
   self.scrubMoved.emit(self.scrub_at(e.position().x()));e.accept();return
  if self.pan_origin is not None:
   x0,start,end=self.pan_origin
   delta=e.position().x()-x0
   if abs(delta)>=3:self.pan_moved=True
   if self.pan_moved:
    span=end-start;shift=-delta*span/max(1,self.width()-48)
    limit=max(span,self.song_duration) if self.song_duration>0 else max(span,end)
    new_start=max(0.0,min(max(0.0,limit-span),start+shift))
    self.show_range(new_start,new_start+span)
   e.accept();return
  if self.drag is None:
   new_hover=self.shared_boundary_hit(e.position().x(),e.position().y())
   if new_hover!=self.hover_shared:self.hover_shared=new_hover;self.update()
   if new_hover is not None:
    self.setCursor(Qt.SizeHorCursor);e.accept();return
   hit=self.word_at(e.position().x(),e.position().y())
   if hit is not None:
    left=self.x_for(float(hit[0]));right=self.x_for(float(hit[1]))
    self.setCursor(Qt.SizeHorCursor if min(abs(e.position().x()-left),abs(e.position().x()-right))<=20 else Qt.PointingHandCursor)
   else:self.setCursor(Qt.OpenHandCursor if self.mode=='hand' else Qt.ArrowCursor)
   return
  if self.drag=='shared' and self.shared_pair is not None and self.shared_origin is not None:
   i=self.shared_pair;old_t,old_end,old_start=self.shared_origin
   # Both sides take the SAME new boundary; a small pre-existing gap/overlap closes.
   target=(old_end+old_start)/2+self.t_for(e.position().x())-old_t
   low=float(self.words[i][0])+.02
   high=float(self.words[i+1][1])-.02
   # Respect adjacent words beyond this pair without changing their timings.
   if i+2<len(self.words):high=min(high,float(self.words[i+2][0]))
   if i>0:low=max(low,float(self.words[i-1][1]))
   if high>=low:
    self.sharedBoundaryChanged.emit(i,round(max(low,min(high,target)),3))
   e.accept();return
  if self.drag=='group':
   absolute=self.t_for(e.position().x())-self.group_drag_origin
   increment=round(absolute-self.group_last_delta,3)
   if abs(increment)>=.001:
    # Clamp requested delta before emission so a rejected move never corrupts drag tracking.
    selected=[i for i in self.multi_selected if 0<=i<len(self.words)]
    if not selected and 0<=self.selected<len(self.words):selected=[self.selected]
    if selected:
     minimum=min(float(self.words[i][0]) for i in selected)
     increment=max(increment,round(-minimum,3))
    if abs(increment)>=.001:
     self.groupShiftRequested.emit(increment)
     self.group_last_delta+=increment
   e.accept();return
  i=self.selected;old_t,a,b=self.origin;delta=self.t_for(e.position().x())-old_t
  if self.drag=='start':a=max(0,min(b-.02,a+delta))
  elif self.drag=='end':b=max(a+.02,b+delta)
  else:
   length=b-a;a=max(0,a+delta);b=a+length
  previous_end,next_start=self.neighbor_limits(i)
  if self.snap_enabled:
   tolerance=9*max(.001,self.view_end-self.view_start)/max(1,self.width()-48)
   candidates=[]
   if self.drag in ('start','move'):candidates.append((abs(a-previous_end),previous_end-a))
   if next_start is not None and self.drag in ('end','move'):candidates.append((abs(b-next_start),next_start-b))
   if candidates:
    distance,shift=min(candidates)
    if distance<=tolerance:
     if self.drag=='start':a+=shift
     elif self.drag=='end':b+=shift
     else:a+=shift;b+=shift
  a,b=self.constrain_word(i,a,b,self.drag)
  self.changed.emit(i,round(a,3),round(b,3))
 def mouseReleaseEvent(self,e):
  if self.scrubbing:
   self.scrubbing=False;self.scrubEnded.emit(self.scrub_at(e.position().x()))
   self.setCursor(Qt.OpenHandCursor if self.mode=='hand' else Qt.ArrowCursor)
   e.accept();return
  if self.pan_origin is not None:
   x0,start,end=self.pan_origin
   if not self.pan_moved:self.seekRequested.emit(max(0,self.t_for(e.position().x())))
   self.pan_origin=None;self.pan_moved=False;self.setCursor(Qt.OpenHandCursor)
   e.accept();return
  if self.drag is not None:
   self.drag=None;self.shared_pair=None;self.shared_origin=None;self.group_drag_origin=None
   self.dragFinished.emit()
  super().mouseReleaseEvent(e)
 def mouseDoubleClickEvent(self,e):
  """Select a visible word and request playback of only that word."""
  if e.button()!=Qt.LeftButton:return super().mouseDoubleClickEvent(e)
  hit=self.word_at(e.position().x(),e.position().y())
  if hit is None:
   at=max(0.0,min(self.song_duration or self.view_end,self.t_for(e.position().x())))
   self.playRequested.emit(at);e.accept();return
  _start,_end,_word,line_index,word_index=hit
  self.active_line=line_index;self.selected=word_index
  self.wordActivated.emit(line_index,word_index)
  self.wordDoubleClicked.emit(line_index,word_index)
  self.selectedChanged.emit();self.update();e.accept()
 def wheelEvent(self,e):
  steps=e.angleDelta().y()/120.0
  if not steps:
   e.ignore();return
  if e.modifiers() & Qt.ControlModifier:
   # Use the same selected-word/playhead anchor as the zoom buttons and
   # slider, rather than zooming away from the highlighted word.
   self.zoom(.75**steps)
  else:
   span=self.view_end-self.view_start
   shift=span*(-.12*steps)
   a=max(0,min(max(0,self.song_duration-span),self.view_start+shift))
   self.show_range(a,a+span)
  e.accept()

class SongOverview(QWidget):
 selectedTime=Signal(float)
 def __init__(self,editor):
  super().__init__();self.editor=editor;self.setFixedHeight(38);self.setToolTip('Entire song: click a lyric region to navigate')
 def paintEvent(self,event):
  p=QPainter(self);p.fillRect(self.rect(),QColor('#17243d'))
  duration=max(.001,self.editor.song_duration)
  w=max(1,self.width()-24);h=self.height()
  # Compact full-song overview: a thin 8-pixel track, matching lyric marker height.
  p.fillRect(QRectF(12,4,w,8),QColor('#865bc5'))
  owner=self.window()
  events=getattr(owner,'project',{}).get('events',[])
  for i,(a,b,_) in enumerate(events):
   x=12+w*max(0,float(a))/duration;right=12+w*min(duration,float(b))/duration
   _bg,_fg,accent=sync_review_colors(getattr(owner,'project',{}),i)
   marker=QRectF(x,19,max(1,right-x),8)
   p.fillRect(marker,QColor(accent))
   if i==getattr(owner,'row',-1):
    p.setPen(QPen(QColor('#ffffff'),2));p.setBrush(Qt.NoBrush);p.drawRect(marker)
  a=12+w*self.editor.view_start/duration;b=12+w*self.editor.view_end/duration
  p.setPen(QPen(QColor('#f6e7ff'),2));p.setBrush(Qt.NoBrush);p.drawRect(QRectF(a,2,max(2,b-a),27))
  p.setPen(QColor('#c1cde4'));p.drawText(12,h-2,'00:00');p.drawText(max(0,self.width()-90),h-2,f'{duration:.0f}s')
  p.end()
 def mousePressEvent(self,e):
  if e.button()!=Qt.LeftButton:return
  duration=self.editor.song_duration
  if duration<=0:return
  t=max(0,min(duration,(e.position().x()-12)/max(1,self.width()-24)*duration))
  self.selectedTime.emit(t)

class RoutedStatus(QLabel):
 def __init__(self, owner, message):
  super().__init__(message)
  self.owner=owner
 def setText(self, message):
  super().setText(str(message))
  if hasattr(self.owner,'activity_title'):
   self.owner.show_status_at_top(str(message))




class PcmScrubLoader(QThread):
 """Decode separated WAV stems off the GUI thread; no project data is modified."""
 ready=Signal(object,str)
 def __init__(self,vocals,instrumental):
  super().__init__();self.paths=(vocals,instrumental)
 def run(self):
  try:
   import numpy as np
   import soundfile as sf
   import sounddevice as sd
   outputs=[];rate=None
   for path in self.paths:
    if not path or not Path(path).is_file():
     outputs.append(None);continue
    samples,sample_rate=sf.read(str(path),dtype='float32',always_2d=True)
    if rate is not None and sample_rate!=rate:
     raise RuntimeError('Vocal and instrumental sample rates differ; regenerate both stems together.')
    rate=sample_rate
    outputs.append(np.ascontiguousarray(samples))
   if outputs[0] is None:raise RuntimeError('An isolated vocals WAV is required for professional scrubbing.')
   self.ready.emit((outputs,rate),'')
  except Exception as exc:self.ready.emit(None,str(exc))


class PcmScrubEngine:
 """PCM cursor follows signed mouse velocity; output never uses QMediaPlayer seeks.

 Position is sampled at individual source sample indices, forward or reverse.
 Device buffering and operating system scheduling prevent guaranteed zero latency.
 """
 def __init__(self,arrays,rate):
  import numpy as np
  import sounddevice as sd
  self.np=np;self.sd=sd;self.arrays=arrays;self.rate=int(rate)
  self.lock=threading.Lock();self.cursor=0.0;self.velocity=0.0
  self.last_move=0.0;self.enabled=False;self.vocals_on=True;self.instrumental_on=False
  self.stream=None;self.last_gain=0.0
 def set_position(self,seconds,velocity=0.0,vocals=True,instrumental=False):
  with self.lock:
   self.cursor=max(0.,float(seconds)*self.rate)
   self.velocity=max(-1.,min(1.,float(velocity)))
   self.last_move=time.monotonic()
   self.vocals_on=bool(vocals);self.instrumental_on=bool(instrumental)
 def start(self):
  if self.stream is None:
   self.stream=self.sd.OutputStream(samplerate=self.rate,channels=2,dtype='float32',
                                    blocksize=256,latency='low',callback=self._callback)
  self.last_gain=0.0
  self.enabled=True
  self.stream.start()
 def stop(self):
  self.enabled=False
  if self.stream is not None:
   try:self.stream.stop()
   except Exception:pass
 def close(self):
  self.stop()
  if self.stream is not None:
   self.stream.close();self.stream=None
 def _callback(self,outdata,frames,time_info,status):
  np=self.np
  with self.lock:
   cursor=self.cursor;velocity=self.velocity
   # Advance through the audio buffer from callback to callback. Previously the
   # same 256 samples repeated each block, causing harsh robotic buzzing.
   if self.enabled and abs(velocity)>0.01:self.cursor=max(0.,cursor+frames*velocity)
   recent=(time.monotonic()-self.last_move)<0.115
   vocals=self.vocals_on;instrumental=self.instrumental_on
  # Silence on a stationary mouse; scrub audio only follows actual movement.
  target_gain=0.70 if self.enabled and recent and abs(velocity)>=0.03 else 0.0
  ramp=np.linspace(self.last_gain,target_gain,frames,endpoint=True,dtype=np.float32)
  self.last_gain=target_gain
  if not np.any(ramp) or not (vocals or instrumental):
   outdata.fill(0);return
  positions=cursor+np.arange(frames,dtype=np.float64)*velocity
  mixed=np.zeros((frames,2),dtype=np.float32)
  count=0
  for active,data in ((vocals,self.arrays[0]),(instrumental,self.arrays[1])):
   if not active or data is None:continue
   length=len(data)
   valid=(positions>=0)&(positions<length-1)
   ix=np.clip(positions.astype(np.int64),0,max(0,length-2))
   frac=(positions-ix).astype(np.float32)
   left=data[ix];right=data[ix+1]
   interp=left+(right-left)*frac[:,None]
   if interp.shape[1]==1:interp=np.repeat(interp,2,axis=1)
   else:interp=interp[:,:2]
   mixed+=np.where(valid[:,None],interp,0.)
   count+=1
  if count>1:mixed*=0.5
  outdata[:]=np.clip(mixed*ramp[:,None],-1,1)

class Main(QMainWindow):
 def __init__(self):
  super().__init__();self.setWindowTitle(f'DeRo Sync {APP_VERSION} (build {APP_BUILD})');self.resize(1260,810);self.setMinimumSize(840,590)
  self.project={'format':'KaraokeStudioProject','version':2,'song':'','artist':'','audio':'','events':[],'word_timings':{},'authoritative_lyrics':'','song_language':'auto','alignment_status':{},'word_scores':{},'manual_overrides':{},'reviewed_lines':{}}
  self.formatting_window=None;self._formatting_update=False;self.last_error='';self.alignment_diagnostics={};self.diagnostic_history=[];self.last_diagnostics_path=None;self.path=None;self.row=0;self.updating=False;self.undo=[];self.redo=[];self.drag_saved=False;self.loop_end=None;self._word_audition=None;self.wave_worker=None;self.loaded_wave_path=None;self.waveform_resolution=1000;self._export_selection_playing=False;self._export_selection_loop=False;self.export_audit_history=[];self._adaptive_worker=None;self._adaptive_pending=None;self._adaptive_key=None;self._adaptive_path=None;self._adaptive_timer=QTimer(self);self._adaptive_timer.setSingleShot(True);self._adaptive_timer.timeout.connect(self.request_adaptive_waveform);self._pending_waveform=None;self.job=None;self._batch_running=False;self._batch_index=-1;self._batch_stage='';self._batch_output=None;self.last_export=None;self.step_failures={};self.step_snapshots={};self.step_timer=None;self.focus_mode=False;self.focus_restore={};self.preview_window=None;self.workspace_layout='Balanced';self.favorite_sites=self.load_favorite_sites();self.app_settings=QSettings('KaraokeMakerLite','KaraokeMakerLite');self.line_view_mode="line";self.saved_signature=None;self._standard_control=None;self._studio_control=None;self._studio_cancel_event=None;self._studio_active_process=None;self._studio_process_lock=threading.Lock();self._studio_close_after_cancel=False
  self.player=QMediaPlayer();self.audio_out=QAudioOutput();self.player.setAudioOutput(self.audio_out);self.audio_out.setVolume(.7)
  # Independent audio stem monitors. The original player remains the transport/time master.
  self.stem_players={};self.stem_outputs={}
  for stem_name in ('vocals','instrumental'):
   stem_player=QMediaPlayer(self);stem_output=QAudioOutput(self)
   stem_player.setAudioOutput(stem_output);stem_output.setVolume(.7)
   self.stem_players[stem_name]=stem_player;self.stem_outputs[stem_name]=stem_output
  self._syncing_stems=False
  # Short, bounded audition clips while dragging. Avoid a free-running transport.
  self._scrub_preview_timer=QTimer(self)
  self._scrub_preview_timer.setSingleShot(True)
  self._scrub_preview_timer.timeout.connect(self._pause_scrub_preview)
  self._scrub_active=False
  self.pcm_scrub=None;self.pcm_loader=None;self._pcm_scrub_last_motion=None;self._pcm_source_key=None;self._pcm_generation=0
  self.player.playbackStateChanged.connect(self.sync_stem_playback)
  self.player.playbackRateChanged.connect(self.sync_stem_speed)
  root=QWidget();self.setCentralWidget(root);outer=QVBoxLayout(root);outer.setContentsMargins(18,14,18,14);outer.setSpacing(12)
  # Two compact rows avoid Qt squeezing labels into unreadable fragments.
  self.app_header=QWidget();header_rows=QVBoxLayout(self.app_header)
  header_rows.setContentsMargins(0,0,0,0);header_rows.setSpacing(6);outer.addWidget(self.app_header)
  head=QHBoxLayout();head.setSpacing(8);header_rows.addLayout(head)
  title=QLabel(f'✦  KARAOKE MAKER LITE · DeRo Sync {APP_VERSION}');title.setStyleSheet('font-size:19px;font-weight:800;color:#d4c7ff');head.addWidget(title);head.addStretch(1)
  head.addWidget(btn('New project',self.new_project));head.addWidget(btn('Open project',self.open_project))
  head.addWidget(btn('Save as…',self.save_as_project));head.addWidget(btn('Save project',self.save_project,True))
  tools_row=QHBoxLayout();tools_row.setSpacing(8);header_rows.addLayout(tools_row)
  tools_row.addWidget(btn('Lyric Formatting & Effects',self.open_lyric_formatting))
  tools_row.addWidget(btn('↶ Undo',self.do_undo));tools_row.addWidget(btn('↷ Redo',self.do_redo))
  tools_row.addWidget(btn('DeRo Benchmark',self.open_dero_benchmark))
  tools_row.addWidget(btn('Sync Inspector',self.show_sync_inspector))
  tools_row.addWidget(btn('Diagnostics',self.save_diagnostics))
  tools_row.addWidget(btn('Diagnostics folder',self.open_diagnostics_folder))
  tools_row.addWidget(btn('🎉 Replay Celebration',self.replay_celebration_test))
  tools_row.addStretch(1)
  self.chrome_toggle_button=btn('Hide project steps ▲',self.toggle_project_navigation)
  self.chrome_toggle_button.setToolTip('Collapse or restore the project name and six-step navigation bar.')
  tools_row.addWidget(self.chrome_toggle_button)
  # Keep the project identity and step navigation in one collapsible container.
  self.project_navigation=QWidget();navigation=QVBoxLayout(self.project_navigation);navigation.setContentsMargins(0,0,0,0);navigation.setSpacing(8);outer.addWidget(self.project_navigation)
  identity=QHBoxLayout();identity.setContentsMargins(0,0,0,0);navigation.addLayout(identity)
  identity.addWidget(QLabel('PROJECT:'))
  self.project_name=QLabel('Untitled Project');self.project_name.setStyleSheet('font-size:14px;font-weight:750;color:#ffffff')
  self.project_name.setMinimumWidth(160);identity.addWidget(self.project_name,1)
  self.project_dirty=QLabel('UNSAVED');self.project_dirty.setStyleSheet('color:#f4c977;font-weight:bold');identity.addWidget(self.project_dirty)
  self.project_identity_layout=identity
  self.tabs=QHBoxLayout();self.tabs.setContentsMargins(0,0,0,0);navigation.addLayout(self.tabs);self.nav_buttons=[]
  self.step_names=['01  SONG','02  SEPARATION','03  LYRICS','04  WORD SYNC','05  VISUALIZER','06  BATCH','07  EXPORT']
  for i,t in enumerate(self.step_names):
   b=btn(t,lambda _,n=i:self.navigate(n));b.setCheckable(True);b.setToolTip('○ Not started');self.tabs.addWidget(b);self.nav_buttons.append(b)

  # Persistent, high-visibility status shared by all five pages.
  activity=QFrame();activity.setObjectName('activityBanner')
  activity.setStyleSheet('QFrame#activityBanner{background:#1b2b46;border:1px solid #485c82;border-radius:9px} QLabel{background:transparent;border:none}')
  activity_layout=QVBoxLayout(activity);activity_layout.setContentsMargins(13,8,13,8);activity_layout.setSpacing(3)
  self.activity_title=QLabel('READY — Import a song to begin')
  self.activity_title.setStyleSheet('font-size:14px;font-weight:700;color:#d9cbff')
  self.activity_detail=QLabel('Processing status, progress and elapsed time will appear here on every tab.')
  self.activity_detail.setStyleSheet('font-size:12px;color:#b9c9e5')
  self.activity_detail.setWordWrap(True)
  celebration_row=QHBoxLayout()
  celebration_row.setContentsMargins(0,0,0,0)
  celebration_row.addWidget(self.activity_title,2)
  self.celebration_effect=DoublePopperCelebration(activity,persistent=True)
  celebration_row.addWidget(self.celebration_effect,3)
  # Shared header grid: stop button stays at the far right and vertically
  # centered within the status header, independent of window width.
  activity_header=QGridLayout()
  activity_header.setContentsMargins(0,0,0,0)
  activity_header.setHorizontalSpacing(12)
  activity_header.setVerticalSpacing(3)
  activity_header.addLayout(celebration_row,0,0,1,1)
  # Real Qt label, independent of the 56-pixel celebration animation canvas.
  self.export_congratulations_label=QLabel('',self.celebration_effect)
  self.celebration_effect.congratulations_label=self.export_congratulations_label
  self.export_congratulations_label.setAttribute(Qt.WA_TransparentForMouseEvents)
  self.export_congratulations_label.setObjectName('exportCongratulationsLabel')
  self.export_congratulations_label.setAlignment(Qt.AlignCenter)
  self.export_congratulations_label.setWordWrap(True)
  self.export_congratulations_label.setStyleSheet('font-size:17px;font-weight:800;color:#70df91;background:transparent;border:none;padding:3px 6px')
  self.export_congratulations_label.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Preferred)
  self.export_congratulations_label.hide()
   # Label is overlaid between the two poppers, not a separate full-width row.
  activity_header.addWidget(self.activity_detail,1,0,1,1)
  activity_header.setColumnStretch(0,1)
  activity_header.setColumnStretch(1,0)
  activity_layout.addLayout(activity_header)
  tally_row=QHBoxLayout()
  self.workflow_label=QLabel('OVERALL: 00:00:00')
  self.workflow_label.setWordWrap(False)
  self.workflow_label.setStyleSheet('font-size:13px;font-weight:750;color:#b7d9ff')
  self.workspace_timer_label=QLabel('SONG: 00:00:00')
  self.workspace_timer_label.setStyleSheet('font-size:13px;font-weight:750;color:#b9efcd')
  self.first_export_label=QLabel('FIRST EXPORT: not completed')
  self.first_export_label.setStyleSheet('font-size:12px;color:#c8baff')
  tally_row.addWidget(self.workspace_timer_label,1)
  tally_row.addWidget(self.workflow_label,1)
  tally_row.addWidget(self.first_export_label,1)
  tally_row.addWidget(btn('Timing tally',self.show_workflow_tally))
  self.cancel_studio_button=QPushButton('Stop Studio export');self.cancel_studio_button.setToolTip('Safely cancel the experimental FFmpeg video render; your project and prior exports remain unchanged.')
  self.cancel_studio_button.clicked.connect(self.cancel_studio_export);self.cancel_studio_button.hide();self.cancel_studio_button.setFixedWidth(245)
  self.cancel_studio_button.setStyleSheet('QPushButton{background:#9e3543;color:#fff0f1;border:1px solid #bd5662;border-radius:9px;padding:8px 14px;font-weight:700;} QPushButton:hover{background:#b54350;border-color:#d46a75;} QPushButton:pressed{background:#7f2734;} QPushButton:disabled{background:#5c414a;color:#c5aeb2;}')
  activity_header.addWidget(self.cancel_studio_button,0,1,2,1,Qt.AlignRight | Qt.AlignVCenter)
  self.cancel_studio_button.raise_()
  self.activity_bar=ThemedProgressBar();self.activity_bar.setRange(0,100);self.activity_bar.setValue(0);self.activity_bar.setTextVisible(False);activity_layout.addWidget(self.activity_bar)
  theme_button=QPushButton('Progress appearance…')
  theme_button.clicked.connect(self.open_progress_theme)
  theme_button.setFixedWidth(245)
  theme_button.setSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed)
  theme_button_row=QHBoxLayout()
  theme_button_row.setContentsMargins(0,0,0,0)
  theme_button_row.addStretch(1)
  theme_button_row.addWidget(theme_button,0,Qt.AlignRight)
  activity_layout.addLayout(theme_button_row)
  self.apply_progress_theme(self._load_progress_theme())
  activity.setMinimumHeight(105)
  activity.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
  outer.addWidget(activity)
  outer.addLayout(tally_row)
  self.activity_panel=activity
  self.activity_started=None;self.activity_task=None;self._viz_eta_samples=[];self._viz_eta_text=''
  self.activity_timer=QTimer(self);self.activity_timer.timeout.connect(self.update_activity_clock)
  self._workflow_job_started=None;self._workflow_final_export=False
  self._workspace_active_index=0;self._workspace_started_monotonic=time.monotonic()
  # Completed-task totals change only when a processing run finishes.
  self.pages=QStackedWidget();outer.addWidget(self.pages,1)
  self.build_song();self.build_separation();self.build_lyrics();self.build_sync();self.build_visualizer();self.build_export();self.batch_page=BatchWorkspace(self.app_settings,metadata_reader=metadata_from_audio,information_cleaner=suggest_song_information,favorite_sites_callback=self.show_favorite_sites);self.batch_page.start_callback=lambda:(setattr(self,'_batch_section_mode',False),self.start_batch_processing());self.batch_page.section_settings_callback=self.open_batch_test_settings;self.batch_page.section_process_callback=self.start_batch_section_test;self.pages.insertWidget(5,self.batch_page);self.pages.setCurrentIndex(0)
  self.pages.currentChanged.connect(lambda _:self.update_stem_monitor())
   # Lower celebration overlay removed at user request; upper activity poppers retained.
  self.status=RoutedStatus(self,'Ready — import a song, then use Separation, Lyrics, Word Sync and Export.')
  self.status.hide() # Messages are routed to the top activity center instead.
  self.refresh();self.navigate(0)
  self.step_timer=QTimer(self);self.step_timer.timeout.connect(self.update_step_indicators);self.step_timer.start(600)
  self.project_label_timer=QTimer(self);self.project_label_timer.timeout.connect(self.update_project_identity);self.project_label_timer.start(700)
  self.update_step_indicators()
  self.word_clipboard=[];self.word_paste_at=None
  self.shortcuts=[]
  for sequence,callback in [('Ctrl+S',self.save_project),('Ctrl+Shift+S',self.save_as_project),('Ctrl+Z',self.do_undo),('Ctrl+Y',self.do_redo),('Ctrl+O',self.open_project),('Ctrl+N',self.new_project),('H',lambda:self.set_editor_mode('hand')),('E',lambda:self.set_editor_mode('edit')),('F11',self.toggle_focus_mode),('Escape',self.exit_focus_mode)]:
   shortcut=QShortcut(QKeySequence(sequence),self);shortcut.activated.connect(callback);self.shortcuts.append(shortcut)
  for sequence,callback in [('Ctrl+C',self.copy_waveform_words),('Ctrl+X',self.cut_waveform_words),('Ctrl+V',self.paste_waveform_words)]:
   shortcut=QShortcut(QKeySequence(sequence),self.timeline);shortcut.activated.connect(callback);self.shortcuts.append(shortcut)
  space_shortcut=QShortcut(QKeySequence(Qt.Key_Space),self);space_shortcut.activated.connect(self.toggle_sync_play_pause);self.shortcuts.append(space_shortcut)
 def update_project_identity(self):
  name=Path(self.path).name if self.path else ((self.song.text().strip() if hasattr(self,'song') else '') or 'Untitled Project')
  if name.endswith('.karaoke.json'):name=name[:-13]
  elif name.endswith('.json'):name=name[:-5]
  self.project_name.setText(name)
  self.project_name.setToolTip(str(self.path or name))
  # Compare serialized project content against last successful save; include editable fields.
  current=copy.deepcopy(self.project)
  if hasattr(self,'song'):
   current.update(song=self.song.text(),artist=self.artist.text(),audio=self.audio.text(),authoritative_lyrics=self.lyrics.toPlainText(),song_language=self.song_language.currentData())
  signature=json.dumps(current,sort_keys=True,ensure_ascii=False,default=str)
  dirty=self.saved_signature is None or signature!=self.saved_signature
  self.project_dirty.setText('● Unsaved changes' if dirty else '✓ Saved')
  self.project_dirty.setStyleSheet('color:#f4c977;font-weight:bold' if dirty else 'color:#77dfac;font-weight:bold')
  self.setWindowTitle(f'{name}{" *" if dirty else ""} — DeRo Sync {APP_VERSION} (integrated build {APP_BUILD})')
 def set_editor_mode(self,mode):
  self.timeline.set_mode(mode)
  self.hand_button.setChecked(mode=='hand')
  self.edit_button.setChecked(mode=='edit')
  self.update_editor_mode_icons()
 def update_editor_mode_icons(self):
  """Draw tool icons in one deliberate color, avoiding Windows color emoji."""
  for button,active,active_color,hand in (
      (self.hand_button,self.hand_button.isChecked(),'#ffbc69',True),
      (self.edit_button,self.edit_button.isChecked(),'#cfadff',False)):
   icon_color=QColor(active_color if active else '#8994a9')
   pixmap=QPixmap(24,24)
   pixmap.fill(Qt.transparent)
   painter=QPainter(pixmap)
   painter.setRenderHint(QPainter.Antialiasing,True)
   if hand:
    # Vector outline, NOT Unicode 'raised hand': Windows may paint that as
    # an unchangeable full-color emoji despite the requested pen color.
    pen=QPen(icon_color,1.8,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(Qt.NoBrush)
    path=QPainterPath()
    path.moveTo(9.4,20.4)
    path.cubicTo(6.5,18.7,5.0,15.7,3.3,13.8)
    path.cubicTo(2.6,12.9,2.8,11.9,3.6,11.5)
    path.cubicTo(4.5,11.1,5.5,11.7,7.3,13.4)
    path.lineTo(7.3,5.8)
    path.cubicTo(7.3,3.7,9.8,3.7,9.8,5.8)
    path.lineTo(9.8,10.1)
    path.lineTo(9.8,4.0)
    path.cubicTo(9.8,1.9,12.3,1.9,12.3,4.0)
    path.lineTo(12.3,9.8)
    path.lineTo(12.3,4.7)
    path.cubicTo(12.3,2.6,14.8,2.6,14.8,4.7)
    path.lineTo(14.8,10.1)
    path.lineTo(14.8,6.4)
    path.cubicTo(14.8,4.3,17.3,4.4,17.3,6.4)
    path.lineTo(17.3,12.0)
    path.cubicTo(18.3,10.1,20.3,10.5,20.5,11.9)
    path.cubicTo(20.8,13.7,19.7,18.1,16.2,20.4)
    path.closeSubpath()
    painter.drawPath(path)
   else:
    painter.setPen(icon_color)
    font=QFont('Segoe UI Symbol',17)
    font.setBold(True)
    painter.setFont(font)
    painter.drawText(pixmap.rect(),Qt.AlignCenter,'✎')
   painter.end()
   button.setIcon(QIcon(pixmap))
   button.setIconSize(pixmap.size())
 def keyPressEvent(self,e):
  if e.key()==Qt.Key_Space and not e.isAutoRepeat() and self.pages.currentIndex()==3:
   if not isinstance(QApplication.focusWidget(),(QLineEdit,QPlainTextEdit,QTextEdit,QDoubleSpinBox)):
    self.play_pause();e.accept();return
  super().keyPressEvent(e)

 def commit_timing_edit(self,words):
  """Persist timings and keep parent event boundaries consistent for export.

  Caller owns snapshot/Undo and timeline repaint. Do not rewrite authoritative text.
  """
  row=self.row
  events=self.project.get('events',[])
  if not (0<=row<len(events)):return
  self.project.setdefault('word_timings',{})[str(row)]=words
  if words:
   begins=[float(w[0]) for w in words]
   ends=[float(w[1]) for w in words]
   if all(math.isfinite(t) for t in begins+ends):
    events[row][0]=max(0.,round(min(begins),3))
    events[row][1]=round(max(max(ends),events[row][0]+.02),3)
  self.mark_manual(row)

 def apply_word_edit(self,words,selection=None):
  self.snapshot();self.commit_timing_edit(words)
  self.project['events'][self.row][2]=' '.join(str(w[2]) for w in words)
  self.mark_manual(self.row);self.timeline.set_words(words);self.refresh_all_timeline_words()
  if selection is not None:self.timeline.selected=max(0,min(selection,len(words)-1))
  self.update_selected_word();self.preview.setText(self.project['events'][self.row][2])
  self.project['authoritative_lyrics']='\n'.join(str(ev[2]) for ev in self.project['events'])
  self.updating=True;self.lyrics.setPlainText(self.project['authoritative_lyrics']);self.updating=False
 def edit_word(self):
  words=self.get_words(self.row);i=self.timeline.selected
  if i>=len(words):return
  value,ok=QInputDialog.getText(self,'Edit word','Word:',text=words[i][2])
  if ok and value.strip():words[i][2]=value.strip();self.apply_word_edit(words,i)
 def add_word(self):
  words=self.get_words(self.row);i=min(self.timeline.selected,len(words)-1)
  value,ok=QInputDialog.getText(self,'Insert word','New word:')
  if not ok or not value.strip():return
  at=float(words[i][1]) if i>=0 else float(self.project['events'][self.row][0]);following=float(words[i+1][0]) if i+1<len(words) else at+.4
  end=max(at+.03,min(at+.3,following));words.insert(i+1,[round(at,3),round(end,3),value.strip()]);self.apply_word_edit(words,i+1)
 def delete_word(self):
  words=self.get_words(self.row);i=self.timeline.selected
  if i>=len(words):return
  words.pop(i);self.apply_word_edit(words,max(0,i-1))
 def split_word(self):
  words=self.get_words(self.row);i=self.timeline.selected
  if i>=len(words):return
  value,ok=QInputDialog.getText(self,'Split word','Enter two parts separated by a space:',text=words[i][2])
  parts=value.strip().split() if ok else []
  if len(parts)!=2: return
  a,b,_=words[i];mid=(a+b)/2;words[i:i+1]=[[a,round(mid,3),parts[0]],[round(mid,3),b,parts[1]]];self.apply_word_edit(words,i)
 def merge_word(self):
  words=self.get_words(self.row);i=self.timeline.selected
  if i+1>=len(words):return
  a,b,t=words[i];_,end,next_text=words[i+1];words[i:i+2]=[[a,end,t+next_text if t.endswith('-') else t+' '+next_text]];self.apply_word_edit(words,i)
 def toggle_lock(self):
  i=self.timeline.selected
  if i in self.timeline.locked:self.timeline.locked.remove(i)
  else:self.timeline.locked.add(i)
  self.status.setText(('Unlocked' if i not in self.timeline.locked else 'Locked')+' word '+str(i+1))
 def selected_waveform_indices(self):
  words=self.get_words(self.row)
  indices=sorted(i for i in self.timeline.multi_selected if 0<=i<len(words))
  if not indices and 0<=self.timeline.selected<len(words):indices=[self.timeline.selected]
  return indices
 def copy_waveform_words(self):
  if self.pages.currentIndex()!=3:return
  words=self.get_words(self.row);indices=self.selected_waveform_indices()
  if not indices:return
  origin=min(float(words[i][0]) for i in indices)
  self.word_clipboard=[[round(float(words[i][0])-origin,3),round(float(words[i][1])-origin,3),str(words[i][2])] for i in indices]
  self.status.setText(f'Copied {len(indices)} word(s). Right-click waveform to choose paste location.')
 def cut_waveform_words(self):
  if self.pages.currentIndex()!=3:return
  words=self.get_words(self.row);indices=self.selected_waveform_indices()
  if not indices:return
  if any(i in self.timeline.locked for i in indices):
   QMessageBox.warning(self,'Locked words','Unlock selected words before cutting.');return
  self.copy_waveform_words()
  for i in reversed(indices):del words[i]
  self.apply_word_edit(words,max(0,min(indices[0],len(words)-1)))
  self.timeline.multi_selected.clear()
  self.status.setText(f'Cut {len(indices)} word(s). Right-click waveform to paste. Ctrl+Z to undo.')
 def paste_waveform_words(self):
  if self.pages.currentIndex()!=3:return
  if not self.word_clipboard:
   self.status.setText('No copied words to paste.');return
  words=self.get_words(self.row)
  anchor=float(self.word_paste_at if self.word_paste_at is not None else self.timeline.playhead)
  if not (math.isfinite(anchor) and anchor>=0):return
  pasted=[[round(anchor+a,3),round(anchor+b,3),t] for a,b,t in self.word_clipboard]
  if any(b<=a or a<0 for a,b,_ in pasted):return
  song_length=float(self.timeline.song_duration or 0)
  if song_length>0 and max(w[1] for w in pasted)>song_length+.001:
   QMessageBox.warning(self,'Paste outside audio','The pasted words would extend past the song.');return
  # Do not silently overwrite or shift existing lyrics; reject collisions.
  if any(a<existing[1]-.0005 and b>existing[0]+.0005 for a,b,_ in pasted for existing in words):
   QMessageBox.warning(self,'Words overlap','The paste position overlaps existing words. Choose an empty waveform location.');return
  first=len(words)
  combined=sorted(words+pasted,key=lambda w:(float(w[0]),float(w[1])))
  indices=[i for i,w in enumerate(combined) if w in pasted]
  self.apply_word_edit(combined,indices[0] if indices else first)
  self.timeline.multi_selected=set(indices)
  self.word_paste_at=None
  self.status.setText(f'Pasted {len(pasted)} word(s) at {anchor:.3f}s. Ctrl+Z to undo.')
 def word_menu(self,pos):
  hit=self.timeline.word_at(pos.x(),pos.y())
  if hit is not None:
   _a,_b,_text,line_index,word_index=hit
   if line_index!=self.row:self.activate_timeline_word(line_index,word_index)
   else:
    self.timeline.selected=word_index
    if word_index not in self.timeline.multi_selected:self.timeline.multi_selected={word_index}
    self.update_selected_word()
  self.word_paste_at=max(0.,self.timeline.t_for(pos.x()))
  menu=QMenu(self);actions=[('Copy selected words',self.copy_waveform_words),('Cut selected words',self.cut_waveform_words),('Paste words here',self.paste_waveform_words),('Edit word',self.edit_word),('Add word after',self.add_word),('Delete word',self.delete_word),('Split word',self.split_word),('Merge with next',self.merge_word),('Lock / Unlock timing',self.toggle_lock)]
  for name,fn in actions:menu.addAction(name,fn)
  menu.exec(self.timeline.mapToGlobal(pos))
 def line_menu(self,pos):
  row=self.lines.indexAt(pos).row()
  if row<0:return
  self.lines.setCurrentRow(row);menu=QMenu(self)
  for name,fn in [('Split line',self.split_line),('Merge with previous line',self.merge_line),('Set line start time',self.set_line_start),('Edit line text',self.edit_line),('Reset line sync',self.reset_line),('Remove line',self.remove_line),('Add new line above',lambda:self.insert_line(False)),('Add new line below',lambda:self.insert_line(True))]:menu.addAction(name,fn)
  menu.exec(self.lines.mapToGlobal(pos))
 def commit_events(self,events,timings):
  self.snapshot();self.project['events']=events;self.project['word_timings']={str(i):w for i,w in enumerate(timings) if w}
  self.project['alignment_status']={str(i):'manual' for i in range(len(events))}
  self.project['manual_overrides']={str(i):True for i in range(len(events))}
  self.project['reviewed_lines']={};self.project['ai_word_timings']={};self.project.pop('sync_inspector',None)
  self.project['word_scores']={};self.project['authoritative_lyrics']='\n'.join(str(ev[2]) for ev in events)
  self.refresh();self.lines.setCurrentRow(min(self.row,len(events)-1))
 def edit_line(self):
  events=copy.deepcopy(self.project['events']);i=self.row
  value,ok=QInputDialog.getText(self,'Edit lyric line','Line:',text=str(events[i][2]))
  if not ok or not value.strip():return
  words=self.get_words(i);old=[w[2] for w in words];new=value.strip().split()
  if words and len(new)==len(old):
   for w,t in zip(words,new):w[2]=t
  elif words:
   answer=QMessageBox.question(self,'Word count changed','The word count changed. Rebuild approximate word blocks for this line?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
   if answer!=QMessageBox.Yes:return
   a,b,_=events[i];step=(b-a)/max(1,len(new));words=[[round(a+j*step,3),round(a+(j+1)*step,3),t] for j,t in enumerate(new)]
  events[i][2]=value.strip();timings=[self.get_words(j) for j in range(len(events))];timings[i]=words;self.commit_events(events,timings)
 def split_line(self):
  events=copy.deepcopy(self.project['events']);i=self.row;words=self.get_words(i)
  if len(words)<2:return
  cut,ok=QInputDialog.getInt(self,'Split line','Split before word number:',max(2,len(words)//2+1),2,len(words))
  if not ok:return
  left,right=words[:cut-1],words[cut-1:];events[i:i+1]=[[left[0][0],left[-1][1],' '.join(w[2] for w in left)],[right[0][0],right[-1][1],' '.join(w[2] for w in right)]]
  times=[self.get_words(j) for j in range(len(self.project['events']))];times[i:i+1]=[left,right];self.commit_events(events,times)
 def merge_line(self):
  i=self.row
  if i<1:return
  events=copy.deepcopy(self.project['events']);words=self.get_words(i-1)+self.get_words(i)
  events[i-1:i+1]=[[min(events[i-1][0],events[i][0]),max(events[i-1][1],events[i][1]),events[i-1][2]+' '+events[i][2]]]
  times=[self.get_words(j) for j in range(len(self.project['events']))];times[i-1:i+1]=[words];self.row=i-1;self.commit_events(events,times)
 def set_line_start(self):
  events=copy.deepcopy(self.project['events']);i=self.row;start=self.player.position()/1000.;delta=start-events[i][0]
  events[i][0]=start;events[i][1]=max(start+.05,events[i][1]+delta)
  times=[self.get_words(j) for j in range(len(events))];times[i]=[[round(max(0,a+delta),3),round(max(.02,b+delta),3),t] for a,b,t in times[i]];self.commit_events(events,times)
 def reset_line(self):
  i=self.row;baseline=self.project.get('ai_word_timings',{}).get(str(i))
  if not baseline:
   QMessageBox.information(self,'Original timing unavailable','This project has no saved AI timing snapshot for this line.');return
  words=copy.deepcopy(baseline);self.apply_word_edit(words,0)
 def remove_line(self):
  events=copy.deepcopy(self.project['events']);i=self.row;events.pop(i);times=[self.get_words(j) for j in range(len(self.project['events']))];times.pop(i);self.commit_events(events,times)
 def insert_line(self,below):
  events=copy.deepcopy(self.project['events']);i=self.row+int(below)
  value,ok=QInputDialog.getText(self,'Insert lyric line','Line text:')
  if not ok or not value.strip():return
  t=self.player.position()/1000.;events.insert(i,[t,t+1.0,value.strip()]);times=[self.get_words(j) for j in range(len(self.project['events']))];times.insert(i,[]);self.row=i;self.commit_events(events,times)
 def show_status_at_top(self,message):
  """Route legacy bottom-bar messages into the persistent top status center."""
  message=str(message).strip()
  if not message:return
  # While a worker is active, its dedicated progress handler owns the banner.
  if self.activity_started is not None:return
  if message.startswith('Export complete:'):
   self.activity_title.setText('COMPLETE — MP4 export')
   self.activity_detail.setText('Video saved to: '+message.split(':',1)[1].strip())
   self.activity_bar.setRange(0,100);self.activity_bar.setValue(100)
  elif message.casefold().endswith('export cancelled'):
   self.activity_title.setText('CANCELLED — '+message[:-10].strip())
   self.activity_detail.setText(message)
   self.activity_bar.setRange(0,100);self.activity_bar.setValue(0)
  elif message.startswith('Alignment finished'):
   self.activity_title.setText('COMPLETE — WhisperX alignment')
   self.activity_detail.setText(message)
   self.activity_bar.setRange(0,100);self.activity_bar.setValue(100)
  elif message.startswith('Demucs finished'):
   self.activity_title.setText('COMPLETE — Vocal separation')
   self.activity_detail.setText(message)
   self.activity_bar.setRange(0,100);self.activity_bar.setValue(100)
  elif message.startswith('Saved '):
   self.activity_title.setText('READY — '+message[:70])
   self.activity_detail.setText(message)
  elif message.startswith(('Opened ','Diagnostics saved:','Placeholder timings','Prepared ','Waveform ready:')):
   self.activity_title.setText('READY — '+message.split(':',1)[0][:65])
   self.activity_detail.setText(message)
  elif message.startswith(('failed','Failed','Error','Waveform unavailable')) or ' failed:' in message:
   self.activity_title.setText('FAILED — Action requires attention')
   self.activity_detail.setText(message)
   self.activity_bar.setRange(0,100);self.activity_bar.setValue(0)
  else:
   self.activity_title.setText('STATUS — Karaoke Maker Lite')
   self.activity_detail.setText(message)
 def _step_fingerprint(self,step):
  """Current inputs relevant to a completed stage; never changes karaoke timings."""
  def digest(parts):return hashlib.sha256(json.dumps(parts,ensure_ascii=False,sort_keys=True,default=str).encode('utf-8')).hexdigest()
  audio=self.audio.text().strip()
  if step==1:return digest([audio,self.instrumental.text().strip(),self.vocals.text().strip()])
  if step==3:return digest([audio,self.vocals.text().strip(),self.lyrics.toPlainText(),self.song_language.currentData()])
  if step==4:return digest([self._step_fingerprint(3),self.project.get('events',[]),self.project.get('word_timings',{}),self.audio_choice.currentIndex(),self.instrumental_volume.value(),self.vocal_volume.value(),self.exit_effect.currentText(),self.exit_duration.value(),self.exit_delay.value()])
  return digest([audio])
 def update_step_indicators(self):
  if not getattr(self,'nav_buttons',None):return
  audio=self.audio.text().strip()
  lyrics=self.lyrics.toPlainText().strip() if hasattr(self,'lyrics') else ''
  stems=bool(self.instrumental.text().strip() and self.vocals.text().strip() and Path(self.instrumental.text().strip()).is_file() and Path(self.vocals.text().strip()).is_file())
  events=self.project.get('events',[])
  statuses=self.project.get('alignment_status',{})
  has_timing=bool(events and self.project.get('word_timings'))
  quality_warning=bool(has_timing and (not statuses or any(v in ('estimated','partial','failed','placeholder','unknown') for v in statuses.values())))
  states=['done' if audio and Path(audio).is_file() else 'idle', 'done' if stems else 'idle','done' if lyrics else 'idle','warn' if quality_warning else ('done' if has_timing else 'idle'),'done','idle','idle']
  reasons=['Audio file is available' if states[0]=='done' else 'Choose a valid audio file', 'Both separated stems are available' if stems else 'Separate vocals or import both stems', 'Authoritative lyrics entered' if lyrics else 'Paste your lyrics', 'Some word times are estimated or uncertain' if quality_warning else ('Word timestamps exist; accuracy still needs listening review' if has_timing else 'No word timing yet'), 'Visualizer is ready','Batch setup workspace (no automatic processing yet)','Export has not completed in this session']
  for step,snapshot in list(self.step_snapshots.items()):
   if step in (1,3,4) and snapshot!=self._step_fingerprint(step):
    if step==3 and has_timing:states[3]='warn';reasons[3]='Lyrics or audio changed since alignment; review or re-align before exporting'
    elif step==4:states[6]='warn';reasons[6]='Project or export settings changed since the last MP4 export'
    elif step==1 and stems:states[1]='warn';reasons[1]='Audio or stem paths changed since separation; verify stems match the song'
  # Export completion belongs to step 06, not Video Designer (step 05).
  # A saved export snapshot marks step 06 complete only while its inputs still match;
  # the earlier code checked states[4], which is always 'done', so Export stayed hollow.
  if 4 in self.step_snapshots and states[6]=='idle':states[6]='done';reasons[6]='MP4 export completed in this session'
  for step,error in self.step_failures.items():
   if 0<=step<5:
    visible_step=6 if step==4 else step
    states[visible_step]='failed';reasons[visible_step]=error
  jobs={'Vocal separation':1,'WhisperX alignment':3,'MP4 export':4,'Visualizer export':4}
  if self.activity_started is not None and self.activity_task in jobs:
   step=jobs[self.activity_task];visible_step=6 if step==4 else step;states[visible_step]='running';reasons[visible_step]='Processing in progress'
  glyph={'done':'✓','running':'◌','warn':'⚠','failed':'✕','idle':'○'}
  colors={'done':'#75dfa4','running':'#86c6ff','warn':'#f2c66d','failed':'#ff8b91','idle':'#a4b2ca'}
  for i,b in enumerate(self.nav_buttons):
   state=states[i] if i<len(states) else 'idle';b.setText(self.step_names[i]+'  '+(glyph[state] if i<len(states) else ''));b.setToolTip(reasons[i] if i<len(reasons) else 'Experimental workspace');b.setStyleSheet('QPushButton{color:'+colors[state]+';}')
 def navigate(self,index):
  self._switch_workspace_timer(index)
  if index==4 and self.project.get('audio'):workflow_milestone(self.project,'Video designer opened')
  self.pages.setCurrentIndex(index)
  for i,b in enumerate(self.nav_buttons):b.setChecked(i==index)
  self.update_sync_status_visibility()
  if index==3:
   self.load_waveform()
   self.update_stem_monitor()
 def toggle_project_navigation(self):
  """Collapse the project identity and workflow steps without changing pages."""
  if not hasattr(self,'project_navigation'):return
  visible=self.project_navigation.isVisible()
  self.project_navigation.setVisible(not visible)
  self.chrome_toggle_button.setText('Show project steps ▼' if visible else 'Hide project steps ▲')
 def update_sync_status_visibility(self):
  # Completed job banners should not consume the Word Sync editing workspace.
  # Keep progress and error information visible whenever it matters.
  if not hasattr(self,'activity_panel') or not hasattr(self,'pages'):return
  in_word_sync=self.pages.currentIndex()==3
  running=self.activity_started is not None
  failed=self.activity_title.text().startswith('FAILED')
  self.activity_panel.setVisible(not in_word_sync or running or failed)
 def make_page(self,heading,desc,header_action=None):
  f=panel();l=QVBoxLayout(f);l.setContentsMargins(22,20,22,20);l.setSpacing(12)
  header=QHBoxLayout();h=QLabel(heading);h.setStyleSheet('font-size:23px;font-weight:750');header.addWidget(h)
  if header_action is not None:
   header.addSpacing(28);header_action.setMinimumWidth(310);header.addWidget(header_action)
  header.addStretch();l.addLayout(header)
  d=QLabel(desc);d.setObjectName('muted');d.setWordWrap(True);l.addWidget(d);self.pages.addWidget(f);return l
 def build_song(self):
  browse=btn('♫  Browse audio…',self.browse_audio,True)
  l=self.make_page('Import song','Choose a local audio file. Song and artist are filled from audio tags when available.',browse)
  split=QSplitter(Qt.Horizontal);l.addWidget(split,1)
  left=panel();lv=QVBoxLayout(left);lv.setContentsMargins(18,18,18,18)
  lv.addWidget(QLabel('SONG INFORMATION'))
  form=QFormLayout();self.song=QLineEdit();self.artist=QLineEdit();self.audio=QLineEdit()
  form.addRow('Song',self.song);form.addRow('Artist',self.artist);form.addRow('Audio path',self.audio)
  self.song_language=SafeValueCombo();self.song_language.addItem('Auto Detect (English / Spanish fallback)','auto');self.song_language.addItem('English','en');self.song_language.addItem('Spanish / Español','es')
  self.song_language.setToolTip('Auto detects from vocals; if unsupported or uncertain, selects English or Spanish from pasted lyrics. Select English or Spanish to override detection.')
  form.addRow('Song language',self.song_language)
  lv.addLayout(form)
  song_actions=QHBoxLayout()
  song_actions.addWidget(btn('Retrieve artist & song metadata',self.retrieve_audio_metadata))
  song_actions.addWidget(btn('Review / Identify Song',self.review_current_song))
  lv.addLayout(song_actions);lv.addStretch();split.addWidget(left)
  # Recent music browser: folders selected by the user are remembered in QSettings.
  # It only lists audio files in the chosen folder; it never scans the whole drive.
  right=panel();rv=QVBoxLayout(right);rv.setContentsMargins(14,14,14,14);rv.setSpacing(9)
  browser_title=QLabel('YOUR MUSIC FOLDERS');browser_title.setStyleSheet('font-size:17px;color:#d5c7ff;font-weight:700')
  rv.addWidget(browser_title)
  folder_row=QHBoxLayout();self.music_folder_combo=QComboBox();self.music_folder_combo.setMinimumWidth(100)
  self.music_folder_combo.setToolTip('Previously opened music folders')
  folder_row.addWidget(self.music_folder_combo,1)
  folder_row.addWidget(btn('Add folder…',self.add_music_folder))
  folder_row.addWidget(btn('Refresh',self.refresh_music_files))
  rv.addLayout(folder_row)
  self.music_file_search=QLineEdit();self.music_file_search.setPlaceholderText('Filter songs in this folder…')
  self.music_file_search.textChanged.connect(self.filter_music_files);rv.addWidget(self.music_file_search)
  self.audio_file_list=QListWidget();self.audio_file_list.setAlternatingRowColors(False)
  self.audio_file_list.setSelectionMode(QAbstractItemView.SingleSelection)
  self.audio_file_list.setToolTip('Double-click a song to load it, or select it and press Use selected song.')
  self.audio_file_list.itemDoubleClicked.connect(lambda _item:self.use_selected_audio_file())
  rv.addWidget(self.audio_file_list,1)
  self.music_folder_status=QLabel('Choose a folder to see its audio files.')
  self.music_folder_status.setObjectName('muted');rv.addWidget(self.music_folder_status)
  use_row=QHBoxLayout();use_row.addStretch(1)
  use_row.addWidget(btn('♫  Use selected song',self.use_selected_audio_file,True))
  rv.addLayout(use_row)
  self.music_folder_combo.currentIndexChanged.connect(self.on_music_folder_changed)
  self.song_summary=QLabel('No song loaded yet')
  self.song_summary.setWordWrap(True)
  self.song_summary.setStyleSheet('font-size:12px;color:#aebfe0;padding:2px 4px')
  rv.addWidget(self.song_summary)
  self.populate_recent_music_folders()
  split.addWidget(right);split.setSizes([650,520])
 def build_separation(self):
  separate=btn('Separate song with Demucs',self.start_separation,True)
  separate.setMinimumWidth(390);separate.setMaximumWidth(430)
  l=self.make_page('Vocal separation','Run Demucs locally to create instrumental and vocal stems, or import stems you already have.',separate)
  split=QSplitter(Qt.Horizontal);l.addWidget(split,1)
  left=panel();lv=QVBoxLayout(left);lv.setContentsMargins(18,18,18,18)
  self.demucs_model=SafeValueCombo()
  self.demucs_model.addItem('High Quality — HTDemucs Fine-Tuned (default)', 'htdemucs_ft')
  self.demucs_model.addItem('Standard — HTDemucs (faster)', 'htdemucs')
  self.demucs_model.setToolTip('Fine-Tuned takes longer but may improve isolation. Each model saves to a separate folder.')
  lv.addWidget(QLabel('VOCAL SEPARATION QUALITY'))
  lv.addWidget(self.demucs_model)
  comparison=QLabel('Fine-Tuned is the default. Standard remains available for comparison. Previous stems are not overwritten by another model.')
  comparison.setWordWrap(True)
  lv.addWidget(comparison)
  self.instrumental=QLineEdit();self.vocals=QLineEdit()
  # Refresh only the stem monitoring and vocal waveform when stem paths change.
  self.vocals.editingFinished.connect(lambda:self.load_waveform(self.vocals.text().strip()) if hasattr(self,'timeline') else None)
  self.vocals.editingFinished.connect(lambda:self.update_stem_monitor() if hasattr(self,'hear_vocals') else None)
  self.instrumental.editingFinished.connect(lambda:self.update_stem_monitor() if hasattr(self,'hear_instrumental') else None)
  lv.addWidget(QLabel('INSTRUMENTAL TRACK'));lv.addWidget(self.instrumental);lv.addWidget(btn('Browse instrumental…',lambda:self.browse_into(self.instrumental)))
  lv.addWidget(QLabel('VOCAL TRACK'));lv.addWidget(self.vocals);lv.addWidget(btn('Browse vocals…',lambda:self.browse_into(self.vocals)))
  lv.addStretch();split.addWidget(left)
  right=panel();rv=QVBoxLayout(right);rv.setContentsMargins(20,20,20,20)
  rv.addWidget(QLabel('SEPARATION ACTIVITY'))
  self.sep_note=QLabel('READY — Choose a song and start separation.')
  self.sep_note.setWordWrap(True);self.sep_note.setMinimumHeight(76)
  self.sep_note.setStyleSheet('background:#1b2b46;border:1px solid #415477;border-radius:10px;padding:16px;font-size:15px;font-weight:650;color:#d8ccff')
  rv.addWidget(self.sep_note)
  self.sep_progress=QProgressBar();self.sep_progress.setRange(0,100);self.sep_progress.setValue(0);self.sep_progress.setFormat('Waiting to start');rv.addWidget(self.sep_progress)
  self.sep_elapsed=QLabel('Elapsed: 00:00  |  Total time: —')
  self.sep_elapsed.setStyleSheet('font-size:14px;color:#d8ccff;padding:6px')
  rv.addWidget(self.sep_elapsed)
  self.sep_started=None
  self.sep_timer=QTimer(self);self.sep_timer.timeout.connect(self.update_separation_clock)
  rv.addWidget(QLabel('PROCESSING DETAILS'))
  self.sep_log=QPlainTextEdit();self.sep_log.setReadOnly(True);self.sep_log.setPlaceholderText('Demucs processing messages will appear here.');rv.addWidget(self.sep_log,1)
  split.addWidget(right);split.setSizes([650,520])
 def build_lyrics(self):
  l=self.make_page('Authoritative lyrics','Your pasted lyrics are never rewritten. Placeholder timings are only a starting point.')
  split=QSplitter(Qt.Horizontal);l.addWidget(split,1)
  left=panel();lv=QVBoxLayout(left);lv.setContentsMargins(15,15,15,15)
  lyrics_header=QHBoxLayout();lyrics_header.addWidget(QLabel('PASTE LYRICS'));lyrics_header.addStretch()
  self.favorite_sites_button=btn('1  Favorite Lyrics Sites',self.show_favorite_sites);self.favorite_sites_button.setMinimumWidth(285);self.favorite_sites_button.setObjectName('favoriteLyrics');lyrics_header.addWidget(self.favorite_sites_button)
  self.auto_sync_button=btn('2  Auto-sync pasted lyrics with WhisperX',self.start_alignment);self.auto_sync_button.setMinimumWidth(330);lyrics_header.addWidget(self.auto_sync_button)
  lv.addLayout(lyrics_header);self.lyrics=QPlainTextEdit();self.lyrics.setPlaceholderText('Paste one lyric line per row…')
  lv.addWidget(self.lyrics,1);lv.addWidget(btn('Create editable lines (placeholder timing)',self.create_lines));lv.addWidget(btn('Quick Karaoke — separate, sync, then preview',self.start_quick_karaoke));split.addWidget(left)
  right=panel();right_box=QVBoxLayout(right);right_box.setContentsMargins(8,8,8,8)
  lyrics_scroll=QScrollArea();lyrics_scroll.setWidgetResizable(True);lyrics_scroll.setFrameShape(QFrame.NoFrame)
  lyrics_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  lyrics_scroll.setStyleSheet('QScrollArea{background:transparent;border:none} QScrollArea > QWidget > QWidget{background:transparent}')
  right_content=QWidget();rv=QVBoxLayout(right_content);rv.setContentsMargins(12,12,12,12)
  lyrics_scroll.setWidget(right_content);right_box.addWidget(lyrics_scroll,1);rv.addWidget(QLabel('LYRIC PREVIEW'))
  self.lyric_preview=QLabel('Your lyric lines will appear here');self.lyric_preview.setAlignment(Qt.AlignTop);self.lyric_preview.setWordWrap(True)
  self.lyric_preview.setStyleSheet('font-size:17px;color:#d3c3ff;padding:12px')
  rv.addWidget(self.lyric_preview,1)
  rv.addWidget(QLabel('LIVE KARAOKE APPEARANCE — updates without video encoding'))
  self.appearance_frame=QLabel('Your lyrics will appear here')
  self.appearance_frame.setAlignment(Qt.AlignCenter)
  self.appearance_frame.setWordWrap(True)
  self.appearance_frame.setMinimumHeight(125)
  self.appearance_frame.setStyleSheet('background:#0b1224;border:1px solid #354562;border-radius:8px')
  rv.addWidget(self.appearance_frame)
  rv.addWidget(QLabel('Font family'))
  self.lyric_font_family=SafeFontCombo()
  self.lyric_font_family.setCurrentFont(QFont(str(self.project.get('lyric_font_family','Arial'))))
  rv.addWidget(self.lyric_font_family)
  font_row=QHBoxLayout()
  font_row.addWidget(QLabel('Font size (1080p pixels)'))
  self.lyric_font_size=SafeValueSpin();self.lyric_font_size.setRange(24,120);self.lyric_font_size.setDecimals(0)
  self.lyric_font_size.setValue(float(self.project.get('lyric_font_size',72)))
  font_row.addWidget(self.lyric_font_size);rv.addLayout(font_row)
  self.lyric_font_bold=QCheckBox('Bold lyric font');self.lyric_font_bold.setChecked(bool(self.project.get('lyric_font_bold',True)))
  rv.addWidget(self.lyric_font_bold)
  outline_row=QHBoxLayout();outline_row.addWidget(QLabel('Outline thickness'))
  self.lyric_outline=SafeValueSpin();self.lyric_outline.setRange(0,8);self.lyric_outline.setDecimals(0)
  self.lyric_outline.setValue(float(self.project.get('lyric_outline',3)))
  outline_row.addWidget(self.lyric_outline);rv.addLayout(outline_row)
  preview_actions=QHBoxLayout()
  preview_actions.addWidget(btn('Render exact frame',self.render_exact_frame))
  preview_actions.addWidget(btn('Render 10-second MP4',self.render_exact_clip))
  rv.addLayout(preview_actions)
  self.rendered_frame=QLabel('Rendered frame appears here (same ASS filter as export)')
  self.rendered_frame.setAlignment(Qt.AlignCenter);self.rendered_frame.setWordWrap(True)
  self.rendered_frame.setMinimumHeight(105)
  rv.addWidget(self.rendered_frame)
  rv.addWidget(QLabel('LYRIC APPEARANCE'))
  rv.addWidget(QLabel('Lyric display style'))
  self.lyric_display_mode=SafeValueCombo()
  self.lyric_display_mode.addItem('Single lyric line','single')
  self.lyric_display_mode.addItem('Two-row preview (current + next)','preview')
  self.lyric_display_mode.addItem('Alternating two rows','alternating')
  self.lyric_display_mode.addItem('Smooth Flow — fixed lyric pages','classic_flow')
  rv.addWidget(QLabel('SMOOTH FLOW TRANSITIONS'))
  self.classic_flow_lines=SafeValueCombo();self.classic_flow_lines.addItem('Three lines per screen',3);self.classic_flow_lines.addItem('Two lines per screen',2)
  rv.addWidget(self.classic_flow_lines)
  flow_row=QHBoxLayout();flow_row.addWidget(QLabel('Fade in (ms)'))
  self.classic_flow_fade_in=SafeValueSpin();self.classic_flow_fade_in.setRange(0,1500);self.classic_flow_fade_in.setDecimals(0);self.classic_flow_fade_in.setSingleStep(50);self.classic_flow_fade_in.setValue(300);flow_row.addWidget(self.classic_flow_fade_in)
  flow_row.addWidget(QLabel('Fade out (ms)'))
  self.classic_flow_fade_out=SafeValueSpin();self.classic_flow_fade_out.setRange(0,2000);self.classic_flow_fade_out.setDecimals(0);self.classic_flow_fade_out.setSingleStep(50);self.classic_flow_fade_out.setValue(400);flow_row.addWidget(self.classic_flow_fade_out)
  rv.addLayout(flow_row)
  rv.addWidget(self.lyric_display_mode)
  rv.addWidget(btn('Apply Smooth Flow look',self.apply_smooth_flow_preset,True))
  self.lyric_display_mode.currentIndexChanged.connect(self._classic_flow_style_selected)
  rv.addWidget(QLabel('Color preset'))
  self.lyric_color_preset=SafeValueCombo()
  for name in ('Classic Karaoke','Electric Blue','Neon Purple','Mint Glow','Classic Flow Green','Custom'):
   self.lyric_color_preset.addItem(name)
  rv.addWidget(self.lyric_color_preset)
  self.reverse_lyric_colors=QCheckBox('Reverse colors (swap sung and unsung)')
  rv.addWidget(self.reverse_lyric_colors)
  color_buttons=QHBoxLayout()
  self.unsung_color_button=btn('Unsung color',lambda:self.choose_lyric_color('unsung'))
  self.sung_color_button=btn('Sung color',lambda:self.choose_lyric_color('sung'))
  color_buttons.addWidget(self.unsung_color_button);color_buttons.addWidget(self.sung_color_button)
  rv.addLayout(color_buttons)
  self.lyric_color_preview=QLabel('Para no verte  |  más')
  self.lyric_color_preview.setAlignment(Qt.AlignCenter)
  self.lyric_color_preview.setMinimumHeight(52)
  rv.addWidget(self.lyric_color_preview)
  self.classic_flow_fade_in.valueChanged.connect(self.update_appearance_preview)
  self.classic_flow_fade_out.valueChanged.connect(self.update_appearance_preview)
  rv.addStretch()
  # Put the interactive appearance controls FIRST, rather than beneath a long
  # lyric preview. Move existing layout items; do not recreate their widgets.
  items=[]
  while rv.count():items.append(rv.takeAt(0))
  preview_index=next((i for i,item in enumerate(items) if item.widget() is self.lyric_preview),1)
  # Original first two items are LYRIC PREVIEW heading and its long content.
  # Keep them after all the appearance tools (but before the trailing spacer).
  ordered=items[2:-1]+items[:2]+items[-1:]
  for item in ordered:rv.addItem(item)
  self.lyric_preview.setMaximumHeight(180)
  self.rendered_frame.setMaximumHeight(270)
  split.addWidget(right);split.setSizes([580,640])
  self.lyric_base_unsung='#EAF3FF';self.lyric_base_sung='#31B9FF'
  self.lyric_color_preset.setCurrentText('Electric Blue')
  self.lyric_color_preset.currentIndexChanged.connect(self.apply_lyric_preset)
  self.reverse_lyric_colors.toggled.connect(self.update_lyric_color_preview)
  for control,signal in ((self.lyric_font_family,self.lyric_font_family.currentFontChanged),(self.lyric_font_size,self.lyric_font_size.valueChanged),(self.lyric_font_bold,self.lyric_font_bold.toggled),(self.lyric_outline,self.lyric_outline.valueChanged),(self.lyric_display_mode,self.lyric_display_mode.currentIndexChanged)):
   signal.connect(self.update_appearance_preview)
  self.update_lyric_color_preview()
  self.update_appearance_preview()
  self.lyrics.textChanged.connect(self.on_lyrics_changed)
  self.lyrics.textChanged.connect(lambda: self.refresh_visualizer_background_preview() if hasattr(self,'viz_preview_label') else None)
  self.update_lyrics_action_buttons()
 def _classic_flow_style_selected(self,*args):
  if not hasattr(self,'lyric_color_preset'):return
  if self.lyric_display_mode.currentData()=='classic_flow' and self.lyric_color_preset.currentText()=='Electric Blue':
   self.lyric_color_preset.setCurrentText('Classic Flow Green')
  self.update_appearance_preview()
 def apply_smooth_flow_preset(self):
  """Apply the reference video's clean, large, readable presentation."""
  self.lyric_display_mode.setCurrentIndex(self.lyric_display_mode.findData('classic_flow'))
  self.classic_flow_lines.setCurrentIndex(self.classic_flow_lines.findData(3))
  self.classic_flow_fade_in.setValue(180);self.classic_flow_fade_out.setValue(320)
  self.lyric_color_preset.setCurrentText('Classic Flow Green')
  self.reverse_lyric_colors.setChecked(False)
  self.lyric_font_family.setCurrentFont(QFont('Arial'))
  self.lyric_font_size.setValue(72);self.lyric_font_bold.setChecked(True);self.lyric_outline.setValue(2)
  if hasattr(self,'lyric_lead'):self.lyric_lead.setValue(2.0)
  if hasattr(self,'lyric_vertical'):self.lyric_vertical.setValue(53)
  if hasattr(self,'export_preview'):
   self.export_preview.setText('SMOOTH FLOW\n\nFixed lyric pages • Wait for the final word • Fade out\nProgressive highlight • Black background')
   self.export_preview.setStyleSheet('background:#000000;border:1px solid #364b77;border-radius:12px;color:#ffffff;font-size:22px;font-weight:700')
  self.update_lyric_color_preview()
 def update_appearance_preview(self,*args):
  if not hasattr(self,'appearance_frame'):return
  from html import escape
  unsung,sung=self.lyric_colors() if hasattr(self,'reverse_lyric_colors') else ('#EAF3FF','#31B9FF')
  size=max(12,round(self.lyric_font_size.value()*0.45))
  family=escape(self.lyric_font_family.currentFont().family(),quote=True)
  weight='bold' if self.lyric_font_bold.isChecked() else 'normal'
  shadow='0px 0px 3px #000000' if self.lyric_outline.value()>0 else 'none'
  background='#000000' if self.lyric_display_mode.currentData()=='classic_flow' else '#0b1224'
  self.appearance_frame.setStyleSheet('background:'+background+';border:1px solid #354562;border-radius:8px')
  # Never use a previous song's timing events to override newly pasted lyrics.
  # Once aligned, select the matching current line; otherwise use the first
  # pasted line (or a neutral placeholder when the field is blank).
  pasted_lines=[v.strip() for v in self.lyrics.toPlainText().splitlines() if v.strip()]
  text=pasted_lines[0] if pasted_lines else 'Your lyrics will appear here'
  if pasted_lines and self.project.get('events'):
   try:
    candidate=str(self.project['events'][min(max(0,self.row),len(self.project['events'])-1)][2]).strip()
    if candidate in pasted_lines:text=candidate
   except (IndexError,ValueError,TypeError):pass
  words=text.split()
  if not words:words=['Your','lyrics','will','appear','here']
  midpoint=max(1,len(words)//2)
  first=escape(' '.join(words[:midpoint]));second=escape(' '.join(words[midpoint:]))
  self.appearance_frame.setText(f'<div style="font-family:{family};font-size:{size}px;font-weight:{weight};text-align:center;text-shadow:{shadow};"><span style="color:{sung}">{first}</span> <span style="color:{unsung}">{second}</span></div>')

 def _render_preview(self,clip=False):
  """Use the exact same ass_file and FFmpeg ASS filter as final export."""
  self.sync_fields()
  if not self.project.get('events'):
   QMessageBox.warning(self,'No lyrics','Create lyric lines before rendering a preview.');return
  ffmpeg=find_ffmpeg()
  if not ffmpeg:
   QMessageBox.warning(self,'FFmpeg missing','FFmpeg is required for an exact rendered preview.');return
  try:
   width,height=map(int,self.resolution.currentText().split('x'))
   position=max(0.0,self.player.position()/1000)
   if position<0.1:
    first=self.project['events'][0]
    position=max(0.0,float(first[0])+.25)
   start=max(0.0,position-2.0) if clip else position
   duration=10.0 if clip else 0.1
   folder=Path(tempfile.gettempdir())/'karaoke_maker_lite_preview'
   folder.mkdir(parents=True,exist_ok=True)
   ass=folder/'current_lyrics.ass'
   ass_file(copy.deepcopy(self.project),ass,width,height)
   target=folder/('exact_preview.mp4' if clip else 'exact_frame.png')
   ass_path=str(ass.resolve()).replace('\\','/').replace(':',r'\:').replace("'",r"\'")
   vf=f"ass=filename='{ass_path}'"
   # Input seek applies to the synthetic background; the ASS timestamps remain
   # in absolute song time via setpts before the subtitle filter.
   vf=f"setpts=PTS+{start:.3f}/TB,{vf}"
   background='black' if self.project.get('lyric_display_mode')=='classic_flow' else '0x0b1224'
   command=[ffmpeg,'-hide_banner','-loglevel','error','-nostdin','-y',
    '-f','lavfi','-i',f'color=c={background}:s={width}x{height}:r=30',
    '-t',str(duration),'-vf',vf]
   if clip:
    audio=self.audio.text().strip()
    if audio and Path(audio).is_file():
     command[command.index('-t'):command.index('-t')]=['-ss',f'{start:.3f}','-i',audio]
     command+=['-map','0:v:0','-map','1:a:0','-c:a','aac','-b:a','160k']
    command+=['-c:v','libx264','-preset','ultrafast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(target)]
   else:command+=['-frames:v','1','-update','1',str(target)]
  except Exception as exc:
   QMessageBox.critical(self,'Preview setup failed',str(exc));return
  def job(emit):
   emit('Rendering '+('10-second exact MP4' if clip else 'exact subtitle frame')+'…')
   result=subprocess.run(command,capture_output=True,text=True,timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   if result.returncode:raise RuntimeError(result.stderr[-1800:] or 'FFmpeg preview failed')
   if not target.is_file() or target.stat().st_size<100:raise RuntimeError('FFmpeg did not create the preview.')
   return str(target)
  def done(path):
   if clip:
    QDesktopServices.openUrl(QUrl.fromLocalFile(path))
   else:
    pix=QPixmap(path)
    if pix.isNull():QMessageBox.warning(self,'Preview error','Unable to open rendered frame.');return
    self.rendered_frame.setPixmap(pix.scaled(440,248,Qt.KeepAspectRatio,Qt.SmoothTransformation))
    self.rendered_frame.setMinimumHeight(248)
  self.begin_job('Exact lyric preview',job,done)
 def render_exact_frame(self):self._render_preview(False)
 def render_exact_clip(self):self._render_preview(True)

 def lyric_palette(self):
  return {'Classic Karaoke':('#FFFFFF','#FFD34D'),
          'Electric Blue':('#EAF3FF','#31B9FF'),
          'Neon Purple':('#FFFFFF','#B38AFF'),
          'Mint Glow':('#F5F8FF','#48E0BA'),
          'Classic Flow Green':('#FFFFFF','#5ADB65')}
 def apply_lyric_preset(self):
  name=self.lyric_color_preset.currentText()
  if name in self.lyric_palette():
   self.lyric_base_unsung,self.lyric_base_sung=self.lyric_palette()[name]
  self.update_lyric_color_preview()
 def lyric_colors(self):
  unsung=getattr(self,'lyric_base_unsung','#EAF3FF')
  sung=getattr(self,'lyric_base_sung','#31B9FF')
  return (sung,unsung) if self.reverse_lyric_colors.isChecked() else (unsung,sung)
 def update_lyric_color_preview(self):
  unsung,sung=self.lyric_colors()
  self.unsung_color_button.setStyleSheet('QPushButton{border-bottom:3px solid '+unsung+';}')
  self.sung_color_button.setStyleSheet('QPushButton{border-bottom:3px solid '+sung+';}')
  self.lyric_color_preview.setText('Sung: '+sung+'    |    Unsung: '+unsung)
  self.lyric_color_preview.setStyleSheet('background:#0b1224;color:'+sung+';border:1px solid #354562;border-radius:8px')
  self.update_appearance_preview()
 def choose_lyric_color(self,kind):
  unsung,sung=self.lyric_colors()
  color=QColorDialog.getColor(QColor(unsung if kind=='unsung' else sung),self,'Choose '+kind+' lyric color')
  if not color.isValid():return
  if kind=='unsung':
   if self.reverse_lyric_colors.isChecked():self.lyric_base_sung=color.name().upper()
   else:self.lyric_base_unsung=color.name().upper()
  else:
   if self.reverse_lyric_colors.isChecked():self.lyric_base_unsung=color.name().upper()
   else:self.lyric_base_sung=color.name().upper()
  self.lyric_color_preset.blockSignals(True)
  self.lyric_color_preset.setCurrentText('Custom')
  self.lyric_color_preset.blockSignals(False)
  self.update_lyric_color_preview()
 def build_sync(self):
  # Compact desktop editing workspace: only the lyrics list and optional advanced tools scroll.
  l=self.make_page('Manual Word Sync','Drag the waveform to navigate. Select a word and drag its edges to adjust timing. Spacebar plays or pauses.')
  # Word Sync uses its full page height, not a giant title + instructions block.
  host=l.parentWidget()
  # make_page's heading is a nested layout so it can also hold a page action.
  # Hide both header rows safely without assuming every layout item is a widget.
  header=l.itemAt(0).layout()
  if header:
   for i in range(header.count()):
    widget=header.itemAt(i).widget()
    if widget:widget.hide()
  description=l.itemAt(1).widget()
  if description:description.hide()
  l.setContentsMargins(7,6,7,6)
  l.setSpacing(5)
  self.sync_page_layout=l
  # Keep essential controls visible at all times, even on a restored laptop window.
  self.timeline=Timeline()
  self.timeline.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
  self.timeline.setMinimumHeight(135)
  self.timeline.changed.connect(self.timeline_change)
  self.timeline.groupShiftRequested.connect(self.shift_selected_words)
  self.timeline.sharedBoundaryChanged.connect(self.timeline_shared_boundary_change)
  self.timeline.selectedChanged.connect(self.update_selected_word)
  self.timeline.wordActivated.connect(self.activate_timeline_word)
  self.timeline.wordDoubleClicked.connect(self.play_timeline_word)
  self.timeline.playRequested.connect(self.play_from_timeline)
  self.timeline.seekRequested.connect(lambda v:self.seek_monitor_position(int(v*1000)))
  self.timeline.scrubStarted.connect(self.begin_playhead_scrub)
  self.timeline.scrubMoved.connect(self.move_playhead_scrub)
  self.timeline.scrubEnded.connect(self.end_playhead_scrub)
  self.timeline.dragFinished.connect(self.finish_timeline_drag)
  self.timeline.setContextMenuPolicy(Qt.CustomContextMenu)
  self.timeline.customContextMenuRequested.connect(self.word_menu)
  self.overview=SongOverview(self.timeline)
  self.overview.selectedTime.connect(self.jump_to_song_time)

  self.sync_editor_split=QSplitter(Qt.Vertical)
  self.sync_editor_split.setChildrenCollapsible(False)
  self.sync_editor_split.setHandleWidth(7)
  l.addWidget(self.sync_editor_split,1)
  self.sync_top_split=QSplitter(Qt.Horizontal)
  self.sync_top_split.setChildrenCollapsible(False)
  self.sync_top_split.setHandleWidth(7)
  self.sync_editor_split.addWidget(self.sync_top_split)
  left=panel();self.sync_lyrics_panel=left
  lv=QVBoxLayout(left);lv.setContentsMargins(7,7,7,7);lv.setSpacing(5)
  # Collapsible tools: hidden by default so lyric lines get the available height.
  self.lyric_timing_toggle=QPushButton('Timing Tools  ▸')
  self.lyric_timing_toggle.setCheckable(True)
  self.lyric_timing_toggle.setChecked(False)
  self.lyric_timing_toggle.setToolTip('Show or hide the manual sync, line timing and review buttons.')
  self.lyric_timing_toggle.setStyleSheet('QPushButton{text-align:left;padding:6px 10px;background:#273653;border:1px solid #3c4b6a;border-radius:7px;} QPushButton:checked{background:#365778;border-color:#88b9de;}')
  lv.addWidget(self.lyric_timing_toggle)
  self.lyric_timing_tools=QWidget()
  tools_layout=QVBoxLayout(self.lyric_timing_tools)
  tools_layout.setContentsMargins(0,2,0,3)
  tools_layout.setSpacing(5)
  sync_actions=QHBoxLayout();sync_actions.setSpacing(5)
  sync_actions.addWidget(btn('Manual Sync',self.generate_words))
  sync_actions.addWidget(btn('Reset Line to AI',self.reset_selected_line_to_ai))
  tools_layout.addLayout(sync_actions)
  timing_actions=QHBoxLayout();timing_actions.setSpacing(5)
  minus_line=btn('◀ Earlier −100ms',lambda:self.nudge_selected_line(-.1))
  minus_line.setToolTip('Move selected lyric line and words 100 ms earlier (Undo: Ctrl+Z).')
  timing_actions.addWidget(minus_line)
  plus_line=btn('Later +100ms ▶',lambda:self.nudge_selected_line(.1))
  plus_line.setToolTip('Move selected lyric line and words 100 ms later (Undo: Ctrl+Z).')
  timing_actions.addWidget(plus_line)
  tools_layout.addLayout(timing_actions)
  # Selected-word nudges belong with the other timing adjustments, not in
  # the playback/zoom toolbar. These preserve their original handlers.
  word_timing_actions=QHBoxLayout();word_timing_actions.setSpacing(5)
  word_timing_actions.addWidget(QLabel('Selected Words'))
  minus_words=btn('◀ −100ms',lambda:self.shift_selected_words(-.1))
  minus_words.setToolTip('Move selected word(s) 100 ms earlier (Undo: Ctrl+Z).')
  word_timing_actions.addWidget(minus_words)
  plus_words=btn('+100ms ▶',lambda:self.shift_selected_words(.1))
  plus_words.setToolTip('Move selected word(s) 100 ms later (Undo: Ctrl+Z).')
  word_timing_actions.addWidget(plus_words)
  tools_layout.addLayout(word_timing_actions)
  review_actions=QHBoxLayout();review_actions.setSpacing(5)
  self.review_next_button=btn('Review Next Issue',self.review_next_issue)
  self.review_next_button.setToolTip('Jump to the next unreviewed Partial, Estimated, or Failed lyric line.')
  review_actions.addWidget(self.review_next_button)
  self.review_mark_button=btn('Mark Reviewed',self.toggle_line_reviewed)
  self.review_mark_button.setToolTip('Mark selected line as checked by listening. Does not change AI alignment quality.')
  review_actions.addWidget(self.review_mark_button)
  tools_layout.addLayout(review_actions)
  self.lyric_timing_tools.setVisible(False)
  lv.addWidget(self.lyric_timing_tools)
  def toggle_lyric_timing_tools(expanded):
   self.lyric_timing_tools.setVisible(expanded)
   self.lyric_timing_toggle.setText('Timing Tools  ▾' if expanded else 'Timing Tools  ▸')
  self.lyric_timing_toggle.toggled.connect(toggle_lyric_timing_tools)
  line_head=QHBoxLayout();line_head.setSpacing(4)
  line_head.addWidget(QLabel('TIME  /  LYRICS — DOUBLE-CLICK TO PLAY LINE'))
  line_head.addStretch(1)
  # Entire-line Earlier/Later controls now live only in collapsible Timing Tools.
  lv.addLayout(line_head)
  self.lines=LyricWordList();self.lines.wordClicked.connect(self.jump_to_lyric_word);self.lines.wordDoubleClicked.connect(self.play_timeline_word);self.lines.lineDoubleClicked.connect(self.play_lyric_row);self.lines.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  self.lines.setWordWrap(True);self.lines.setTextElideMode(Qt.ElideNone)
  self.lines.setStyleSheet('QListWidget::item{padding:0px;margin:0px;} QListWidget::item:selected{background:#283d63;border:1px solid #6e86b5;border-radius:4px;}')
  self.lines.setResizeMode(QListView.Adjust);self.lines.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
  self.lines.currentRowChanged.connect(self.select_line)
  
  self.lines.setContextMenuPolicy(Qt.CustomContextMenu)
  self.lines.customContextMenuRequested.connect(self.line_menu)
  lv.addWidget(self.lines,1);left.setMinimumWidth(265)
  self.review_summary_label=QLabel('Review: no alignment results yet')
  self.review_summary_label.setWordWrap(True)
  self.review_summary_label.setStyleSheet('color:#bcd1f0;font-size:12px;')
  lv.addWidget(self.review_summary_label)
  self.sync_top_split.addWidget(left)

  right=panel();rv=QVBoxLayout(right);rv.setContentsMargins(9,8,9,8);rv.setSpacing(5)
  preview_head=QHBoxLayout();preview_head.addWidget(QLabel('LIVE LYRIC TIMING PREVIEW'));preview_head.addStretch()
  preview_head.addWidget(btn('Lyric Appearance →',self.open_lyric_appearance))
  preview_head.addWidget(btn('Exact Frame',self.render_exact_frame))
  rv.addLayout(preview_head)
  # Appearance controls and layout controls belong together in the preview pane,
  # not on a separate page-width row above the editing workspace.
  appearance_actions=QHBoxLayout();appearance_actions.setSpacing(4)
  appearance_actions.addWidget(QLabel('Layout:'))
  self.layout_selector=SafeValueCombo();self.layout_selector.addItems(['Balanced','Lyrics Focus','Waveform Focus','My Layout'])
  self.layout_selector.setMinimumWidth(125)
  self.layout_selector.currentTextChanged.connect(self.set_workspace_layout)
  appearance_actions.addWidget(self.layout_selector)
  appearance_actions.addWidget(btn('Reset Layout',self.reset_sync_layout))
  appearance_actions.addWidget(btn('Save My Layout',self.save_my_sync_layout))
  appearance_actions.addWidget(btn('Advanced Tools ▾',lambda:self.sync_scroller.setVisible(not self.sync_scroller.isVisible())))
  appearance_actions.addWidget(btn('10s MP4 Preview',self.render_exact_clip))
  appearance_actions.addStretch()
  rv.addLayout(appearance_actions)
  self.preview=QLabel('Choose a lyric line')
  self.preview.setAlignment(Qt.AlignCenter);self.preview.setWordWrap(True)
  self.preview.setStyleSheet('background:#0b1428;border:1px solid #334664;border-radius:9px;font-size:28px;font-weight:750;color:#eaf3ff;padding:8px')
  self.preview.setMinimumHeight(60);rv.addWidget(self.preview,1)
  self.sync_time_caption=QLabel('START —  |  END —  |  DURATION —')
  self.sync_time_caption.setAlignment(Qt.AlignCenter)
  self.sync_time_caption.setStyleSheet('color:#82dcbd;font-weight:650')
  rv.addWidget(self.sync_time_caption)
  self.sync_top_split.addWidget(right)
  self.sync_top_split.setSizes([470,730])

  # Exactly two compact toolbar rows; controls move with the waveform panel.
  timeline_panel=panel();self.sync_timeline_panel=timeline_panel
  waveform_layout=QVBoxLayout(timeline_panel)
  waveform_layout.setContentsMargins(7,5,7,6);waveform_layout.setSpacing(4)
  self.sync_toolbar=QWidget()
  self.sync_toolbar.setObjectName('wordSyncCompactToolbar')
  self.sync_toolbar.setStyleSheet('QWidget#wordSyncCompactToolbar{border:none;border-radius:0px;background:#101b32;}')
  toolbar_v=QVBoxLayout(self.sync_toolbar);toolbar_v.setContentsMargins(5,5,5,5);toolbar_v.setSpacing(3)
  top=QHBoxLayout();top.setSpacing(4)
  bottom=QHBoxLayout();bottom.setSpacing(4)
  def compact(label,callback,layout=top,width=None,primary=False):
   widget=btn(label,callback,primary)
   widget.setFixedHeight(29)
   widget.setSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed)
   if width:widget.setMinimumWidth(width)
   layout.addWidget(widget)
   return widget
  self.hand_button=compact('✋ Hand',lambda:self.set_editor_mode('hand'))
  self.edit_button=compact('✎ Edit',lambda:self.set_editor_mode('edit'))
  for widget in (self.hand_button,self.edit_button):widget.setCheckable(True)
  self.hand_button.setChecked(True)
  self.update_editor_mode_icons()
  neutral=('QPushButton,QPushButton:checked,QPushButton:hover,QPushButton:checked:hover{background:#273653;color:#fff;border:1px solid #3c4b6a;}')
  for widget in (self.hand_button,self.edit_button):widget.setStyleSheet(neutral)
  compact('↶ Undo',self.do_undo);compact('↷ Redo',self.do_redo)
  compact('Fit Song',self.fit_song);compact('Fit Line',self.fit_line);compact('Fit Word',self.fit_word)
  self.focus_button=compact('Full Screen',self.toggle_focus_mode)
  # Approved restrained golden-yellow accent; sizing and callback unchanged.
  self.focus_button.setStyleSheet(
   'QPushButton{background:#414535;color:#F2E5AD;border:1px solid #A39A62;}'
   'QPushButton:hover{background:#494D3C;color:#FFF0BF;border:1px solid #B2AA76;}'
  )
  self.hear_vocals=QCheckBox('Vocals');self.hear_vocals.setChecked(True)
  self.hear_instrumental=QCheckBox('Instrumental');self.hear_instrumental.setChecked(False)
  self.hear_vocals.toggled.connect(self.update_stem_monitor)
  self.hear_instrumental.toggled.connect(self.update_stem_monitor)
  top.addWidget(self.hear_vocals);top.addWidget(self.hear_instrumental)
  self.playback_speed=SafeValueCombo()
  self.playback_speed.addItems(['0.1×','0.2×','0.3×','0.4×','0.5×','0.75×','1×','1.25×','1.5×','2×'])
  self.playback_speed.setCurrentIndex(6);self.playback_speed.setFixedHeight(29)
  self.playback_speed.currentIndexChanged.connect(lambda i:self.player.setPlaybackRate([.1,.2,.3,.4,.5,.75,1.,1.25,1.5,2.][i]))
  top.addWidget(self.playback_speed)
  compact('1×',lambda:self.playback_speed.setCurrentIndex(6))
  compact('■ Stop',self.stop_song,bottom)
  self.waveform_play_button=compact('▶ Play / Pause',self.play_pause,bottom,155,True)
  self.waveform_play_button.setFixedWidth(155)  # Prevent expansion into a long bar.
  self.waveform_play_line_button=compact('▶ Play Line',self.play_line,bottom,140)
  self.waveform_play_line_button.setFixedWidth(140)  # Compact, legible width.
  compact('▶ Play Word',self.play_selected_word,bottom)
  self.waveform_play_next_word_button=compact('▶ Play Next Word',self.play_next_word,bottom)
  compact('▶ Play Next Line',self.play_next_line,bottom)
  # Keep zoom minus / slider / plus together as ONE toolbar item.  The
  # even-spacing routine must not insert stretches inside this group.
  zoom_group=QWidget()
  zoom_row=QHBoxLayout(zoom_group)
  zoom_row.setContentsMargins(0,0,0,0)
  zoom_row.setSpacing(5)
  compact('Zoom −',lambda:self.timeline.zoom(1.5),zoom_row)
  self.waveform_zoom_slider=QSlider(Qt.Horizontal);self.waveform_zoom_slider.setRange(0,1000)
  self.waveform_zoom_slider.setFixedWidth(300)
  self.waveform_zoom_slider.valueChanged.connect(self.set_waveform_zoom_from_slider)
  self.timeline.viewRangeChanged.connect(self.sync_waveform_zoom_slider)
  self.timeline.viewRangeChanged.connect(lambda _span:self.schedule_adaptive_waveform())
  zoom_row.addWidget(self.waveform_zoom_slider)
  compact('Zoom +',lambda:self.timeline.zoom(.67),zoom_row)
  bottom.addWidget(zoom_group)
  # Distribute the controls evenly across each row, treating the entire
  # zoom cluster as one control. Do not resize individual buttons.
  for layout in (top,bottom):
   for index in range(layout.count()-1,0,-1):
    layout.insertStretch(index,1)
  toolbar_v.addLayout(top);toolbar_v.addLayout(bottom)
  waveform_layout.addWidget(self.sync_toolbar)
  self.timeline.set_show_all_words(True)
  self.snap_button=QPushButton('Snap to words');self.snap_button.setCheckable(True)
  self.snap_button.toggled.connect(lambda enabled:setattr(self.timeline,'snap_enabled',enabled))
  # The resolution control lives exclusively in Advanced Tools.
  self.wave_resolution=SafeValueCombo()
  self.wave_resolution.addItems(['100','200','300','400','500','600','700','800','900','1000 (default)'])
  self.wave_resolution.setCurrentIndex(9)
  self.wave_resolution.setToolTip('Vocal waveform peaks per second. 1000 is the default.')
  self.wave_resolution.currentIndexChanged.connect(self.change_waveform_resolution)
  self.sync_waveform_zoom_slider(self.timeline.view_end-self.timeline.view_start)
  waveform_layout.addWidget(self.overview)
  waveform_layout.addWidget(self.timeline,1)
  self.sync_editor_split.addWidget(timeline_panel)
  self.sync_timeline_panel.setMinimumHeight(210)
  self.sync_editor_split.setSizes([340,380])
  self.sync_editor_split.setStretchFactor(0,1)
  self.sync_editor_split.setStretchFactor(1,2)

  # Rarely used controls remain available without forcing the primary workspace to scroll.
  self.sync_advanced=QWidget();advanced=QVBoxLayout(self.sync_advanced)
  advanced.setContentsMargins(5,5,5,5)
  
  self.sync_scroller=QScrollArea();self.sync_scroller.setWidgetResizable(True)
  self.sync_scroller.setWidget(self.sync_advanced)
  self.sync_scroller.setVisible(False)
  self.sync_scroller.setMaximumHeight(155)
  waveform_advanced=QHBoxLayout()
  waveform_advanced.addWidget(QLabel('Waveform resolution (peaks/s):'))
  waveform_advanced.addWidget(self.wave_resolution)
  self.wave_style_select=SafeValueCombo()
  self.wave_style_select.addItems(['Classic (original)','High Detail (blue PCM)'])
  self.wave_style_select.setCurrentIndex(1)  # Default appearance: High Detail (blue PCM)
  self.wave_style_select.setToolTip('Choose the original purple envelope or high-detail blue signed PCM min/max. Does not change word timings.')
  self.wave_style_select.currentIndexChanged.connect(self.change_waveform_style)
  waveform_advanced.addWidget(QLabel('Appearance:'))
  waveform_advanced.addWidget(self.wave_style_select)

  waveform_advanced.addWidget(self.snap_button)
  waveform_advanced.addWidget(btn('Export Sync Review (HTML)',self.export_sync_review))
  waveform_advanced.addWidget(btn('Open review folder',self.open_sync_review_folder))
  waveform_advanced.addStretch(1)
  advanced.addLayout(waveform_advanced)
  advanced_row=QGridLayout();advanced.addLayout(advanced_row)
  advanced_actions=[('■ Stop + Reset',self.stop_reset),('Song + Selected Line',self.song_and_line),('Live Preview',self.show_live_preview),('Loop word',self.loop_word),('◀ Previous word',lambda:self.step_word(-1)),('Next word ▶',lambda:self.step_word(1)),('Start −50ms',lambda:self.nudge_word('start',-.05)),('Start +50ms',lambda:self.nudge_word('start',.05)),('End −50ms',lambda:self.nudge_word('end',-.05)),('End +50ms',lambda:self.nudge_word('end',.05)),('Shift all −100ms',lambda:self.shift_all_words(-.1)),('Shift all +100ms',lambda:self.shift_all_words(.1)),('★ Lyrics Sites',self.show_favorite_sites)]
  for i,(label,action) in enumerate(advanced_actions):advanced_row.addWidget(btn(label,action),i//5,i%5)
  self.follow=QCheckBox('Follow playback');self.follow.setChecked(True);advanced.addWidget(self.follow)
  speed_row=QHBoxLayout();speed_row.addWidget(QLabel('Line click behavior'))
  self.line_mode=SafeValueCombo();self.line_mode.addItems(['Click line: Fit Line','Click line: Full Song + Location']);self.line_mode.currentIndexChanged.connect(self.change_line_view_mode)
  speed_row.addWidget(self.line_mode);advanced.addLayout(speed_row)
  self.time_readout=QLabel('00:00.000 / 00:00.000');advanced.addWidget(self.time_readout)
  self.seek=QSlider(Qt.Horizontal);self.seek.setRange(0,1000);self.seek.sliderReleased.connect(self.seek_audio);advanced.addWidget(self.seek)
  wrow=QHBoxLayout();wrow.addWidget(QLabel('Selected word'));self.word_label=QLabel('—');wrow.addWidget(self.word_label)
  wrow.addWidget(QLabel('Start'));self.start=SafeValueSpin();self.start.setRange(0,99999);self.start.setDecimals(3);self.start.valueChanged.connect(self.spin_change);wrow.addWidget(self.start)
  wrow.addWidget(QLabel('End'));self.end=SafeValueSpin();self.end.setRange(0,99999);self.end.setDecimals(3);self.end.valueChanged.connect(self.spin_change);wrow.addWidget(self.end)
  advanced.addLayout(wrow)
  erow=QHBoxLayout()
  for label,fn in [('Edit word',self.edit_word),('Add word',self.add_word),('Delete word',self.delete_word),('Split word',self.split_word),('Merge next',self.merge_word),('Lock / Unlock',self.toggle_lock),('Generate line blocks',self.generate_words),('Generate all blocks',self.generate_all_words)]:erow.addWidget(btn(label,fn))
  advanced.addLayout(erow)
  self.sync_page_layout.insertWidget(self.sync_page_layout.indexOf(self.sync_editor_split),self.sync_scroller)
  self.player.positionChanged.connect(self.on_position)
  self.workspace_layout='Balanced'
  self.sync_layout_changing=False
  self.sync_right_stack=self.sync_editor_split
  self.sync_main_horizontal=self.sync_top_split
  # Defer restoring saved splitter geometry until Qt has laid out the window.
  QTimer.singleShot(0,self.restore_my_sync_layout_on_startup)

 def center_selected_line(self):
  if not self.project.get('events') or not (0<=self.row<len(self.project['events'])):return
  words=self.get_words(self.row)
  if words:
   index=min(max(0,self.timeline.selected),len(words)-1)
   a,b,_=words[index]
  else:a,b=self.project['events'][self.row][:2]
  center=(float(a)+float(b))/2
  span=max(.75,self.timeline.view_end-self.timeline.view_start)
  start=max(0,center-span/2)
  self.timeline.show_range(start,start+span)

 def play_lyric_row(self,row):
  """Only blank/status parts of a row should request whole-line playback."""
  if not (0<=row<len(self.project.get('events',[]))):return
  self.lines.setCurrentRow(row)
  self.fit_line();self.play_line()

 def play_line_from_item(self,item):
  """Double-clicking a lyric line seeks to it and plays only that line."""
  row=self.lines.row(item)
  if row<0:return
  if self.lines.currentRow()!=row:self.lines.setCurrentRow(row)
  self.fit_line();self.play_line()

 def fit_word(self):
  words=self.get_words(self.row) if self.project.get('events') else []
  if not words:return self.fit_line()
  index=min(max(0,self.timeline.selected),len(words)-1)
  a,b,_=words[index];a=float(a);b=float(b)
  padding=max(.2,(b-a)*.6)
  self.timeline.show_range(max(0,a-padding),b+padding)

 def toggle_sync_play_pause(self):
  if self.pages.currentIndex()!=3:return
  if isinstance(QApplication.focusWidget(),(QLineEdit,QPlainTextEdit,QTextEdit,QDoubleSpinBox)):return
  self.play_pause()

 def open_lyric_appearance(self):
  """Jump straight to the visible appearance controls on the Lyrics tab."""
  self.navigate(2)
  if hasattr(self,'appearance_frame'):
   self.appearance_frame.setFocus(Qt.OtherFocusReason)
  if hasattr(self,'lyric_font_family'):
   self.lyric_font_family.setFocus(Qt.OtherFocusReason)
 def _apply_sync_split_ratios(self,vertical,horizontal):
  """Split available space between upper panels and waveform; protect word track."""
  split=self.sync_editor_split
  usable=max(1,split.height()-split.handleWidth())
  upper=max(145,int(usable*vertical))
  wave=max(self.sync_timeline_panel.minimumHeight(),usable-upper)
  split.setSizes([upper,wave])
  width=max(1,self.sync_top_split.width()-self.sync_top_split.handleWidth())
  self.sync_top_split.setSizes([max(265,int(width*horizontal)),max(270,int(width*(1-horizontal)))])

 def save_my_sync_layout(self):
  """Persist the user's actual manually dragged arrangement, not preset sizes."""
  try:
   self.app_settings.setValue('word_sync/my_vertical_split',self.sync_editor_split.saveState())
   self.app_settings.setValue('word_sync/my_horizontal_split',self.sync_top_split.saveState())
   self.app_settings.setValue('word_sync/has_my_layout',True)
   self.app_settings.sync()
   self.status.setText('My Layout saved. Select My Layout to restore it anytime.')
  except Exception as exc:
   QMessageBox.warning(self,'Save My Layout',str(exc))

 def restore_my_sync_layout_on_startup(self):
  # First launch remains Balanced; an explicit saved preference is restored.
  if self.app_settings.value('word_sync/has_my_layout',False,type=bool):
   self.layout_selector.setCurrentText('My Layout')
  else:
   self.set_workspace_layout('Balanced',force=True)

 def reset_sync_layout(self):
  if getattr(self,'focus_mode',False):self.exit_focus_mode()
  self.layout_selector.blockSignals(True)
  self.layout_selector.setCurrentText('Balanced')
  self.layout_selector.blockSignals(False)
  self.set_workspace_layout('Balanced',force=True)
  self.status.setText('Default Balanced layout restored. Your saved My Layout is still available.')

 def set_workspace_layout(self,mode,force=False):
  if not hasattr(self,'sync_editor_split'):return
  if mode not in ('Balanced','Lyrics Focus','Waveform Focus','My Layout'):mode='Balanced'
  self.workspace_layout=mode
  if mode=='My Layout':
   vertical=self.app_settings.value('word_sync/my_vertical_split')
   horizontal=self.app_settings.value('word_sync/my_horizontal_split')
   if vertical is not None and horizontal is not None:
    ok_v=self.sync_editor_split.restoreState(vertical)
    ok_h=self.sync_top_split.restoreState(horizontal)
    if ok_v and ok_h:return
   self.status.setText('No saved My Layout yet. Drag the dividers, then click Save My Layout.')
   return
  presets={'Balanced':(.49,.40),'Lyrics Focus':(.60,.54),'Waveform Focus':(.32,.40)}
  self._apply_sync_split_ratios(*presets[mode])

 def load_favorite_sites(self):
  try:
   path=Path.home()/'.karaoke_maker_lite'/'favorite_lyrics_sites.json'
   data=json.loads(path.read_text(encoding='utf-8'))
   return [x for x in data if isinstance(x,dict) and x.get('name') and x.get('url')][:200]
  except Exception:return []
 def persist_favorite_sites(self):
  try:
   path=Path.home()/'.karaoke_maker_lite'/'favorite_lyrics_sites.json'
   path.parent.mkdir(parents=True,exist_ok=True)
   path.write_text(json.dumps(self.favorite_sites,indent=2,ensure_ascii=False),encoding='utf-8')
  except Exception as exc:QMessageBox.warning(self,'Favorite sites',f'Unable to save favorites: {exc}')
 def copy_song_search_to_clipboard(self):
  """Copy the currently displayed artist and song, never stale project metadata."""
  artist=self.artist.text().strip()
  song=self.song.text().strip()
  search_text=' '.join(part for part in (artist,song) if part)
  if not search_text:
   return ''
  clipboard=QApplication.clipboard()
  clipboard.setText(search_text,clipboard.Mode.Clipboard)
  QApplication.processEvents()
  return search_text if clipboard.text(clipboard.Mode.Clipboard)==search_text else '' 
 def show_favorite_sites(self, search_provider=None):
  # Reuse this exact dialog for both the Song/Lyrics tab and the Batch queue.
  # A provider is supplied only for Batch; regular Lyrics retains its existing behavior.
  if not callable(search_provider):
   search_provider=self.copy_song_search_to_clipboard
  search_text=search_provider()
  d=QDialog(self);d.setWindowTitle('Favorite Lyrics Sites');d.resize(760,350);d.setMinimumWidth(560)
  v=QVBoxLayout(d);v.addWidget(QLabel('Favorite lyrics websites — saved for all projects'))
  status=QLabel(('Copied to clipboard: '+search_text) if search_text else 'Nothing copied. Select a song with an artist or title first.')
  status.setWordWrap(True)
  v.addWidget(status)
  def recopy():
   copied=search_provider()
   status.setText(('Copied to clipboard: '+copied) if copied else 'Nothing copied. Select a song with an artist or title first.')
   return copied
  v.addWidget(btn('Copy artist + song again',recopy))
  items=QListWidget();items.setSpacing(0);items.setVerticalScrollMode(QListWidget.ScrollPerPixel);v.addWidget(items,0)
  def refill(selected=None):
   items.clear()
   for entry in self.favorite_sites:
    name=str(entry['name']).strip()
    host=QUrl(str(entry['url'])).host().lower().removeprefix('www.')
    if name.lower().rstrip('/') in (str(entry['url']).lower().rstrip('/'), host, 'https://'+host, 'http://'+host):
     name={'azlyrics.com':'AZLyrics','genius.com':'Genius','songlyrics.com':'SongLyrics'}.get(host,host or name)
    items.addItem(f"{name}  —  {entry['url']}")
   # Show up to six compact entries without an oversized empty list.
   row_height=max(31,items.sizeHintForRow(0)) if items.count() else 31
   items.setFixedHeight(min(6,max(2,items.count()))*row_height+8)
   if selected is not None and 0<=selected<items.count():items.setCurrentRow(selected)
  def edit(add=False):
   idx=items.currentRow()
   if not add and idx<0:return
   old={} if add else self.favorite_sites[idx]
   name,ok=QInputDialog.getText(d,'Site name','Name:',text=old.get('name',''))
   if not ok or not name.strip():return
   url,ok=QInputDialog.getText(d,'Site URL','Website URL (https://...):',text=old.get('url','https://'))
   if not ok:return
   url=url.strip()
   parsed=QUrl(url)
   if parsed.scheme().lower() not in ('http','https') or not parsed.host():
    QMessageBox.warning(d,'Invalid link','Enter a full http:// or https:// website URL.');return
   entry={'name':name.strip(),'url':url}
   if add:self.favorite_sites.append(entry);idx=len(self.favorite_sites)-1
   else:self.favorite_sites[idx]=entry
   self.persist_favorite_sites();refill(idx)
  def remove():
   idx=items.currentRow()
   if idx<0:return
   if QMessageBox.question(d,'Remove favorite','Remove this favorite site?')!=QMessageBox.Yes:return
   self.favorite_sites.pop(idx);self.persist_favorite_sites();refill(min(idx,len(self.favorite_sites)-1))
  def move(delta):
   idx=items.currentRow();target=idx+delta
   if idx<0 or target<0 or target>=len(self.favorite_sites):return
   self.favorite_sites[idx],self.favorite_sites[target]=self.favorite_sites[target],self.favorite_sites[idx]
   self.persist_favorite_sites();refill(target)
  def open_selected(search=False):
   search = (search is True)
   idx=items.currentRow()
   if idx<0:
    QMessageBox.information(d,'Select a site','Select a favorite lyrics website first.')
    return
   entry=self.favorite_sites[idx]
   url=QUrl(entry['url'])
   copied=recopy()
   if search:
    if not isinstance(copied,str) or not copied.strip():
     QMessageBox.information(d,'Song information needed','Select a song with an artist and title before searching.')
     return
    # AZLyrics supports query-string searches; do not attempt to control a browser tab.
    if url.host().lower() in ('azlyrics.com','www.azlyrics.com','search.azlyrics.com'):
     from urllib.parse import urlencode
     url=QUrl('https://search.azlyrics.com/search.php?'+urlencode({'q':copied,'w':'lyrics'}))
    else:
     QMessageBox.information(d,'Manual website search',
      'This favorite does not have a configured direct-search URL.\n\n'
      'The artist and song title have been copied. Paste into the website search box with Ctrl+V.')
   if QDesktopServices.openUrl(url):
    if copied:
     QTimer.singleShot(450,search_provider)
    d.accept()
   else:
    QMessageBox.warning(d,'Unable to open link','Could not open the selected website.')
  buttons=QHBoxLayout();v.addLayout(buttons)
  buttons.addWidget(btn('Search current song',lambda checked=False:open_selected(search=True)))
  buttons.addWidget(btn('Open website',lambda checked=False:open_selected(search=False)))
  manage=QHBoxLayout();v.addLayout(manage)
  for label,fn in [('Add',lambda checked=False:edit(add=True)),('Edit',lambda checked=False:edit(add=False)),('Remove',remove),('↑',lambda:move(-1)),('↓',lambda:move(1))]:manage.addWidget(btn(label,fn))
  v.addWidget(btn('Close',d.accept));items.itemDoubleClicked.connect(lambda _item:open_selected(search=False))
  refill();d.exec()
 def build_export(self):
  # One responsive header toolbar: keep all four export actions together,
  # rather than duplicating action buttons above the preview.
  f=panel();l=QVBoxLayout(f);l.setContentsMargins(22,20,22,20);l.setSpacing(12)
  header=QHBoxLayout();header.setSpacing(16)
  labels=QVBoxLayout();labels.setSpacing(8)
  heading=QLabel('Preview & export');heading.setStyleSheet('font-size:23px;font-weight:750');labels.addWidget(heading)
  subtitle=QLabel('Choose single-line, two-row preview, or alternating karaoke lyrics with word highlighting.')
  subtitle.setObjectName('muted');subtitle.setWordWrap(True);labels.addWidget(subtitle)
  header.addLayout(labels,1)
  toolbar_area=QScrollArea();toolbar_area.setWidgetResizable(True)
  toolbar_area.setFrameShape(QFrame.NoFrame)
  toolbar_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  toolbar_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  toolbar_area.setMinimumHeight(69);toolbar_area.setMaximumHeight(82)
  toolbar_area.setStyleSheet('QScrollArea{background:transparent;border:none} QScrollArea > QWidget > QWidget{background:transparent}')
  toolbar_body=QWidget();toolbar=QHBoxLayout(toolbar_body);toolbar.setContentsMargins(0,0,0,0);toolbar.setSpacing(10)
  export_button=btn('Export karaoke MP4',self.start_visualizer_export,True);export_button.setMinimumWidth(220)
  toolbar.addWidget(btn('Open exported file',self.preview_export))
  toolbar.addWidget(btn('Open export folder',self.open_export_folder))
  toolbar.addWidget(export_button)
  toolbar_area.setWidget(toolbar_body);header.addWidget(toolbar_area,3)
  l.addLayout(header);self.pages.addWidget(f)
  split=QSplitter(Qt.Horizontal);l.addWidget(split,1)
  left=panel();lv=QVBoxLayout(left);lv.setContentsMargins(20,20,20,20);lv.addWidget(QLabel('VIDEO PREVIEW'))
  self.export_preview=QLabel('KARAOKE VIDEO\n\nDark navy background • Centered karaoke lyrics\nWord-by-word highlight');self.export_preview.setAlignment(Qt.AlignCenter)
  self.export_preview.setStyleSheet('background:#090f22;border:1px solid #364b77;border-radius:12px;color:#c4aaff;font-size:22px;font-weight:700')
  self.export_preview.setMinimumHeight(280);lv.addWidget(self.export_preview,1)
  split.addWidget(left)
  right=panel();right_outer=QVBoxLayout(right);right_outer.setContentsMargins(8,8,8,8)
  settings_scroll=QScrollArea();settings_scroll.setWidgetResizable(True);settings_scroll.setFrameShape(QFrame.NoFrame)
  settings_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  settings_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  settings_scroll.setStyleSheet('QScrollArea{background:transparent;border:none} QScrollArea > QWidget > QWidget{background:transparent}')
  settings_body=QWidget();rv=QVBoxLayout(settings_body);rv.setContentsMargins(12,12,12,12);rv.setSpacing(8)
  settings_scroll.setWidget(settings_body);right_outer.addWidget(settings_scroll,1)
  rv.addWidget(QLabel('KARAOKE LYRIC TIMING'))
  self.opening_progress_enabled=QCheckBox('Centered opening progress bar');self.opening_progress_enabled.setChecked(bool(self.project.get('opening_progress_enabled',self.project.get('lyric_countdown',True))));rv.addWidget(self.opening_progress_enabled)
  rv.addWidget(QLabel('Requested progress bar duration (maximum visible time)'))
  self.opening_progress_duration=SafeValueSpin();self.opening_progress_duration.setRange(.5,20);self.opening_progress_duration.setSingleStep(.5);self.opening_progress_duration.setDecimals(1);self.opening_progress_duration.setSuffix(' seconds');self.opening_progress_duration.setValue(float(self.project.get('opening_progress_duration',5)));rv.addWidget(self.opening_progress_duration)
  rv.addWidget(QLabel('Start progress bar this many seconds before first lyric'))
  self.opening_progress_before=SafeValueSpin();self.opening_progress_before.setRange(0,30);self.opening_progress_before.setSingleStep(.5);self.opening_progress_before.setDecimals(1);self.opening_progress_before.setSuffix(' seconds before');self.opening_progress_before.setValue(float(self.project.get('opening_progress_before',5)));rv.addWidget(self.opening_progress_before)
  rv.addWidget(QLabel('The bar ends before the first lyric. If singing starts near 0:00, the bar\nwill be short even at 5 seconds. These controls do not delay the song.'))
  rv.addWidget(QLabel('Show current lyric before singing'))
  self.lyric_lead=SafeValueSpin();self.lyric_lead.setRange(0,5);self.lyric_lead.setSingleStep(.5);self.lyric_lead.setDecimals(1);self.lyric_lead.setSuffix(' seconds');self.lyric_lead.setValue(float(self.project.get('lyric_lead_seconds',2)));rv.addWidget(self.lyric_lead)
  rv.addWidget(QLabel('Lyric vertical center (percentage of video height)'))
  self.lyric_vertical=SafeValueSpin();self.lyric_vertical.setRange(12,88);self.lyric_vertical.setDecimals(0);self.lyric_vertical.setSuffix(' %');self.lyric_vertical.setValue(float(self.project.get('lyric_vertical_percent',53)));rv.addWidget(self.lyric_vertical)
  rv.addWidget(QLabel('Highlight: PROGRESSIVE LEFT-TO-RIGHT FILL'))
  rv.addWidget(QLabel('LYRIC EXIT TRANSITION'))
  self.exit_effect=SafeValueCombo();self.exit_effect.addItems(['Fade Out','None']);self.exit_effect.setCurrentText(self.project.get('lyric_exit','Fade Out'));rv.addWidget(self.exit_effect)
  self.exit_delay=SafeValueSpin();self.exit_delay.setRange(0,1000);self.exit_delay.setDecimals(0);self.exit_delay.setSuffix(' ms after last word');self.exit_delay.setValue(self.project.get('lyric_exit_delay',150));rv.addWidget(self.exit_delay)
  self.exit_duration=SafeValueSpin();self.exit_duration.setRange(0,2000);self.exit_duration.setDecimals(0);self.exit_duration.setSuffix(' ms fade');self.exit_duration.setValue(self.project.get('lyric_exit_duration',450));rv.addWidget(self.exit_duration)
  self.export_range=ExportRangeBar();rv.addWidget(self.export_range)
  self.export_range_label=QLabel('Full song selected');rv.addWidget(self.export_range_label)
  range_buttons=QHBoxLayout();range_buttons.addWidget(btn('Full Song',lambda:self.export_range.set_range(0,self.export_range.duration)))
  range_buttons.addWidget(btn('Start at playhead',lambda:self.export_range.set_range(self.player.position()/1000,self.export_range.end)))
  range_buttons.addWidget(btn('End at playhead',lambda:self.export_range.set_range(self.export_range.start,self.player.position()/1000)))
  rv.addLayout(range_buttons)
  self.export_range.changed.connect(lambda a,b:self.export_range_label.setText(f'Start {a:.3f}s  •  End {b:.3f}s  •  Length {b-a:.3f}s'))
  selection_controls=QHBoxLayout()
  selection_controls.addWidget(btn('▶ Play Selection',self.play_export_selection))
  selection_controls.addWidget(btn('⏸ Pause',self.pause_export_selection))
  self.export_loop_button=QPushButton('🔁 Loop Selection')
  self.export_loop_button.setCheckable(True)
  self.export_loop_button.toggled.connect(self.set_export_selection_loop)
  selection_controls.addWidget(self.export_loop_button)
  selection_controls.addWidget(btn('▶ Play from Start',self.play_export_selection))
  rv.addLayout(selection_controls)
  self.export_range.changed.connect(self.export_selection_range_changed)
  self.player.durationChanged.connect(lambda ms:self.export_range.set_duration(ms/1000) if ms>0 else None)
  rv.addWidget(QLabel('EXPORT SETTINGS'))
  self.resolution=SafeValueCombo();self.resolution.addItems(['1920x1080','1440x1080','1280x720']);rv.addWidget(QLabel('Resolution'));rv.addWidget(self.resolution)
  self.encoder=SafeValueCombo();self.encoder.addItems(['CPU H.264 (libx264)','NVIDIA NVENC (h264_nvenc)']);self.encoder.setCurrentIndex(1);rv.addWidget(QLabel('Encoder'));rv.addWidget(self.encoder)
  self.audio_choice=SafeValueCombo();self.audio_choice.addItems(['Instrumental if available','Original song']);rv.addWidget(QLabel('Audio source'));rv.addWidget(self.audio_choice)
  rv.addWidget(QLabel('EXPORT AUDIO MIX — independent stem levels'))
  self.instrumental_volume=QSlider(Qt.Horizontal);self.instrumental_volume.setRange(0,100);self.instrumental_volume.setValue(100)
  self.instrumental_volume_label=QLabel('Instrumental: 100%')
  self.instrumental_volume.valueChanged.connect(lambda v:self.instrumental_volume_label.setText(f'Instrumental: {v}%'))
  rv.addWidget(self.instrumental_volume_label);rv.addWidget(self.instrumental_volume)
  self.vocal_volume=QSlider(Qt.Horizontal);self.vocal_volume.setRange(0,100);self.vocal_volume.setValue(20)
  self.vocal_volume_label=QLabel('Vocals: 20%')
  self.vocal_volume.valueChanged.connect(lambda v:self.vocal_volume_label.setText(f'Vocals: {v}%'))
  rv.addWidget(self.vocal_volume_label);rv.addWidget(self.vocal_volume)
  rv.addWidget(QLabel('Mix requires both separated stems. Original-song mode uses its own audio.'))
  self.export_progress=ThemedProgressBar();self.export_progress.setRange(0,0);self.export_progress.hide();rv.addWidget(self.export_progress)
  self.apply_progress_theme(self._load_progress_theme())
  self.auto_open_export=QCheckBox('Automatically open completed video');self.auto_open_export.setChecked(True);rv.addWidget(self.auto_open_export)
  split.addWidget(right);split.setSizes([730,430])
 def _load_progress_theme(self):
  t=progress_theme_defaults()
  try:
   saved=json.loads(self.app_settings.value('progress/theme_json','{}'))
   if isinstance(saved,dict):t=normalize_progress_theme(saved)
  except (ValueError,TypeError):pass
  return t
 def apply_progress_theme(self,t):
  self._progress_theme=t
  css=progress_theme_css(t)
  for attr in ('activity_bar','export_progress'):
   bar=getattr(self,attr,None)
   if bar is not None:
    bar.apply_theme(t)
    bar.installEventFilter(self)
    if bar.parentWidget() is not None:bar.parentWidget().installEventFilter(self)
    self._resize_progress_bar(bar,t)
  self._progress_theme=t
 def _resize_progress_bar(self,bar,t=None):
  t=t or getattr(self,'_progress_theme',progress_theme_defaults())
  parent=bar.parentWidget()
  layout=parent.layout() if parent is not None else None
  available=layout.contentsRect().width() if layout is not None else (parent.width() if parent else bar.width())
  percent=max(30,min(100,int(t.get('width',100))))
  if available<=0:return
  maximum=max(1,round(available*percent/100))
  if bar.maximumWidth()!=maximum:bar.setMaximumWidth(maximum)
 def eventFilter(self,obj,event):
  if event.type() in (QEvent.Resize,QEvent.Show,QEvent.LayoutRequest):
   for attr in ('activity_bar','export_progress'):
    bar=getattr(self,attr,None)
    if bar is not None and (obj is bar or obj is bar.parentWidget()):
     self._resize_progress_bar(bar)
  return super().eventFilter(obj,event)
 def open_progress_theme(self):
  ProgressThemeDialog(self,self.app_settings,self.apply_progress_theme).exec()
 def begin_job(self,label,fn,done,final_export=False):
  if self.job and self.job.isRunning():
   QMessageBox.information(self,'Busy','A processing task is already running.');return
  if final_export:
   self._clear_export_congratulations()
  workflow_begin(self.project,'processing started')
  self._workflow_job_started=time.monotonic();self._workflow_final_export=bool(final_export)
  self.activity_task=label;self.activity_started=time.monotonic();self._viz_eta_samples=[];self._viz_eta_text=''
  step={'Vocal separation':1,'WhisperX alignment':3,'MP4 export':4,'Visualizer export':4}.get(label)
  if step is not None:self.step_failures.pop(step,None);self.update_step_indicators()
  self.activity_last_message='Starting processing…'
  self.activity_title.setText('PROCESSING — '+label)
  self.update_sync_status_visibility()
  self.activity_bar.setRange(0,0)
  self.activity_detail.setText('Elapsed: 00:00  |  Starting processing…')
  self.activity_timer.start(1000)
  self.update_activity_clock()
  self.status.setText(label+' — working…')
  self.cancel_studio_button.setVisible(label in ('Studio video export','Visualizer export','MP4 export'))
  self.cancel_studio_button.setText('Stop Visualizer export' if label=='Visualizer export' else 'Stop MP4 export' if label=='MP4 export' else 'Stop Studio export')
  self.job=JobWorker(fn);self.job.progress.connect(lambda msg:self.job_progress(label,msg))
  self.job.completed.connect(lambda result,error:self.job_done(label,result,error,done))
  self.job.start()
 def _workspace_clock(self):
  # Deprecated wall-clock workspace_seconds are deliberately not used for tallying.
  clock=self.project.get('workflow_timing')
  return clock.setdefault('completed_workspace_seconds',{}) if clock else None

 def _switch_workspace_timer(self,index):
  self._workspace_active_index=index
  if hasattr(self,'workspace_timer_label'):self.update_workflow_tally()

 def _workspace_elapsed(self,index):
  clock=self.project.get('workflow_timing') or {}
  return sum(max(0.,float(run.get('seconds',0) or 0)) for run in clock.get('runs',[])
             if run.get('status')=='completed' and self._run_workspace(run)==index)

 def _checkpoint_workspace_timer(self):
  # Saving a project must not add idle/editing time to completed processing totals.
  return

 def _reset_workspace_clock(self):
  self._workspace_active_index=self.pages.currentIndex() if hasattr(self,'pages') else 0

 def _run_workspace(self,run):
  value=run.get('workspace')
  if value is not None:
   try:return int(value)
   except (TypeError,ValueError):pass
  return {'Vocal separation':1,'WhisperX alignment':3,'Exact lyric preview':3,
          'Sync review export':3,'Studio video export':5,'MP4 export':5}.get(run.get('step'),-1)

 def _successful_processing_total(self):
  clock=self.project.get('workflow_timing') or {}
  return sum(max(0.,float(run.get('seconds',0) or 0)) for run in clock.get('runs',[])
             if run.get('status')=='completed')

 def update_workflow_tally(self):
  clock=self.project.get('workflow_timing')
  names=('Song','Separation','Lyrics','Word Sync','Video Designer','Export')
  index=getattr(self,'_workspace_active_index',0)
  name=names[index] if 0<=index<len(names) else str(index)
  total=self._successful_processing_total()
  self.workspace_timer_label.setText(f'{name}: {workflow_duration(self._workspace_elapsed(index))}')
  self.workflow_label.setText(f'OVERALL: {workflow_duration(total)}')
  first=clock.get('first_export_processing_seconds') if clock else None
  self.first_export_label.setText('FIRST EXPORT: '+(workflow_duration(first) if first is not None else 'not completed'))
  self.workflow_label.setToolTip('Sum of successfully completed processing tasks only. No idle or manual editing time. Updates when tasks complete.')
  self.workspace_timer_label.setToolTip('Successful completed processing tasks in this workspace. Navigation alone does not increase this timer.')

 def show_workflow_tally(self):
  clock=self.project.get('workflow_timing')
  if not clock:
   QMessageBox.information(self,'Timing tally','Select a song to begin tracking completed processing tasks.');return
  self.update_workflow_tally()
  names=('Song','Separation','Lyrics','Word Sync','Video Designer','Export')
  text=[self.workspace_timer_label.text(),self.workflow_label.text(),self.first_export_label.text(),'',
        'SUCCESSFUL PROCESSING TIME BY WORKSPACE (not live)']
  text += [f'{name}: {workflow_duration(self._workspace_elapsed(i))}' for i,name in enumerate(names)]
  text+=['','COMPLETED / FAILED / CANCELLED PROCESSING RUNS']
  successes={};non_successes={}
  for i,run in enumerate(clock.get('runs',[]),1):
   duration=max(0.,float(run.get('seconds',0) or 0));status=run.get('status','unknown')
   workspace=self._run_workspace(run)
   label=names[workspace] if 0<=workspace<len(names) else 'Other'
   text.append(f"{i}. [{label}] {run.get('step','Task')}: {workflow_duration(duration)} ({status})")
   tally=successes if status=='completed' else non_successes
   tally[run.get('step','Task')]=tally.get(run.get('step','Task'),0.)+duration
  text+=['','SUCCESSFUL TOTALS BY TASK']
  text += [f'{name}: {workflow_duration(seconds)}' for name,seconds in successes.items()]
  text+=['','FAILED / CANCELLED TIME (EXCLUDED FROM OVERALL)']
  text += [f'{name}: {workflow_duration(seconds)}' for name,seconds in non_successes.items()]
  text+=['','Overall counts only successful processing tasks, including repeat runs.',
         'No manual editing, browsing, waiting or time while the app is closed.',
         'First Export records the successful processing total at the first full export.',
         'Older projects may contain legacy wall-clock milestones; they are not counted.']
  dialog=QDialog(self);dialog.setWindowTitle('Completed-task timing tally');dialog.resize(760,560)
  layout=QVBoxLayout(dialog);view=QPlainTextEdit();view.setReadOnly(True);view.setPlainText('\n'.join(text))
  layout.addWidget(view);layout.addWidget(btn('Close',dialog.accept));dialog.exec()
 def update_activity_clock(self):
  """Update the active job progress message; never advance completed-task totals."""
  if self.activity_started is None:return
  seconds=int(max(0.,time.monotonic()-self.activity_started))
  message=getattr(self,'activity_last_message','Processing…')
  self.activity_detail.setText(f'Elapsed: {seconds//60:02d}:{seconds%60:02d}  |  {message}' + (f'  |  {self._viz_eta_text}' if self.activity_task=='Visualizer export' and self._viz_eta_text else ''))
 def activity_message(self,message):
  self.activity_last_message=str(message).strip().replace('\n',' ')[:200]
  self.update_activity_clock()
 def update_separation_clock(self):
  if self.sep_started is not None:
   seconds=int(time.monotonic()-self.sep_started)
   self.sep_elapsed.setText(f'Elapsed: {seconds//60:02d}:{seconds%60:02d}  |  Total time: running…')
 def job_progress(self,label,msg):
  message=str(msg).strip()
  self.activity_message(message)
  if label=='Visualizer export':
   match=re.search(r'Visualizer rendering:\s*([\d,]+)/([\d,]+) frames',message)
   if match and self.activity_started is not None:
    frames,total=(int(x.replace(',','')) for x in match.groups())
    elapsed=max(0.01,time.monotonic()-self.activity_started)
    samples=self._viz_eta_samples
    samples.append((elapsed,frames))
    if len(samples)>20:samples.pop(0)
    base_t,base_f=samples[0]
    rate=(frames-base_f)/max(0.01,elapsed-base_t) if len(samples)>1 else frames/elapsed
    if rate>0 and total>0:
     remaining=max(0,round((total-frames)/rate))
     finish=datetime.datetime.now()+datetime.timedelta(seconds=remaining)
     self._viz_eta_text=f'ETA: {remaining//3600:02d}:{remaining//60%60:02d}:{remaining%60:02d} remaining | Finish ~{finish:%I:%M %p}'
    self.activity_bar.setRange(0,1000)
    self.activity_bar.setValue(round(1000*frames/max(1,total)))
    self.update_activity_clock()
  if label=='Vocal separation':
   match_global=re.search(r'(?<!\d)(\d{1,3}(?:\.\d+)?)\s*%',message)
   if match_global:
    self.activity_bar.setRange(0,100);self.activity_bar.setValue(round(min(100,max(0,float(match_global.group(1))))))
  self.status.setText(message[:240])
  if label=='Vocal separation':
   self.sep_note.setText('PROCESSING — Demucs is separating vocals and instrumental.\nPlease wait; this can take several minutes.')
   match=re.search(r'(?<!\d)(\d{1,3}(?:\.\d+)?)\s*%',message)
   if match:
    percent=min(100,max(0,float(match.group(1))))
    self.sep_progress.setRange(0,100)
    self.sep_progress.setValue(round(percent))
    self.sep_progress.setFormat(f'Demucs: {percent:.0f}% (reported processing stage)')
   if message and (not match or 'separat' in message.lower() or 'model' in message.lower()):
    self.sep_log.appendPlainText(message)
 def job_done(self,label,result,error,done):
  completed_at=time.time()
  final_export=self._workflow_final_export
  clock=workflow_begin(self.project,'processing started')
  cancelled=(label=='MP4 export' and getattr(self,'_standard_control',None) is not None and self._standard_control.event.is_set()) or (label=='Studio video export' and self._studio_cancel_event is not None and self._studio_cancel_event.is_set()) or (label=='Visualizer export' and getattr(self,'_visualizer_control',None) is not None and self._visualizer_control.event.is_set())
  run={'step':label,'workspace':{'Vocal separation':1,'WhisperX alignment':3,'Exact lyric preview':3,'Sync review export':3,'Studio video export':5,'MP4 export':5}.get(label,getattr(self,'_workspace_active_index',0)),
   'seconds':max(0.,time.monotonic()-self._workflow_job_started) if self._workflow_job_started is not None else 0.,
   'status':'cancelled' if cancelled else 'failed' if error else 'completed'}
  clock['runs'].append(run);self._workflow_job_started=None;self._workflow_final_export=False
  # Final status may still change if the result handler rejects the output.
  self.update_workflow_tally()
  if label=='MP4 export':
   pending_close=self._studio_close_after_cancel;self._studio_close_after_cancel=False
   self._standard_control=None
   self.cancel_studio_button.hide();self.cancel_studio_button.setEnabled(True)
   self.cancel_studio_button.setText('Stop Studio export')
   if pending_close:QTimer.singleShot(150,self._finish_cancelled_close)
   if cancelled:
    self.activity_timer.stop();self.activity_started=None
    self.activity_bar.setRange(0,100);self.activity_bar.setValue(0);self.export_progress.hide()
    self._clear_export_congratulations();self.update_step_indicators();self.update_sync_status_visibility()
    self.activity_title.setText('CANCELLED — MP4 export')
    self.activity_detail.setText('Stopped. The previous video and project timings are unchanged.')
    self.status.setText('MP4 export cancelled')
    return
  if label=='Studio video export':
   self._studio_control=None
   pending_close=self._studio_close_after_cancel
   self._studio_close_after_cancel=False
   self.cancel_studio_button.hide()
   self.cancel_studio_button.setEnabled(True)
   self.cancel_studio_button.setText('Stop Studio export')
   was_cancelled=self._studio_cancel_event is not None and self._studio_cancel_event.is_set()
   self._studio_cancel_event=None
   with self._studio_process_lock:self._studio_active_process=None
   if was_cancelled:
    self.activity_timer.stop();self.activity_started=None;self.activity_bar.setRange(0,100);self.activity_bar.setValue(0)
    self.activity_title.setText('CANCELLED — Studio video export')
    self.activity_detail.setText('Stopped. Project data is unchanged; saving and opening projects are available again.')
    self.export_progress.hide();self.update_step_indicators();self.update_sync_status_visibility()
    if pending_close:QTimer.singleShot(150,self._finish_cancelled_close)
    return
  self.activity_timer.stop()
  if label=='Studio video export' and pending_close:QTimer.singleShot(150,self._finish_cancelled_close)
  if label=='Visualizer export':
   if getattr(self,'_export_audit_current',None) is not None and (error or cancelled):
    self._export_audit_current.record('export_cancelled' if cancelled else 'export_failed',error=str(error or '')[:2000])
   self._export_audit_current=None
   self.cancel_studio_button.hide();self.cancel_studio_button.setEnabled(True);self.cancel_studio_button.setText('Stop Studio export')
   was_cancelled=bool(getattr(self,'_visualizer_control',None) is not None and self._visualizer_control.event.is_set())
   self._visualizer_control=None
   if was_cancelled:
    self.activity_timer.stop();self.activity_started=None;self.activity_bar.setRange(0,100);self.activity_bar.setValue(0)
    self.activity_title.setText('CANCELLED — Visualizer export')
    self.activity_detail.setText('Export stopped safely. Your project and previous exports are unchanged.')
    self.update_step_indicators();self.update_sync_status_visibility();return
  elapsed=int(time.monotonic()-self.activity_started) if self.activity_started is not None else 0
  self.project.setdefault('processing_benchmarks',[]).append({'step':label,'elapsed_seconds':elapsed,'status':'failed' if error else 'completed'})
  self.activity_started=None
  self.activity_bar.setRange(0,100)
  self.activity_bar.setValue(0 if error else 100)
  self.activity_title.setText(('FAILED — ' if error else 'COMPLETE — ')+label)
  self.update_sync_status_visibility()
  self.activity_detail.setText(f'Total time: {elapsed//60:02d}:{elapsed%60:02d}  |  '+(error.splitlines()[0][:150] if error else 'Processing finished successfully.'))
  self.export_progress.hide()
  if label=='Vocal separation':
   self.sep_timer.stop()
   if self.sep_started is not None:
    seconds=int(time.monotonic()-self.sep_started)
    self.sep_elapsed.setText(f'Elapsed: {seconds//60:02d}:{seconds%60:02d}  |  Total time: {seconds//60:02d}:{seconds%60:02d}')
  if error:
   step={'Vocal separation':1,'WhisperX alignment':3,'MP4 export':4,'Visualizer export':4}.get(label)
   if step is not None:self.step_failures[step]=error.splitlines()[0][:180];self.update_step_indicators()
   self.record_diagnostic_error(label,error)
   self.status.setText(label+' failed: '+error.splitlines()[0][:200])
   if label=='Vocal separation':self.sep_note.setText('FAILED — Vocal separation could not finish.\nSee processing details and the error dialog.');self.sep_log.appendPlainText(error[:3000])
   self._quick_karaoke_pending=False
   if self._batch_running:
    QTimer.singleShot(0,lambda e=error:self._batch_failed(e));return
   QMessageBox.critical(self,label+' failed',error[:3000]);return
  try:
   done(result)
   self.update_workflow_tally()
   if final_export:
    if clock.get('first_export_at') is None:
     clock['first_export_at']=completed_at
     clock['first_export_processing_seconds']=sum(max(0.,float(item.get('seconds',0) or 0)) for item in clock['runs'] if item.get('status')=='completed')
    self.update_workflow_tally()
    try:
     timing_path=Path(result).with_suffix('.timing.json')
     timing_path.write_text(json.dumps({'song':self.project.get('song',''),'workflow_timing':clock,
      'total_to_first_export_seconds':clock.get('first_export_processing_seconds'),
      'successful_processing_total_seconds':sum(max(0.,float(item.get('seconds',0) or 0)) for item in clock['runs'] if item.get('status')=='completed'),
      'note':'Successful task-processing time only. Failed/cancelled tasks remain visible in runs but do not increase the displayed overall total.'},indent=2),encoding='utf-8')
    except OSError as exc:self.status.setText('Video exported; timing report could not be saved: '+str(exc))
   step={'Vocal separation':1,'WhisperX alignment':3,'MP4 export':4,'Visualizer export':4}.get(label)
   if step is not None:self.step_snapshots[step]=self._step_fingerprint(step)
   self.update_step_indicators()
   self._quick_karaoke_after_step(label)
   if self._batch_running:QTimer.singleShot(0,lambda stage=label:self._batch_completed_stage(stage))
  except Exception as exc:
   run['status']='result handling failed'
   self._clear_export_congratulations()
   self.activity_bar.setRange(0,100);self.activity_bar.setValue(0)
   self.activity_title.setText('FAILED — '+label)
   self.activity_detail.setText('Result validation failed: '+str(exc)[:200])
   self.status.setText(label+' result failed: '+str(exc)[:200])
   self.update_workflow_tally()
   step={'Vocal separation':1,'WhisperX alignment':3,'MP4 export':4,'Visualizer export':4}.get(label)
   if step is not None:self.step_failures[step]=str(exc)[:180];self.update_step_indicators()
   self.record_diagnostic_error(label+' result',traceback.format_exc())
   if self._batch_running:QTimer.singleShot(0,lambda e=str(exc):self._batch_failed(e))
   else:QMessageBox.critical(self,label+' result error',str(exc))
 def record_diagnostic_error(self,label,error):
  self.last_error=str(error)
  self.diagnostic_history.append({'time':datetime.datetime.now().isoformat(timespec='seconds'),'task':label,'traceback':str(error)})
  self.diagnostic_history=self.diagnostic_history[-20:]
 def open_diagnostics_folder(self):
  """Open the location of the most recently saved diagnostics ZIP, or the default folder."""
  if self.last_diagnostics_path and Path(self.last_diagnostics_path).is_file():
   folder=Path(self.last_diagnostics_path).parent
  else:
   folder=Path.home()
  try:
   if sys.platform=='win32':
    if self.last_diagnostics_path and Path(self.last_diagnostics_path).is_file():
     subprocess.Popen(['explorer.exe','/select,',str(Path(self.last_diagnostics_path))])
    else:
     os.startfile(str(folder))
   elif not QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder))):
    raise RuntimeError('Could not open the folder.')
  except Exception as exc:
   QMessageBox.warning(self,'Cannot open diagnostics folder',str(exc))
 def load_last_export_audit(self):
  try:
   if self.last_export:
    path=Path(self.last_export).with_suffix('.export-audit.json')
    if path.is_file():return json.loads(path.read_text(encoding='utf-8'))
  except Exception as exc:return {'error':str(exc)}
  return None
 def export_diagnostic_settings(self):
  """Record configured settings separately from actual MP4 properties."""
  try:
   return {'resolution':self.resolution.currentText(),'fps':60,
    'encoder':'h264_nvenc' if self.encoder.currentIndex()==1 else 'libx264',
    'nvenc_preset':'p5','nvenc_cq':19,'cpu_crf':18,'aac_bitrate_kbps':320,
    'selected_start_seconds':round(self.export_range.start,3),
    'selected_end_seconds':round(self.export_range.end,3),
    'selected_duration_seconds':round(self.export_range.end-self.export_range.start,3),
    'instrumental_percent':self.instrumental_volume.value(),
    'vocal_percent':self.vocal_volume.value(),
    'studio_video':self.studio_video_settings()}
  except Exception as exc:return {'error':str(exc)}
 def new_export_audit(self,kind,target,width,height,start,end,settings=None):
  requested=self.export_diagnostic_settings()
  requested.update({'resolution':f'{width}x{height}','start_seconds':round(start,3),'end_seconds':round(end,3),'duration_seconds':round(end-start,3)})
  if settings is not None:requested['studio_video']=settings
  return {'build':APP_BUILD,'export_type':kind,'target':str(target),
   'started_at':datetime.datetime.now().isoformat(timespec='seconds'),
   'requested':requested,'status':'started'}
 def inspect_export_mp4(self,path):
  """Probe the completed file; unavailable tools are reported, never guessed."""
  path=Path(path)
  result={'exists':path.is_file()}
  if not path.is_file():return result
  result['size_bytes']=path.stat().st_size
  probe=shutil.which('ffprobe')
  ffmpeg=find_ffmpeg()
  if not probe and ffmpeg:
   candidate=Path(ffmpeg).with_name('ffprobe.exe' if sys.platform=='win32' else 'ffprobe')
   if candidate.is_file():probe=str(candidate)
  if probe:
   try:
    p=subprocess.run([probe,'-v','error','-show_entries','format=duration,size,bit_rate:stream=index,codec_type,codec_name,width,height,r_frame_rate,avg_frame_rate,bit_rate,encoder:stream_tags=encoder','-of','json',str(path)],capture_output=True,text=True,timeout=25,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if p.returncode==0:
     result['probe']='ffprobe';result['metadata']=json.loads(p.stdout);return result
    result['probe_error']=p.stderr[-1000:]
   except Exception as exc:result['probe_error']=str(exc)
  if ffmpeg:
   try:
    p=subprocess.run([ffmpeg,'-hide_banner','-i',str(path)],capture_output=True,text=True,timeout=20,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    result['probe']='ffmpeg-text';result['stream_description']=p.stderr[-4500:]
   except Exception as exc:result['probe_error']=str(exc)
  return result
 def finish_export_audit(self,audit,began,error=None,canceled=False):
  audit['completed_at']=datetime.datetime.now().isoformat(timespec='seconds')
  audit['elapsed_seconds']=round(time.monotonic()-began,3)
  has_error=error is not None
  audit['status']='canceled' if canceled else 'failed' if has_error else 'completed'
  if has_error:audit['error']=str(error)
  audit['actual']=({'file':str(audit['target']),'not_inspected':True,'reason':'This attempt did not publish a verified output; an existing target may belong to an earlier export.'} if has_error or canceled else self.inspect_export_mp4(audit['target']))
  try:
   md=audit['actual'].get('metadata',{});streams=md.get('streams',[])
   video=next((v for v in streams if v.get('codec_type')=='video'),{})
   audio=next((v for v in streams if v.get('codec_type')=='audio'),{})
   def rate(value):
    try:
     a,b=str(value).split('/');return float(a)/float(b) if float(b) else None
    except (ValueError,ZeroDivisionError,AttributeError):return None
   fps=rate(video.get('avg_frame_rate'))
   audit['verification']={'resolution_match':(video.get('width')==int(audit['requested']['resolution'].split('x')[0]) and video.get('height')==int(audit['requested']['resolution'].split('x')[1])) if video else None,
    'fps_match':abs(fps-60)<.15 if fps is not None else None,
    'aac_audio':audio.get('codec_name')=='aac' if audio else None,
    'duration_seconds':float(md['format']['duration']) if md.get('format',{}).get('duration') else None,
    'audio_bitrate_bps':audio.get('bit_rate'),'video_bitrate_bps':video.get('bit_rate'),
    'encoder_metadata':video.get('tags',{}).get('encoder'),
    'note':'CQ and preset are FFmpeg command settings, not verifiable from MP4 metadata.'}
  except Exception as exc:audit['verification_error']=str(exc)
  self.export_audit_history.append(audit)
  self.export_audit_history=self.export_audit_history[-12:]
  try:
   p=Path(audit['target']).with_suffix('.export-audit.json')
   p.write_text(json.dumps(audit,indent=2,ensure_ascii=False),encoding='utf-8')
  except Exception as exc:audit['report_write_error']=str(exc)
 def save_diagnostics(self):
  """User-initiated local ZIP report; never include lyrics, audio, or project contents."""
  if self.job and self.job.isRunning():
   QMessageBox.information(self,'Diagnostics','Please wait for the current task to finish before generating diagnostics.');return
  answer=QMessageBox.question(self,'Save diagnostics report?',
   'This report includes technical details such as Python and package versions, FFmpeg paths, audio file paths and sizes, and recent error tracebacks.\n\nIt does NOT include your audio, lyrics, or project contents. File paths may reveal your Windows username. Review the ZIP before sharing it.\n\nCreate report?',
   QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)
  if answer!=QMessageBox.Yes:return
  suggested=Path.home()/('Karaoke_Maker_Lite_Diagnostics_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip')
  destination,_=QFileDialog.getSaveFileName(self,'Save diagnostic ZIP',str(suggested),'ZIP archives (*.zip)')
  if not destination:return
  try:
   report={'application':'Karaoke Maker Lite','version':APP_BUILD,'generated_at':datetime.datetime.now().isoformat(),
    'platform':platform.platform(),'python_version':sys.version,'python_executable':sys.executable,
    'working_directory':os.getcwd(),'application_file':str(Path(__file__).resolve()),
    'packages':{},'ffmpeg':{},'audio_files':{},'alignment':self.alignment_diagnostics,'errors':self.diagnostic_history,
    'export_settings':self.export_diagnostic_settings(),'export_history':list(self.export_audit_history),
    'last_export_audit':self.load_last_export_audit(),
    'privacy':'Audio contents, lyric text, and project contents excluded; alignment diagnostics contain counts and reasons only; paths and tracebacks may contain personal information.'}
   for name in ('PySide6','whisperx','torch','torchaudio','demucs','imageio-ffmpeg','numpy','soundfile','ctranslate2','faster-whisper'):
    try:report['packages'][name]=importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:report['packages'][name]='not installed'
    except Exception as exc:report['packages'][name]='check failed: '+repr(exc)
   try:
    import torch
    report['torch']={'cuda_available':torch.cuda.is_available(),'cuda_version':torch.version.cuda,
     'gpu':torch.cuda.get_device_name(0) if torch.cuda.is_available() else None}
   except Exception as exc:report['torch']={'error':repr(exc)}
   for key,path in [('original',self.audio.text().strip()),('vocals',self.vocals.text().strip()),('instrumental',self.instrumental.text().strip())]:
    if path:
     f=Path(path)
     report['audio_files'][key]={'path':str(f),'exists':f.is_file(),'size_bytes':f.stat().st_size if f.is_file() else None}
   report['ffmpeg']['path_on_PATH']=shutil.which('ffmpeg')
   report['ffmpeg']['ffprobe_on_PATH']=shutil.which('ffprobe')
   probe=shutil.which('ffprobe')
   if probe:
    try:
     r=subprocess.run([probe,'-version'],capture_output=True,text=True,timeout=10,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
     report['ffmpeg']['ffprobe_check']={'available':r.returncode==0,'first_line':r.stdout.splitlines()[0] if r.stdout else '', 'exit_code':r.returncode}
    except Exception as exc:report['ffmpeg']['ffprobe_check']={'available':False,'error':repr(exc)}
   else:
    report['ffmpeg']['ffprobe_check']={'available':False,'note':'ffprobe is required for verified MP4 export; install it on PATH or beside FFmpeg.'}
   detected=find_ffmpeg()
   report['ffmpeg']['detected_decoder']=detected
   for key,exe in [('PATH',shutil.which('ffmpeg')),('detected',detected)]:
    if not exe:continue
    try:
     result=subprocess.run([exe,'-version'],capture_output=True,text=True,timeout=10,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
     report['ffmpeg'][key+'_version']={'exit_code':result.returncode,'first_line':result.stdout.splitlines()[0] if result.stdout else '', 'stderr':result.stderr[:600]}
    except Exception as exc:report['ffmpeg'][key+'_version']={'error':repr(exc)}
   # Test the same FFmpeg setup path used before WhisperX alignment.
   try:report['ffmpeg']['whisperx_ready_executable']=prepare_whisperx_ffmpeg()
   except Exception as exc:report['ffmpeg']['whisperx_setup_error']=repr(exc)
   for key,path in [('original',self.audio.text().strip()),('vocals',self.vocals.text().strip())]:
    if path and Path(path).is_file() and shutil.which('ffmpeg'):
     try:
      r=subprocess.run(['ffmpeg','-hide_banner','-v','error','-i',path,'-t','0.1','-ac','1','-ar','16000','-f','s16le','-'],capture_output=True,timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
      report['audio_files'][key]['ffmpeg_decode_test']={'exit_code':r.returncode,'bytes_decoded':len(r.stdout),'stderr':r.stderr.decode(errors='replace')[:800]}
     except Exception as exc:report['audio_files'][key]['ffmpeg_decode_test']={'error':repr(exc)}
   destination=Path(destination)
   with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED) as z:
    z.writestr('diagnostics.json',json.dumps(report,indent=2,ensure_ascii=False))
    z.writestr('README.txt','Karaoke Maker Lite diagnostics\n\nReview diagnostics.json before sharing. Paths and tracebacks can reveal usernames and folders. No audio or lyric contents are included.\n')
   self.last_diagnostics_path=str(destination)
   self.status.setText('Diagnostics saved: '+str(destination))
   QMessageBox.information(self,'Diagnostics saved','Report saved to:\n'+str(destination)+'\n\nReview it before uploading here.')
  except Exception as exc:
   QMessageBox.critical(self,'Diagnostics failed',str(exc)+'\n'+traceback.format_exc(limit=3))
 def start_quick_karaoke(self):
  """Optional orchestration of the existing processing steps; never alters models."""
  self.sync_fields()
  if self.job and self.job.isRunning():
   QMessageBox.information(self,'Busy','Wait for the current processing task to finish.');return
  if not Path(self.audio.text().strip()).is_file():
   QMessageBox.warning(self,'Choose a song','Load an audio file in Song first.');return
  if not self.lyrics.toPlainText().strip():
   QMessageBox.warning(self,'Paste lyrics','Paste the correct lyrics before starting Quick Karaoke.');return
  if self.project.get('word_timings'):
   QMessageBox.information(self,'Timing already exists','This project already has word timings. Keeping them unchanged. Review and export when ready.');self.navigate(3);return
  self._quick_karaoke_pending=True
  if Path(self.instrumental.text().strip()).is_file() and Path(self.vocals.text().strip()).is_file():
   QTimer.singleShot(0,self.start_alignment)
  else:
   self.navigate(1)
   self.start_separation()
 def _quick_karaoke_after_step(self,label):
  if not getattr(self,'_quick_karaoke_pending',False):return
  if label=='Vocal separation':
   self.navigate(2)
   QTimer.singleShot(0,self.start_alignment)
  elif label=='WhisperX alignment':
   self._quick_karaoke_pending=False
   self.navigate(3)
   QTimer.singleShot(0,self.fit_song)
   QMessageBox.information(self,'Quick Karaoke ready','Separation and synchronization finished. Check word timing, then use Exact Frame or 10-second MP4 Preview. Export only when the result looks right.')
 def start_separation(self):
  audio=self.audio.text().strip()
  if not Path(audio).is_file():QMessageBox.warning(self,'Missing audio','Choose a song first.');return
  try:import demucs.separate
  except Exception as exc:
   logging.exception('Demucs dependency import failed')
   self._quick_karaoke_pending=False
   QMessageBox.warning(self,'Demucs unavailable',str(exc)+'\n\n'+'Install into Python 3.12: py -3.12 -m pip install demucs\n\nFor NVIDIA GPU acceleration, your existing compatible CUDA PyTorch installation must also be working.');return
  output=Path(audio).parent/'Karaoke Maker Stems'
  model_name=str(self.demucs_model.currentData() or 'htdemucs_ft')
  def job(emit):
   # Demucs runs in a child process, and its audio loader invokes 'ffmpeg' by
   # executable name. imageio-ffmpeg can provide only a versioned executable,
   # so expose an ffmpeg.exe on the inherited PATH before launching Demucs.
   # Use the existing verified setup shared with WhisperX; do not alter models.
   emit('Checking FFmpeg availability for Demucs…')
   prepared_ffmpeg=prepare_whisperx_ffmpeg()
   emit('Demucs decoder ready: '+prepared_ffmpeg)
   # Demucs 4.1.0 may fail to decode M4A even when a usable ffmpeg.exe
   # is available. Decode with our verified FFmpeg first, then give Demucs
   # an ordinary stereo PCM WAV. Keep the original filename stem for its output.
   with tempfile.TemporaryDirectory(prefix='kml_demucs_input_') as input_dir:
    wav=Path(input_dir)/(Path(audio).stem+'.wav')
    emit('Preparing compatible WAV input for Demucs (original unchanged)…')
    run_command([prepared_ffmpeg,'-hide_banner','-nostdin','-y','-loglevel','error',
                 '-i',audio,'-map','0:a:0','-vn','-ac','2','-ar','44100',
                 '-c:a','pcm_s16le',str(wav)],emit)
    if not wav.is_file() or wav.stat().st_size<44:
     raise RuntimeError('FFmpeg did not produce a valid WAV input for Demucs.')
    emit('Running Demucs model: '+model_name+' (GPU if available)…')
    cmd=[sys.executable,'-m','demucs','-n',model_name,'--two-stems','vocals','-o',str(output),str(wav)]
    run_command(cmd,emit)
   # An exact model-specific path is critical: never accidentally pick older
   # standard-model stems when fine-tuned separation was requested.
   stem_dir=output/model_name/Path(audio).stem
   instrumental=stem_dir/'no_vocals.wav'
   vocals=stem_dir/'vocals.wav'
   if not instrumental.is_file() or not vocals.is_file():
    raise RuntimeError('Demucs did not create both stems for '+model_name+' in '+str(stem_dir))
   return str(instrumental),str(vocals)
  self.sep_log.clear()
  self.sep_started=time.monotonic()
  self.sep_elapsed.setText('Elapsed: 00:00  |  Total time: running…')
  if self.job and self.job.isRunning():
   self.sep_started=None
   QMessageBox.information(self,'Busy','A processing task is already running.');return
  self.sep_timer.start(1000)
  self.sep_progress.setRange(0,0)
  self.sep_progress.setFormat('Preparing Demucs…')
  self.sep_note.setText('STARTING — '+model_name+' vocal separation…')
  self.sep_progress.show()
  def done(paths):
   self.instrumental.setText(paths[0]);self.vocals.setText(paths[1]);self.sync_fields();self.status.setText('Demucs finished — stems ready')
   self.sep_progress.setRange(0,100);self.sep_progress.setValue(100);self.sep_progress.setFormat('100% — Separation complete')
   self.update_stem_monitor();self.load_waveform(self.vocals.text().strip())
   self.sep_note.setText('COMPLETE — '+model_name+' separation finished successfully!\nInstrumental and vocal tracks are ready. Continue to 03 LYRICS.')
   self.sep_log.appendPlainText('Finished successfully. Both stem paths have been populated.')
   # No completion tone for separation; celebrate only completed exports.
   self.navigate(2)
  self.begin_job('Vocal separation',job,done)
 def open_dero_benchmark(self):
  """Launch isolated, read-only benchmark interface; never mutates the project."""
  script=Path(__file__).resolve().with_name('dero_benchmark_gui.py')
  if not script.is_file():
   QMessageBox.warning(self,'DeRo Benchmark','Missing dero_benchmark_gui.py beside the application.');return
  try:
   subprocess.Popen([sys.executable,str(script)],cwd=str(script.parent),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  except Exception as exc:QMessageBox.critical(self,'DeRo Benchmark',str(exc))

 def sync_json_export_folder(self):
  """Open the folder containing the last exported Sync Inspector JSON."""
  saved=str(self.app_settings.value('last_sync_json_export','') or '')
  target=Path(saved).expanduser() if saved else Path.home()/'Karaoke_Sync_Inspector.json'
  folder=target.parent
  if not folder.is_dir():
   QMessageBox.warning(self,'JSON export folder','Folder does not exist: '+str(folder));return
  try:
   if sys.platform=='win32':
    if target.is_file():subprocess.Popen(['explorer.exe','/select,',str(target.resolve())])
    else:subprocess.Popen(['explorer.exe',str(folder.resolve())])
   elif not QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder.resolve()))):
    raise RuntimeError('Could not open the folder.')
  except Exception as exc:QMessageBox.warning(self,'JSON export folder',str(exc))

 def sync_review_export_folder(self):
  saved=str(self.app_settings.value('last_sync_review_folder','') or '')
  previous=str(self.app_settings.value('last_sync_review_export','') or '')
  candidates=[]
  if saved:candidates.append(Path(saved).expanduser())
  if previous:candidates.append(Path(previous).expanduser().parent)
  if self.path:candidates.append(Path(self.path).expanduser().parent)
  audio=self.audio.text().strip()
  if audio:candidates.append(Path(audio).expanduser().parent)
  candidates.append(Path.home())
  return next(folder for folder in candidates if folder.is_dir())

 def open_sync_review_folder(self):
  folder=self.sync_review_export_folder()
  saved=str(self.app_settings.value('last_sync_review_export','') or '')
  target=Path(saved).expanduser() if saved else None
  try:
   if sys.platform=='win32':
    if target is not None and target.is_file() and target.resolve().parent==folder.resolve():
     subprocess.Popen(['explorer.exe','/select,',str(target.resolve())])
    else:subprocess.Popen(['explorer.exe',str(folder.resolve())])
   elif not QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder.resolve()))):
    raise RuntimeError('Could not open the review folder.')
  except Exception as exc:QMessageBox.warning(self,'Review export folder',str(exc))

 def export_sync_review(self):
  """Create a self-contained, offline, zoomable waveform and word-timing report."""
  from dero_sync_review_exporter import build_review_html
  if not self.project.get('events'):
   QMessageBox.information(self,'Export Sync Review','Synchronize or load lyrics before exporting a review.');return
  vocals=self.vocal_waveform_path()
  if not vocals:
   QMessageBox.warning(self,'Export Sync Review','An isolated vocals file is required. Complete Separation or browse to vocals.wav.');return
  ffmpeg=find_ffmpeg()
  if not ffmpeg:
   QMessageBox.warning(self,'Export Sync Review','FFmpeg was not found. Install FFmpeg or configure C:\\\\FFmpeg\\\\bin.');return
  self.sync_fields()
  suggestion=self.sync_review_export_folder() / (safe_song_filename('',self.project.get('song') or 'Song')+'_DeRo_Sync_Review.html')
  target,_=QFileDialog.getSaveFileName(self,'Export interactive Sync Review',str(suggestion),'Interactive HTML review (*.html)')
  if not target:return
  if not target.lower().endswith('.html'):target+='.html'
  if self.job and self.job.isRunning():
   QMessageBox.information(self,'Busy','A processing task is already running.');return
  self.app_settings.setValue('last_sync_review_folder',str(Path(target).resolve().parent))
  project=copy.deepcopy(self.project)
  def job(emit):
   emit('Decoding isolated vocals for the review…')
   return build_review_html(project,vocals,target,ffmpeg,progress=emit)
  def done(report):
   self.app_settings.setValue('last_sync_review_export',str(Path(report['path']).resolve()))
   QMessageBox.information(self,'Sync Review exported',
    'Created: '+report['path']+'\n\n'
    +str(report['lines'])+' lines, '+str(report['words'])+' words. '
    +'Size: '+f"{report['bytes']/1048576:.1f}"+' MB.\n\n'
    +'Open the HTML in Edge or Chrome. It contains its own audio, waveform, and exact stored timestamps.')
   QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(target).resolve())))
  self.begin_job('Sync review export',job,done)

 def show_sync_inspector(self):
  """Developer-only, read-only inspector. Raw data is kept separate from editable lyrics."""
  d=QDialog(self);d.setWindowTitle('Developer Diagnostics — Synchronization Inspector');d.resize(1130,760)
  layout=QVBoxLayout(d)
  note=QLabel('Read-only diagnostic data. Pasted lyrics remain authoritative. Raw results are captured only by synchronization runs made with v0100_33 or later.')
  note.setWordWrap(True);layout.addWidget(note)
  data=self.project.get('sync_inspector',{})
  if not data:
   layout.addWidget(QLabel('No raw alignment snapshot in this project. Run Auto-sync again to collect one. Back up manually corrected timing first: auto-sync can replace edits.'))
  else:
   tabs=SafeValueCombo();tabs.addItems(['Comparison: raw WhisperX vs final words','Raw WhisperX aligned words','Recognized transcript','WhisperX alignment input windows']);layout.addWidget(tabs)
   table=QTableWidget();table.setEditTriggers(QTableWidget.NoEditTriggers);table.setAlternatingRowColors(True);table.setSortingEnabled(False)
   layout.addWidget(table,1)
   raw=data.get('raw_aligned_segments',[])
   def fmt(value):
    try:return f'{float(value):.3f}' if value is not None else '—'
    except (ValueError,TypeError):return '—'
   def render(index):
    rows=[]
    if index==0:
     headers=['Line','Final word','Final start','Final end','WhisperX word','Raw start','Raw end','Start Δ (ms)','End Δ (ms)','Status']
     for i,ev in enumerate(self.project.get('events',[])):
      final=self.project.get('word_timings',{}).get(str(i),[])
      rawwords=raw[i].get('words',[]) if i<len(raw) else []
      def norm(t):return re.sub(r'[^\w]+','',str(t).casefold(),flags=re.UNICODE)
      matcher=difflib.SequenceMatcher(None,[norm(x[2]) for x in final],[norm(x.get('word','')) for x in rawwords],autojunk=False)
      paired={}
      for block in matcher.get_matching_blocks():
       for k in range(block.size):paired[block.a+k]=block.b+k
      for j,w in enumerate(final):
       rw=rawwords[paired[j]] if j in paired else None
       def delta(k):
        if rw is None or rw.get(k) is None:return '—'
        try:return str(round((float(w[0 if k=='start' else 1])-float(rw[k]))*1000))
        except (ValueError,TypeError):return '—'
       rows.append([str(i+1),str(w[2]),fmt(w[0]),fmt(w[1]),str(rw.get('word','')) if rw else '—',fmt(rw.get('start')) if rw else '—',fmt(rw.get('end')) if rw else '—',delta('start'),delta('end'), 'matched text' if rw else 'estimated/unmatched'])
    elif index==1:
     headers=['Line','Raw word','Start','End','Score']
     for i,seg in enumerate(raw):
      for w in seg.get('words',[]):rows.append([str(i+1),str(w.get('word','')),fmt(w.get('start')),fmt(w.get('end')),fmt(w.get('score'))])
    elif index==2:
     headers=['Segment','Start','End','Recognized text']
     for i,seg in enumerate(data.get('recognized_segments',[])):rows.append([str(i+1),fmt(seg.get('start')),fmt(seg.get('end')),str(seg.get('text',''))])
    else:
     headers=['Line','Proposed start','Proposed end','Pasted text sent to aligner']
     for i,seg in enumerate(data.get('alignment_inputs',[])):rows.append([str(i+1),fmt(seg.get('start')),fmt(seg.get('end')),str(seg.get('text',''))])
    table.clear();table.setColumnCount(len(headers));table.setHorizontalHeaderLabels(headers);table.setRowCount(len(rows))
    for r,row in enumerate(rows):
     for c,value in enumerate(row):table.setItem(r,c,QTableWidgetItem(value))
    table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
    table.horizontalHeader().setStretchLastSection(True)
    table.resizeColumnsToContents()
   tabs.currentIndexChanged.connect(render);render(0)
  actions=QHBoxLayout();layout.addLayout(actions)
  def export():
   if not data:return
   previous=str(self.app_settings.value('last_sync_json_export','') or '')
   export_dir=Path(previous).expanduser().parent if previous else Path.home()
   # Use the same artist/title source and filename sanitizer as video export.
   artist=self.artist.text().strip() or str(self.project.get('artist','') or '').strip()
   song=self.song.text().strip() or str(self.project.get('song','') or '').strip()
   basename=safe_song_filename(artist,song,'Untitled Song')
   name=export_dir / (basename+' - Sync Lyrics.json')
   path,_=QFileDialog.getSaveFileName(d,'Export sync inspector',str(name),'JSON files (*.json)')
   if not path:return
   try:
    payload={'schema':1,'notice':'Contains song lyrics, raw AI transcription, file/project metadata and timings. Review before sharing.', 'song':self.project.get('song',''), 'artist':self.project.get('artist',''), 'sync_inspector':data,'final_events':self.project.get('events',[]),'final_word_timings':self.project.get('word_timings',{}),'alignment_status':self.project.get('alignment_status',{}),'word_scores':self.project.get('word_scores',{})}
    Path(path).write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding='utf-8')
    self.app_settings.setValue('last_sync_json_export',str(Path(path).resolve()))
    QMessageBox.information(d,'Export complete','Saved detailed synchronization report. It contains lyric text; review before sharing.')
   except Exception as exc:QMessageBox.critical(d,'Export failed',str(exc))
  actions.addWidget(btn('Export detailed JSON',export));actions.addWidget(btn('Open JSON export folder',self.sync_json_export_folder));actions.addStretch();actions.addWidget(btn('Close',d.accept))
  d.exec()

 def start_alignment(self,batch_mode=False):
  self.sync_fields()
  source=self.vocal_waveform_path()
  if not source:
   self._quick_karaoke_pending=False
   QMessageBox.warning(self,'Isolated vocals required',
    'Word Sync needs the separated vocals.wav file. No valid vocal stem is connected to this project.\n\n'
    'Open 02 SEPARATION and select an existing vocals.wav file, or run Demucs.\n'
    'Your pasted lyrics and existing word timings have not been changed.')
   self.load_waveform()
   return
  self.load_waveform()
  lyrics=[x.strip() for x in self.lyrics.toPlainText().splitlines() if x.strip()]
  if not lyrics:QMessageBox.warning(self,'Missing lyrics','Paste your correct lyrics first.');return
  try:import whisperx
  except Exception as exc:
   logging.exception('WhisperX dependency import failed')
   self._quick_karaoke_pending=False
   QMessageBox.warning(self,'WhisperX unavailable',str(exc)+'\n\n'+'Install WhisperX in your Python 3.12 environment. Check your working PyTorch/CUDA setup before changing it.');return
  if self.project.get('word_timings') and batch_mode:
   self._batch_failed('Existing word timings require manual review; refusing to overwrite.');return
  if self.project.get('word_timings'):
   if QMessageBox.question(self,'Replace existing word timings?','Automatic alignment will replace existing manual word timing edits. Continue?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
  try:prepare_whisperx_ffmpeg()
  except Exception as exc:
   self._quick_karaoke_pending=False
   QMessageBox.critical(self,'FFmpeg setup for WhisperX failed',str(exc));return
  # Work on an immutable copy of the user's text. Never replace it with recognition output.
  original_lyrics=self.lyrics.toPlainText()
  requested_language=self.song_language.currentData() or 'auto'
  def job(emit):
   import whisperx,torch
   device='cuda' if torch.cuda.is_available() else 'cpu';compute='float16' if device=='cuda' else 'int8'
   emit('Loading WhisperX audio…');audio=whisperx.load_audio(source)
   # Build 0.1.0.31 produced the best verified synchronization. Preserve its
   # recognition model and batch size while a replacement alignment strategy
   # is developed from real-song evidence.
   recognition_model='small';batch_size=8
   emit(f'Loading {recognition_model} speech recognition model…');model=whisperx.load_model(recognition_model,device,compute_type=compute)
   # Forced languages bypass Whisper's unreliable song-language detector.
   # Auto is intentionally restricted to English and Spanish, the two
   # languages offered by the UI and supported by WhisperX aligners.
   if requested_language in ('en','es'):
    language=requested_language
    emit('Song language selected: '+('English' if language=='en' else 'Spanish')+' (automatic detection bypassed)')
    result=model.transcribe(audio,batch_size=batch_size,language=language)
    detected_language='manual:'+language
    language_source='manual'
   else:
    result=model.transcribe(audio,batch_size=batch_size)
    detected_language=str(result.get('language') or 'unknown').lower().strip()
    language=detected_language
    language_source='automatic'
    if language not in ('en','es'):
     # The user's pasted words are the safest language clue when the model
     # reports Latin or another code we cannot align in this workflow.
     import unicodedata
     tokens=[unicodedata.normalize('NFKD',w).casefold().strip('.,!?¿¡:;()[]"\'') for line in lyrics for w in line.split()]
     english={'the','and','you','your','i','me','my','we','are','is','it','to','of','in','that','for','with','love','dont','not','on','this','be','was','can','have'}
     spanish={'que','de','la','el','los','las','yo','tu','te','mi','me','es','en','un','una','con','por','para','como','pero','si','amor','corazon','quiero','estoy','eres','tengo'}
     english_score=sum(w in english for w in tokens)
     spanish_score=sum(w in spanish for w in tokens)
     language='es' if spanish_score>english_score else 'en'
     language_source='lyrics_fallback'
     emit('Detected unsupported/uncertain language '+detected_language+'. Pasted-lyrics clue: '+('Spanish' if language=='es' else 'English')+'.')
     emit('Retrying transcription as '+language+'; pasted lyrics will not be modified.')
     result=model.transcribe(audio,batch_size=batch_size,language=language)
   del model
   if device=='cuda':torch.cuda.empty_cache()
   emit('Alignment language: '+language+' (detected: '+detected_language+'; source: '+language_source+') — matching pasted words')
   recognized=[seg for seg in result.get('segments',[]) if str(seg.get('text','')).strip()]
   if not recognized:raise RuntimeError('No speech was recognized. Try using a vocal stem.')
   # Align the recognized transcript first. ASR segment boundaries can span
   # thirty seconds; evenly dividing those segments produced inaccurate lyric
   # windows. Real word timestamps provide the global anchors instead.
   def normalize(word):return re.sub(r'[^\w]+','',word.casefold(),flags=re.UNICODE)
   emit('Finding word-level anchors in the recognized vocals…')
   align_model,metadata=whisperx.load_align_model(language_code=language,device=device)
   recognized_alignment=whisperx.align(recognized,align_model,metadata,audio,device,return_char_alignments=False)
   recognized_aligned=recognized_alignment.get('segments',[])
   ref=[]
   for seg in recognized_aligned:
    for word in seg.get('words',[]):
     try:
      token=str(word.get('word','')).strip();a=float(word['start']);b=float(word['end'])
      if normalize(token) and math.isfinite(a) and math.isfinite(b) and b>a:ref.append((normalize(token),a,b))
     except (KeyError,TypeError,ValueError):continue
   flat=[(i,token) for i,line in enumerate(lyrics) for token in line.split()]
   anchors=monotonic_word_anchors([token for _,token in flat],ref,normalize)
   candidate_anchor_count=len(anchors)
   if not ref:raise RuntimeError('No recognized words to use as timing anchors')
   if not anchors:raise RuntimeError('No pasted lyric words matched the recognized word timestamps')
   # A tiny recognized transcript is not an acceptable basis for a full-song map.
   # Do NOT overwrite existing timings with invented equally spaced guesses.
   minimum_words=min(len(flat),max(8,math.ceil(len(flat)*.20)))
   minimum_anchors=min(len(flat),max(4,math.ceil(len(flat)*.08)))
   if len(ref)<minimum_words or len(anchors)<minimum_anchors:
    raise RuntimeError(
     f'Automatic synchronization stopped: WhisperX recognized only {len(ref)} timed words '
     f'and matched {len(anchors)} of {len(flat)} pasted words. '
     f'Minimum required for this song: {minimum_words} recognized and {minimum_anchors} matching words. '
     'No lyrics or existing word timings were replaced. '
     'Check that the isolated vocal stem contains clear singing; try a better vocal separation or a stronger Whisper model.')
   line_counts=[len(line.split()) for line in lyrics]
   alignment_windows,anchors=prepare_alignment_windows(line_counts,anchors)
   segments=[{'start':a,'end':b,'text':line} for line,(a,b) in zip(lyrics,alignment_windows)]
   emit('Aligning exact pasted lyrics with WhisperX…')
   aligned=whisperx.align(segments,align_model,metadata,audio,device,return_char_alignments=False)
   returned_aligned_segments=aligned.get('segments',[])
   aligned_segments=reconcile_alignment_segments(segments,returned_aligned_segments,normalize)
   missing_segment_count=sum(seg is None for seg in aligned_segments)
   if missing_segment_count:
    emit(f'WhisperX omitted {missing_segment_count} lyric line(s); using local anchor windows for those lines.')
   output=[];wordmap={};statuses={};scores={};reasons={};matched_counts={};direct_anchor_counts={};offset=0
   for i,line in enumerate(lyrics):
    seg=aligned_segments[i];segment_missing=seg is None;seg=seg or {}
    exact=line.split();input_a=float(segments[i]['start']);input_b=float(segments[i]['end']);a=float(seg.get('start',input_a));b=float(seg.get('end',input_b))
    candidates=[w for w in seg.get('words',[]) if str(w.get('word','')).strip()]
    recovered,word_scores,matched_count,valid_count=recover_line_timings(exact,candidates,a,b,normalize)
    reliable,quality_reason=forced_alignment_quality(exact,recovered,word_scores)
    if segment_missing:reliable=False;quality_reason='whisperx_segment_missing'
    direct_count=sum((offset+j) in anchors for j in range(len(exact)))
    if reliable:
     output.append([round(a,3),round(max(a+.1,b),3),line]);wordmap[str(i)]=recovered
    else:
     output.append([round(input_a,3),round(max(input_a+.1,input_b),3),line]);wordmap[str(i)]=estimate_line_timings(exact,input_a,input_b)
    scores[str(i)]=word_scores
    direct_anchor_counts[str(i)]=direct_count
    if not reliable and exact:
     statuses[str(i)]='estimated'
     reasons[str(i)]=quality_reason
    elif direct_count==0 and exact:
     statuses[str(i)]='estimated'
     reasons[str(i)]='no_direct_transcript_support'
    elif matched_count==len(exact) and direct_count>=max(1,math.ceil(len(exact)*.4)):
     statuses[str(i)]='aligned'
     reasons[str(i)]='all_words_text_matched_to_whisperx_timestamps'
    elif matched_count>0:
     statuses[str(i)]='partial'
     reasons[str(i)]=f'{matched_count}_of_{len(exact)}_words_timed_from_whisperx'
    else:
     statuses[str(i)]='estimated' if exact else 'failed'
     reasons[str(i)]='no_matching_timestamped_words' if exact else 'empty_line'
    matched_counts[str(i)]=matched_count
    offset+=len(exact)
   trusted_lines=sum(status in ('aligned','partial') for status in statuses.values())
   if trusted_lines==0 or trusted_lines < min(len(lyrics),max(2,math.ceil(len(lyrics)*.10))):
    raise RuntimeError(
     f'Automatic sync rejected: only {trusted_lines} of {len(lyrics)} lines have any supported '
     'alignment; the remainder are estimated. Existing word timings have NOT been replaced. '
     'Please review the vocals stem and recognition quality before retrying.')
   inspector={'schema':3,'build':APP_BUILD,'recognition_model':recognition_model,'detected_language':detected_language,'language':language,'requested_language':requested_language,'language_source':language_source,'recognized_segments':[{'start':seg.get('start'),'end':seg.get('end'),'text':seg.get('text','')} for seg in recognized], 'recognized_words':[{'token':token,'start':a,'end':b} for token,a,b in ref], 'recognized_word_anchors':len(ref), 'candidate_anchor_words':candidate_anchor_count, 'reliable_anchor_words':len(anchors), 'returned_alignment_segments':len(returned_aligned_segments), 'missing_alignment_segments':missing_segment_count, 'direct_anchor_counts':direct_anchor_counts, 'alignment_inputs':[{'start':seg['start'],'end':seg['end'],'text':seg['text']} for seg in segments], 'raw_aligned_segments':[{'missing':seg is None,'start':(seg or {}).get('start'),'end':(seg or {}).get('end'),'text':(seg or {}).get('text',''),'words':[{'word':w.get('word',''),'start':w.get('start'),'end':w.get('end'),'score':w.get('score')} for w in (seg or {}).get('words',[])]} for seg in aligned_segments]};
   summary={'build':APP_BUILD,'recognition_model':recognition_model,'detected_language':detected_language,'language':language,'requested_language':requested_language,'language_source':language_source,'total_lines':len(lyrics),'recognized_segments':len(recognized),'recognized_tokens':len(ref),'pasted_tokens':len(flat),'candidate_anchor_tokens':candidate_anchor_count,'anchored_tokens':len(anchors),'returned_alignment_segments':len(returned_aligned_segments),'missing_alignment_segments':missing_segment_count,'line_details':[{'line_index':i+1,'status':statuses[str(i)],'reason':reasons[str(i)],'word_count':len(lyrics[i].split()),'direct_anchor_words':direct_anchor_counts[str(i)],'review_confidence':('high' if direct_anchor_counts[str(i)]>=max(1,math.ceil(len(lyrics[i].split())*.6)) else 'medium' if direct_anchor_counts[str(i)] else 'review'),'scored_words':sum(isinstance(v,(int,float)) for v in scores[str(i)]),'matched_timed_words':matched_counts[str(i)]} for i in range(len(lyrics))], 'note':'No lyric text or audio included. Timing behavior is restored to the verified 0.1.0.31 path. Missing WhisperX result segments use their anchored local window instead of aborting the whole song.'}
   return output,wordmap,language,statuses,scores,summary,inspector
  def done(result):
   self.snapshot()
   self.project['authoritative_lyrics']=original_lyrics
   self.project['events']=result[0];self.project['word_timings']=result[1];self.project['ai_word_timings']=copy.deepcopy(result[1])
   self.project['alignment_status']=result[3];self.project['word_scores']=result[4]
   self.project['manual_overrides']={}
   self.project['reviewed_lines']={}  # Fresh alignment invalidates prior review checks.
   self.alignment_diagnostics=result[5]
   self.project['sync_inspector']=result[6]
   self.refresh()
   counts={key:list(result[3].values()).count(key) for key in ('aligned','partial','estimated','failed')}
   summary=f"Timestamp-matched: {counts['aligned']}  |  Partial: {counts['partial']}  |  Estimated: {counts['estimated']}  |  Failed: {counts['failed']}"
   self.status.setText('Alignment finished ('+result[2]+'). '+summary)
   # No completion tone for alignment; celebrate only completed exports.
   if batch_mode:
    self.navigate(3)
    return
   quality_box=QMessageBox(self)
   quality_box.setWindowTitle('Synchronization quality')
   quality_box.setIcon(QMessageBox.Information)
   quality_box.setText(summary+'\\n\\nPartial and estimated lines need manual review. Timestamp matches do not guarantee audible accuracy. Your pasted lyrics were preserved.')
   inspect_button=quality_box.addButton('Export JSON / Sync Inspector',QMessageBox.ActionRole)
   folder_button=quality_box.addButton('Open JSON export folder',QMessageBox.ActionRole)
   quality_box.addButton(QMessageBox.Ok)
   quality_box.exec()
   if quality_box.clickedButton() is inspect_button:self.show_sync_inspector()
   elif quality_box.clickedButton() is folder_button:self.sync_json_export_folder()
   self.navigate(3)
   QTimer.singleShot(0,self.fit_song)
  self.begin_job('WhisperX alignment',job,done)


 def studio_video_defaults(self):
  return {'enabled':False,'background':'','background_color':'#0B1224','visualizer':True,'style':'Classic Spectrum',
   'bars':32,'spectrum_color':'#35A5FF','spectrum_height':240,'particles':True,'particle_count':10,
   'particle_color':'#FFDE59','title_enabled':False,'title_seconds':3.0,'outro_enabled':False,
   'outro_seconds':2.0,'video_fps':30,'motion_background':''}
 def studio_video_settings(self):
  result=self.studio_video_defaults()
  result.update(self.project.get('studio_video',{}))
  return result
 def open_lyric_formatting(self):
  """One shared project, maximized formatting workspace; no extra project tab."""
  if self.formatting_window is not None:
   self.refresh_formatting_window();self.formatting_window.showMaximized();self.formatting_window.raise_();self.formatting_window.activateWindow();return
  dlg=QDialog(self);dlg.setWindowTitle('DeRo Sync — Lyric Formatting & Effects Studio · v0.2.0.64')
  dlg.setWindowFlags(Qt.Window);dlg.setMinimumSize(850,570)
  self.formatting_window=dlg;self._formatting_controls={}
  root=QVBoxLayout(dlg);root.setContentsMargins(12,10,12,10);root.setSpacing(8)
  header=QHBoxLayout();header.addWidget(QLabel('LYRIC FORMATTING & EFFECTS STUDIO'),1)
  header.addWidget(btn('↶ Undo project',self.do_undo));header.addWidget(btn('↷ Redo project',self.do_redo))
  header.addWidget(btn('Save project',self.save_project));header.addWidget(btn('Close',dlg.close));root.addLayout(header)
  hint=QLabel('Live project settings • Sections start compact • Spin boxes and dropdowns ignore accidental mouse-wheel changes')
  hint.setObjectName('muted');root.addWidget(hint)
  scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.NoFrame)
  scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  grid_body=QWidget();grid=QGridLayout(grid_body);grid.setSpacing(10)
  scroll.setWidget(grid_body);root.addWidget(scroll,3)
  def group(title,r,c,open_default=True):
   g=QGroupBox(title);g.setCheckable(True);g.setChecked(bool(self.app_settings.value('format_section_'+title,open_default,type=bool)))
   g.setStyleSheet('QGroupBox{font-weight:bold;border:1px solid #405172;border-radius:9px;margin-top:8px;padding:8px} QGroupBox::title{subcontrol-origin:margin;left:12px;padding:0 4px}')
   outer=QVBoxLayout(g);body=QWidget();layout=QFormLayout(body);layout.setContentsMargins(2,4,2,2);layout.setSpacing(7);outer.addWidget(body)
   body.setVisible(g.isChecked());g.toggled.connect(body.setVisible)
   g.toggled.connect(lambda enabled,key=title:self.app_settings.setValue('format_section_'+key,enabled))
   grid.addWidget(g,r,c);return layout,g
  def make_spin(layout,label,key,minimum,maximum,step=1,suffix='',default=0):
   spin=SafeValueSpin();spin.setRange(minimum,maximum);spin.setSingleStep(step);spin.setDecimals(1 if step<1 else 0);spin.setSuffix(suffix)
   spin.setValue(float(self.project.get(key,default)));layout.addRow(label,spin)
   self._formatting_controls[key]=spin
   spin.editingFinished.connect(lambda k=key,w=spin:self.commit_format_setting(k,int(w.value()) if w.decimals()==0 else float(w.value())))
   return spin
  def make_check(layout,label,key,default=False):
   control=QCheckBox(label);control.setChecked(bool(self.project.get(key,default)));layout.addRow(control)
   self._formatting_controls[key]=control
   control.toggled.connect(lambda v,k=key:self.commit_format_setting(k,v))
   return control
  def linked(layout,label,key,control):
   # Main export controls remain authoritative; editing this window updates them.
   if isinstance(control,QDoubleSpinBox):
    widget=SafeValueSpin();widget.setRange(control.minimum(),control.maximum());widget.setDecimals(control.decimals());widget.setSingleStep(control.singleStep());widget.setSuffix(control.suffix());widget.setValue(control.value())
    widget.editingFinished.connect(lambda w=widget,c=control:self.commit_linked_format(c,w.value()))
   elif isinstance(control,QCheckBox):
    widget=QCheckBox();widget.setChecked(control.isChecked());widget.toggled.connect(lambda v,c=control:self.commit_linked_format(c,v))
   elif isinstance(control,QFontComboBox):
    widget=SafeFontCombo();widget.setCurrentFont(control.currentFont())
    widget.currentFontChanged.connect(lambda font,c=control:self.commit_linked_format(c,font))
   elif isinstance(control,QComboBox):
    widget=SafeValueCombo()
    for i in range(control.count()):widget.addItem(control.itemText(i),control.itemData(i))
    widget.setCurrentIndex(control.currentIndex())
    widget.currentIndexChanged.connect(lambda i,c=control:self.commit_linked_format(c,i))
   else:return
   self._formatting_controls[key]=widget;layout.addRow(label,widget)
  typography,_=group('Typography & position',0,0)
  linked(typography,'Font family','lyric_font_family',self.lyric_font_family)
  linked(typography,'Font size','lyric_font_size',self.lyric_font_size)
  linked(typography,'Bold','lyric_font_bold',self.lyric_font_bold)
  linked(typography,'Vertical position','lyric_vertical_percent',self.lyric_vertical)
  colors,_=group('Colors & highlighting',0,1)
  linked(colors,'Color preset','lyric_color_preset',self.lyric_color_preset)
  linked(colors,'Reverse colors','lyric_reverse_colors',self.reverse_lyric_colors)
  colors.addRow(btn('Choose unsung color',lambda:self.choose_formatting_color('unsung')))
  colors.addRow(btn('Choose sung color',lambda:self.choose_formatting_color('sung')))
  fades,_=group('Fades & animation',1,0)
  linked(fades,'Display mode','lyric_display_mode',self.lyric_display_mode)
  linked(fades,'Fade in (ms)','classic_flow_fade_in',self.classic_flow_fade_in)
  linked(fades,'Normal fade out (ms)','classic_flow_fade_out',self.classic_flow_fade_out)
  make_spin(fades,'Final song lyric fade (ms)','lyric_final_fade_out',0,5000,100,' ms',2000)
  linked(fades,'Hold after words (ms)','lyric_exit_delay',self.exit_delay)
  silence,_=group('Silence progress bar',1,1)
  make_check(silence,'Show between long lyric gaps','silence_progress_enabled',False)
  make_spin(silence,'Minimum gap (seconds)','silence_progress_threshold',1,60,.5,' s',5)
  silence.addRow(QLabel('Progress fill only — no countdown text.'))
  advanced,_=group('Advanced & opening',2,0,False)
  linked(advanced,'Outline','lyric_outline',self.lyric_outline)
  linked(advanced,'Rows per page','classic_flow_lines',self.classic_flow_lines)
  linked(advanced,'Lyric lead','lyric_lead_seconds',self.lyric_lead)
  linked(advanced,'Opening bar','opening_progress_enabled',self.opening_progress_enabled)
  linked(advanced,'Opening duration','opening_progress_duration',self.opening_progress_duration)
  linked(advanced,'Opening lead','opening_progress_before',self.opening_progress_before)
  export,_=group('Other lyric exit',2,1,False)
  linked(export,'Exit effect','lyric_exit',self.exit_effect)
  linked(export,'Standard exit fade','lyric_exit_duration',self.exit_duration)
  lower=QHBoxLayout();root.addLayout(lower)
  lower.addWidget(btn('Collapse all',lambda:self.toggle_formatting_groups(False)))
  lower.addWidget(btn('Expand all',lambda:self.toggle_formatting_groups(True)))
  lower.addStretch()
  preview=QLabel();preview.setMinimumHeight(105);preview.setAlignment(Qt.AlignCenter)
  preview.setStyleSheet('background:#0b1329;border:1px solid #3c4b6a;border-radius:10px;padding:14px')
  root.addWidget(preview,1);self.formatting_preview=preview
  self.refresh_formatting_window()
  dlg.finished.connect(self._formatting_closed)
  dlg.showMaximized()
 def _formatting_closed(self,*args):
  self.formatting_window=None;self._formatting_controls={};self.formatting_preview=None
 def toggle_formatting_groups(self,expanded):
  if not self.formatting_window:return
  for group in self.formatting_window.findChildren(QGroupBox):group.setChecked(expanded)
 def commit_linked_format(self,target,value):
  if self._formatting_update or self.updating:return
  current=target.currentFont() if isinstance(target,QFontComboBox) else target.isChecked() if isinstance(target,QCheckBox) else target.currentIndex() if isinstance(target,QComboBox) else target.value()
  if current==value:return
  self.sync_fields();self.snapshot()
  if isinstance(target,QFontComboBox):target.setCurrentFont(value)
  elif isinstance(target,QCheckBox):target.setChecked(value)
  elif isinstance(target,QComboBox):target.setCurrentIndex(value)
  else:target.setValue(value)
  self.sync_fields();self.refresh_formatting_window()
 def commit_format_setting(self,key,value):
  if self._formatting_update or self.updating:return
  self.sync_fields()
  if self.project.get(key, False if key=='silence_progress_enabled' else 5 if key=='silence_progress_threshold' else 2000)==value:return
  self.snapshot();self.project[key]=value
  self.refresh_formatting_window()
 def choose_formatting_color(self,kind):
  self.sync_fields();old=self.lyric_colors()[0 if kind=='unsung' else 1]
  color=QColorDialog.getColor(QColor(old),self.formatting_window,'Choose lyric color')
  if not color.isValid():return
  self.snapshot()
  # choose_lyric_color uses the same underlying palette; avoid a second dialog.
  reverse=self.reverse_lyric_colors.isChecked()
  if kind=='unsung':
   if reverse:self.lyric_base_sung=color.name().upper()
   else:self.lyric_base_unsung=color.name().upper()
  else:
   if reverse:self.lyric_base_unsung=color.name().upper()
   else:self.lyric_base_sung=color.name().upper()
  self.lyric_color_preset.setCurrentText('Custom');self.update_lyric_color_preview();self.sync_fields();self.refresh_formatting_window()
 def refresh_formatting_window(self):
  if self.formatting_window is None:return
  self._formatting_update=True
  try:
   mapping={'lyric_font_family':self.lyric_font_family,'lyric_font_size':self.lyric_font_size,'lyric_font_bold':self.lyric_font_bold,'lyric_vertical_percent':self.lyric_vertical,'lyric_color_preset':self.lyric_color_preset,'lyric_reverse_colors':self.reverse_lyric_colors,'lyric_display_mode':self.lyric_display_mode,'classic_flow_fade_in':self.classic_flow_fade_in,'classic_flow_fade_out':self.classic_flow_fade_out,'lyric_exit_delay':self.exit_delay,'lyric_outline':self.lyric_outline,'classic_flow_lines':self.classic_flow_lines,'lyric_lead_seconds':self.lyric_lead,'opening_progress_enabled':self.opening_progress_enabled,'opening_progress_duration':self.opening_progress_duration,'opening_progress_before':self.opening_progress_before,'lyric_exit':self.exit_effect,'lyric_exit_duration':self.exit_duration}
   for key,widget in self._formatting_controls.items():
    source=mapping.get(key)
    if source is not None:
     if isinstance(source,QFontComboBox):
      if isinstance(widget,QFontComboBox):widget.setCurrentFont(source.currentFont())
      else:widget.setCurrentText(source.currentFont().family())
     elif isinstance(source,QCheckBox):widget.setChecked(source.isChecked())
     elif isinstance(source,QComboBox):widget.setCurrentIndex(source.currentIndex())
     else:widget.setValue(source.value())
    elif isinstance(widget,QCheckBox):widget.setChecked(bool(self.project.get(key,False)))
    else:widget.setValue(float(self.project.get(key,5 if key=='silence_progress_threshold' else 2000)))
   if self.formatting_preview is not None:
    sung,unsung=self.lyric_colors()[1],self.lyric_colors()[0]
    self.formatting_preview.setText('<span style="font-size:25px;color:'+unsung+'">When the stars begin to shine</span><br><span style="font-size:25px;color:'+sung+'">I will be waiting here for you</span><br><span style="font-size:12px;color:#b7c3df">Colors preview • Rendered fade timings are used in MP4 exports</span>')
  finally:self._formatting_update=False
 def build_visualizer(self):
  root=panel();outer=QVBoxLayout(root);outer.setContentsMargins(18,16,18,16);outer.setSpacing(10)
  top=QHBoxLayout();heading=QLabel('DeRo Cinematic Visualizer');heading.setStyleSheet('font-size:22px;font-weight:800');top.addWidget(heading,1)
  top.addWidget(btn('Save Visualizer settings',self.persist_visualizer_settings))
  top.addWidget(btn('Preview 8 seconds',lambda:self.start_visualizer_export(preview=True)))
  top.addWidget(btn('Export final MP4',self.start_visualizer_export,True));outer.addLayout(top)
  hint=QLabel('Original Visualizer v0.1.45 renderer • Native Sync controls • One-pass MP4 export • 1080p / 60 FPS default')
  hint.setObjectName('muted');hint.setWordWrap(True);outer.addWidget(hint)
  grid=QGridLayout();grid.setSpacing(12);outer.addLayout(grid,1)
  left_scroll=QScrollArea();left_scroll.setWidgetResizable(True);left_scroll.setFrameShape(QFrame.NoFrame)
  left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  grid.addWidget(left_scroll,0,0)
  left=panel();form=QVBoxLayout(left);form.setSpacing(8);left_scroll.setWidget(left)
  right_scroll=QScrollArea();right_scroll.setWidgetResizable(True);right_scroll.setFrameShape(QFrame.NoFrame)
  right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  grid.addWidget(right_scroll,0,1)
  right=panel();preview=QVBoxLayout(right);right_scroll.setWidget(right)
  grid.setColumnStretch(0,2);grid.setColumnStretch(1,5)
  form.addWidget(QLabel('BACKGROUND'))
  bg=QHBoxLayout();self.viz_background=QLineEdit();self.viz_background.setPlaceholderText('Optional image background');bg.addWidget(self.viz_background,1);bg.addWidget(btn('Browse',self.pick_visualizer_background));bg.addWidget(btn('Use Background Studio',self.use_background_studio));form.addLayout(bg)
  self.viz_reactive=QCheckBox('Bass-reactive particles');self.viz_reactive.setChecked(True);form.addWidget(self.viz_reactive)
  self.viz_use_stems=QCheckBox('Use separated stems when available (100% instrumental / 20% vocals)');self.viz_use_stems.setChecked(True);form.addWidget(self.viz_use_stems)
  self.viz_enabled=QCheckBox('Enable audio-reactive spectrum');self.viz_enabled.setChecked(True);form.addWidget(self.viz_enabled)
  self.viz_particles=QCheckBox('Enable original floating particles');self.viz_particles.setChecked(True);form.addWidget(self.viz_particles)
  form.addWidget(QLabel('OUTPUT'))
  self.viz_resolution=SafeValueCombo();self.viz_resolution.addItems(['1920 x 1080','1280 x 720']);form.addWidget(self.viz_resolution)
  self.viz_fps=SafeValueCombo();self.viz_fps.addItems(['60','30']);self.viz_fps.setCurrentText('60');form.addWidget(self.viz_fps)
  form.addWidget(QLabel('SPECTRUM'))
  self.viz_bars=SafeValueSpin();self.viz_bars.setRange(16,2048);self.viz_bars.setDecimals(0);self.viz_bars.setValue(384);form.addWidget(QLabel('Frequency bands'));form.addWidget(self.viz_bars)
  self.viz_spectrum_style=SafeValueCombo();self.viz_spectrum_style.addItems(['Classic bars','Gradient bars','Glow bars','Reflected bars','Filled spectrum']);form.addWidget(self.viz_spectrum_style)
  self.viz_spectrum_mapping=SafeValueCombo();self.viz_spectrum_mapping.addItems(['Stepped','Balanced','Smooth']);form.addWidget(QLabel('Spectrum mapping'));form.addWidget(self.viz_spectrum_mapping)
  self.viz_spectrum_color=QLineEdit('#f0f6ff');form.addWidget(QLabel('Spectrum color'));form.addWidget(self.viz_spectrum_color)
  self.viz_color_end=QLineEdit('#35a5ff');form.addWidget(QLabel('Spectrum gradient end color'));form.addWidget(self.viz_color_end)
  form.addWidget(QLabel('PARTICLES'))
  self.viz_dust=SafeValueSpin();self.viz_dust.setRange(0,800);self.viz_dust.setDecimals(0);self.viz_dust.setValue(130);form.addWidget(QLabel('Particle quantity'));form.addWidget(self.viz_dust)
  self.viz_particle_speed=SafeValueSpin();self.viz_particle_speed.setRange(.1,30);self.viz_particle_speed.setValue(20);form.addWidget(QLabel('Particle speed'));form.addWidget(self.viz_particle_speed)
  self.viz_particle_direction=SafeValueCombo();self.viz_particle_direction.addItems(['Out','Left','Right','Up','Down']);form.addWidget(QLabel('Particle direction'));form.addWidget(self.viz_particle_direction)
  self.viz_particle_color=QLineEdit('#ebeef7');form.addWidget(QLabel('Particle color'));form.addWidget(self.viz_particle_color)
  form.addStretch(1)
  preview.addWidget(QLabel('VISUALIZER PREVIEW / EXPORT STATUS'))
  self.viz_preview_label=AspectPreviewLabel('Original DeRo Visualizer renderer\n\n384 spectrum bands • 130 particles\n\nYour saved settings are applied to the final render.')
  self.viz_preview_label.setAlignment(Qt.AlignCenter);self.viz_preview_label.setMinimumSize(440,320)
  self.viz_preview_label.setStyleSheet('QLabel{background:#081329;color:#b9d4ff;border:1px solid #36547e;border-radius:12px;font-size:17px}')
  preview.addWidget(self.viz_preview_label,1)
  self.viz_exact_still_button=QPushButton('Render exact song frame (static)')
  self.viz_exact_still_button.clicked.connect(self.render_exact_visualizer_still)
  preview.addWidget(self.viz_exact_still_button)
  self.viz_diagnostics_label=QLabel('Export diagnostics will be saved beside the MP4.');self.viz_diagnostics_label.setObjectName('muted');preview.addWidget(self.viz_diagnostics_label)
  self.pages.addWidget(root)
  self._viz_static_timer=QTimer(self)
  self._viz_static_timer.setSingleShot(True)
  self._viz_static_timer.setInterval(450)
  self._viz_static_timer.timeout.connect(self._render_static_visualizer_preview)
  for control in (self.viz_enabled,self.viz_particles,self.viz_reactive):
   control.toggled.connect(self._schedule_static_visualizer_preview)
  for control in (self.viz_bars,self.viz_dust,self.viz_particle_speed):
   control.valueChanged.connect(self._schedule_static_visualizer_preview)
  for control in (self.viz_spectrum_style,self.viz_spectrum_mapping,self.viz_particle_direction):
   control.currentTextChanged.connect(self._schedule_static_visualizer_preview)
  for control in (self.viz_spectrum_color,self.viz_color_end,self.viz_particle_color):
   control.textChanged.connect(self._schedule_static_visualizer_preview)
  self.viz_background.textChanged.connect(self.refresh_visualizer_background_preview)
  self._restore_visualizer_settings()
  self.refresh_visualizer_background_preview()
 def _visualizer_settings_dict(self):
  resolution=tuple(map(int,self.viz_resolution.currentText().replace(' ','').split('x')))
  return {'resolution':resolution,'fps':int(self.viz_fps.currentText()),
   'visualizer_enabled':self.viz_enabled.isChecked(),'particles_enabled':self.viz_particles.isChecked(),
   'bars':int(self.viz_bars.value()),'spectrum_style':self.viz_spectrum_style.currentText(),
   'spectrum_mapping':self.viz_spectrum_mapping.currentText(),'spectrum_color':self.viz_spectrum_color.text().strip(),
   'spectrum_color_end':self.viz_color_end.text().strip(),'dust_count':int(self.viz_dust.value()),
   'particle_speed':float(self.viz_particle_speed.value()),'particle_direction':self.viz_particle_direction.currentText(),
   'particle_color':self.viz_particle_color.text().strip(),'background':self.viz_background.text().strip(),
   'particle_reactive':self.viz_reactive.isChecked(),'particle_continuous':True,'particle_reactivity':'Bass',
   'spectrum_mirrored':True,'spectrum_density':1.0,'spectrum_fill':.58,'spectrum_gain':1.5,
   'frequency_min':50.0,'frequency_max':10584.0,'frequency_scale':'Linear','spectrum_width':.8,
   'spectrum_x':.5,'spectrum_y':.9,'spectrum_height':.198,'reactive_fraction':.24,
   'sensitivity':3.0,'export_encoder':'Auto (GPU if available)'}
 def persist_visualizer_settings(self):
  self.project['visualizer_settings']=self._visualizer_settings_dict()
  self.project['visualizer_use_stems']=self.viz_use_stems.isChecked()
  self.project['visualizer_lyric_style']={'lyric_display_mode':'classic_flow','lyric_font_family':'Arial',
   'lyric_font_size':72,'lyric_font_bold':True,'lyric_unsung_color':'#EAF3FF','lyric_sung_color':'#31B9FF'}
  self.project['visualizer_lyric_style_saved']=True
  self.viz_diagnostics_label.setText('Visualizer settings saved in this Sync project.')
 def _restore_visualizer_settings(self):
  d=self.project.get('visualizer_settings',{})
  self.viz_enabled.setChecked(bool(d.get('visualizer_enabled',True)));self.viz_particles.setChecked(bool(d.get('particles_enabled',True)))
  self.viz_resolution.setCurrentText('1920 x 1080' if tuple(d.get('resolution',(1920,1080)))==(1920,1080) else '1280 x 720')
  self.viz_fps.setCurrentText(str(d.get('fps',60)));self.viz_bars.setValue(float(d.get('bars',384)))
  self.viz_spectrum_style.setCurrentText(str(d.get('spectrum_style','Classic bars')));self.viz_spectrum_mapping.setCurrentText(str(d.get('spectrum_mapping','Stepped')))
  self.viz_spectrum_color.setText(str(d.get('spectrum_color','#f0f6ff')));self.viz_color_end.setText(str(d.get('spectrum_color_end','#35a5ff')))
  self.viz_dust.setValue(float(d.get('dust_count',130)));self.viz_particle_speed.setValue(float(d.get('particle_speed',20)))
  self.viz_particle_direction.setCurrentText(str(d.get('particle_direction','Out')));self.viz_particle_color.setText(str(d.get('particle_color','#ebeef7')))
  self.viz_background.setText(str(d.get('background','')));self.viz_reactive.setChecked(bool(d.get('particle_reactive',True)))
  self.viz_use_stems.setChecked(bool(self.project.get('visualizer_use_stems',True)))
 def _visualizer_sample_lyrics(self):
  # Actual pasted lyrics, not a generic placeholder. Read-only preview only.
  try:
   raw=self.lyrics.toPlainText()
  except (AttributeError,RuntimeError):
   raw=str(self.project.get('authoritative_lyrics',''))
  lines=[line.strip() for line in raw.splitlines() if line.strip()]
  if not lines:
   for event in self.project.get('events',[]):
    if isinstance(event,(list,tuple)) and len(event)>2 and str(event[2]).strip():
     lines.append(str(event[2]).strip())
    if len(lines)==2:break
  return lines[:2] if lines else ['Your karaoke lyrics','will appear here']
 def _schedule_static_visualizer_preview(self,*ignored):
  if hasattr(self,'_viz_static_timer'):
   self._viz_static_timer.start()
 def _render_static_visualizer_preview(self):
  # Never substitute synthetic spectrum/particles for the user's actual renderer.
  # Exact stills are generated on demand using real audio and libass.
  pass
 def refresh_visualizer_background_preview(self,*ignored):
  # Preserve the last verified still until the user requests another.
  if hasattr(self,'viz_preview_label'):
   self.viz_preview_label.setSampleLyrics(self._visualizer_sample_lyrics())
   path=self.viz_background.text().strip()
   self.viz_preview_label.setPreviewImage(QPixmap(path) if path and Path(path).is_file() else QPixmap())
   self.viz_diagnostics_label.setText('Background changed. Click Render exact song frame to refresh the original visualizer.')
 def render_exact_visualizer_still(self):
  if getattr(self,'_exact_still_worker',None) is not None and self._exact_still_worker.isRunning():
   return
  self.sync_fields()
  original=self.audio.text().strip()
  if not original or not Path(original).is_file():
   QMessageBox.warning(self,'Song missing','Load the song audio first.');return
  ffmpeg=find_ffmpeg()
  if not ffmpeg:
   QMessageBox.warning(self,'FFmpeg missing','FFmpeg is required for the exact lyric overlay.');return
  self.persist_visualizer_settings()
  project=copy.deepcopy(self.project)
  if not project.get('events') or not project.get('word_timings'):
   QMessageBox.warning(self,'Lyrics timing missing','Complete Word Sync to preview the actual timed lyrics.');return
  # First section with lyrics, preferably near 30 seconds.
  starts=[float(e[0]) for e in project.get('events',[]) if isinstance(e,(list,tuple)) and len(e)>0]
  seconds=min(starts,key=lambda x:abs(x-30.0))+0.25 if starts else 30.0
  self.viz_exact_still_button.setEnabled(False)
  self.viz_diagnostics_label.setText('Rendering exact still from real song audio and original Visualizer…')
  worker=ExactVisualizerStillWorker(project,self._visualizer_settings_dict(),original,ffmpeg,seconds)
  self._exact_still_worker=worker
  worker.ready.connect(self._exact_visualizer_still_ready)
  worker.finished.connect(lambda: self.viz_exact_still_button.setEnabled(True))
  worker.start()
 def _exact_visualizer_still_ready(self,frame,error):
  if error:
   self.viz_diagnostics_label.setText('Exact still unavailable: '+error[:260])
   return
  from PIL.ImageQt import ImageQt
  self.viz_preview_label.setSampleLyrics([])
  self.viz_preview_label.setPreviewImage(QPixmap.fromImage(ImageQt(frame)))
  self.viz_diagnostics_label.setText('Exact still: real audio, original renderer and export lyric overlay. Preview only.')

 def background_picker_folder(self,current_path=''):
  folder=str(self.app_settings.value('last_background_folder','') or '')
  if folder and Path(folder).is_dir():return folder
  if current_path and Path(current_path).expanduser().parent.is_dir():
   return str(Path(current_path).expanduser().parent)
  return str(Path.home())
 def remember_background_folder(self,path):
  if path and Path(path).parent.is_dir():
   self.app_settings.setValue('last_background_folder',str(Path(path).parent))
 def pick_visualizer_background(self):
  path,_=QFileDialog.getOpenFileName(self,'Select Visualizer background',self.background_picker_folder(self.viz_background.text().strip()),'Images (*.png *.jpg *.jpeg *.bmp *.webp);;All files (*)')
  if path:
   self.remember_background_folder(path)
   self.viz_background.setText(path);self.persist_visualizer_settings()
 def use_background_studio(self):
  # Explicit opt-in: never overwrite a project's chosen background automatically.
  import json
  manifest=Path.home()/'Documents'/'DeRo Background Studio'/'sync_handoff.json'
  try:
   data=json.loads(manifest.read_text(encoding='utf-8'))
   if not isinstance(data,dict) or type(data.get('schema')) is not int or data['schema'] != 1:
    raise ValueError('Unsupported Background Studio handoff schema. Expected version 1. Please update both apps and send the background again.')
   if not isinstance(data.get('png_path'),str) or not data['png_path'].strip():
    raise ValueError('Background Studio handoff has no valid png_path.')
   path=Path(data['png_path']).expanduser().resolve()
   if not path.is_file() or path.suffix.lower()!='.png':raise ValueError('The exported PNG is missing.')
   from PIL import Image
   with Image.open(path) as im:im.verify()
  except (OSError,ValueError,KeyError,TypeError) as exc:
   QMessageBox.warning(self,'Background Studio image unavailable',f'Use Send to DeRo Sync in Background Studio first.\n\n{exc}')
   return
  self.viz_background.setText(str(path))
  self.persist_visualizer_settings()

 def start_visualizer_export(self,preview=False,batch_output=None,batch_test_range=None):
  self.sync_fields()
  if not self.project.get('events') or not self.project.get('word_timings'):
   QMessageBox.warning(self,'Word timings required','Create lyric lines and word timings in Sync before exporting with Visualizer.');return
  original=self.audio.text().strip()
  if not original or not Path(original).is_file():QMessageBox.warning(self,'Song missing','Select a valid song on the Song page first.');return
  ffmpeg=find_ffmpeg()
  if not ffmpeg:QMessageBox.warning(self,'FFmpeg missing','Install FFmpeg or make it available on PATH.');return
  self.persist_visualizer_settings();settings=self._visualizer_settings_dict();project=copy.deepcopy(self.project)
  # Use the same selected export range as the Export tab. A preview is at most eight seconds.
  range_start=(float(batch_test_range[0]) if batch_test_range is not None else 0.0 if batch_output is not None else float(self.export_range.start))
  range_end=(float(batch_test_range[1]) if batch_test_range is not None else None if batch_output is not None else float(self.export_range.end))
  if range_end is not None and range_end <= range_start:
   QMessageBox.warning(self,'Invalid export selection','Set a valid start and end in the Export tab before exporting.');return
  clip_start=range_start
  clip_end=(range_start+8.0 if range_end is None else min(range_end,range_start+8.0)) if preview else range_end

  if batch_output is not None:
   output=Path(batch_output)
   if output.parent.is_dir():self.app_settings.setValue('last_video_export_folder',str(output.parent))
   if output.exists():
    self._batch_failed('Refusing to overwrite existing MP4: '+str(output));return
  elif preview:output=Path(tempfile.gettempdir())/'dero_sync_visualizer_preview.mp4'
  else:
   name=safe_song_filename(self.artist.text(),self.song.text() or Path(original).stem,'Karaoke')
   chosen,_=QFileDialog.getSaveFileName(self,'Export DeRo Visualizer MP4',str(Path.home()/(name+'.mp4')),'MP4 video (*.mp4)')
   if not chosen:return
   self.app_settings.setValue('last_video_export_folder',str(Path(chosen).expanduser().parent))
   output=Path(chosen)
   if output.exists() and QMessageBox.question(self,'Overwrite video?',str(output),QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
  diag=output.with_name(output.stem+' Diagnostics.json')
  inst=self.instrumental.text().strip();voc=self.vocals.text().strip()
  use_stems=self.viz_use_stems.isChecked() and bool(inst and Path(inst).is_file())
  if batch_output is not None and (not use_stems or not voc or not Path(voc).is_file() or Path(inst).parent.resolve()!=Path(voc).parent.resolve()):
   self._batch_failed('Batch requires valid paired instrumental and vocal stems; export cancelled.');return
  if use_stems:
   if not voc or not Path(voc).is_file():
    QMessageBox.warning(self,'Vocal stem unavailable','Both instrumental and vocal stems are required for the 100% / 20% stem mix. This export will use the original song instead.')
    use_stems=False
   elif Path(inst).parent.resolve()!=Path(voc).parent.resolve():
    QMessageBox.warning(self,'Stem folder mismatch','The instrumental and vocal stems are not in the same folder. Export cancelled to prevent mixing unrelated stems.')
    return
  control=None
  from visualizer_sync_bridge import run_sync_export
  from visualizer_engine.export_control import ExportControl
  control=ExportControl();self._visualizer_control=control
  export_audit=(self._batch_audit if batch_output is not None else ExportAudit(output.parent,'single'))
  export_audit.record('export_started',output=str(output),preview=bool(preview),batch=bool(batch_output),source=original,settings={'fps':settings.get('fps') if isinstance(settings,dict) else None}) if batch_output is None else None
  self._export_audit_current=export_audit
  progress_state={'last':0.0}
  def job(emit):
   def progress(done,total):
    emit(f'Visualizer rendering: {done:,}/{total:,} frames ({done/total*100:.1f}%)')
    now=time.monotonic()
    if now-progress_state['last']>=30 or done>=total:
     progress_state['last']=now
     export_audit.record('render_progress',output=str(output),frames=int(done),total_frames=int(total))
   path,report=run_sync_export(project,settings,original,inst,voc,use_stems,
      float(self.instrumental_volume.value()),float(self.vocal_volume.value()),str(output),ffmpeg,
      progress=progress,control=control,diagnostics_path=str(diag),
      start_seconds=clip_start,end_seconds=clip_end)
   return path
  def done(path):
   self.last_export=path;self.activity_title.setText('COMPLETE — DeRo Visualizer MP4 exported')
   if batch_output is None:export_audit.record('export_finished',output=str(path),audit=verify_mp4(path,ffmpeg))
   try:report=json.loads(diag.read_text(encoding='utf-8'))
   except Exception:report={}
   self.activity_detail.setText(f'{path} • {report.get("effective_export_fps",0):.2f} effective FPS • {report.get("total_seconds",0):.1f}s')
   self.viz_diagnostics_label.setText(f'Completed. Diagnostics: {diag}')
   self._visualizer_control=None
   if batch_output is None and not preview:self.celebrate_success('export',str(path))
   if batch_output is None and (preview or self.auto_open_export.isChecked()):QTimer.singleShot(9500 if not preview else 0,lambda p=str(path):QDesktopServices.openUrl(QUrl.fromLocalFile(p)))
  self.begin_job('Visualizer export',job,done,final_export=not preview)
 def _batch_audio_duration(self,path):
  """Determine audio duration using available local tools, without requiring ffprobe."""
  path=Path(path)
  if not path.is_file():raise RuntimeError(f'Audio file not found: {path}')
  # Mutagen reads container metadata without invoking any external executable.
  try:
   from mutagen import File as MutagenFile
   audio=MutagenFile(str(path))
   length=float(audio.info.length) if audio and audio.info else 0
   if math.isfinite(length) and length>1:return length
  except Exception:
   logging.debug('Audio duration detection via Mutagen failed for %s', path, exc_info=True)
  # SoundFile handles WAV/FLAC and other libsndfile-supported formats.
  try:
   import soundfile as sf
   info=sf.info(str(path))
   length=float(info.frames)/float(info.samplerate)
   if math.isfinite(length) and length>1:return length
  except Exception:
   logging.debug('Audio duration detection via SoundFile failed for %s', path, exc_info=True)
  probe=shutil.which('ffprobe')
  ffmpeg=find_ffmpeg()
  if not probe and ffmpeg:
   candidate=Path(ffmpeg).with_name('ffprobe.exe' if sys.platform=='win32' else 'ffprobe')
   if candidate.is_file():probe=str(candidate)
  if probe:
   try:
    result=subprocess.run([probe,'-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)],capture_output=True,text=True,timeout=30,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if result.returncode==0:
     length=float(result.stdout.strip())
     if math.isfinite(length) and length>1:return length
   except Exception:
    logging.debug('Audio duration detection via ffprobe failed for %s', path, exc_info=True)
  # The bundled imageio-ffmpeg binary can report media duration through -i.
  if ffmpeg:
   try:
    result=subprocess.run([ffmpeg,'-hide_banner','-i',str(path)],capture_output=True,text=True,timeout=30,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    match=re.search(r'Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)',result.stderr)
    if match:
     hours,minutes,seconds=match.groups()
     length=int(hours)*3600+int(minutes)*60+float(seconds)
     if math.isfinite(length) and length>1:return length
   except Exception:
    logging.debug('Audio duration detection via FFmpeg failed for %s', path, exc_info=True)
  logging.warning('All audio duration detection methods failed for %s', path)
  raise RuntimeError('Cannot determine audio duration with Mutagen, SoundFile, ffprobe, or FFmpeg. Check that the source audio file is valid.')

 def open_batch_test_settings(self):
  """Non-destructive, selected-song-only test range; playback uses a dedicated player."""
  ws=self.batch_page
  if not (0<=ws.selected<len(ws.songs)):
   QMessageBox.information(self,'Test Section','Select a song in Batch Setup or Lyrics first.');return
  song=ws.songs[ws.selected];source=Path(song['path'])
  if not source.is_file():QMessageBox.warning(self,'Test Section','Audio file is missing: '+str(source));return
  try:duration=self._batch_audio_duration(source)
  except Exception as exc:QMessageBox.warning(self,'Test Section',str(exc));return
  d=QDialog(self);d.setWindowTitle('Test Section Settings — '+ws.song_name(song));d.resize(660,330)
  lay=QVBoxLayout(d);lay.addWidget(QLabel('Choose a short section for this song. Original audio, lyrics and full-song timings remain unchanged.'))
  bar=ExportRangeBar();bar.set_duration(duration)
  prior=song.get('batch_test_range')
  if isinstance(prior,(list,tuple)) and len(prior)==2:bar.set_range(*prior)
  else:bar.set_range(0,min(duration,30.))
  lay.addWidget(bar)
  info=QLabel();lay.addWidget(info)
  spins=QHBoxLayout();start=QDoubleSpinBox();end=QDoubleSpinBox()
  for spin in (start,end):spin.setRange(0,duration);spin.setDecimals(3);spin.setSuffix(' s');spin.setSingleStep(1.)
  spins.addWidget(QLabel('Start'));spins.addWidget(start);spins.addWidget(QLabel('End'));spins.addWidget(end);lay.addLayout(spins)
  updating=[False]
  def sync(a,b):
   if updating[0]:return
   updating[0]=True;start.setValue(a);end.setValue(b);info.setText(f'Start {a:.3f}s  •  End {b:.3f}s  •  Length {b-a:.3f}s');updating[0]=False
  def spin_changed(_):
   if not updating[0]:bar.set_range(start.value(),end.value())
  bar.changed.connect(sync);start.valueChanged.connect(spin_changed);end.valueChanged.connect(spin_changed);sync(bar.start,bar.end)
  transport=QMediaPlayer(d);audio_output=QAudioOutput(d);transport.setAudioOutput(audio_output);transport.setSource(QUrl.fromLocalFile(str(source)))
  looping=[False]
  def check_end(ms):
   if ms>=int(bar.end*1000):
    if looping[0]:transport.setPosition(int(bar.start*1000));transport.play()
    else:transport.pause()
  transport.positionChanged.connect(check_end)
  buttons=QHBoxLayout()
  def add(text,fn):
   b=QPushButton(text);b.clicked.connect(fn);buttons.addWidget(b);return b
  add('Full Song',lambda:bar.set_range(0,duration))
  add('Start at Playhead',lambda:bar.set_range(transport.position()/1000,bar.end))
  add('End at Playhead',lambda:bar.set_range(bar.start,transport.position()/1000))
  lay.addLayout(buttons);buttons=QHBoxLayout()
  def play_selection():transport.setPosition(int(bar.start*1000));transport.play()
  add('Play Selection',play_selection);add('Pause',transport.pause)
  loop=add('Loop Selection: OFF',lambda:None)
  def toggle_loop():looping[0]=not looping[0];loop.setText('Loop Selection: ON' if looping[0] else 'Loop Selection: OFF')
  loop.clicked.disconnect();loop.clicked.connect(toggle_loop)
  add('Play from Start',lambda:(transport.setPosition(0),transport.play()))
  lay.addLayout(buttons)
  actions=QHBoxLayout();actions.addStretch(1)
  cancel=QPushButton('Cancel');cancel.clicked.connect(d.reject);actions.addWidget(cancel)
  save=QPushButton('Save Test Section');save.setObjectName('batchStartButton');save.clicked.connect(d.accept);actions.addWidget(save);lay.addLayout(actions)
  accepted=d.exec()==QDialog.Accepted
  transport.stop()
  if accepted:
   song['batch_test_range']=[round(bar.start,3),round(bar.end,3)];ws.save();ws.process_log.appendPlainText(f'Test section saved for {ws.song_name(song)}: {bar.start:.3f}s–{bar.end:.3f}s')

 def _batch_cache_identity(self, song, source, stems):
  from alignment_cache import make_identity
  return make_identity(source, song['lyrics'], stems, str(self.demucs_model.currentData() or 'htdemucs_ft'), 'small', self.song_language.currentData() or 'auto')

 def _batch_restore_cached_alignment(self, song, source, stems):
  from alignment_cache import load_cached_alignment
  if not getattr(self,'_batch_section_mode',False):return False
  identity=self._batch_cache_identity(song,source,stems)
  result=load_cached_alignment(Path(self.batch_page.output_path.text()),identity)
  if result is None:return False
  self.project.update(result)
  self.alignment_diagnostics=result.get('alignment_diagnostics',{})
  self.refresh()
  self.batch_page.process_log.appendPlainText('  Reusing verified saved full-song alignment; skipping WhisperX (timings unchanged)')
  self._batch_audit.record('alignment_cache_hit',song=self._batch_index+1,cache_key=identity['key'])
  return True

 def _batch_save_cached_alignment(self, song):
  from alignment_cache import save_cached_alignment
  source=Path(song['path']);model=str(self.demucs_model.currentData() or 'htdemucs_ft')
  stems=source.parent/'Karaoke Maker Stems'/model/source.stem
  identity=self._batch_cache_identity(song,source,stems)
  path=save_cached_alignment(Path(self.batch_page.output_path.text()),identity,self.project,self.alignment_diagnostics)
  self.batch_page.process_log.appendPlainText('  Saved full-song alignment cache: '+path.name)
  self._batch_audit.record('alignment_cache_saved',song=self._batch_index+1,cache_key=identity['key'])

 def start_batch_section_test(self):
  ws=self.batch_page
  if self._batch_running:return
  if not (0<=ws.selected<len(ws.songs)):
   QMessageBox.warning(self,'Section test','Select the test song in Batch Setup or Lyrics first.');return
  song=ws.songs[ws.selected];rng=song.get('batch_test_range')
  if not isinstance(rng,(list,tuple)) or len(rng)!=2 or float(rng[1])-float(rng[0])<.1:
   QMessageBox.information(self,'Section test','Open Test Section Settings and save a valid range first.');return
  if QMessageBox.question(self,'Process test section',f"Process ONLY {ws.song_name(song)} from {float(rng[0]):.3f}s to {float(rng[1]):.3f}s?\nCached full-song alignment will be reused when available; otherwise align once, then render the short MP4.",QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)!=QMessageBox.Yes:return
  self._batch_test_indices=[ws.selected];self._batch_section_mode=True
  self.start_batch_processing()

 def start_batch_processing(self):
  if self._batch_running:return
  if self.job is not None and self.job.isRunning():
   QMessageBox.warning(self,'Batch','Wait for the current task to finish.');return
  ws=self.batch_page
  if not ws.songs or not ws.output_path.text().strip() or not Path(ws.output_path.text()).is_dir():
   QMessageBox.warning(self,'Batch setup','Add songs and select an existing output folder.');return
  if not ws.images:
   QMessageBox.warning(self,'Batch setup','Select an approved folder containing background images.');return
  if any(not str(song.get('lyrics','')).strip() for song in ws.songs):
   QMessageBox.warning(self,'Batch lyrics','Paste lyrics for every queued song first.');return
  try:
   import demucs.separate,whisperx
   if not find_ffmpeg():raise RuntimeError('FFmpeg is unavailable')
  except Exception as exc:
   QMessageBox.warning(self,'Batch dependencies','Demucs, WhisperX and FFmpeg must be available: '+str(exc));return
  if self.project.get('audio') and self.saved_signature!=json.dumps(self.project,sort_keys=True,ensure_ascii=False,default=str):
   QMessageBox.warning(self,'Unsaved project','Save your current single-song project before starting Batch. It will be replaced in the active workspace.');return
  if not getattr(self,'_batch_section_mode',False):self._batch_test_indices=list(range(len(ws.songs)))
  self._clear_export_congratulations()
  self._batch_running=True;self._batch_index=-1;ws.start_batch_button.setEnabled(False);ws.section_process_button.setEnabled(False);ws.section_settings_button.setEnabled(False)
  self._batch_audit=ExportAudit(Path(ws.output_path.text()),'batch')
  self._batch_audit.record('batch_started',song_count=len(self._batch_test_indices),app_version=APP_BUILD,section_test=bool(getattr(self,'_batch_section_mode',False)))
  ws.process_log.appendPlainText('Starting sequential batch. Original audio and existing outputs will not be overwritten.')
  QTimer.singleShot(0,self._batch_next_song)

 def _batch_next_song(self):
  if not self._batch_running:return
  ws=self.batch_page;self._batch_index+=1
  if self._batch_index>=len(self._batch_test_indices):
   self._batch_running=False;ws.start_batch_button.setEnabled(True);ws.section_process_button.setEnabled(True);ws.section_settings_button.setEnabled(True)
   ws.refresh(keep_selection=True)
   exported=sum(ws.songs[i].get('batch_status')=='completed' for i in self._batch_test_indices)
   failed=sum(ws.songs[i].get('batch_status')=='failed' for i in self._batch_test_indices)
   ws.process_log.appendPlainText(f'Batch finished: {exported} exported, {failed} failed. Review any sync warnings.')
   self._batch_audit.record('batch_finished',exported=exported,failed=failed,review=sum(bool(ws.songs[i].get('batch_sync_review_required')) for i in self._batch_test_indices))
   if exported and not failed and not getattr(self,'_batch_section_mode',False):
    self.celebrate_success('batch',f'{exported} songs exported successfully. Review flagged lyric timings if needed.')
   if ws.open_folder.isChecked():QTimer.singleShot(9500,lambda folder=ws.output_path.text():QDesktopServices.openUrl(QUrl.fromLocalFile(folder)))
   self._batch_section_mode=False
   return
  self._batch_song_index=self._batch_test_indices[self._batch_index]
  song=ws.songs[self._batch_song_index]
  try:
   source=Path(song['path'])
   if not source.is_file():raise RuntimeError('Audio file missing')
   self._batch_duration=self._batch_audio_duration(source)
   background=ws.background_for_song(self._batch_song_index)
   if not background:raise RuntimeError('No approved background image')
   if self.reset_for_new_song() is False:raise RuntimeError('Cannot reset project')
   self.song.setText(str(song.get('title') or source.stem));self.artist.setText(str(song.get('artist') or ''))
   self.audio.setText(str(source));self.lyrics.setPlainText(song['lyrics'])
   self.viz_background.setText(background);self.viz_enabled.setChecked(ws.visualizer.isChecked());self.viz_particles.setChecked(ws.particles.isChecked());self.viz_use_stems.setChecked(True)
   self.viz_resolution.setCurrentText('1920 x 1080');self.viz_fps.setCurrentText('60')
   self.instrumental_volume.setValue(100);self.vocal_volume.setValue(20)
   self.sync_fields();self.project['authoritative_lyrics']=song['lyrics'];self.project['batch_background']=background
   base=safe_song_filename(self.artist.text(),self.song.text() or source.stem,'Karaoke')
   folder=Path(ws.output_path.text());candidate=folder/(base+'.mp4');n=2
   while candidate.exists() or candidate.with_suffix('.karaoke.json').exists():
    candidate=folder/(f'{base} ({n}).mp4');n+=1
   if getattr(self,'_batch_section_mode',False):
    a,b=map(float,song['batch_test_range'])
    testbase=f'{base} TEST {a:.3f}-{b:.3f}s'
    candidate=folder/(testbase+'.mp4');n=2
    while candidate.exists() or candidate.with_suffix('.karaoke.json').exists():
     candidate=folder/(f'{testbase} ({n}).mp4');n+=1
   self._batch_output=candidate
   song['batch_status']='separating';song['batch_error']='';ws.save();ws.process_log.appendPlainText(f'{self._batch_index+1}/{len(self._batch_test_indices)}: {base} — separating')
   self._batch_audit.record('song_started',song=base,index=self._batch_index+1,source=str(source),output=str(candidate))
   self._batch_stage='Vocal separation'
   model=str(self.demucs_model.currentData() or 'htdemucs_ft')
   stems=source.parent/'Karaoke Maker Stems'/model/source.stem
   inst=stems/'no_vocals.wav';voc=stems/'vocals.wav'
   if inst.exists() or voc.exists():
    if not (inst.is_file() and voc.is_file() and inst.stat().st_size>44 and voc.stat().st_size>44):
     raise RuntimeError('Existing stem files are incomplete; refusing to overwrite: '+str(stems))
    self.instrumental.setText(str(inst));self.vocals.setText(str(voc));self.sync_fields()
    ws.process_log.appendPlainText('  Reusing existing paired stems (no overwrite)')
    QTimer.singleShot(0,lambda:self._batch_completed_stage('Vocal separation'))
   else:self.start_separation()
  except Exception as exc:self._batch_failed(str(exc))

 def _batch_completed_stage(self,stage):
  if not self._batch_running or stage!=self._batch_stage:return
  ws=self.batch_page;song=ws.songs[self._batch_song_index]
  try:
   if stage=='Vocal separation':
    self._batch_stage='WhisperX alignment';song['batch_status']='aligning';ws.save()
    self._batch_audit.record('stage_started',song=self._batch_index+1,stage='alignment')
    ws.process_log.appendPlainText('  Stems ready; preparing pasted lyric alignment')
    source=Path(song['path']);model=str(self.demucs_model.currentData() or 'htdemucs_ft')
    stems=source.parent/'Karaoke Maker Stems'/model/source.stem
    if self._batch_restore_cached_alignment(song,source,stems):
     QTimer.singleShot(0,lambda:self._batch_completed_stage('WhisperX alignment'))
    else:
     ws.process_log.appendPlainText('  No matching cache; running full-song WhisperX alignment')
     self.start_alignment(batch_mode=True)
   elif stage=='WhisperX alignment':
    # Automatic export may use WhisperX's partial/estimated timestamps, but must
    # never misrepresent those timings as verified. Reject missing/failed timings.
    statuses=self.project.get('alignment_status',{})
    if not statuses or not self.project.get('events') or not self.project.get('word_timings'):
     raise RuntimeError('No usable synchronization results; export cancelled')
    counts={key:sum(v==key for v in statuses.values()) for key in ('aligned','partial','estimated','failed')}
    # v0.2.1.36: report-only diagnostics; never change export or timing decisions.
    try:
     report_path=Path(ws.output_path.text())/(self._batch_output.stem+'_alignment_report.json')
     report=save_alignment_report(self.project,report_path)
     ws.process_log.appendPlainText(
      f"  Alignment report: {report_path.name} — "
      f"{report['finding_counts']['critical']} critical, "
      f"{report['finding_counts']['warning']} warnings (diagnostic only)")
    except Exception as diagnostic_error:
     ws.process_log.appendPlainText(f'  Alignment report unavailable: {diagnostic_error}')
    if counts['failed'] or any(v not in ('aligned','partial','estimated') for v in statuses.values()):
     raise RuntimeError('Synchronization has failed or unsupported lines; export cancelled')
    if getattr(self,'_batch_section_mode',False):
     try:self._batch_save_cached_alignment(song)
     except Exception as cache_error:ws.process_log.appendPlainText('  Alignment cache unavailable: '+str(cache_error))
    needs_review=bool(counts['partial'] or counts['estimated'])
    self._batch_audit.record('alignment_completed',song=self._batch_index+1,counts=counts,needs_review=needs_review)
    song['batch_sync_review_required']=needs_review
    song['batch_alignment_counts']=counts
    self.project['batch_sync_review_required']=needs_review
    self.project['batch_alignment_counts']=counts
    if needs_review:
     ws.process_log.appendPlainText(
      f"  WARNING — timing needs review: {counts['aligned']} aligned, "
      f"{counts['partial']} partial, {counts['estimated']} estimated. "
      'Continuing automated export; accuracy is NOT verified.')
    else:
     ws.process_log.appendPlainText('  All lines aligned; timing still benefits from listening review')
    self._batch_stage='Visualizer export';song['batch_status']='exporting';ws.save()
    self._batch_audit.record('export_started',song=self._batch_index+1,output=str(self._batch_output),test_range=(song.get('batch_test_range') if getattr(self,'_batch_section_mode',False) else None))
    ws.process_log.appendPlainText('  Rendering MP4 with original DeRo particles')
    self.start_visualizer_export(batch_output=self._batch_output,batch_test_range=(song.get('batch_test_range') if getattr(self,'_batch_section_mode',False) else None))
   elif stage=='Visualizer export':
    if not self._batch_output.is_file() or self._batch_output.stat().st_size<1024:
     raise RuntimeError('Export did not produce a valid MP4')
    self.project['authoritative_lyrics']=song['lyrics'];self.project['batch_background']=song['background']
    target=self._batch_output.with_suffix('.karaoke.json')
    with target.open('x',encoding='utf-8') as handle:json.dump(self.project,handle,ensure_ascii=False,indent=2)
    song['batch_status']='completed';song['batch_output']=str(self._batch_output);song['batch_project']=str(target)
    audit=verify_mp4(self._batch_output,find_ffmpeg(),expected_duration=(float(song['batch_test_range'][1])-float(song['batch_test_range'][0]) if getattr(self,'_batch_section_mode',False) else getattr(self,'_batch_duration',None)))
    self._batch_audit.record('export_finished',song=self._batch_index+1,output=str(self._batch_output),project=str(target),alignment_counts=song.get('batch_alignment_counts'),needs_review=bool(song.get('batch_sync_review_required')),test_range=(song.get('batch_test_range') if getattr(self,'_batch_section_mode',False) else None),audit=audit)
    ws.process_log.appendPlainText('  MP4 audit: '+audit['result']+' — '+', '.join(audit['issues'] or ['stream and duration checks passed']))
    ws.save();ws.refresh(keep_selection=True);ws.process_log.appendPlainText(('  EXPORTED — NEEDS SYNC REVIEW: ' if song.get('batch_sync_review_required') else '  COMPLETED: ')+str(self._batch_output))
    if self._batch_index<len(self._batch_test_indices)-1:self.play_batch_song_tone()
    QTimer.singleShot(0,self._batch_next_song)
  except Exception as exc:self._batch_failed(str(exc))

 def _batch_failed(self,error):
  if not self._batch_running:return
  ws=self.batch_page
  if 0<=self._batch_index<len(self._batch_test_indices):
   song=ws.songs[self._batch_test_indices[self._batch_index]];song['batch_status']='failed';song['batch_error']=str(error)[:1000];ws.save();ws.refresh(keep_selection=True)
   if getattr(self,'_batch_audit',None):self._batch_audit.record('song_failed',song=self._batch_index+1,error=str(error)[:1000],stage=getattr(self,'_batch_stage',None))
   ws.process_log.appendPlainText(f'  FAILED: {str(error)[:500]}')
  QTimer.singleShot(0,self._batch_next_song)

 def cancel_visualizer_export(self):
  control=getattr(self,'_visualizer_control',None)
  if control is not None:control.cancel()
 def pick_video_background(self):
  path,_=QFileDialog.getOpenFileName(self,'Select video background',self.background_picker_folder(self.video_background.text().strip()),'Images and videos (*.png *.jpg *.jpeg *.bmp *.webp *.mp4 *.mkv *.mov *.webm);;All files (*)')
  if path:
   self.remember_background_folder(path)
   self.video_background.setText(path)
 def pick_video_color(self,key,button):
  current=self._video_color.get(key,self.studio_video_settings().get(key,'#FFFFFF'))
  chosen=QColorDialog.getColor(QColor(current),self,'Select video color')
  if chosen.isValid():self._video_color[key]=chosen.name();button.setToolTip('Selected color: '+chosen.name());button.setStyleSheet('');self.persist_video_settings()
 def persist_video_settings(self,*ignored):
  if getattr(self,'_video_restoring',False) or not hasattr(self,'video_enabled'):return
  data={'enabled':self.video_enabled.isChecked(),'background':self.video_background.text().strip(),
   'background_color':self._video_color.get('background_color','#0B1224'),
   'visualizer':self.video_visualizer.isChecked(),'style':self.video_style.currentText(),
   'bars':int(self.video_bars.currentText()),'spectrum_color':self._video_color.get('spectrum_color','#35A5FF'),
   'spectrum_height':self.video_height.value(),'particles':self.video_particles.isChecked(),
   'particle_count':self.video_particle_count.value(),'particle_color':self._video_color.get('particle_color','#FFDE59'),
   'title_enabled':self.video_intro.isChecked(),'title_seconds':self.video_intro_seconds.value(),
   'outro_enabled':self.video_outro.isChecked(),'outro_seconds':self.video_outro_seconds.value(),
   'motion_background':self.video_motion.isChecked()}
  self.project['studio_video']=data
 def restore_video_settings(self):
  self._video_restoring=True
  try:
   d=self.studio_video_settings();self._video_color={k:d[k] for k in ('background_color','spectrum_color','particle_color')}
   self.video_enabled.setChecked(bool(d['enabled']));self.video_background.setText(str(d['background']))
   self.video_visualizer.setChecked(bool(d['visualizer']));self.video_style.setCurrentText(str(d['style']))
   self.video_bars.setCurrentText(str(d['bars']));self.video_height.setValue(int(d['spectrum_height']))
   self.video_particles.setChecked(bool(d['particles']));self.video_particle_count.setValue(int(d['particle_count']))
   self.video_intro.setChecked(bool(d['title_enabled']));self.video_intro_seconds.setValue(float(d['title_seconds']))
   self.video_outro.setChecked(bool(d['outro_enabled']));self.video_outro_seconds.setValue(float(d['outro_seconds']))
   self.video_motion.setChecked(bool(d.get('motion_background',False)))
   for key,button in (('background_color',self.video_bg_color),('spectrum_color',self.video_spectrum_color),('particle_color',self.video_particle_color)):
    button.setStyleSheet('');button.setToolTip('Selected color: '+str(d[key]))
  finally:self._video_restoring=False
 def studio_export_command(self,ffmpeg,asspath,audio,target,width,height,duration,settings,preview_at=None,clip_start=0.):
  """Self-contained enhanced FFmpeg composition, isolated from original Lite exporter."""
  fps=60;has_visual=bool(settings['visualizer']);has_dust=bool(settings['particles'])
  bgpath=str(settings.get('background') or '').strip()
  if bgpath and not Path(bgpath).is_file():raise RuntimeError('Background does not exist: '+bgpath)
  cmd=[ffmpeg,'-hide_banner','-nostdin','-y','-loglevel','error']
  is_image=bool(bgpath and Path(bgpath).suffix.lower() in ('.jpg','.jpeg','.png','.bmp','.webp'))
  if bgpath:
   if is_image:cmd+=['-loop','1','-framerate',str(fps),'-i',bgpath]
   else:cmd+=['-stream_loop','-1','-ss',f'{clip_start:.3f}','-i',bgpath]
  else:cmd+=['-f','lavfi','-i',f"color=c={settings['background_color'].replace('#','0x')}:s={width}x{height}:r={fps}"]
  cmd+=['-ss',f'{clip_start:.3f}','-t',f'{duration:.3f}','-i',audio]
  filters=[f'[0:v]fps={fps},scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},trim=duration={duration:.3f},setpts=PTS-STARTPTS,format=yuv420p[base]']
  # use actual instrumental audio as frequency analysis input, spectrum starts near screen bottom
  prev='[base]'
  if has_visual:
   bars=int(settings['bars']);h=max(80,int(settings['spectrum_height']));w=round(width*.88)
   color=settings['spectrum_color'].replace('#','0x')
   # showspectrum is highly compatible with FFmpeg builds and audio-reactive.
   # Quantization via scale nearest preserves the selected band count.
   filters.append(f'[1:a]asplit=2[main_audio][viz_audio]')
   filters.append(f'[viz_audio]showfreqs=s={bars}x{max(64,h)}:mode=bar:ascale=log:fscale=log:colors={color},fps={fps},trim=duration={duration:.3f},scale={w}:{h}:flags=neighbor,format=yuv420p[vis]')
   y=height-h-max(12,round(height*.035));x=round((width-w)/2)
   filters.append(f'{prev}[vis]overlay={x}:{y}:shortest=1[vizbase]');prev='[vizbase]'
  else:filters.append('[1:a]anull[main_audio]')
  if has_dust:
   count=max(1,min(30,int(settings['particle_count'])));c=settings['particle_color'].replace('#','0x')
   # Real FFmpeg overlay animations; position expressions evaluate each frame.
   # A separate 4x4 colored dot is emitted to avoid embedding any images.
   dot_tags=''.join('[dot'+str(i)+']' for i in range(count))
   if count>1:
    filters.append(f'color=c={c}@0.75:s=4x4:r={fps}:d={duration:.3f},format=rgba,split={count}{dot_tags}')
   else:
    filters.append(f'color=c={c}@0.75:s=4x4:r={fps}:d={duration:.3f},format=rgba[dot0]')
   for i in range(count):
    x=(i*937)%width
    y=(i*131)%height
    pace=10+i%9*3
    source=f'[dot{i}]'
    out=f'[p{i}]'
    filters.append(f"{prev}{source}overlay=x='{x}+{(i%5+1)*6}*sin(t*{.3+(i%7)*.1:.2f})':y='mod({height+y}-t*{pace},{height})':shortest=1{out}")
    prev=out
  # ASS subtitles are rendered on original song clock; title scene shifts output afterward.
  escaped=str(asspath.resolve()).replace('\\','/').replace(':',r'\:').replace("'",r"\'")
  filters.append(f"{prev}ass=filename='{escaped}',trim=duration={duration:.3f},setpts=PTS-STARTPTS[lyrics]")
  title_seconds=float(settings['title_seconds']) if settings['title_enabled'] else 0.
  outro_seconds=float(settings['outro_seconds']) if settings['outro_enabled'] else 0.
  if title_seconds:
   # Use solid title cards, Unicode names supplied via ASS for reliable quoting.
   title_ass=asspath.parent/'studio_intro.ass';self.write_studio_card_ass(title_ass,width,height,title_seconds,self.project.get('song',''),self.project.get('artist',''))
   esc=str(title_ass.resolve()).replace('\\','/').replace(':',r'\:')
   filters.append(f"color=c=0x081329:s={width}x{height}:r={fps}:d={title_seconds},ass=filename='{esc}'[intro]")
  if outro_seconds:
   filters.append(f'color=c=0x081329:s={width}x{height}:r={fps}:d={outro_seconds}[outro]')
  if title_seconds or outro_seconds:
   segments=[]
   if title_seconds:segments.append('[intro]')
   segments.append('[lyrics]')
   if outro_seconds:segments.append('[outro]')
   filters.append(''.join(segments)+f'concat=n={len(segments)}:v=1:a=0[vout]')
  else:filters.append('[lyrics]null[vout]')
  if title_seconds:
   delay=int(title_seconds*1000)
   filters.append(f'[main_audio]adelay={delay}:all=1,apad,atrim=duration={duration+title_seconds+outro_seconds:.3f}[audout]')
  elif outro_seconds:
   filters.append(f'[main_audio]apad,atrim=duration={duration+outro_seconds:.3f}[audout]')
  else:filters.append('[main_audio]anull[audout]')
  graph=';'.join(filters)
  cmd+=['-filter_complex',graph,'-map','[vout]','-map','[audout]']
  if preview_at is not None:
   # Create a short full-composition clip; no attempt to seek in graph as it would
   # desynchronize ASS. Frame previews are extracted from the rendered segment.
   cmd+=['-t',str(max(3.,preview_at+3.))]
  else:cmd+=['-t',str(round(duration+title_seconds+outro_seconds,3))]
  encoder='h264_nvenc' if self.encoder.currentIndex()==1 else 'libx264'
  cmd+=['-c:v',encoder]
  cmd+=['-preset','p5','-rc','vbr','-cq','19','-b:v','0'] if encoder=='h264_nvenc' else ['-preset','medium','-crf','18']
  cmd+=['-pix_fmt','yuv420p','-c:a','aac','-b:a','320k','-movflags','+faststart',str(target)]
  return cmd
 def write_studio_card_ass(self,path,width,height,length,song,artist):
  def clean(s):return safe_ass(s).replace('\r',' ')
  data=f"""[Script Info]\nScriptType: v4.00+\nPlayResX: {width}\nPlayResY: {height}\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Title,Arial,78,&H00FFFFFF,&H00FFFFFF,&H00212A42,&H00212A42,-1,0,0,0,100,100,0,0,1,2,0,5,20,20,20,1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:00.00,{ass_timestamp(length)},Title,,0,0,0,,{clean(song)}\\N{clean(artist)}\n"""
  path.write_text(data,encoding='utf-8-sig')
 def start_studio_export(self,preview=False):
  if (self.job is not None and self.job.isRunning()) or self.activity_started is not None:
   QMessageBox.information(self,'Processing in progress','Stop or finish the current task before starting another export.');return
  self.sync_fields();self.persist_video_settings()
  audio=self.audio.text().strip();original=audio
  if not audio or not Path(audio).is_file():QMessageBox.warning(self,'No song','Import a valid audio file first.');return
  if not self.project.get('events'):QMessageBox.warning(self,'No lyrics','Synchronize or manually enter timed lyric lines first.');return
  settings=self.studio_video_settings()
  inst=self.instrumental.text().strip()
  if self.audio_choice.currentIndex()==0 and inst and Path(inst).is_file():
   if Path(inst).parent.name.casefold()!=Path(original).stem.casefold():
    if QMessageBox.question(self,'Imported stem','Instrumental may be from a different song. Use anyway?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
   audio=inst
  ffmpeg=find_ffmpeg()
  if not ffmpeg:QMessageBox.warning(self,'FFmpeg missing','FFmpeg is required.');return
  try:
   width,height=map(int,self.resolution.currentText().split('x'))
   probe=subprocess.run([ffmpeg,'-hide_banner','-i',audio],capture_output=True,text=True,timeout=15)
   m=re.search(r'Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)',probe.stderr)
   if not m:raise RuntimeError('Cannot determine audio duration')
   duration=int(m[1])*3600+int(m[2])*60+float(m[3])
   self.export_range.set_duration(duration)
  except Exception as e:QMessageBox.warning(self,'Audio validation',str(e));return
  if preview:
   output=Path(tempfile.gettempdir())/'karaoke_maker_lite_video_designer_preview.mp4'
  else:
   name=safe_song_filename(self.artist.text(),self.song.text() or Path(original).stem,'Karaoke')
   chosen,_=QFileDialog.getSaveFileName(self,'Export enhanced video',str(Path.home()/(name+' - Studio.mp4')),'MP4 video (*.mp4)')
   if not chosen:return
   self.app_settings.setValue('last_video_export_folder',str(Path(chosen).expanduser().parent))
   output=Path(chosen)
   if output.exists() and QMessageBox.question(self,'Overwrite existing video?',str(output),QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
  clip_start,clip_end=(0.,duration) if preview else (self.export_range.start,self.export_range.end)
  clip_duration=clip_end-clip_start
  project=copy.deepcopy(self.project)
  control=ExportControl();self._studio_control=control
  cancel=control.event;self._studio_cancel_event=cancel
  def job(emit):
   audit=self.new_export_audit('studio',str(output),width,height,clip_start,clip_end,settings)
   began=time.monotonic()
   try:
    return _studio_export_job(emit,audit,began,ffmpeg,project,width,height,audio,output,settings,clip_start,clip_duration,preview,cancel)
   except Exception as exc:
    self.finish_export_audit(audit,began,error=str(exc),canceled=control.event.is_set())
    raise
  def _studio_export_job(emit,audit,began,ffmpeg,project,width,height,audio,output,settings,clip_start,clip_duration,preview,cancel):
   control.check()
   with tempfile.TemporaryDirectory(prefix='.karaoke-studio-merged-',dir=output.parent) as td:
    temp=Path(td);ass=temp/'lyrics.ass';ass_file(project,ass,width,height)
    if clip_start>0.001:
     shifted=temp/'lyrics_clip.ass';shift_ass_dialogues(ass,shifted,clip_start,clip_duration);ass=shifted
    # Render to a temporary MP4 so cancellation or errors never overwrite a completed video.
    partial=temp/'studio_export_in_progress.mp4'
    command=self.studio_export_command(ffmpeg,ass,audio,partial,width,height,clip_duration,settings,preview_at=8 if preview else None,clip_start=clip_start)
    audit['ffmpeg_command']=command
    audit['subtitle_filters']=sum(str(v).count('ass=filename=') for v in command)
    audit['lyric_display_mode']=project.get('lyric_display_mode')
    audit['subtitle_clock']='clip-local' if clip_start>0.001 else 'original-v73'
    if audit['subtitle_filters']<1:raise RuntimeError('Missing ASS subtitle renderer')
    emit('Compositing Studio background + lyrics + visualizer + particles (Stop available)')
    run_controlled_export(command,emit,control)
    if cancel.is_set():raise RuntimeError('Studio export cancelled')
    if not partial.is_file() or partial.stat().st_size<1000:raise RuntimeError('No valid MP4 produced.')
    require_verified_mp4(partial,ffmpeg,expected_duration=(min(clip_duration+float(settings['title_seconds'] if settings['title_enabled'] else 0)+float(settings['outro_seconds'] if settings['outro_enabled'] else 0),11.) if preview else clip_duration+float(settings['title_seconds'] if settings['title_enabled'] else 0)+float(settings['outro_seconds'] if settings['outro_enabled'] else 0)),expected_resolution=(width,height),expected_fps=60,cancel=control)
    control.commit(lambda:os.replace(str(partial),str(output)))
   self.finish_export_audit(audit,began)
   return str(output)
  def done(path):
   self.last_export=path;self.activity_title.setText('COMPLETE — Studio video rendered');self.activity_detail.setText(path)
   if not preview:self.celebrate_success('export',str(path))
   if preview:QDesktopServices.openUrl(QUrl.fromLocalFile(path))
   elif self.auto_open_export.isChecked():QDesktopServices.openUrl(QUrl.fromLocalFile(path))
  self.begin_job('Studio video export',job,done,final_export=not preview)
 def run_cancellable_studio_command(self,command,emit,cancel):
  # Only the experimental Studio exporter uses this path; Demucs/WhisperX are untouched.
  if cancel.is_set():raise RuntimeError('Studio export cancelled')
  flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
  process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
   text=True,encoding='utf-8',errors='replace',bufsize=1,creationflags=flags)
  with self._studio_process_lock:self._studio_active_process=process
  tail=[]
  try:
   if cancel.is_set() and process.poll() is None:process.terminate()
   for line in process.stdout:
    line=line.strip()
    if line:
     tail.append(line);tail=tail[-20:]
     if 'time=' in line or 'error' in line.lower():emit(line[:180])
    if cancel.is_set() and process.poll() is None:process.terminate()
   code=process.wait()
   if cancel.is_set():raise RuntimeError('Studio export cancelled')
   if code:raise RuntimeError(f'FFmpeg exited with code {code}: '+'\n'.join(tail[-12:]))
  finally:
   if process.poll() is None:
    try:process.kill()
    except OSError as exc:
     logging.warning('Studio FFmpeg cleanup: could not kill process pid=%s: %s',process.pid,exc)
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:
    logging.warning('Studio FFmpeg cleanup: process pid=%s did not exit within 5 seconds',process.pid)
   if process.stdout:process.stdout.close()
   with self._studio_process_lock:
    if self._studio_active_process is process:self._studio_active_process=None
 def cancel_studio_export(self):
  standard=getattr(self,'_standard_control',None)
  if standard is not None:
   if not standard.cancel():return  # Publication already committed: completion wins.
   self.cancel_studio_button.setEnabled(False);self.cancel_studio_button.setText('Stopping export…')
   self.activity_title.setText('STOPPING — MP4 export')
   self.activity_detail.setText('Stopping FFmpeg and removing temporary output…')
   return
  studio=getattr(self,'_studio_control',None)
  if studio is not None:
   if not studio.cancel():return
   self.cancel_studio_button.setEnabled(False);self.cancel_studio_button.setText('Stopping export…')
   self.activity_title.setText('STOPPING — Studio video export')
   self.activity_detail.setText('Stopping FFmpeg and removing temporary output…')
   return
  if getattr(self,'_visualizer_control',None) is not None:
   self.cancel_visualizer_export();self.cancel_studio_button.setEnabled(False);self.cancel_studio_button.setText('Stopping export…');return
  cancel=self._studio_cancel_event
  if cancel is None or not (self.job and self.job.isRunning()):return
  cancel.set()
  self.cancel_studio_button.setEnabled(False)
  self.cancel_studio_button.setText('Stopping export…')
  self.activity_title.setText('STOPPING — Studio video export')
  self.activity_detail.setText('Stopping FFmpeg and cleaning up temporary files. Please wait a moment…')
  with self._studio_process_lock:process=self._studio_active_process
  if process is not None and process.poll() is None:
   try:process.terminate()
   except OSError as exc:
    logging.warning('Studio FFmpeg cancellation: could not terminate process pid=%s: %s',process.pid,exc)
  QTimer.singleShot(2500,self._force_studio_stop)
  # Do not terminate the Python QThread. The worker exits when FFmpeg stops.
 def _finish_cancelled_close(self):
  # Wait for the QThread to actually leave its run() method before destroying Qt objects.
  if self.job is not None and self.job.isRunning():
   QTimer.singleShot(150,self._finish_cancelled_close)
   return
  self.close()
 def _force_studio_stop(self):
  cancel=self._studio_cancel_event
  if cancel is None or not cancel.is_set():return
  with self._studio_process_lock:process=self._studio_active_process
  if process is not None and process.poll() is None:
   try:process.kill()
   except OSError as exc:
    logging.warning('Studio FFmpeg forced cancellation: could not kill process pid=%s: %s',process.pid,exc)
 def preview_studio_frame(self):
  # Render a short starting clip through the same merged composition graph.
  self.start_studio_export(preview=True)

 def start_export(self):
  if (self.job is not None and self.job.isRunning()) or self.activity_started is not None:
   QMessageBox.information(self,'Processing in progress','Stop or finish the current task before starting another export.');return
  if hasattr(self,'video_enabled') and self.video_enabled.isChecked():return self.start_studio_export()
  self.sync_fields()
  remaining=self.review_remaining_indices()
  if remaining:
   total=len(self.review_issue_indices())
   response=QMessageBox.question(self,'Synchronization review',
    f'{len(remaining)} of {total} Partial/Estimated/Failed lines have not been marked reviewed.\n\n'
    'You may export anyway. Would you like to continue?',
    QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)
   if response!=QMessageBox.Yes:return
  original=self.audio.text().strip()
  instrumental=self.instrumental.text().strip()
  vocals=self.vocals.text().strip()
  if not original or not Path(original).is_file():
   QMessageBox.warning(self,'Missing original song','Select a valid original song before exporting.');return
  if not self.project.get('events'):
   QMessageBox.warning(self,'Missing lyrics','Create or align lyric lines first.');return
  # Old stems can survive project changes in earlier versions. Never silently
  # use an unrelated instrumental just because the path exists.
  use_stems=self.audio_choice.currentIndex()==0 and bool(instrumental) and Path(instrumental).is_file()
  if use_stems:
   source=Path(original).stem.casefold()
   # Demucs normally stores stems in a directory named after the source song.
   # External/imported stems cannot be proven to belong to this song: require
   # explicit user confirmation rather than guessing.
   stem_dir=Path(instrumental).parent.name.casefold()
   if stem_dir!=source:
    response=QMessageBox.question(self,'Verify instrumental track',
     'The instrumental is not in a folder named after the current song.\n\n'
     f'CURRENT SONG:\n{original}\n\nINSTRUMENTAL:\n{instrumental}\n\n'
     'This may be audio from another project. Export using the original song instead?',
     QMessageBox.Yes|QMessageBox.Cancel,QMessageBox.Yes)
    if response!=QMessageBox.Yes:return
    use_stems=False
  audio=instrumental if use_stems else original
  mix_stems=use_stems and bool(vocals) and Path(vocals).is_file() and Path(vocals).parent==Path(instrumental).parent
  if use_stems and vocals and Path(vocals).is_file() and not mix_stems:
   QMessageBox.warning(self,'Mismatched stems','Vocal and instrumental files are from different folders. Export cancelled.');return
  instrumental_gain=self.instrumental_volume.value()/100.0
  vocal_gain=self.vocal_volume.value()/100.0
  ffmpeg=find_ffmpeg()
  if not ffmpeg:QMessageBox.warning(self,'FFmpeg missing','Install imageio-ffmpeg or make FFmpeg available on PATH.');return
  # Validate the actual selected audio duration, not the title or MP4 filename.
  try:
   probe=subprocess.run([ffmpeg,'-hide_banner','-i',audio],capture_output=True,text=True,timeout=20)
   match=re.search(r'Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)',probe.stderr)
   duration=int(match.group(1))*3600+int(match.group(2))*60+float(match.group(3)) if match else None
  except Exception:duration=None
  if not duration:
   QMessageBox.warning(self,'Audio verification failed','Cannot determine the selected audio duration. Export cancelled.');return
  self.export_range.set_duration(duration)
  events=self.project.get('events',[])
  valid=[]
  for e in events:
   try:
    a,b,t=e
    if float(b)>float(a) and str(t).strip() and float(a)<duration:valid.append(e)
   except (TypeError,ValueError):pass
  if not valid:
   QMessageBox.warning(self,'No visible lyrics','No lyric lines fall within the selected audio duration. Export cancelled.');return
  safe=safe_song_filename(self.artist.text(), self.song.text() or Path(original).stem, 'Karaoke')
  target,_=QFileDialog.getSaveFileName(self,'Export MP4',str(Path.home()/(safe+'.mp4')),'MP4 video (*.mp4)')
  if not target:return
  self.app_settings.setValue('last_video_export_folder',str(Path(target).expanduser().parent))
  if Path(target).exists():
   choice=QMessageBox.question(self,'Replace existing video?',
    f'This video already exists:\n\n{target}\n\nReplace it with the new export?',
    QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
   if choice!=QMessageBox.Yes:return
  width,height=map(int,self.resolution.currentText().split('x'));encoder='h264_nvenc' if self.encoder.currentIndex()==1 else 'libx264'
  try:
   filters=subprocess.run([ffmpeg,'-hide_banner','-filters'],capture_output=True,text=True,timeout=15).stdout
   encoders=subprocess.run([ffmpeg,'-hide_banner','-encoders'],capture_output=True,text=True,timeout=15).stdout
   if not re.search(r'\sass\s',filters):raise RuntimeError('FFmpeg lacks the ASS/libass subtitle filter.')
   if not re.search(r'\s'+re.escape(encoder)+r'\s',encoders):raise RuntimeError('FFmpeg lacks encoder '+encoder+'.')
  except Exception as exc:
   QMessageBox.warning(self,'FFmpeg capability check',str(exc));return
  clip_start,clip_end=self.export_range.start,self.export_range.end
  clip_duration=clip_end-clip_start
  project=copy.deepcopy(self.project)
  # Write a report beside the video so failed exports can be diagnosed later.
  report_path=Path(target).with_suffix('.export-diagnostics.json')
  control=ExportControl();self._standard_control=control
  def job(emit):
   began=time.monotonic()
   audit=self.new_export_audit('standard',target,width,height,clip_start,clip_end)
   report={'version':APP_BUILD,'project_song':project.get('song'),
    'original_audio':original,'selected_audio':audio,'instrumental':instrumental if use_stems else None,
    'vocals':vocals if mix_stems else None,'duration_seconds':duration,
    'valid_lyric_events':len(valid),'target':target,'status':'started'}
   try:
    control.check()
    with tempfile.TemporaryDirectory(prefix='.karaoke-lite-',dir=Path(target).parent) as tmp:
     partial=Path(tmp)/'verified_output.mp4'
     sub=Path(tmp)/'lyrics.ass';ass_file(project,sub,width,height)
     ass_content=sub.read_text(encoding='utf-8-sig')
     count=sum(1 for line in ass_content.splitlines() if line.startswith('Dialogue: '))
     report['ass_dialogue_events']=count
     if count==0:raise RuntimeError('Generated ASS subtitle file has no lyric dialogue events.')
     # Keep a copy for direct inspection and recovery if export fails.
     Path(target).with_suffix('.lyrics.ass').write_bytes(sub.read_bytes())
     ass_path=str(sub.resolve()).replace('\\','/').replace(':',r'\:').replace("'",r"\'")
     # Keep v73's known-good full-song subtitle pipeline unchanged.
     # For partial exports shift the ASS dialogue clock instead of video PTS.
     if clip_start>0.001:
      shifted=Path(tmp)/'lyrics_clip.ass';shift_ass_dialogues(sub,shifted,clip_start,clip_duration)
      ass_path=str(shifted.resolve()).replace('\\','/').replace(':',r'\:').replace("'",r"\'")
     vf=f"ass=filename='{ass_path}'"

     background='black' if project.get('lyric_display_mode')=='classic_flow' else '0x0b1224'
     command=[ffmpeg,'-hide_banner','-nostdin','-y','-f','lavfi','-i',f'color=c={background}:s={width}x{height}:r=60','-ss',f'{clip_start:.3f}','-t',f'{clip_duration:.3f}','-i',audio]
     if mix_stems:
      command+=['-ss',f'{clip_start:.3f}','-t',f'{clip_duration:.3f}','-i',vocals,'-filter_complex',f'[1:a]volume={instrumental_gain:.4f}[inst];[2:a]volume={vocal_gain:.4f}[vox];[inst][vox]amix=inputs=2:duration=longest:normalize=0[mixed]','-map','0:v:0','-map','[mixed]']
     else:
      command+=['-map','0:v:0','-map','1:a:0']
      if use_stems:command+=['-af',f'volume={instrumental_gain:.4f}']
     command+=['-vf',vf,'-c:v',encoder]
     command+=['-preset','p5','-rc','vbr','-cq','19','-b:v','0'] if encoder=='h264_nvenc' else ['-preset','medium','-crf','18']
     command+=['-t',f'{clip_duration:.3f}','-pix_fmt','yuv420p','-c:a','aac','-b:a','320k','-shortest','-movflags','+faststart',str(partial)]
     report['ffmpeg_command']=command
     audit['ffmpeg_command']=command
     audit['subtitle_filters']=sum(str(v).count('ass=filename=') for v in command)
     audit['lyric_display_mode']=project.get('lyric_display_mode')
     audit['subtitle_clock']='clip-local' if clip_start>0.001 else 'original-v73'
     if audit['subtitle_filters']!=1:raise RuntimeError('Expected exactly one ASS subtitle renderer')
     emit('Export audio: '+Path(audio).name+' | ASS lyric lines: '+str(count))
     run_controlled_export(command,emit,control)
     if not partial.is_file() or partial.stat().st_size<1024:raise RuntimeError('Export did not produce a valid-sized MP4')
     # Decode a video frame during a lyric event and verify that it is not just
     # the plain solid-color background. This catches invisible ASS overlays.
     in_clip=[e for e in valid if float(e[0])<clip_end and float(e[1])>clip_start]
     if in_clip:
      a,b,_=in_clip[0];sample=max(0.,min(clip_duration-.1,(max(float(a),clip_start)+min(float(b),clip_end))/2-clip_start))
     else:sample=max(0.,clip_duration/2)
     check=control.run([ffmpeg,'-hide_banner','-loglevel','error','-ss',f'{sample:.3f}','-i',str(partial),'-frames:v','1','-vf','scale=160:90','-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
     if check.returncode or len(check.stdout)!=160*90*3:
      raise RuntimeError('Unable to verify a rendered video frame during the lyrics.')
     pixels=check.stdout
     if in_clip and len(set(pixels[i:i+3] for i in range(0,len(pixels),3)))<8:
      raise RuntimeError('Rendered video frame appears to contain no lyrics. Check the generated .lyrics.ass file.')
     report['stream_verification']=require_verified_mp4(partial,ffmpeg,expected_duration=clip_duration,expected_resolution=(width,height),expected_fps=60,cancel=control)
     report['verified_frame_seconds']=round(sample,3)
     control.commit(lambda:os.replace(str(partial),str(target)))
     report['status']='verified'
     self.finish_export_audit(audit,began)
     report['audit_path']=str(Path(target).with_suffix('.export-audit.json'))
     report['elapsed_seconds']=audit.get('elapsed_seconds')
     return target
   except Exception as exc:
    report['status']='canceled' if control.event.is_set() else 'failed';report['error']=str(exc)
    self.finish_export_audit(audit,began,error=str(exc),canceled=control.event.is_set())
    report['audit_path']=str(Path(target).with_suffix('.export-audit.json'))
    report['elapsed_seconds']=audit.get('elapsed_seconds')
    raise
   finally:
    try:report_path.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    except OSError:
     logging.exception('Could not save MP4 export diagnostic report to %s', report_path)
  self.export_progress.show()
  def done(path):
   self.last_export=path;self.status.setText('Export verified: '+path)
   self.activity_detail.setText('Video verified — audio and visible lyric frame checked. File: '+path)
   self.activity_title.setText('🎉 Karaoke video export verified!')
   self.celebrate_success('export',str(path))
   if self.auto_open_export.isChecked():QTimer.singleShot(350,self.open_export_file)
  self.begin_job('MP4 export',job,done,final_export=True)
 def replay_celebration_test(self):
  """Replay the existing double-popper overlay and original chime without an export."""
  effect=getattr(self,'celebration_effect',None)
  if effect is not None:
   effect.start()
  self.play_celebration_audio()

 def _clear_export_congratulations(self):
  """Remove an earlier success notice before a newly accepted export or batch."""
  label=getattr(self,'export_congratulations_label',None)
  if label is not None:
   label.clear()
   label.hide()

 def celebrate_success(self, kind, detail=''):
  """Celebrate a verified standalone export or the successful end of a whole batch."""
  if kind=='batch':
   self.activity_title.setText('✓  BATCH COMPLETE — All songs exported!')
  else:
   self.activity_title.setText('✓  COMPLETE — Video exported successfully!')
  self.activity_detail.setText(detail)
  self.activity_title.setStyleSheet('font-size:21px;font-weight:800;color:#70df91')
  self.activity_bar.setRange(0,100)
  self.activity_bar.setValue(100)
  self.activity_bar.setStyleSheet('QProgressBar{background:#263a50;border:0;border-radius:4px} QProgressBar::chunk{background:#55c66c;border-radius:4px}')
  self.navigate(6)
  self.activity_panel.show()
  self.export_congratulations_label.setText('🎉 Congratulations! Batch completed!' if kind=='batch' else '🎉 Congratulations! Video exported successfully!')
  self.celebration_effect.start()
  left=self.celebration_effect._geometry(0)[0]
  right=self.celebration_effect._geometry(1)[0]
  margin=max(22,int(self.celebration_effect.height()*.48))
  self.export_congratulations_label.setGeometry(int(left+margin),0,max(1,int(right-left-2*margin)),self.celebration_effect.height())
  self.export_congratulations_label.show()
  self.export_congratulations_label.raise_()
  self.play_celebration_audio()

 def play_batch_song_tone(self):
  """A short cue after an individual batch song, never the full celebration."""
  self._play_notification_file('DeRo_Song_Completed_Quick_Tone.wav')

 def _play_notification_file(self, filename):
  path=Path(__file__).resolve().parent/filename
  if not path.is_file():return
  if sys.platform=='win32':
   try:
    import winsound
    winsound.PlaySound(str(path),winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_NODEFAULT)
    return
   except Exception:pass
  try:
   from PySide6.QtMultimedia import QSoundEffect
   if not hasattr(self,'_batch_notification_sound'):
    self._batch_notification_sound=QSoundEffect(self)
    self._batch_notification_sound.setSource(QUrl.fromLocalFile(str(path)))
    self._batch_notification_sound.setVolume(.55)
   self._batch_notification_sound.stop()
   self._batch_notification_sound.play()
  except Exception:pass

 def play_celebration_audio(self):
  """Play the user's approved WAV once, asynchronously; never block the GUI."""
  path=Path(__file__).resolve().parent/'DeRo_Cheerful_Completion_Chime.wav'
  if not path.is_file():return
  if sys.platform=='win32':
   try:
    import winsound
    winsound.PlaySound(str(path),winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_NODEFAULT)
    return
   except Exception:pass
  try:
   from PySide6.QtMultimedia import QSoundEffect
   if not hasattr(self,'_celebration_sound'):
    self._celebration_sound=QSoundEffect(self)
    self._celebration_sound.setSource(QUrl.fromLocalFile(str(path)))
    self._celebration_sound.setVolume(.75)
   self._celebration_sound.stop()
   self._celebration_sound.play()
  except Exception:pass

 def play_success_tone(self, stage='export'):
  """Nonblocking, cheerful completion cue for successful processing stages.

  Windows uses winsound in a daemon thread; other systems use the Qt beep.
  Only call this from successful completion callbacks, never on failure.
  """
  patterns={
   'separation':[(523,100),(659,100),(784,220)],
   'alignment':[(587,100),(740,100),(880,220)],
   'export':[(659,110),(880,120),(1047,250)],
  }
  if sys.platform=='win32':
   try:
    import winsound
    notes=patterns.get(stage,patterns['export'])
    def chime():
     try:
      for frequency,duration in notes:
       winsound.Beep(frequency,duration)
     except Exception:
      pass
    threading.Thread(target=chime,daemon=True).start()
    return
   except Exception:
    pass
  QApplication.beep()
 def open_export_file(self):
  if not self.last_export or not Path(self.last_export).is_file():
   QMessageBox.information(self,'Open video','No completed MP4 was found. Export a video first.');return
  if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(self.last_export).resolve()))):
   QMessageBox.warning(self,'Open video','Windows could not open the exported MP4. File: '+self.last_export)
 def open_export_folder(self):
  # Folder access is independent of export completion. Prefer the most recently
  # chosen export destination, then a prior completed export, then home.
  saved=str(self.app_settings.value('last_video_export_folder','') or '').strip()
  candidates=[saved]
  if self.last_export:
   candidates.append(str(Path(self.last_export).expanduser().parent))
  candidates.append(str(Path.home()))
  folder=next((Path(p).expanduser() for p in candidates if p and Path(p).expanduser().is_dir()),Path.home())
  try:
   if sys.platform=='win32':
    subprocess.Popen(['explorer.exe',str(folder.resolve())])
   elif not QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder.resolve()))):
    raise RuntimeError('Could not open the export folder.')
  except Exception as exc:
   QMessageBox.warning(self,'Open export folder',f'Could not open folder: {folder}\n{exc}')
 def preview_export(self):
  self.open_export_file()
 def audio_picker_folder(self):
  folder=str(self.app_settings.value('last_audio_folder','') or '')
  if folder and Path(folder).is_dir():return folder
  current=self.audio.text().strip() if hasattr(self,'audio') else ''
  if current and Path(current).parent.is_dir():return str(Path(current).parent)
  return str(Path.home())
 def remember_audio_folder(self,path):
  if path and Path(path).parent.is_dir():
   self.app_settings.setValue('last_audio_folder',str(Path(path).parent))
   if hasattr(self,'music_folder_combo'):
    self._remember_music_folder(str(Path(path).parent))
    self.populate_recent_music_folders(str(Path(path).parent))
 def browse_into(self,widget):
  p,_=QFileDialog.getOpenFileName(self,'Select audio',self.audio_picker_folder(),'Audio (*.mp3 *.wav *.flac *.m4a *.aac *.ogg);;All files (*)')
  if p:
   widget.setText(p)
   self.remember_audio_folder(p)
 def has_unsaved_changes(self):
  self.sync_fields()
  self.project['authoritative_lyrics']=self.lyrics.toPlainText()
  signature=json.dumps(self.project,sort_keys=True,ensure_ascii=False,default=str)
  return self.saved_signature is None and self.has_project_content() or (self.saved_signature is not None and signature!=self.saved_signature)
 def has_project_content(self):
  return bool(self.path or self.audio.text().strip() or self.song.text().strip() or self.lyrics.toPlainText().strip() or self.project.get('events'))
 def confirm_leave_project(self):
  if not self.has_unsaved_changes():return True
  result=QMessageBox.warning(self,'Save current project?',
   'Your current project has unsaved changes.\n\nSave before opening another song or project?',
   QMessageBox.Save|QMessageBox.Discard|QMessageBox.Cancel,QMessageBox.Save)
  if result==QMessageBox.Cancel:return False
  if result==QMessageBox.Discard:return True
  return bool(self.save_project())
 def new_project(self):
  """Start a clean project without changing the current saved file."""
  if not self.confirm_no_active_processing():return
  if not self.confirm_leave_project():return
  if self.reset_for_new_song() is False:return
  self.player.setSource(QUrl())
  self.update_stem_monitor()
  self.navigate(0)
  self.status.setText('New project ready — select an audio file in 01 SONG.')
  self.update_project_identity()

 def reset_for_new_song(self):
  if not self.confirm_no_active_processing():return False
  self.invalidate_pcm_scrub()
  self.player.stop();self.loop_end=None
  # Clear old stems immediately; refresh() will also clear their visible fields.
  self.instrumental.clear();self.vocals.clear()
  self.project={'format':'KaraokeStudioProject','version':2,'song':'','artist':'','audio':'','events':[],'word_timings':{},'authoritative_lyrics':'','song_language':'auto','alignment_status':{},'word_scores':{},'manual_overrides':{},'reviewed_lines':{}}
  self._reset_workspace_clock()
  self._quick_karaoke_pending=False
  self.path=None;self.saved_signature=None;self.undo.clear();self.redo.clear()
  self.step_failures.clear();self.step_snapshots.clear();self.last_export=None
  self.alignment_diagnostics={};self.diagnostic_history=[]
  self.loaded_wave_path=None;self.row=0
  # A new audio selection is a new workspace, not just a new audio path.
  # Explicitly reset the paste widget and its preview as well as project data.
  # Block its textChanged signal while clearing to avoid re-populating the model.
  self.updating=True
  try:
   self.lyrics.blockSignals(True)
   self.lyrics.clear()
   self.lyric_preview.setText('Your lyric lines will appear here')
   if hasattr(self,'appearance_frame'):
    self.appearance_frame.setText('Your lyrics will appear here')
   if hasattr(self,'rendered_frame'):
    self.rendered_frame.clear()
    self.rendered_frame.setText('Rendered frame appears here (same ASS filter as export)')
  finally:
   self.lyrics.blockSignals(False)
   self.updating=False
  self.sep_timer.stop()
  self.sep_started=None
  self.sep_log.clear()
  self.sep_note.setText('READY — New song selected. Vocal separation will start automatically.')
  self.sep_progress.setRange(0,100)
  self.sep_progress.setValue(0)
  self.sep_progress.setFormat('Waiting to start')
  self.sep_elapsed.setText('Elapsed: 00:00  |  Total time: —')
  self.refresh()
  self.update_step_indicators()
  self.update_project_identity()
 def review_current_song(self, path=None, title=None, artist=None, return_values=False):
  """Review two fields before applying a selected song; Cancel makes no changes."""
  audio_path=path or self.audio.text().strip()
  if not audio_path or not Path(audio_path).is_file():
   QMessageBox.information(self,'Song information','Load an audio file first.');return False
  original_title=title if title is not None else self.song.text()
  original_artist=artist if artist is not None else self.artist.text()
  suggested_title,suggested_artist=suggest_song_information(original_title,original_artist,audio_path)
  d=QDialog(self);d.setWindowTitle('Confirm Song Information');d.resize(550,295)
  layout=QVBoxLayout(d)
  note=QLabel('Check the detected song and artist. Edit either field, restore the original information, or click OK to continue. The audio file is never changed.')
  note.setWordWrap(True);layout.addWidget(note)
  form=QFormLayout();song_edit=QLineEdit(suggested_title);artist_edit=QLineEdit(suggested_artist)
  form.addRow('Song title',song_edit);form.addRow('Artist',artist_edit);layout.addLayout(form)
  info=QLabel('Source: local audio tags / filename. Check or edit both fields before continuing.')
  info.setWordWrap(True);layout.addWidget(info)
  layout.addStretch()
  actions=QHBoxLayout();layout.addLayout(actions)
  def restore():
   song_edit.setText(original_title);artist_edit.setText(original_artist)
   info.setText('Original detected values restored. You can still edit before confirming.')
  actions.addWidget(btn('Restore Original',restore))
  actions.addWidget(btn('Cancel',d.reject))
  actions.addWidget(btn('OK — Continue',d.accept,True))
  if d.exec()!=QDialog.Accepted:return False
  if return_values:return song_edit.text().strip(),artist_edit.text().strip()
  self.song.setText(song_edit.text().strip());self.artist.setText(artist_edit.text().strip())
  self.song_summary.setText(self.song.text()+'\n'+(self.artist.text() or 'Artist not provided'))
  self.update_project_identity()
  return True

 def retrieve_audio_metadata(self):
  """Fill only Song and Artist from local tags, with a filename fallback."""
  audio_path=self.audio.text().strip()
  if not audio_path or not Path(audio_path).is_file():
   QMessageBox.information(self,'Audio metadata','Choose an audio file first.');return
  title,artist=metadata_from_audio(audio_path)
  if title:self.song.setText(title)
  if artist:self.artist.setText(artist)
  self.song_summary.setText((self.song.text().strip() or 'Song title not found')+'\n'+(self.artist.text().strip() or 'Artist not found'))
  self.update_project_identity()
  if artist:
   message='Song and artist were read from the audio tags or filename.'
  else:
   message='The song title was taken from the metadata or filename, but no artist tag was found. You can enter the artist manually.'
  QMessageBox.information(self,'Audio metadata',message+'\n\nThe audio file was not changed.')

 def _recent_music_folders(self):
  folders=self.app_settings.value('recent_music_folders',[],type=list) or []
  last=str(self.app_settings.value('last_audio_folder','') or '')
  if last:folders=[last]+folders
  result=[];seen=set()
  for folder in folders:
   try:
    normalized=str(Path(str(folder)).expanduser().resolve())
    if normalized not in seen and Path(normalized).is_dir():
     seen.add(normalized);result.append(normalized)
   except Exception:pass
  return result[:12]
 def _remember_music_folder(self,folder):
  try:
   folder=str(Path(folder).expanduser().resolve())
   if not Path(folder).is_dir():return
   folders=[folder]+[x for x in self._recent_music_folders() if x!=folder]
   self.app_settings.setValue('recent_music_folders',folders[:12])
   self.app_settings.setValue('last_audio_folder',folder)
  except Exception:pass
 def populate_recent_music_folders(self,select_folder=None):
  if not hasattr(self,'music_folder_combo'):return
  folders=self._recent_music_folders()
  if select_folder:
   try:
    selected=str(Path(select_folder).resolve())
    if Path(selected).is_dir() and selected not in folders:folders.insert(0,selected)
   except Exception:pass
  self.music_folder_combo.blockSignals(True);self.music_folder_combo.clear()
  for folder in folders:self.music_folder_combo.addItem(folder,folder)
  if folders:
   target=str(Path(select_folder).resolve()) if select_folder else folders[0]
   index=self.music_folder_combo.findData(target)
   self.music_folder_combo.setCurrentIndex(max(0,index))
  self.music_folder_combo.blockSignals(False)
  self.refresh_music_files()
 def add_music_folder(self):
  start=self.music_folder_combo.currentData() or self.audio_picker_folder()
  folder=QFileDialog.getExistingDirectory(self,'Add a music folder',str(start))
  if folder:
   self._remember_music_folder(folder);self.populate_recent_music_folders(folder)
 def on_music_folder_changed(self,_index):
  folder=self.music_folder_combo.currentData()
  if folder:
   self._remember_music_folder(folder);self.refresh_music_files()
 def refresh_music_files(self):
  if not hasattr(self,'audio_file_list'):return
  folder=self.music_folder_combo.currentData()
  self.audio_file_list.clear()
  if not folder or not Path(folder).is_dir():
   self.music_folder_status.setText('No available folder selected. Use Add folder… to choose one.')
   return
  supported={'.mp3','.wav','.flac','.m4a','.aac','.ogg','.opus','.wma','.aiff','.aif'}
  try:
   files=sorted((p for p in Path(folder).iterdir() if p.is_file() and p.suffix.lower() in supported),key=lambda p:p.name.casefold())
  except Exception as exc:
   self.music_folder_status.setText('Could not read this folder: '+str(exc));return
  for path in files:
   item=QListWidgetItem(path.name);item.setData(Qt.UserRole,str(path))
   item.setToolTip(str(path));self.audio_file_list.addItem(item)
  self.filter_music_files()
  count=self.audio_file_list.count()
  self.music_folder_status.setText(f'{count} audio file'+('s' if count!=1 else '')+' in '+str(folder))
 def filter_music_files(self,_text=None):
  if not hasattr(self,'audio_file_list'):return
  query=self.music_file_search.text().strip().casefold()
  visible=0
  for i in range(self.audio_file_list.count()):
   item=self.audio_file_list.item(i);hide=query not in item.text().casefold()
   item.setHidden(hide)
   if not hide:visible+=1
  if query:
   folder=self.music_folder_combo.currentData() or ''
   total=self.audio_file_list.count()
   self.music_folder_status.setText(f'Showing {visible} of {total} audio files in {folder}')
 def use_selected_audio_file(self):
  item=self.audio_file_list.currentItem() if hasattr(self,'audio_file_list') else None
  if not item:
   QMessageBox.information(self,'Select a song','Choose an audio file from the list first.');return
  path=item.data(Qt.UserRole)
  self._use_audio_path(path)
 def browse_audio(self):
  if not self.confirm_no_active_processing():return
  p,_=QFileDialog.getOpenFileName(self,'Select audio',self.audio_picker_folder(),'Audio (*.mp3 *.wav *.flac *.m4a *.aac *.ogg *.opus *.wma *.aiff);;All files (*)')
  if p:self._use_audio_path(p)
 def _use_audio_path(self,p):
  if not p or not Path(p).is_file() or p==self.audio.text():return
  if not self.confirm_no_active_processing():return
  # Review before any destructive reset; Cancel preserves the current project.
  title,artist=metadata_from_audio(p)
  confirmed=self.review_current_song(p,title,artist,return_values=True)
  if confirmed is False:return
  confirmed_title,confirmed_artist=confirmed
  if not self.confirm_leave_project():return
  if self.reset_for_new_song() is False:return
  workflow_begin(self.project,'song selected')
  self._reset_workspace_clock()
  self.song.setText(confirmed_title);self.artist.setText(confirmed_artist);self.audio.setText(p)
  self.remember_audio_folder(p)
  self.song_summary.setText(confirmed_title+'\n'+(confirmed_artist or 'Artist not provided'))
  self.player.setSource(QUrl.fromLocalFile(p))
  self.load_waveform(self.vocals.text().strip())
  self.update_stem_monitor()
  self.update_project_identity()
  self.navigate(1)
  QTimer.singleShot(0,self.start_separation)

 def vocal_waveform_path(self):
  path=self.vocals.text().strip()
  if path and Path(path).is_file():return path
  # Recover existing Demucs files for this exact audio basename; no new separation.
  # Never use an unrelated file or silently overwrite an explicitly invalid path.
  if path:return ''
  audio=self.audio.text().strip()
  if not audio or not Path(audio).is_file():return ''
  root=Path(audio).parent/'Karaoke Maker Stems'
  candidates=sorted(root.glob('*/'+Path(audio).stem+'/vocals.wav')) if root.is_dir() else []
  candidates=[candidate for candidate in candidates if candidate.is_file() and candidate.stat().st_size>44]
  if len(candidates)!=1:return ''
  recovered=str(candidates[0])
  self.vocals.setText(recovered)
  instrumental=candidates[0].with_name('no_vocals.wav')
  if instrumental.is_file() and not self.instrumental.text().strip():self.instrumental.setText(str(instrumental))
  # Keep recovered stems in project state on the next regular save/sync.
  self.project['vocals']=recovered
  if instrumental.is_file():self.project['instrumental']=str(instrumental)
  return recovered
 def schedule_adaptive_waveform(self):
  # Defer quick zoom / pan movements; the ordinary waveform stays visible.
  if not hasattr(self,'timeline') or not hasattr(self,'_adaptive_timer'):return
  if self.timeline.wave_style!='high_detail' or self.timeline.view_end-self.timeline.view_start>12.0:
   self._adaptive_timer.stop()
   if self.timeline.adaptive_detail is not None:self.timeline.adaptive_detail=None;self.timeline.update()
   return
  self._adaptive_timer.start(180)
 def request_adaptive_waveform(self):
  if self.timeline.wave_style!='high_detail':return
  span=self.timeline.view_end-self.timeline.view_start
  if span>12.0 or span<=0:return
  path=self.vocal_waveform_path()
  if not path:return
  window=self.timeline.adaptive_detail
  if window and self._adaptive_path==path and window[0]<=self.timeline.view_start+.001 and window[1]>=self.timeline.view_end-.001:return
  # Avoid retaining multiple running QThread objects; finish current job first.
  if self._adaptive_worker and self._adaptive_worker.isRunning():
   self._adaptive_pending=True;return
  margin=min(3.,max(.3,span*.4))
  a=max(0.,self.timeline.view_start-margin)
  b=min(self.timeline.song_duration or self.timeline.view_end+margin,self.timeline.view_end+margin)
  if b<=a:return
  key=(path,round(a,4),round(b,4))
  self._adaptive_key=key;self._adaptive_path=path;self._adaptive_pending=False
  worker=AdaptivePcmWindowWorker(path,key,a,b)
  self._adaptive_worker=worker
  worker.ready.connect(self.adaptive_waveform_ready)
  worker.finished.connect(self.adaptive_waveform_finished)
  worker.start()
 def adaptive_waveform_ready(self,key,result,error):
  if key!=self._adaptive_key or key[0]!=self.vocal_waveform_path():return
  if result:
   a,b,detail=result
   self.timeline.set_adaptive_detail(a,b,detail)
  elif error and hasattr(self,'status'):
   self.status.setText('Adaptive PCM unavailable; using standard blue waveform: '+error[:160])
 def adaptive_waveform_finished(self):
  # Retry only when the user changed the view while decoding; failures fall back.
  pending=bool(self._adaptive_pending)
  self._adaptive_pending=False;self._adaptive_worker=None
  if pending and self.timeline.wave_style=='high_detail' and self.timeline.view_end-self.timeline.view_start<=12.0:
   self.schedule_adaptive_waveform()

 def change_waveform_style(self,index):
  self.timeline.set_wave_style('high_detail' if index==1 else 'classic')
  if index==1 and self.waveform_resolution<1000:
   self.wave_resolution.setCurrentIndex(9)
  self.schedule_adaptive_waveform()

 def change_waveform_resolution(self,index):
  self.waveform_resolution=(100,200,300,400,500,600,700,800,900,1000)[max(0,min(9,index))]
  self.loaded_wave_path=None
  self.load_waveform(self.vocals.text().strip())
 def load_waveform(self,path=None):
  # Never show mixed/instrumental waveforms in the Word Sync editor.
  wanted=self.vocal_waveform_path()
  key=(wanted,self.waveform_resolution)
  if not wanted:
   self.loaded_wave_path=None;self.timeline.set_waveform([],0);self.timeline.set_detail_waveform([])
   if hasattr(self,'status'):self.status.setText('Vocal waveform missing: no valid isolated vocals path. Open Separation to select a vocals.wav stem, or run Demucs.')
   return
  if key==self.loaded_wave_path:return
  if self.wave_worker and self.wave_worker.isRunning():
   self._pending_waveform=key
   return
  self.loaded_wave_path=key
  self.timeline.set_waveform([],0);self.timeline.set_detail_waveform([])
  self.wave_worker=WaveformWorker(wanted,self.waveform_resolution)
  self.wave_worker.ready.connect(lambda peaks,duration,error,key=key,worker=self.wave_worker:self.waveform_ready(key,peaks,duration,error,worker.detail_peaks))
  self.wave_worker.finished.connect(self.waveform_finished)
  self.wave_worker.start()
  self.status.setText(f'Reading vocal waveform at {self.waveform_resolution} peaks/sec…')
 def waveform_finished(self):
  requested=(self.vocal_waveform_path(),self.waveform_resolution)
  self._pending_waveform=None
  if requested[0] and requested!=self.loaded_wave_path:self.load_waveform(requested[0])
 def waveform_ready(self,key,peaks,duration,error,detail=None):
  if key!=(self.vocal_waveform_path(),self.waveform_resolution):return
  self.timeline.set_waveform(peaks,duration)
  self.timeline.set_detail_waveform(detail or [])
  self.schedule_adaptive_waveform()
  if peaks and self.pcm_scrub is None and (self.pcm_loader is None or not self.pcm_loader.isRunning()):
   self.start_pcm_loader()
  if error or not peaks:self.loaded_wave_path=None
  self.status.setText((f'Vocal waveform: {duration:.1f}s — {len(peaks)} peaks ({self.waveform_resolution}/s)') if peaks else ('Vocal waveform unavailable: '+(error or 'No vocal samples decoded')))
 def update_stem_monitor(self,*_):
  """Use separated stems for Word Sync listening; never alter export mixing."""
  key=(self.vocal_waveform_path(),self.instrumental.text().strip())
  if self._pcm_source_key is not None and key!=self._pcm_source_key:
   self.invalidate_pcm_scrub()
  if self.pcm_scrub is None and key[0]:self.start_pcm_loader()
  if not hasattr(self,'hear_vocals'):return
  in_sync=self.pages.currentIndex()==3
  have_stems=bool(self.vocal_waveform_path())
  # Outside Word Sync, retain the application's original playback behavior.
  self.audio_out.setMuted(in_sync and have_stems)
  for name,check in [('vocals',self.hear_vocals),('instrumental',self.hear_instrumental)]:
   path=(self.vocals if name=='vocals' else self.instrumental).text().strip()
   player=self.stem_players[name];output=self.stem_outputs[name]
   valid=bool(in_sync and have_stems and path and Path(path).is_file())
   output.setMuted(not (valid and check.isChecked()))
   if valid:
    url=QUrl.fromLocalFile(path)
    if player.source()!=url:player.setSource(url)
    player.setPlaybackRate(self.player.playbackRate())
    if abs(player.position()-self.player.position())>120:player.setPosition(self.player.position())
    if check.isChecked() and self.player.playbackState()==QMediaPlayer.PlayingState:player.play()
    else:player.pause()
   else:player.pause()
 def seek_monitor_position(self,ms):
  """Seek the master and active stems once, not on every playback tick."""
  ms=max(0,int(ms))
  self.player.setPosition(ms)
  if self.pages.currentIndex()!=3 or not self.audio_out.isMuted():return
  for name,player in self.stem_players.items():
   if player.source().isEmpty() or self.stem_outputs[name].isMuted():continue
   player.setPosition(ms)
 def sync_stem_positions(self,ms):
  """No periodic re-seeks: each seek disrupts continuous audio decoding."""
  return
 def sync_stem_playback(self,state):
  if self.pages.currentIndex()!=3 or not self.audio_out.isMuted():return
  for name,player in self.stem_players.items():
   if player.source().isEmpty() or self.stem_outputs[name].isMuted():continue
   if state==QMediaPlayer.PlayingState:player.play()
   elif state==QMediaPlayer.StoppedState:player.stop()
   else:player.pause()
 def sync_stem_speed(self,rate):
  for player in self.stem_players.values():player.setPlaybackRate(rate)
 def fit_line(self):
  events=self.project.get('events',[])
  if not events or not (0<=self.row<len(events)):return
  a,b,_=events[self.row]
  words=self.get_words(self.row)
  if words:a=min(a,min(w[0] for w in words));b=max(b,max(w[1] for w in words))
  pad=max(.6,(b-a)*.15)
  self.timeline.show_range(max(0,a-pad),b+pad)

 def step_word(self,direction):
  words=self.get_words(self.row)
  if not words:return
  self.timeline.selected=max(0,min(len(words)-1,self.timeline.selected+direction))
  self.update_selected_word()
  self.timeline.show_range(max(0,words[self.timeline.selected][0]-1.2),words[self.timeline.selected][1]+1.2)
  self.seek_monitor_position(int(words[self.timeline.selected][0]*1000))
 def play_next_word(self):
  """Select and audition the next timed word, continuing into later lyric lines."""
  events=self.project.get('events',[])
  if not events or not self.audio.text():
   self.status.setText('Open a song with synchronized lyrics first.')
   return
  # Prefer the word after the current selection. At the end of a line,
  # continue with the first timed word in the next available lyric line.
  current_row=max(0,min(self.row,len(events)-1))
  current_words=self.get_words(current_row)
  current_index=self.timeline.selected
  if current_index < -1:current_index=-1
  if current_index+1 < len(current_words):
   target_row=current_row;target_index=current_index+1
  else:
   target_row=None;target_index=None
   for row_index in range(current_row+1,len(events)):
    candidate_words=self.get_words(row_index)
    if candidate_words:
     target_row=row_index;target_index=0;break
  if target_row is None:
   self.status.setText('Already at the final synchronized word.')
   return
  self._word_audition=None
  self.activate_timeline_word(target_row,target_index)
  self.fit_word()
  self.play_timeline_word(target_row,target_index)

 def play_next_line(self):
  """Select and audition the next lyric line; never change stored timings."""
  events=self.project.get('events',[])
  if not events or not self.audio.text():
   self.status.setText('Open a song with synchronized lyrics first.')
   return
  next_row=self.row+1
  if next_row>=len(events):
   self.status.setText('Already at the final lyric line.')
   return
  self._word_audition=None
  self.lines.setCurrentRow(next_row)
  # setCurrentRow normally updates self.row via the selection signal.
  # Ensure the next line is active even if that signal is unavailable.
  if self.row!=next_row:self.row=next_row;self.refresh()
  self.fit_line()
  self.play_line()

 def play_line(self):
  self._word_audition=None
  events=self.project.get('events',[])
  if not (0<=self.row<len(events)) or not self.audio.text():return
  a,b,_=events[self.row]
  words=self.get_words(self.row)
  if words:a=min(a,words[0][0]);b=max(b,words[-1][1])
  self.seek_monitor_position(int(max(0,a)*1000));self.loop_end=int(b*1000);self.player.play()
 def nudge_word(self,edge,delta):
  words=self.get_words(self.row);i=self.timeline.selected
  if not (0<=i<len(words)):return
  a,b,_=words[i]
  if edge=='start':a=max(0,min(b-.02,round(a+delta,3)))
  else:b=max(a+.02,round(b+delta,3))
  a,b=self.timeline.constrain_word(i,a,b,edge)
  self.snapshot();words[i][0]=a;words[i][1]=b
  self.commit_timing_edit(words)
  self.timeline.set_words(words);self.refresh_all_timeline_words();self.update_selected_word()
  # Keep the edited word visible even when a nudge crosses the viewport edge.
  if not (self.timeline.view_start<=a<=b<=self.timeline.view_end):self.timeline.zoom(1.0)
 def fmt_time(self,ms):
  ms=max(0,int(ms));return f'{ms//60000:02d}:{ms//1000%60:02d}.{ms%1000:03d}'
 def sync_fields(self):
  self.project.update(song_language=self.song_language.currentData(),song=self.song.text(),artist=self.artist.text(),audio=self.audio.text(),instrumental=self.instrumental.text(),vocals=self.vocals.text(),instrumental_volume=self.instrumental_volume.value(),vocal_volume=self.vocal_volume.value(),audio_choice=self.audio_choice.currentIndex(),lyric_exit=self.exit_effect.currentText(),lyric_exit_duration=int(self.exit_duration.value()),lyric_exit_delay=int(self.exit_delay.value()),lyric_display_mode=self.lyric_display_mode.currentData(),classic_flow_lines=self.classic_flow_lines.currentData(),classic_flow_fade_in=int(self.classic_flow_fade_in.value()),classic_flow_fade_out=int(self.classic_flow_fade_out.value()),lyric_color_preset=self.lyric_color_preset.currentText(),lyric_reverse_colors=self.reverse_lyric_colors.isChecked(),lyric_base_unsung=self.lyric_base_unsung,lyric_base_sung=self.lyric_base_sung,lyric_unsung_color=self.lyric_colors()[0],lyric_sung_color=self.lyric_colors()[1],lyric_read_ahead=self.lyric_display_mode.currentData()!='single',opening_progress_enabled=self.opening_progress_enabled.isChecked(),opening_progress_duration=float(self.opening_progress_duration.value()),opening_progress_before=float(self.opening_progress_before.value()),lyric_lead_seconds=self.lyric_lead.value(),lyric_vertical_percent=int(self.lyric_vertical.value()),lyric_font_size=int(self.lyric_font_size.value()),lyric_font_family=self.lyric_font_family.currentFont().family(),lyric_font_bold=self.lyric_font_bold.isChecked(),lyric_outline=int(self.lyric_outline.value()))
 def review_issue_indices(self):
  statuses=self.project.get('alignment_status',{})
  events=self.project.get('events',[])
  return [i for i in range(len(events)) if statuses.get(str(i),'unknown') in ('partial','estimated','failed')]
 def review_remaining_indices(self):
  reviewed=self.project.get('reviewed_lines',{})
  return [i for i in self.review_issue_indices() if not reviewed.get(str(i),False)]
 def update_review_ui(self):
  if not hasattr(self,'review_summary_label'):return
  issues=self.review_issue_indices()
  remaining=self.review_remaining_indices()
  self.review_summary_label.setWordWrap(True)
  self.review_summary_label.setText(
   f'Review: {len(issues)-len(remaining)}/{len(issues)} issue lines checked • {len(remaining)} remaining'
   + ' &nbsp; | &nbsp; <span style="color:#ffce72">◐ PARTIAL</span>'
   + ' &nbsp; <span style="color:#ff8c9d">~ ESTIMATED</span>'
   + ' &nbsp; <span style="color:#66dfc7">✎ EDITED (verify by listening)</span>')
  self.review_next_button.setEnabled(bool(remaining))
  current=bool(self.project.get('reviewed_lines',{}).get(str(self.row),False))
  self.review_mark_button.setText('Undo Reviewed' if current else 'Mark Reviewed')
  self.review_mark_button.setEnabled(0<=self.row<len(self.project.get('events',[])))
 def review_next_issue(self):
  remaining=self.review_remaining_indices()
  if not remaining:
   QMessageBox.information(self,'Synchronization review','No unreviewed Partial, Estimated, or Failed lines remain.')
   return
  next_rows=[i for i in remaining if i>self.row]
  target=next_rows[0] if next_rows else remaining[0]
  self.lines.setCurrentRow(target)
  self.select_line(target)
  self.fit_line()
  self.lines.scrollToItem(self.lines.item(target))
  self.status.setText(f'Review line {target+1}: listen to its vocals, inspect word timing, then click Mark Reviewed.')
 def toggle_line_reviewed(self):
  events=self.project.get('events',[])
  if not (0<=self.row<len(events)):return
  key=str(self.row)
  self.snapshot()
  reviewed=self.project.setdefault('reviewed_lines',{})
  if reviewed.get(key,False):reviewed.pop(key,None)
  else:reviewed[key]=True
  self.update_review_ui()
  self.refresh_review_line_label(self.row)
  self.update_project_identity()
 def refresh_review_line_label(self,i):
  if not (0<=i<len(self.project.get('events',[])) and i<self.lines.count()):return
  a,b,t=self.project['events'][i]
  status=self.project.get('alignment_status',{}).get(str(i),'unknown')
  symbol={'aligned':'✓','partial':'◐','estimated':'~','failed':'!','manual':'✎','placeholder':'·'}.get(status,'?')
  reviewed=' [REVIEWED]' if self.project.get('reviewed_lines',{}).get(str(i),False) else ''
  self.lines.item(i).setText(f'{symbol} [{'EDITED' if status=='manual' else status.upper()}]{reviewed} {a:07.2f}–{b:07.2f}   {t}')
 def refresh(self):
  self.updating=True
  if hasattr(self,'video_enabled'):self.restore_video_settings()
  self.instrumental_volume.setValue(int(self.project.get('instrumental_volume',100)))
  self.vocal_volume.setValue(int(self.project.get('vocal_volume',20)))
  self.audio_choice.setCurrentIndex(int(self.project.get('audio_choice',0)))
  self.lyric_base_unsung=self.project.get('lyric_base_unsung','#EAF3FF')
  self.lyric_base_sung=self.project.get('lyric_base_sung','#31B9FF')
  self.lyric_color_preset.blockSignals(True)
  self.lyric_color_preset.setCurrentText(self.project.get('lyric_color_preset','Electric Blue'))
  self.lyric_color_preset.blockSignals(False)
  self.reverse_lyric_colors.setChecked(bool(self.project.get('lyric_reverse_colors',False)))
  self.update_lyric_color_preview()
  self.lyric_display_mode.setCurrentIndex(max(0,self.lyric_display_mode.findData(self.project.get('lyric_display_mode','classic_flow'))));self.classic_flow_lines.setCurrentIndex(max(0,self.classic_flow_lines.findData(int(self.project.get('classic_flow_lines',3)))));self.classic_flow_fade_in.setValue(int(self.project.get('classic_flow_fade_in',180)));self.classic_flow_fade_out.setValue(int(self.project.get('classic_flow_fade_out',320)));self.opening_progress_enabled.setChecked(bool(self.project.get('opening_progress_enabled',self.project.get('lyric_countdown',True))));self.opening_progress_duration.setValue(float(self.project.get('opening_progress_duration',5)));self.opening_progress_before.setValue(float(self.project.get('opening_progress_before',5)));self.lyric_lead.setValue(float(self.project.get('lyric_lead_seconds',2)));self.lyric_vertical.setValue(float(self.project.get('lyric_vertical_percent',53)));self.lyric_font_size.setValue(float(self.project.get('lyric_font_size',72)));self.lyric_font_family.setCurrentFont(QFont(self.project.get('lyric_font_family','Arial')));self.lyric_font_bold.setChecked(bool(self.project.get('lyric_font_bold',True)));self.lyric_outline.setValue(float(self.project.get('lyric_outline',2)))
  self.exit_effect.setCurrentText(self.project.get('lyric_exit','Fade Out'));self.exit_duration.setValue(self.project.get('lyric_exit_duration',450));self.exit_delay.setValue(self.project.get('lyric_exit_delay',150))
  for w,key in [(self.song,'song'),(self.artist,'artist'),(self.audio,'audio'),(self.instrumental,'instrumental'),(self.vocals,'vocals')]:w.setText(str(self.project.get(key,'')))
  self.song_language.setCurrentIndex(max(0,self.song_language.findData(self.project.get('song_language','auto'))))
  self.player.setSource(QUrl.fromLocalFile(self.audio.text())) if self.audio.text() else None
  self.load_waveform(self.vocals.text().strip());self.update_stem_monitor()
  self.song_summary.setText((self.song.text() or 'No song loaded yet')+'\n'+self.artist.text())
  events=self.project.get('events',[]);self.lines.clear();self.lines.active_row=-1;self.lines.active_word=-1;self._line_word_widget_row=None
  for i,(a,b,t) in enumerate(events):
   status=self.project.get('alignment_status',{}).get(str(i),'unknown')
   symbol={'aligned':'✓','partial':'◐','estimated':'~','failed':'!','manual':'✎','placeholder':'·'}.get(status,'?')
   self.lines.addItem(f'{symbol} [{status.upper()}] {a:07.2f}–{b:07.2f}   {t}')
   self.refresh_review_line_label(i)
  self.lyrics.setPlainText(self.project.get('authoritative_lyrics',''))
  self.lyric_preview.setText(self.lyrics.toPlainText()[:2500] or 'Your lyric lines will appear here')
  self.updating=False
  if events:self.lines.setCurrentRow(min(self.row,len(events)-1))
  else:self.timeline.set_words([]);self.timeline.set_all_words([],self.row);self.preview.setText('No lyric lines yet')
  self.update_appearance_preview()
  self.update_review_ui()
 def update_lyrics_action_buttons(self):
  """Emphasize the next useful action: find lyrics first, then synchronize them."""
  if not hasattr(self,'lyrics') or not hasattr(self,'auto_sync_button'):return
  has_lyrics=bool(self.lyrics.toPlainText().strip())
  prominent=('QPushButton{background:#765be2;color:#ffffff;border:1px solid #9a86ff;font-weight:750;} '
             'QPushButton:hover{background:#9179f2;border-color:#c0b2ff;}')
  secondary=('QPushButton{background:#273653;color:#aab9d7;border:1px solid #3c4b6a;font-weight:600;} '
             'QPushButton:hover{background:#394d76;color:#eaf0ff;}')
  self.auto_sync_button.setEnabled(has_lyrics)
  self.auto_sync_button.setStyleSheet(prominent if has_lyrics else secondary)
  self.favorite_sites_button.setStyleSheet(secondary if has_lyrics else prominent)
  if has_lyrics:
   self.auto_sync_button.setToolTip('Lyrics detected. Start WhisperX synchronization when you are ready.')
   self.favorite_sites_button.setToolTip('Lyrics are already present. Open this only if you need to find or replace them.')
  else:
   self.auto_sync_button.setToolTip('Paste your authoritative lyrics first. This button becomes active when text is entered.')
   self.favorite_sites_button.setToolTip('Find the song lyrics to paste into the box below.')
 def on_lyrics_changed(self):
  text=self.lyrics.toPlainText()
  self.update_lyrics_action_buttons()
  self.lyric_preview.setText(text[:2500] or 'Your lyric lines will appear here')
  if not self.updating and hasattr(self,'rendered_frame'):
   self.rendered_frame.clear()
   self.rendered_frame.setText('Render exact frame to preview the current lyrics')
  if not self.updating:
   self.project['authoritative_lyrics']=text
   if text.strip():workflow_milestone(self.project,'Lyrics entered')
  if hasattr(self,'appearance_frame'):self.update_appearance_preview()
 def finish_timeline_drag(self):
  self.drag_saved=False
  self.update_selected_word()
 def mark_manual(self,i):
  workflow_milestone(self.project,'First timing/lyric edit')
  self.project.setdefault('reviewed_lines',{}).pop(str(i),None)
  self.project.setdefault('manual_overrides',{})[str(i)]=True
  self.project.setdefault('alignment_status',{})[str(i)]='manual'
  self.refresh_review_line_label(i)
  self.lines.viewport().update()
  self.timeline.update();self.overview.update()
  self.update_review_ui()
 def select_line(self,i):
  if i<0 or i>=len(self.project.get('events',[])):return
  if i!=self.row:self.timeline.multi_selected.clear()
  self.row=i;a,b,t=self.project['events'][i];self.preview.setText(str(t))
  self.update_review_ui()
  self.update_appearance_preview()
  self.timeline.multi_selected.clear()
  self.timeline.set_words(self.get_words(i))
  self.refresh_all_timeline_words()
  self.fit_line()
  self.update_selected_word();self.update_sync_inline_preview(self.player.position());self.overview.update()
 def get_words(self,i):
  raw=self.project.get('word_timings',{}).get(str(i),[])
  return [[float(a),float(b),str(t)] for a,b,t in raw]
 def refresh_all_timeline_words(self):
  """Keep full-song context visible while the active line stays editable."""
  self.timeline.set_all_words(flatten_song_words(self.project.get('word_timings',{})),self.row)
 def activate_timeline_word(self,line_index,word_index):
  """Make a clicked waveform word the editable word without changing the view."""
  events=self.project.get('events',[])
  if not (0<=line_index<len(events)):return
  words=self.get_words(line_index)
  if not (0<=word_index<len(words)):return
  if line_index!=self.row:self.timeline.multi_selected.clear()
  self.row=line_index
  previous=self.lines.blockSignals(True)
  self.lines.setCurrentRow(line_index)
  self.lines.blockSignals(previous)
  item=self.lines.item(line_index)
  if item:self.lines.scrollToItem(item,QAbstractItemView.PositionAtCenter)
  self.preview.setText(str(events[line_index][2]))
  self.timeline.set_words(words)
  self.timeline.set_active_line(line_index)
  self.timeline.selected=word_index
  self.update_appearance_preview()
  self.update_selected_word()
  self.update_sync_inline_preview(self.player.position())
  self.overview.update()
 def select_lyric_row(self,line_index):
  self._word_audition=None
  if not (0<=line_index<len(self.project.get('events',[]))):return
  if self.lines.currentRow()!=line_index:self.lines.setCurrentRow(line_index)
  else:self.fit_line()
  a=self.project['events'][line_index][0]
  self.loop_end=None
  self.seek_monitor_position(int(max(0,float(a))*1000))
 def jump_to_lyric_word(self,line_index,word_index):
  self._word_audition=None
  self.activate_timeline_word(line_index,word_index)
  words=self.get_words(line_index)
  if 0<=word_index<len(words):
   start,end,_=words[word_index]
   pad=max(.22,(end-start)*.65)
   self.timeline.show_range(max(0,start-pad),end+pad)
   self.loop_end=None
   self.seek_monitor_position(int(max(0,start)*1000))
 def play_timeline_word(self,line_index,word_index):
  """Play exactly one double-clicked waveform word, then pause at its end."""
  if line_index!=self.row or word_index!=self.timeline.selected:self.activate_timeline_word(line_index,word_index)
  words=self.get_words(line_index)
  if not (0<=word_index<len(words)) or not self.audio.text():return
  start,end,_word=words[word_index]
  self._word_audition=(line_index,word_index)
  self.seek_monitor_position(int(max(0.,float(start))*1000));self.loop_end=int(float(end)*1000);self.player.play()
 def play_from_timeline(self,at):
  """Start normal playback where empty waveform space was double-clicked."""
  if not self.audio.text():return
  self._word_audition=None
  self.loop_end=None;self.seek_monitor_position(int(max(0.,float(at))*1000));self.player.play()
 def refresh_selected_word_highlight(self):
  """Keep the selected word visibly highlighted in both lyric list and waveform."""
  if not hasattr(self,'lines'):return
  words=self.get_words(self.row) if 0<=self.row<len(self.project.get('events',[])) else []
  i=self.timeline.selected
  self.lines.set_active_word(self.row,i if 0<=i<len(words) else -1)
  if 0<=self.row<self.lines.count() and 0<=i<len(words):
   self.lines.item(self.row).setToolTip('Selected word: '+str(words[i][2]))
  if hasattr(self,'timeline'):self.timeline.update()

 def snapshot(self):self.undo.append(copy.deepcopy(self.project));self.undo=self.undo[-80:];self.redo.clear()
 def generate_words(self):
  if not self.project['events']:return
  self.snapshot();a,b,t=self.project['events'][self.row];tokens=t.split();step=(b-a)/max(1,len(tokens))
  self.project.setdefault('word_timings',{})[str(self.row)]=[[round(a+j*step,3),round(a+(j+1)*step,3),token] for j,token in enumerate(tokens)];self.project.setdefault('alignment_status',{})[str(self.row)]='estimated';self.select_line(self.row)
 def generate_all_words(self):
  events=self.project.get('events',[])
  if not events:return
  existing=self.project.get('word_timings',{})
  missing=[i for i,event in enumerate(events) if not existing.get(str(i)) and str(event[2]).strip()]
  if not missing:
   self.status.setText('All lyric lines already have word blocks. Existing edits preserved.');return
  self.snapshot()
  for i in missing:
   a,b,t=events[i];tokens=str(t).split();step=max(.02,(float(b)-float(a))/max(1,len(tokens)))
   self.project.setdefault('word_timings',{})[str(i)]=[[round(float(a)+j*step,3),round(float(a)+(j+1)*step,3),token] for j,token in enumerate(tokens)]
   self.project.setdefault('alignment_status',{})[str(i)]='estimated'
  self.select_line(self.row)
  self.status.setText(f'Prepared {len(missing)} lyric lines; existing word edits preserved. Timings are placeholders, not AI alignment.')
 def timeline_shared_boundary_change(self,i,t):
  """Resize consecutive words atomically, preserving their outer timestamps."""
  words=self.get_words(self.row)
  if not (0<=i<len(words)-1 and self.timeline.drag=='shared'):return
  first,second=words[i],words[i+1]
  if i in self.timeline.locked or i+1 in self.timeline.locked:return
  if not (float(first[0])+.02<=t<=float(second[1])-.02):return
  if not self.drag_saved:self.snapshot();self.drag_saved=True
  first[1]=t;second[0]=t
  self.commit_timing_edit(words)
  self.timeline.set_words(words)
  self.timeline.selected=i
  self.refresh_all_timeline_words()
  self.update_selected_word()
 def timeline_change(self,i,a,b):
  words=self.get_words(self.row)
  if i>=len(words):return
  if not self.timeline.drag:return
  if not hasattr(self,'drag_saved') or not self.drag_saved:self.snapshot();self.drag_saved=True
  a,b=self.timeline.constrain_word(i,a,b,self.timeline.drag or 'both')
  words[i][0]=a;words[i][1]=b;self.commit_timing_edit(words);self.timeline.set_words(words);self.timeline.selected=i;self.refresh_all_timeline_words();self.update_selected_word()
 def update_selected_word(self):
  words=self.get_words(self.row) if self.project.get('events') else [];i=self.timeline.selected
  self.updating=True
  if i<len(words):self.word_label.setText(f'{words[i][2]}  ({max(0.0,words[i][1]-words[i][0]):.3f}s)');self.start.setValue(words[i][0]);self.end.setValue(words[i][1])
  else:self.word_label.setText('—')
  self.updating=False
  if hasattr(self,'sync_time_caption') and 0<=self.row<len(self.project.get('events',[])):
   words=self.get_words(self.row)
   i=self.timeline.selected
   if 0<=i<len(words):
    start,end,_=words[i];self.sync_time_caption.setText(f'START {float(start):.3f}s     END {float(end):.3f}s     DURATION {max(0,float(end)-float(start)):.3f}s')
  self.refresh_selected_word_highlight()

 def spin_change(self):
  if self.updating:return
  words=self.get_words(self.row);i=self.timeline.selected
  if i>=len(words) or self.end.value()<=self.start.value():return
  a,b=self.timeline.constrain_word(i,self.start.value(),self.end.value())
  self.snapshot();words[i][:2]=[a,b];self.commit_timing_edit(words);self.timeline.set_words(words);self.refresh_all_timeline_words();self.update_selected_word()
 def create_lines(self):
  tokens=[x.strip() for x in self.lyrics.toPlainText().splitlines() if x.strip()]
  if not tokens:return
  if self.project.get('events'):
   answer=QMessageBox.question(self,'Replace existing lyric lines?','Creating new lines will replace current line timings and word edits. Your pasted lyrics will be kept. Continue?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
   if answer!=QMessageBox.Yes:return
  self.snapshot();self.project['authoritative_lyrics']=self.lyrics.toPlainText();self.project['events']=[[i*4.0,i*4.0+3.5,line] for i,line in enumerate(tokens)];self.project['word_timings']={};self.project['word_scores']={};self.project['manual_overrides']={};self.project['reviewed_lines']={};self.project['alignment_status']={str(i):'placeholder' for i in range(len(tokens))};self.refresh();self.status.setText('Placeholder timings created. Exact pasted lyric text preserved; timing requires editing.')
 def sync_waveform_zoom_slider(self,span):
  # Logarithmic zoom scale: 0 = widest view, 1000 = closest view.
  span=max(.35,min(120.,float(span)))
  fraction=math.log(120./span)/math.log(120./.35)
  slider=getattr(self,'waveform_zoom_slider',None)
  if slider is None:return
  slider.blockSignals(True)
  try:slider.setValue(round(1000*fraction))
  finally:slider.blockSignals(False)
 def set_waveform_zoom_from_slider(self,value):
  desired=120.*(.35/120.)**(float(value)/1000.)
  current=max(.001,self.timeline.view_end-self.timeline.view_start)
  self.timeline.zoom(desired/current)
 def fit_song(self):
  duration=max(.35,self.timeline.song_duration or self.player.duration()/1000 or 1)
  self.timeline.show_range(0,duration);self.overview.update()
 def jump_to_song_time(self,t):
  self.seek_monitor_position(int(t*1000))
  events=self.project.get('events',[])
  if events:
   i=min(range(len(events)),key=lambda i:0 if events[i][0]<=t<=events[i][1] else min(abs(t-events[i][0]),abs(t-events[i][1])))
   self.lines.setCurrentRow(i)
  span=min(max(.35,self.timeline.view_end-self.timeline.view_start),max(.35,self.timeline.song_duration))
  a=max(0,min(max(0,self.timeline.song_duration-span),t-span/2))
  self.timeline.show_range(a,a+span)
 def song_and_line(self):
  self.line_mode.setCurrentIndex(1);self.fit_song()
 def change_line_view_mode(self,index):
  self.line_view_mode='song' if index==1 else 'line'
  if self.project.get('events'):
   if index:self.fit_song()
   else:self.fit_line()
 def stop_reset(self):
  self.player.stop();self.loop_end=None;self.seek_monitor_position(0);self.fit_song()
 def toggle_focus_mode(self):
  if getattr(self,'focus_mode',False):return self.exit_focus_mode()
  if self.pages.currentIndex()!=3:self.navigate(3)
  self.focus_mode=True
  self.focus_restore={'fullscreen':self.isFullScreen(),'geometry':self.saveGeometry()}
  self._focus_hidden=[]
  if self.sync_scroller.isVisible():
   self._focus_hidden.append(self.sync_scroller)
   self.sync_scroller.hide()
  outer=self.centralWidget().layout()
  for i in range(outer.count()):
   widget=outer.itemAt(i).widget()
   if widget and widget is not self.pages and widget.isVisible():
    self._focus_hidden.append(widget);widget.hide()
  self.showFullScreen()
  self.status.setText('Full-screen Word Sync active. Press F11 or Escape to restore the window.')
 def exit_focus_mode(self):
  if not getattr(self,'focus_mode',False):return
  self.focus_mode=False
  for widget in getattr(self,'_focus_hidden',[]):widget.show()
  if self.focus_restore.get('fullscreen'):self.showFullScreen()
  else:
   self.showNormal();self.restoreGeometry(self.focus_restore['geometry'])
  self.status.setText('Exited full-screen Word Sync.')

 def show_live_preview(self):
  if self.preview_window is None:
   self.preview_window=QWidget(self,Qt.Tool)
   self.preview_window.setWindowTitle('Live Karaoke Preview — Hide to return')
   self.preview_window.resize(500,280)
   layout=QVBoxLayout(self.preview_window)
   self.live_preview_label=QLabel('Live lyrics will appear here')
   self.live_preview_label.setAlignment(Qt.AlignCenter);self.live_preview_label.setWordWrap(True)
   self.live_preview_label.setStyleSheet('background:#101728;color:#c7b0ff;font-size:27px;font-weight:bold;padding:18px')
   layout.addWidget(self.live_preview_label,1)
   layout.addWidget(btn('Hide Preview',self.preview_window.hide))
  self.preview_window.show();self.preview_window.raise_();self.update_live_preview(self.player.position())
 def update_live_preview(self,ms):
  from html import escape
  t=ms/1000
  events=self.project.get('events',[])
  if self.project.get('lyric_display_mode')=='classic_flow' and events:
   ordered=sorted(enumerate(events),key=lambda item:(float(item[1][0]),item[0]))
   page_size=max(2,min(3,int(self.project.get('classic_flow_lines',3))))
   lead=max(0.,min(5.,float(self.project.get('lyric_lead_seconds',2))))
   fade_ms=max(0,min(2000,int(self.project.get('classic_flow_fade_out',400))))
   final_fade_ms=max(0,min(5000,int(self.project.get('lyric_final_fade_out',2000))))
   hold=max(0.,min(1.,float(self.project.get('lyric_exit_delay',150))/1000.))
   previous_end=0.;active_page=None;opacity=1.
   for page_pos in range(0,len(ordered),page_size):
    page=ordered[page_pos:page_pos+page_size]
    page_start=max(0.,float(page[0][1][0])-lead,previous_end)
    ends=[]
    for idx,event in page:
     words=self.get_words(idx)
     ends.append(max((float(word[1]) for word in words),default=float(event[1])))
    last_word_end=max(ends);fade_ms_here=final_fade_ms if page_pos+page_size>=len(ordered) else fade_ms;page_end=max(page_start+.03,last_word_end)+hold+fade_ms_here/1000.
    if page_start<=t<=page_end:
     active_page=page
     fade_start=page_end-fade_ms_here/1000. if fade_ms_here else page_end
     opacity=1. if t<=fade_start or fade_ms_here<=0 else max(0.,min(1.,(page_end-t)/(fade_ms_here/1000.)))
     break
    previous_end=page_end
   if active_page is None:self.live_preview_label.setText('♪');return
   def faded(color):
    raw=color.lstrip('#');rgb=[int(raw[i:i+2],16) for i in (0,2,4)]
    return 'rgb('+','.join(str(round(value*opacity)) for value in rgb)+')'
   unsung,sung=self.lyric_colors();rows=[]
   for idx,event in active_page:
    words=self.get_words(idx)
    if words:rows.append(' '.join(progressive_word_html(word,t,a,b,faded(sung),faded(unsung)) for a,b,word in words))
    else:rows.append('<span style="color:'+faded(unsung)+'">'+escape(str(event[2]))+'</span>')
   self.live_preview_label.setText('<div style="text-align:center;">'+'<br><br>'.join(rows)+'</div>');return
  line=next((i for i,(a,b,_) in enumerate(events) if float(a)<=t<=float(b)),None)
  if line is None:self.live_preview_label.setText('♪');return
  words=self.get_words(line)
  if not words:self.live_preview_label.setText(str(events[line][2]));return
  parts=[]
  for a,b,word in words:
   parts.append(progressive_word_html(word,t,a,b,'#ffd176','#8492b3'))
  self.live_preview_label.setText(' '.join(parts))
 def shift_selected_words(self,delta):
  """Shift only selected words; preserve durations, permit overlaps, single undo per drag."""
  words=self.get_words(self.row)
  selected=sorted(i for i in self.timeline.multi_selected if 0<=i<len(words))
  if not selected and 0<=self.timeline.selected<len(words):selected=[self.timeline.selected]
  if not selected:return
  delta=round(float(delta),3)
  if not delta:return
  if any(float(words[i][0])+delta < 0 for i in selected):
   if self.timeline.drag!='group':QMessageBox.information(self,'Word shift unavailable','Cannot move a word before 00:00.')
   return
  if self.timeline.drag!='group' or not getattr(self,'drag_saved',False):
   self.snapshot()
   if self.timeline.drag=='group':self.drag_saved=True
  for i in selected:
   words[i][0]=round(float(words[i][0])+delta,3)
   words[i][1]=round(float(words[i][1])+delta,3)
  self.commit_timing_edit(words)
  self.timeline.set_words(words)
  self.refresh_all_timeline_words()
  self.update_selected_word()
  self.status.setText(f'Moved {len(selected)} selected word(s) {delta:+.3f}s. Other words unchanged. Ctrl+Z to undo.')

 def nudge_selected_line(self,delta):
  """Shift one selected line with its word timing while preserving neighbors."""
  events=self.project.get('events',[])
  i=self.lines.currentRow() if hasattr(self,'lines') else self.row
  if not (0<=i<len(events)):
   self.status.setText('Select a lyric line before nudging.');return
  try:
   start=float(events[i][0]);end=float(events[i][1])
   words=self.get_words(i)
   bounds=[start+delta,end+delta]+[float(v)+delta for word in words for v in word[:2]]
   if any(not math.isfinite(x) for x in bounds) or min(bounds)<-0.000001:
    QMessageBox.information(self,'Line nudge unavailable','This adjustment would move lyric timing before 00:00.');return
   if i and start+delta<float(events[i-1][1])-.000001:
    QMessageBox.information(self,'Line nudge unavailable','This adjustment would overlap the previous lyric line.');return
   if i+1<len(events) and end+delta>float(events[i+1][0])+.000001:
    QMessageBox.information(self,'Line nudge unavailable','This adjustment would overlap the next lyric line.');return
  except (ValueError,TypeError,IndexError) as exc:
   QMessageBox.warning(self,'Invalid lyric timing',str(exc));return
  self.snapshot()
  events[i][0]=round(start+delta,3);events[i][1]=round(end+delta,3)
  if str(i) in self.project.get('word_timings',{}):
   self.project['word_timings'][str(i)]=[[round(a+delta,3),round(b+delta,3),text] for a,b,text in words]
  self.mark_manual(i)
  self.row=i
  self.refresh()
  self.status.setText(f'Line {i+1} shifted {delta:+.3f} seconds, including word timings. Ctrl+Z to undo.')
 def shift_all_words(self,delta):
  events=self.project.get('events',[])
  if not events:return
  earliest=min([float(e[0]) for e in events]+[float(w[0]) for words in self.project.get('word_timings',{}).values() for w in words] or [0])
  if delta<0 and earliest+delta<0:
   QMessageBox.information(self,'Shift unavailable','This shift would move a lyric before 00:00.');return
  self.snapshot()
  for event in events:event[0]=round(float(event[0])+delta,3);event[1]=round(float(event[1])+delta,3)
  for words in self.project.get('word_timings',{}).values():
   for word in words:word[0]=round(float(word[0])+delta,3);word[1]=round(float(word[1])+delta,3)
  self.refresh();self.status.setText(f'Shifted all lyric timings {delta:+.3f} seconds. Undo available.')
 def reset_selected_line_to_ai(self):
  # Reuse the existing per-line restore action, preserving all other manual edits.
  self.reset_line()
 def stop_song(self):
  """Stop all playback and return to the beginning without changing word selection."""
  self._word_audition=None;self.loop_end=None;self._scrub_was_playing=False;self._scrub_active=False
  self._scrub_preview_timer.stop()
  if self.pcm_scrub:self.pcm_scrub.stop()
  self.player.stop()
  for stem_player in self.stem_players.values():stem_player.stop()
  self.seek_monitor_position(0)
 def play_selected_word(self):
  """Audition the highlighted word only, keeping its selection for editing."""
  if not (0<=self.row<len(self.project.get('events',[]))):return
  words=self.get_words(self.row)
  index=self.timeline.selected
  if not (0<=index<len(words)):
   self.status.setText('Select a word in the lyric list or waveform first.')
   return
  self.play_timeline_word(self.row,index)
 def play_entire_song(self):
  """Play from song start through its end, regardless of word/line audition."""
  if not self.audio.text():self.status.setText('Choose an audio file first.');return
  self._word_audition=None;self.loop_end=None
  self.fit_song()
  self.seek_monitor_position(0)
  self.player.play()
 def _pause_scrub_preview(self):
  """End a short audition clip; do not let normal playback run away."""
  if not self._scrub_active:return
  self.player.pause()
  for stem_player in self.stem_players.values():stem_player.pause()
 def invalidate_pcm_scrub(self):
  self._pcm_generation+=1
  self._pcm_source_key=None
  if self.pcm_scrub is not None:
   self.pcm_scrub.close();self.pcm_scrub=None

 def start_pcm_loader(self):
  if self.pcm_scrub is not None or (self.pcm_loader is not None and self.pcm_loader.isRunning()):return
  vocals=self.vocal_waveform_path()
  instrumental=self.instrumental.text().strip() if hasattr(self,'instrumental') else ''
  if not vocals or not Path(vocals).is_file():return
  key=(vocals,instrumental);generation=self._pcm_generation
  self.pcm_loader=PcmScrubLoader(vocals,instrumental)
  self.pcm_loader.ready.connect(lambda data,error,key=key,generation=generation:self.pcm_scrub_ready(data,error,key,generation))
  self.pcm_loader.finished.connect(self._pcm_loader_finished)
  self.pcm_loader.start()
 def _pcm_loader_finished(self):
  current=(self.vocal_waveform_path(),self.instrumental.text().strip())
  if self._pcm_source_key!=current and current[0]:
   QTimer.singleShot(0,self.start_pcm_loader)

 def pcm_scrub_ready(self,data,error,key=None,generation=None):
  current=(self.vocal_waveform_path(),self.instrumental.text().strip())
  if generation!=self._pcm_generation or key!=current:return
  self._pcm_source_key=key
  if error:
   self.status.setText('Live PCM scrubbing unavailable: '+error)
   return
  try:
   self.pcm_scrub=PcmScrubEngine(*data)
   self.status.setText('Live bidirectional PCM scrubbing ready.')
  except Exception as exc:
   self.status.setText('PCM scrub setup failed: '+str(exc))
 def pcm_scrub_enabled(self):
  return self.pcm_scrub is not None
 def begin_playhead_scrub(self,seconds):
  """Use bounded forward audio snippets when moving the playhead by hand."""
  if not self.audio.text():return
  self._word_audition=None;self.loop_end=None
  self._scrub_active=True
  self._scrub_was_playing=self.player.playbackState()==QMediaPlayer.PlayingState
  self._scrub_preview_timer.stop()
  self.player.pause()
  for stem_player in self.stem_players.values():stem_player.pause()
  self._last_scrub_seek=0.0
  self._pcm_scrub_last_motion=(float(seconds),time.monotonic())
  if self.pcm_scrub_enabled():
   try:
    self.pcm_scrub.set_position(seconds,0.,self.hear_vocals.isChecked(),self.hear_instrumental.isChecked())
    self.pcm_scrub.start()
   except Exception as exc:
    self.status.setText('PCM output failed: '+str(exc))
    self.pcm_scrub.stop() if self.pcm_scrub else None
  else:
   self.status.setText('PCM scrubbing is loading or unavailable; Qt snippet preview is limited.')
   self.move_playhead_scrub(seconds,force=True)
 def move_playhead_scrub(self,seconds,force=False):
  if not self.audio.text() or not self._scrub_active:return
  now=time.monotonic()
  if self.pcm_scrub_enabled():
   previous=self._pcm_scrub_last_motion
   dt=max(0.001,now-previous[1]) if previous else 0.001
   velocity=(float(seconds)-previous[0])/dt if previous else 0.0
   # Always-on bidirectional scrub: right = forward, left = reverse.
   # Maintain original recording pitch in either direction.
   direction=-1.0 if velocity < -0.005 else (1.0 if velocity > 0.005 else 0.0)
   self._pcm_scrub_last_motion=(float(seconds),now)
   self.pcm_scrub.set_position(seconds,direction,self.hear_vocals.isChecked(),self.hear_instrumental.isChecked())
   return
  # Qt Multimedia cannot do sample-accurate bidirectional tape scrubbing.
  # Audition a short forward snippet at the CURRENT pointer position instead
  # of starting unbounded playback at the original playhead position.
  if force or now-getattr(self,'_last_scrub_seek',0.0)>=.17:
   self._scrub_preview_timer.stop()
   self.player.pause()
   for stem_player in self.stem_players.values():stem_player.pause()
   self.seek_monitor_position(int(max(0.,seconds)*1000))
   self.player.play()
   self._scrub_preview_timer.start(120)
   self._last_scrub_seek=now
 def end_playhead_scrub(self,seconds):
  if not self._scrub_active:return
  self._scrub_preview_timer.stop()
  if self.pcm_scrub_enabled():self.pcm_scrub.stop()
  self._scrub_active=False
  self.player.pause()
  for stem_player in self.stem_players.values():stem_player.pause()
  # Preserve exact released position rather than where the last preview finished.
  self.seek_monitor_position(int(max(0.,seconds)*1000))
  self.timeline.playhead=max(0.,seconds);self.timeline.update()
  if getattr(self,'_scrub_was_playing',False):self.player.play()
  self._scrub_was_playing=False
 def play_pause(self):
  self._word_audition=None
  self.loop_end=None
  if not self.audio.text():self.status.setText('Choose an audio file first.');return
  if self.player.playbackState()==QMediaPlayer.PlayingState:self.player.pause()
  else:self.player.play()
 def update_sync_inline_preview(self,ms):
  """Keep the in-page Word Sync preview synchronized without video encoding."""
  if not self.project.get('events') or not hasattr(self,'preview'):return
  from html import escape
  t=ms/1000.0
  if not (0<=self.row<len(self.project['events'])):return
  line=self.project['events'][self.row]
  words=self.get_words(self.row)
  unsung,sung=self.lyric_colors()
  if not words:
   self.preview.setText(escape(str(line[2])));return
  parts=[]
  for a,b,word in words:
   parts.append(progressive_word_html(word,t,a,b,sung,unsung))
  self.preview.setText('<div style="text-align:center;">'+' '.join(parts)+'</div>')
 def follow_playback_line(self,t):
  """Load the timed line under the playhead without changing waveform zoom."""
  events=self.project.get('events',[])
  matches=[i for i,(a,b,_) in enumerate(events) if float(a)<=t<=float(b)]
  if not matches:return
  row=max(matches,key=lambda i:float(events[i][0]))
  words=self.get_words(row)
  if row!=self.row:
   self.row=row
   blocked=self.lines.blockSignals(True)
   self.lines.setCurrentRow(row)
   self.lines.blockSignals(blocked)
   item=self.lines.item(row)
   if item:self.lines.scrollToItem(item,QAbstractItemView.PositionAtCenter)
   self.timeline.set_words(words)
   self.timeline.set_active_line(row)
   self.update_appearance_preview();self.overview.update()
  if words:
   active=[i for i,(a,b,_) in enumerate(words) if float(a)<=t<=float(b)]
   if active:index=active[-1]
   else:
    started=[i for i,(a,b,_) in enumerate(words) if float(a)<=t]
    index=started[-1] if started else 0
   if index!=self.timeline.selected:
    self.timeline.selected=index;self.update_selected_word();self.timeline.update()
 def play_export_selection(self):
  """Audition only the export range using the existing song transport."""
  if not self.audio.text().strip():
   self.status.setText('Load a song before playing the export selection.');return
  a,b=self.export_range.start,self.export_range.end
  if b-a<.02:
   self.status.setText('Drag the export handles apart to select a playable section.');return
  self._word_audition=None;self.loop_end=None
  self._export_selection_playing=True
  self.seek_monitor_position(round(a*1000))
  self.player.play()
 def pause_export_selection(self):
  """Pause playback without discarding the export selection."""
  self._export_selection_playing=False
  self.player.pause()
 def set_export_selection_loop(self,enabled):
  self._export_selection_loop=bool(enabled)
 def export_selection_range_changed(self,a,b):
  """Stop an audition if the selection is edited outside the playhead."""
  if self._export_selection_playing and not a-0.02<=self.player.position()/1000<=b+0.02:
   self.pause_export_selection()
 def _check_export_selection_end(self,ms):
  if not self._export_selection_playing:return False
  start_ms=round(self.export_range.start*1000)
  end_ms=round(self.export_range.end*1000)
  if ms < end_ms:return False
  if self._export_selection_loop and end_ms-start_ms>=20:
   self.seek_monitor_position(start_ms)
   # Keep transport playing, including if Qt paused at the end of the media.
   self.player.play()
  else:
   self._export_selection_playing=False
   self.player.pause()
   self.seek_monitor_position(end_ms)
  return True
 def on_position(self,ms):
  if self._check_export_selection_end(ms):return
  # A double-click word audition must leave that word selected for edge editing.
  # Pause before running follow-playback, which would otherwise select the next word.
  finished_word_audition=self._word_audition is not None and self.loop_end is not None and ms>=self.loop_end
  if self.loop_end is not None and ms>=self.loop_end:
   self.player.pause();self.loop_end=None
   self._word_audition=None
  if finished_word_audition:
   # Keep the original word selected even if pause state updates asynchronously.
   pass
  elif self._word_audition is not None:
   line_index,word_index=self._word_audition
   if self.row!=line_index or self.timeline.selected!=word_index:
    self.activate_timeline_word(line_index,word_index)
  elif self.follow.isChecked() and self.player.playbackState()==QMediaPlayer.PlayingState and self.pages.currentIndex()==3 and not self.timeline.drag and not self.timeline.scrubbing:
   self.follow_playback_line(ms/1000.0)
  self.update_sync_inline_preview(ms)
  if not self.seek.isSliderDown():self.seek.setValue(int(ms/max(1,self.player.duration())*1000))
  if not self.timeline.scrubbing:self.timeline.playhead=ms/1000.0
  self.timeline.update()
  if hasattr(self,"overview"):self.overview.update()
  if self.preview_window is not None and self.preview_window.isVisible():self.update_live_preview(ms)
  self.time_readout.setText(self.fmt_time(ms)+' / '+self.fmt_time(self.player.duration()))
  if self.follow.isChecked() and self.player.playbackState()==QMediaPlayer.PlayingState and self.pages.currentIndex()==3 and not self.timeline.drag and not self.timeline.scrubbing:
   if self.timeline.playhead>self.timeline.view_end or self.timeline.playhead<self.timeline.view_start:
    span=self.timeline.view_end-self.timeline.view_start
    a=max(0,self.timeline.playhead-span*.25);self.timeline.show_range(a,a+span)
 def seek_audio(self):self.seek_monitor_position(int(self.seek.value()/1000*self.player.duration()))
 def loop_word(self):
  self._word_audition=None
  words=self.get_words(self.row);i=self.timeline.selected
  if i<len(words) and self.audio.text():self.seek_monitor_position(int(words[i][0]*1000));self.player.play();self.loop_end=int(words[i][1]*1000)
 def do_undo(self):
  if self.undo:
   clock=self.project.get('workflow_timing')
   self.redo.append(copy.deepcopy(self.project));self.project=self.undo.pop()
   if clock is not None:self.project['workflow_timing']=clock
   self.refresh()
   if hasattr(self,'refresh_formatting_window'):self.refresh_formatting_window()
 def do_redo(self):
  if self.redo:
   clock=self.project.get('workflow_timing')
   self.undo.append(copy.deepcopy(self.project));self.project=self.redo.pop()
   if clock is not None:self.project['workflow_timing']=clock
   self.refresh()
   if hasattr(self,'refresh_formatting_window'):self.refresh_formatting_window()
 def open_project(self):
  if not self.confirm_no_active_processing():return
  p,_=QFileDialog.getOpenFileName(self,'Open Karaoke Studio project',str(Path.home()),'Karaoke project (*.json);;All files (*)')
  if not p:return
  try:
   d=json.loads(Path(p).read_text(encoding='utf-8'))
   validate_project_payload(d)
   if 'authoritative_lyrics' not in d:
    d['authoritative_lyrics']='\n'.join(str(e[2]) for e in d.get('events',[]) if len(e)>=3)
   d.setdefault('alignment_status',{});d.setdefault('word_scores',{});d.setdefault('manual_overrides',{});d.setdefault('reviewed_lines',{})
   if not self.confirm_leave_project():return
   self.invalidate_pcm_scrub()
   self.player.stop();self.loaded_wave_path=None;self.step_snapshots.clear();self.step_failures.clear()
   workflow_begin(d,'project opened; earlier elapsed time unavailable')
   self.project=d;self._reset_workspace_clock();self.path=p;self.undo.clear();self.redo.clear();self.refresh();self.saved_signature=json.dumps(self.project,sort_keys=True,ensure_ascii=False,default=str);self.update_project_identity();self.status.setText('Opened '+Path(p).name+' (Save creates a separate copy)')
  except Exception as e:QMessageBox.critical(self,'Open failed',str(e))
 def save_as_project(self):
  previous=self.path
  self.path=None
  result=self.save_project()
  if not result:self.path=previous
  return result
 def save_project(self):
  self._checkpoint_workspace_timer()
  self.sync_fields();self.project['authoritative_lyrics']=self.lyrics.toPlainText();p=self.path
  if not p:
   # Default to Artist - Song Title while retaining .karaoke.json compatibility.
   song=safe_song_filename(self.artist.text(),self.song.text() or (Path(self.audio.text()).stem if self.audio.text() else ''))
   p,_=QFileDialog.getSaveFileName(self,'Save Karaoke project',str(Path.home()/(song+'.karaoke.json')),'Karaoke project (*.json)')
  if not p:return False
  try:
   # Keep all original project keys untouched, updating only fields edited here.
   target=Path(p);target.parent.mkdir(parents=True,exist_ok=True)
   fd,tmp=tempfile.mkstemp(prefix='.karaoke-',suffix='.tmp',dir=target.parent)
   try:
    with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(self.project,f,indent=2,ensure_ascii=False)
    os.replace(tmp,target)
   finally:
    if os.path.exists(tmp):os.unlink(tmp)
   self.path=p;self.saved_signature=json.dumps(self.project,sort_keys=True,ensure_ascii=False,default=str);self.update_project_identity();self.status.setText('Saved '+target.name);return True
  except Exception as e:QMessageBox.critical(self,'Save failed',str(e));return False

 def confirm_no_active_processing(self):
  """Prevent project replacement while background work can still write results."""
  busy=bool((self.job is not None and self.job.isRunning()) or self.activity_started is not None)
  if busy:
   QMessageBox.information(self,"Processing in progress","Please wait for the active task to finish before changing projects or exiting.")
   return False
  return True

 def closeEvent(self,event):
  if self.pcm_loader is not None and self.pcm_loader.isRunning():
   QMessageBox.information(self,'PCM audio loading','Please finish loading the scrub audio before closing.')
   event.ignore();return
  if self.pcm_scrub:
   self.pcm_scrub.close();self.pcm_scrub=None
  busy=bool((self.job is not None and self.job.isRunning()) or self.activity_started is not None)
  if busy and self.activity_task in ('Studio video export','MP4 export'):
   if self._studio_close_after_cancel:
    event.ignore();return
   answer=QMessageBox.question(self,'Export still running',
    'The video export is still running.\n\nCancel the export and close the application?\nYour project can be saved after the task stops.',
    QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)
   if answer==QMessageBox.Yes:
    self._studio_close_after_cancel=True
    self.cancel_studio_export()
    self.activity_detail.setText('Stopping export before closing safely…')
   event.ignore();return
  if not self.confirm_no_active_processing():event.ignore();return
  if self.wave_worker is not None and self.wave_worker.isRunning():
   QMessageBox.information(self,"Waveform loading","Please wait for the waveform to finish loading before closing.")
   event.ignore();return
  if self.confirm_leave_project():event.accept()
  else:event.ignore()

if __name__=='__main__':
 try:
  app=QApplication(sys.argv)
  app.setStyleSheet(STYLE)
  window=Main()
  window.show()
  sys.exit(app.exec())
 except Exception:
  error=traceback.format_exc()
  try:
   report=Path(__file__).resolve().parent/'Karaoke_Maker_Lite_Startup_Error.txt'
   report.write_text(datetime.datetime.now().isoformat(timespec='seconds')+'\n'+error,encoding='utf-8')
   print('Startup error saved to:',report,flush=True)
  except Exception:pass
  print(error,file=sys.stderr,flush=True)
  raise


# ZIP packaging checksum padding:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 00000004
