# DeRo Sync v0.2.1.30
- Replaced single right-side party emoji with actual Qt-painted two-popper effect, staggered 0.7 seconds apart.
- Small confetti pieces fall under gravity and gradually fade; animation ends after ~4.5 seconds.
- Separate quick two-note WAV on successful intermediate batch song exports; final successful batch gets only the approved original celebration chime.
- Celebrations restricted to completed standalone MP4 exports and fully successful batches; no save/separation/alignment celebrations.
- Original visualizer renderer and user project files unchanged.
- Windows GUI playback and rendering still require on-device testing.
