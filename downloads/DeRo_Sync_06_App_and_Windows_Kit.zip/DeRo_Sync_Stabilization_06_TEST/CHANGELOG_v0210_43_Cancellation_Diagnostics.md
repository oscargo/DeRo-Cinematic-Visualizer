# v0.2.1.43 — Studio cancellation diagnostics (maintenance)

- Log OSError failures from terminate/kill calls for Studio FFmpeg export cancellation.
- Log process wait timeout during cleanup.
- No changes to cancellation timing, signals, process control, audio, word timing, or encoding.
- Adds AST regression guards.
- Windows real-export cancellation remains unverified.
