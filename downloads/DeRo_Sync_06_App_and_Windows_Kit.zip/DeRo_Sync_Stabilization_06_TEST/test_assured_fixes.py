"""Focused regression checks; no Qt, AI models, or audio devices required."""
import ast
import copy
import difflib
import importlib.util
import math
from pathlib import Path
import re
import tempfile
import unittest
import wave

ROOT=Path(__file__).parent
SOURCE=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py').read_text(encoding='utf-8')
TREE=ast.parse(SOURCE)
MAIN=next(n for n in TREE.body if isinstance(n,ast.ClassDef) and n.name=='Main')

def extract(nodes, namespace=None):
 ns={'re':re,'time':__import__('time'),'math':math,'difflib':difflib,'copy':copy,'Path':Path}
 ns.update(namespace or {})
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'<application>','exec'),ns)
 return ns

FUNCTIONS=extract([n for n in TREE.body if isinstance(n,ast.FunctionDef)])

def method(name, namespace=None):
 node=next(n for n in MAIN.body if isinstance(n,ast.FunctionDef) and n.name==name)
 return extract([node],{**FUNCTIONS,**(namespace or {})})[name]

class Dummy:
 pass
class Field:
 def __init__(self,value):self.value=value
 def text(self):return self.value
class FakeSettings:
 def __init__(self,values=None):self.values=dict(values or {})
 def value(self,key,default=None):return self.values.get(key,default)
 def setValue(self,key,value):self.values[key]=value

class FakeEngine:
 instances=[]
 def __init__(self,*args):self.closed=False;self.instances.append(self)
 def close(self):self.closed=True

class RegressionTests(unittest.TestCase):
 def run_job_completion(self, label, final=False, error='', cancelled=False):
  import threading
  class Null:
   def __getattr__(self,name):return lambda *args,**kwargs:None
  d=Dummy();d.project={};FUNCTIONS['workflow_begin'](d.project,now=100.)
  d._workflow_final_export=final;d._workflow_job_started=__import__('time').monotonic()-2
  d.activity_started=__import__('time').monotonic()-2;d._studio_close_after_cancel=False
  d._studio_cancel_event=threading.Event();d._studio_process_lock=threading.Lock()
  if cancelled:d._studio_cancel_event.set()
  for name in ('activity_timer','activity_bar','activity_title','activity_detail','export_progress','status','cancel_studio_button'):
   setattr(d,name,Null())
  for name in ('update_workflow_tally','update_sync_status_visibility','update_step_indicators','record_diagnostic_error','_quick_karaoke_after_step'):
   setattr(d,name,lambda *args:None)
  d.step_snapshots={};d.step_failures={};d._batch_running=False;d._quick_karaoke_pending=False;d._step_fingerprint=lambda n:'snapshot'
  with tempfile.TemporaryDirectory() as temp:
   target=Path(temp)/'video.mp4'
   method('job_done',{'QMessageBox':Null(),'json':__import__('json'),'traceback':__import__('traceback')})(d,label,str(target),error,lambda result:None)
   report=target.with_suffix('.timing.json').exists()
  return d.project['workflow_timing'],report
  def test_startup_activity_timer_callback_exists(self):
   # Regression for v0.2.0.68 failure before the main window appeared.
   callback=method('update_activity_clock')
   d=Dummy();d.activity_started=__import__('time').monotonic()-2
   d.activity_last_message='Working';d.activity_detail=Dummy()
   messages=[];d.activity_detail.setText=lambda value:messages.append(value)
   callback(d)
   self.assertIn('Working',messages[-1]);self.assertIn('Elapsed:',messages[-1])
   d.activity_started=None;callback(d)
   self.assertEqual(len(messages),1)
 def test_full_export_freezes_and_writes_report(self):
  clock,report=self.run_job_completion('MP4 export',True)
  self.assertIsNotNone(clock['first_export_at']);self.assertTrue(report)
  self.assertEqual(clock['runs'][0]['status'],'completed')
 def test_preview_does_not_finish_workflow(self):
  clock,report=self.run_job_completion('Studio video export',False)
  self.assertIsNone(clock['first_export_at']);self.assertFalse(report)
 def test_failed_export_does_not_finish_workflow(self):
  clock,report=self.run_job_completion('MP4 export',True,error='test error')
  self.assertIsNone(clock['first_export_at']);self.assertFalse(report)
  self.assertEqual(clock['runs'][0]['status'],'failed')
 def test_cancelled_export_does_not_finish_workflow(self):
  clock,report=self.run_job_completion('Studio video export',True,cancelled=True)
  self.assertIsNone(clock['first_export_at']);self.assertFalse(report)
  self.assertEqual(clock['runs'][0]['status'],'cancelled')
 def test_saved_review_folder_has_priority(self):
  with tempfile.TemporaryDirectory() as temp:
   root=Path(temp);saved=root/'saved';saved.mkdir();project=root/'project';project.mkdir()
   d=Dummy();d.app_settings=FakeSettings({'last_sync_review_folder':str(saved)})
   d.path=str(project/'song.json');d.audio=Field('')
   self.assertEqual(method('sync_review_export_folder')(d),saved)
 def test_missing_review_folder_falls_back_to_project(self):
  with tempfile.TemporaryDirectory() as temp:
   d=Dummy();d.app_settings=FakeSettings({'last_sync_review_folder':str(Path(temp)/'missing')})
   d.path=str(Path(temp)/'song.json');d.audio=Field('')
   self.assertEqual(method('sync_review_export_folder')(d),Path(temp))
 def test_review_folder_restores_from_last_file(self):
  with tempfile.TemporaryDirectory() as temp:
   d=Dummy();d.app_settings=FakeSettings({'last_sync_review_export':str(Path(temp)/'old.html')})
   d.path=None;d.audio=Field('')
   self.assertEqual(method('sync_review_export_folder')(d),Path(temp))
 def test_open_folder_selects_last_existing_review(self):
  from types import SimpleNamespace
  with tempfile.TemporaryDirectory() as temp:
   target=Path(temp)/'review.html';target.write_text('test')
   d=Dummy();d.app_settings=FakeSettings({'last_sync_review_export':str(target)})
   d.sync_review_export_folder=lambda:Path(temp);calls=[]
   method('open_sync_review_folder',{'sys':SimpleNamespace(platform='win32'),'subprocess':SimpleNamespace(Popen=lambda args:calls.append(args))})(d)
   self.assertEqual(calls,[['explorer.exe','/select,',str(target.resolve())]])
 def test_open_folder_without_previous_export(self):
  from types import SimpleNamespace
  with tempfile.TemporaryDirectory() as temp:
   d=Dummy();d.app_settings=FakeSettings();d.sync_review_export_folder=lambda:Path(temp);calls=[]
   method('open_sync_review_folder',{'sys':SimpleNamespace(platform='win32'),'subprocess':SimpleNamespace(Popen=lambda args:calls.append(args))})(d)
   self.assertEqual(calls,[['explorer.exe',str(Path(temp).resolve())]])
 def test_export_folder_persists_and_cancel_preserves_it(self):
  from types import SimpleNamespace
  with tempfile.TemporaryDirectory() as temp:
   chosen=Path(temp)/'new.html';saved=FakeSettings({'last_sync_review_folder':'unchanged'})
   d=Dummy();d.project={'events':[[0,1,'one']]};d.vocal_waveform_path=lambda:'vocals';d.sync_fields=lambda:None
   d.path=None;d.job=None;d.app_settings=saved;d.sync_review_export_folder=lambda:Path(temp);captured={}
   d.begin_job=lambda label,job,done:captured.update(done=done)
   method('export_sync_review',{'QFileDialog':SimpleNamespace(getSaveFileName=lambda *args:('','')),'find_ffmpeg':lambda:'ffmpeg'})(d)
   self.assertEqual(saved.value('last_sync_review_folder'),'unchanged')
   namespace={'QFileDialog':SimpleNamespace(getSaveFileName=lambda *args:(str(chosen),'')),
    'find_ffmpeg':lambda:'ffmpeg','QMessageBox':SimpleNamespace(information=lambda *args:None),
    'QDesktopServices':SimpleNamespace(openUrl=lambda *args:True),'QUrl':SimpleNamespace(fromLocalFile=lambda x:x)}
   method('export_sync_review',namespace)(d)
   self.assertEqual(saved.value('last_sync_review_folder'),str(Path(temp).resolve()))
   self.assertIsNone(saved.value('last_sync_review_export'))
   captured['done']({'path':str(chosen),'lines':1,'words':1,'bytes':100})
   self.assertEqual(saved.value('last_sync_review_export'),str(chosen.resolve()))
 def test_workflow_live_and_first_export_total(self):
  d={};clock=FUNCTIONS['workflow_begin'](d,now=100.)
  self.assertEqual(FUNCTIONS['workflow_elapsed'](d,now=145.),45.)
  clock['first_export_at']=160.
  self.assertEqual(FUNCTIONS['workflow_elapsed'](d,now=999.),60.)
 def test_workflow_reopen_preserves_start(self):
  import json
  d={};FUNCTIONS['workflow_begin'](d,'song selected',now=100.)
  d=json.loads(json.dumps(d));FUNCTIONS['workflow_begin'](d,'opened',now=200.)
  self.assertEqual(FUNCTIONS['workflow_elapsed'](d,now=250.),150.)
  self.assertEqual(d['workflow_timing']['origin'],'song selected')
 def test_milestones_are_first_occurrences(self):
  d={};FUNCTIONS['workflow_begin'](d,now=100.)
  FUNCTIONS['workflow_milestone'](d,'Lyrics entered',now=120.)
  FUNCTIONS['workflow_milestone'](d,'Lyrics entered',now=140.)
  self.assertEqual(d['workflow_timing']['milestones']['Lyrics entered'],20.)
 def test_undo_redo_preserves_timing_history(self):
  d=Dummy();clock={'started_at':100.,'runs':[{'step':'test'}]}
  d.project={'workflow_timing':clock,'value':'new'};d.undo=[{'value':'old'}];d.redo=[];d.refresh=lambda:None
  method('do_undo')(d);self.assertIs(d.project['workflow_timing'],clock)
  method('do_redo')(d);self.assertIs(d.project['workflow_timing'],clock)
 def test_duration_format(self):
  self.assertEqual(FUNCTIONS['workflow_duration'](3661.8),'01:01:01')
  self.assertEqual(FUNCTIONS['workflow_duration'](-3),'00:00:00')
 def test_status_colors_are_distinct(self):
  palette=FUNCTIONS['sync_review_colors']
  colors=[palette({'alignment_status':{'0':status}},0) for status in ('partial','estimated','manual','aligned','failed')]
  self.assertEqual(len(set(c[2] for c in colors)),5)
 def test_manual_override_changes_color(self):
  palette=FUNCTIONS['sync_review_colors'];d={'alignment_status':{'0':'estimated'}}
  before=palette(d,0);d['manual_overrides']={'0':True}
  self.assertNotEqual(before,palette(d,0))
  self.assertEqual(palette(d,0),palette({'alignment_status':{'0':'manual'}},0))
 def test_mark_reviewed_keeps_uncertainty_color(self):
  palette=FUNCTIONS['sync_review_colors'];d={'alignment_status':{'0':'partial'}}
  before=palette(d,0);d['reviewed_lines']={'0':True}
  self.assertEqual(before,palette(d,0))
 def test_palette_survives_save_load(self):
  import json
  d={'alignment_status':{'0':'estimated','1':'manual'}}
  self.assertEqual(FUNCTIONS['sync_review_colors'](d,0),FUNCTIONS['sync_review_colors'](json.loads(json.dumps(d)),0))
 def test_invalid_recovered_order_rejected(self):
  words,scores,*_=FUNCTIONS['recover_line_timings'](['one','missing','three'],[
   {'word':'one','start':1,'end':2,'score':.9},
   {'word':'three','start':1.9,'end':2.5,'score':.9}],1,3,str.casefold)
  self.assertFalse(FUNCTIONS['forced_alignment_quality'](['one','missing','three'],words,scores)[0])
 def test_valid_words_still_accepted(self):
  words=[[1,1.3,'one'],[1.4,1.8,'two']]
  self.assertTrue(FUNCTIONS['forced_alignment_quality'](['one','two'],words,[.9,.8])[0])
 def test_invalid_and_nonfinite_times_rejected(self):
  for words in ([[float('nan'),2,'one']], [[-1,2,'one']], [[2,1,'one']]):
   self.assertFalse(FUNCTIONS['forced_alignment_quality'](['one'],words,[.9])[0])
 def test_actual_short_clip_threshold_expressions(self):
  # Evaluate the application expressions, not copies of its formula.
  alignment=next(n for n in MAIN.body if isinstance(n,ast.FunctionDef) and n.name=='start_alignment')
  assigns={n.targets[0].id:n.value for n in ast.walk(alignment) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
  for count in (1,3,7,100):
   env={'flat':[None]*count,'math':math}
   for name in ('minimum_words','minimum_anchors'):
    threshold=eval(compile(ast.Expression(assigns[name]),'<threshold>','eval'),env)
    self.assertLessEqual(threshold,count)
  check=next(n for n in ast.walk(alignment) if isinstance(n,ast.Compare) and isinstance(n.left,ast.Name) and n.left.id=='trusted_lines' and isinstance(n.ops[0],ast.Lt))
  self.assertEqual(eval(compile(ast.Expression(check.comparators[0]),'<threshold>','eval'),{'lyrics':['one'],'math':math}),1)
 def test_pcm_invalidation_closes_engine(self):
  d=Dummy();d._pcm_generation=0;d._pcm_source_key=('old','');d.pcm_scrub=FakeEngine()
  old=d.pcm_scrub;method('invalidate_pcm_scrub')(d)
  self.assertTrue(old.closed);self.assertIsNone(d.pcm_scrub);self.assertIsNone(d._pcm_source_key);self.assertEqual(d._pcm_generation,1)
 def test_pcm_stale_results_rejected_current_results_accepted(self):
  d=Dummy();d._pcm_generation=2;d.vocal_waveform_path=lambda:'new';d.instrumental=Field('inst');d.pcm_scrub=None;d._pcm_source_key=None
  d.status=Dummy();d.status.setText=lambda msg:None
  ready=method('pcm_scrub_ready',{'PcmScrubEngine':FakeEngine})
  ready(d,([],16000),'',('old','inst'),1);self.assertIsNone(d.pcm_scrub)
  ready(d,([],16000),'',('new','inst'),1);self.assertIsNone(d.pcm_scrub)
  ready(d,([],16000),'',('new','inst'),2);self.assertIsInstance(d.pcm_scrub,FakeEngine)
 def test_structural_edit_invalidates_metadata(self):
  d=Dummy();d.project={'reviewed_lines':{'1':True},'ai_word_timings':{'1':[[1,2,'old']]},'sync_inspector':{'old':True}}
  d.snapshot=lambda:None;d.refresh=lambda:None;d.row=0;d.lines=Dummy();d.lines.setCurrentRow=lambda n:None
  method('commit_events')(d,[[0,1,'new']],[[[0,1,'new']]])
  self.assertEqual(d.project['reviewed_lines'],{});self.assertEqual(d.project['ai_word_timings'],{});self.assertNotIn('sync_inspector',d.project)
 def test_manual_edit_invalidates_review(self):
  d=Dummy();d.project={'reviewed_lines':{'0':True}};d.lines=Dummy();d.lines.count=lambda:0
  d.lines.viewport=lambda:d.lines;d.lines.update=lambda:None
  d.timeline=d.lines;d.overview=d.lines;d.refresh_review_line_label=lambda i:None;d.update_review_ui=lambda:None
  method('mark_manual')(d,0);self.assertEqual(d.project['reviewed_lines'],{})
 def test_review_export_snapshots_and_uses_worker(self):
  d=Dummy();d.project={'events':[[0,1,'one']]};d.vocal_waveform_path=lambda:'vocals';d.sync_fields=lambda:None;d.path=None;d.job=None
  d.app_settings=FakeSettings();d.sync_review_export_folder=lambda:ROOT
  class Dialog:
   @staticmethod
   def getSaveFileName(*args):return ('review.html','')
  captured={}
  def begin(label,job,done):captured.update(job=job)
  d.begin_job=begin
  def build(project,*args,**kwargs):return copy.deepcopy(project)
  method('export_sync_review',{'QFileDialog':Dialog,'find_ffmpeg':lambda:'ffmpeg'})(d)
  d.project['events'][0][2]='changed'
  import dero_sync_review_exporter
  old=dero_sync_review_exporter.build_review_html
  # The method imports the real builder locally; replace it before another call.
  dero_sync_review_exporter.build_review_html=build
  try:
   method('export_sync_review',{'QFileDialog':Dialog,'find_ffmpeg':lambda:'ffmpeg'})(d)
   d.project['events'][0][2]='changed again'
   result=captured['job'](lambda m:None)
   self.assertEqual(result['events'][0][2],'changed')
  finally:dero_sync_review_exporter.build_review_html=old
 def test_export_smoke_and_invalid_line(self):
  import dero_sync_review_exporter as exporter
  import shutil
  if shutil.which("ffmpeg") is None:
   self.skipTest("FFmpeg not found on PATH; review-export integration requires FFmpeg")
  with tempfile.TemporaryDirectory() as temp:
   wav=Path(temp)/'audio.wav';target=Path(temp)/'review.html'
   with wave.open(str(wav),'wb') as w:
    w.setparams((1,2,16000,0,'NONE','not compressed'));w.writeframes(b'\0\0'*16000)
   project={'events':[[0,1,'one']],'word_timings':{'0':[[.1,.5,'one']]}}
   report=exporter.build_review_html(project,wav,target)
   self.assertEqual(report['words'],1);self.assertEqual(report['duration'],1)
   for value in (float('nan'),float('inf'),-1):
    project['events'][0][0]=value
    with self.assertRaises(ValueError):exporter.build_review_html(project,wav,target)

class FormattingWindowRegressionTests(unittest.TestCase):
 def test_font_control_is_checked_before_generic_combo(self):
  main=next(n for n in TREE.body if isinstance(n,ast.ClassDef) and n.name=='Main')
  fn=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='open_lyric_formatting')
  linked=next(n for n in ast.walk(fn) if isinstance(n,ast.FunctionDef) and n.name=='linked')
  checks=[n for n in linked.body if isinstance(n,ast.If)]
  def branch_type(n):
   return next((x.id for x in ast.walk(n.test) if isinstance(x,ast.Name) and x.id in ('QFontComboBox','QComboBox')),None)
  # The QFontComboBox check must occur in an earlier branch than QComboBox.
  branches=[]
  for n in checks:
   while n:
    branches.append(branch_type(n))
    n=n.orelse[0] if len(n.orelse)==1 and isinstance(n.orelse[0],ast.If) else None
  self.assertLess(branches.index('QFontComboBox'),branches.index('QComboBox'))
 def test_format_refresh_has_safe_font_combo_check(self):
  main=next(n for n in TREE.body if isinstance(n,ast.ClassDef) and n.name=='Main')
  fn=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='refresh_formatting_window')
  source=ast.unparse(fn)
  self.assertIn('isinstance(widget, QFontComboBox)',source)
if __name__=='__main__':unittest.main(verbosity=2)

# ZIP packaging checksum padding: 00000014
