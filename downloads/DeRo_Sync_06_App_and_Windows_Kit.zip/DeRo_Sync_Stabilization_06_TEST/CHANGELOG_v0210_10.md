# DeRo Sync v0.2.1.10 — Batch Rename

- Added **Rename Song** to the Batch song queue on both Setup and Lyrics screens.
- Double-click a song to rename its display label.
- New additions get conservative automatic cleanup: leading track numbers and common bracketed official-video/audio labels.
- User-edited names are stored with the batch workspace and restored between sessions.
- The original audio file path, name, and bytes are never modified by renaming.
- Automated batch export remains disabled as in v0.2.1.09.
