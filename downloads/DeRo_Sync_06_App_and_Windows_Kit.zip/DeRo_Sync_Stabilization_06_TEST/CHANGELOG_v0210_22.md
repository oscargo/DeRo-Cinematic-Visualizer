# v0.2.1.22 — Batch Continue After Sync

- Batch alignment with partial or estimated (but no failed) lines now proceeds automatically to original DeRo Visualizer MP4 export.
- Logs a prominent sync review warning; persists batch_sync_review_required and alignment counts in song queue and editable project JSON.
- Missing timings or failed/unknown statuses still stop the affected song.
- Corrected APP_BUILD/APP_VERSION, launcher, and VERSION consistency.
- Existing single-song alignment and export behavior unchanged.

Not tested on Windows with real audio. Exports with uncertain timing are NOT verified and need listening review.
