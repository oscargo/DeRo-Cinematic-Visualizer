# DeRo Sync v0.2.1.33
- Batch Lyrics: clipboard paste saves lyrics for the selected song, then selects the next song without lyrics and focuses its editor.
- Does not auto-advance on typing, project restoration, or edits to existing lyrics.
- If no later unfilled song exists, selection stays on current song.
- Preserves original three-column Setup layout from v0.2.1.32.
- Windows Qt GUI behavior requires testing on user machine.
