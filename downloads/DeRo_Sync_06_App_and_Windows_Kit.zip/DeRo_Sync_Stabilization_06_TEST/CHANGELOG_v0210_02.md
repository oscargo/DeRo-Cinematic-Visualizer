# DeRo Sync v0.2.1.02 — Visualizer Export Fixes

- Visualizer ASS lyric bridge enforces a maximum of two flow rows and uses saved Sync lyric appearance settings. Does not modify saved project timings.
- Visualizer full export uses the selection set in the Export tab.
- Preview 8 seconds exports up to eight seconds beginning at the selected range start.
- Original visualizer renderer and particle code remain unchanged.
- Updated release identifier, launcher, and export diagnostics identifier.

Testing: Python syntax and source-level regression checks; Windows UI, FFmpeg end-to-end export and audio sync must be tested on Windows before replacing the stable version.
