# v0.2.1.43 studio export pipeline verification

Added `test_studio_export_pipeline_43.py` (2 tests):

1. Extracts and calls the **actual** `Main.studio_export_command` method (without importing the Qt UI) and verifies the four combinations of independent visualizer/particles toggles, plus the ASS subtitle filter.
2. Generates a short real audio file and ASS subtitle file, invokes the application's **actual** FFmpeg command generator, runs that command with libx264 and libass, and verifies that the resulting MP4 contains both audio and video streams.

Regression result: 59 tests discovered, 59 passed. No application source code changed in this stage.

Limitations: 320x180 / 0.4 seconds smoke test, not full 1080p60 karaoke export; does not exercise Qt UI, word highlighting, timing accuracy, title cards, NVENC, cancellation, or Windows-specific operation. FFmpeg-based test skips when FFmpeg or FFprobe is unavailable.
