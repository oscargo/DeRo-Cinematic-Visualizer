# DeRo Sync v0.2.0.78

- Lyrics page now highlights the next appropriate action.
- Before lyrics are entered, Favorite Lyrics Sites is prominent and Auto-sync is subdued and disabled.
- Once non-whitespace lyric text is present, Auto-sync becomes prominent and enabled while Favorite Lyrics Sites becomes secondary.
- Clearing the lyrics reverses the emphasis automatically.
- The state is recalculated on text edits and when a saved project populates the lyrics editor.
- Preserves the v0.2.0.77 Recent Music Folders browser and earlier waveform, clipboard, and export fixes.
