"""Guard audio duration fallback diagnostics without requiring audio dependencies."""
import ast
from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')

class AudioDurationDiagnosticsTests(unittest.TestCase):
    def test_each_fallback_logs_and_continues(self):
        tree = ast.parse(SOURCE.read_text(encoding='utf-8'))
        methods = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == '_batch_audio_duration']
        self.assertEqual(len(methods), 1)
        method = methods[0]
        handlers = [n for n in ast.walk(method) if isinstance(n, ast.ExceptHandler) and isinstance(n.type, ast.Name) and n.type.id == 'Exception']
        self.assertEqual(len(handlers), 4)
        for handler in handlers:
            self.assertFalse(any(isinstance(n, ast.Pass) for n in handler.body))
            calls = [n for n in ast.walk(handler) if isinstance(n, ast.Call)]
            self.assertTrue(any(isinstance(c.func, ast.Attribute) and isinstance(c.func.value, ast.Name) and c.func.value.id == 'logging' and c.func.attr == 'debug' for c in calls))
        self.assertTrue(any(isinstance(n, ast.Raise) for n in ast.walk(method)))

if __name__ == '__main__': unittest.main()
