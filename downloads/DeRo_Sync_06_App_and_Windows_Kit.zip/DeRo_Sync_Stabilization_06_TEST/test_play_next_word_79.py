from pathlib import Path

SOURCE = Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')

def test_play_next_word_button_is_between_word_and_line_controls():
    source = SOURCE.read_text(encoding="utf-8")
    word = source.index("compact('▶ Play Word',self.play_selected_word,bottom)")
    next_word = source.index("self.waveform_play_next_word_button=compact('▶ Play Next Word',self.play_next_word,bottom)")
    next_line = source.index("compact('▶ Play Next Line',self.play_next_line,bottom)")
    assert word < next_word < next_line

def test_next_word_advances_across_lines_and_auditions_without_editing_timings():
    source = SOURCE.read_text(encoding="utf-8")
    start = source.index(" def play_next_word(self):")
    end = source.index(" def play_next_line(self):", start)
    method = source[start:end]
    assert "for row_index in range(current_row+1,len(events))" in method
    assert "self.activate_timeline_word(target_row,target_index)" in method
    assert "self.play_timeline_word(target_row,target_index)" in method
    assert "self.snapshot()" not in method
    assert "Already at the final synchronized word." in method
