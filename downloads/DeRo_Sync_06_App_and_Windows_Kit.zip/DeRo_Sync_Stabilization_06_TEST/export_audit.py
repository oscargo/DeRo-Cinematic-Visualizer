"""Crash-tolerant append-only export event history and observational MP4 validation."""
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import threading
import time

_LOCK = threading.Lock()

class ExportAudit:
 def __init__(self, output_folder, mode):
  self.path=Path(output_folder)/'DeRo_Export_History.jsonl'
  self.mode=mode
  self.run_id=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')+'-'+str(os.getpid())
  self.started=time.monotonic()
 def record(self, event, **data):
  payload={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'elapsed_monotonic_seconds':round(time.monotonic()-self.started,3),
           'run_id':self.run_id,'mode':self.mode,'event':event,**data}
  try:
   with _LOCK:
    self.path.parent.mkdir(parents=True,exist_ok=True)
    with self.path.open('a',encoding='utf-8') as f:
     f.write(json.dumps(payload,ensure_ascii=False,default=str)+'\n')
     f.flush();os.fsync(f.fileno())
  except OSError:
   pass  # Never crash a working export because a diagnostics disk is full/unwritable.

# Re-export the shared validator for existing callers.
from visualizer_engine.media_validation import verify_mp4, require_verified_mp4
