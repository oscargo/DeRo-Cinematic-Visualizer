import ast
from pathlib import Path
import unittest

SOURCE=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py').read_text(encoding='utf-8')
TREE=ast.parse(SOURCE)
class ExportFeatureTests(unittest.TestCase):
 def test_range_widget_and_playback(self):
  self.assertIn('class ExportRangeBar(QWidget)',SOURCE)
  for action in ('play_export_selection','pause_export_selection','set_export_selection_loop','_check_export_selection_end'):
   self.assertIn('def '+action+'(',SOURCE)
 def test_export_presets(self):
  self.assertIn("fps=60;has_visual=",SOURCE)
  self.assertIn("'-cq','19'",SOURCE)
  self.assertIn("'-b:a','320k'",SOURCE)
 def test_both_exporters_use_clip(self):
  self.assertIn('clip_start,clip_end=self.export_range.start,self.export_range.end',SOURCE)
  self.assertIn('clip_duration=clip_end-clip_start',SOURCE)
  self.assertIn('clip_start=clip_start)',SOURCE)
 def test_diagnostics(self):
  for token in ('def inspect_export_mp4(', 'def finish_export_audit(',"'export_history':list(self.export_audit_history)","'ffmpeg_command'"):
   self.assertIn(token,SOURCE)
if __name__=='__main__':unittest.main()
