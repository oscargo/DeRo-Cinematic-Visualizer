# v0.2.1.27
- Batch Processing Start button constrained to 250px (~2.6 inches at 96 DPI), left aligned.
- Open Output Folder button beside Start; opens configured existing folder in Windows Explorer without deleting or creating files.
- Based on v0.2.1.25; existing batch pipeline preserved.
- Completion chime from the unverified v0.2.1.26 is not included.
