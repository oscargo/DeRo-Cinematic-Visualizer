"""Read-only release consistency check for DeRo Sync release directories."""
from pathlib import Path
import re,sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
main=list(root.glob('DeRo_Sync_v0210_*.py'))
issues=[]
if len(main)!=1: issues.append(f'Expected one main entrypoint, found {len(main)}')
if not (root/'VERSION').is_file(): issues.append('VERSION missing')
if main and (root/'VERSION').is_file():
 src=main[0].read_text(encoding='utf-8');m=re.search(r"APP_VERSION\s*=\s*['\"]v0210_(\d+)['\"]",src)
 version=(root/'VERSION').read_text().strip();v=re.fullmatch(r'v0\.2\.1\.(\d+)',version)
 if not m: issues.append('APP_VERSION missing/unexpected')
 if not v: issues.append(f'VERSION invalid: {version!r}')
 if m and v and m.group(1)!=v.group(1):issues.append(f'Version mismatch: APP_VERSION v0210_{m.group(1)} vs VERSION {version}')
 if m and not re.search(rf'v0210_{m.group(1)}_',main[0].name):issues.append('Main filename mismatch')
if not (root/'Launch_DeRo_Sync.bat').exists():issues.append('Launcher missing')
for x in issues:print('FAIL:',x)
if not issues:print('PASS: checked VERSION, APP_VERSION, main filename and launcher presence')
sys.exit(bool(issues))
