# v0.2.1.25 — Responsive Batch Setup

- Setup uses three columns on sufficiently wide windows and vertically stacked full-width panels on smaller windows.
- Entire Setup page scrolls vertically in compact layout; no narrow Batch Settings column.
- Output-folder path remains directly below Select Output Folder.
- Preserves the existing v0.2.1.24 processing engine and all single-song workflows.
- Windows visual testing required; Python syntax and ZIP integrity checked.
