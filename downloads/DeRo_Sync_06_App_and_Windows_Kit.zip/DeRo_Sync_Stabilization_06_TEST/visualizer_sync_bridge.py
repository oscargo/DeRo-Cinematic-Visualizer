"""DeRo Sync -> original DeRo Visualizer rendering bridge.

The Visualizer v0.1.45 renderer/exporter modules are copied unchanged except
for the diagnostics version constant. This module adapts Sync project data to
Visualizer's LyricDocument and Settings APIs.
"""
from __future__ import annotations
import os, sys, json, tempfile
from pathlib import Path
ENGINE_DIR = Path(__file__).resolve().parent / 'visualizer_engine'
if str(ENGINE_DIR) not in sys.path:
    sys.path.insert(0, str(ENGINE_DIR))
from visualizer_core import Settings
from export_video import export as visualizer_export
from export_control import ExportControl
from export_diagnostics import ExportReport
from lyric_model import LyricDocument, STYLE_DEFAULTS
from audio_mix import mix_spec, prepare_mix


def make_settings(values, song='', artist=''):
    """Strict, explicit UI-to-core mapping; unknown keys are not forwarded."""
    d = dict(values or {})
    width, height = d.get('resolution', (1920, 1080))
    mapping = {
        'width': int(width), 'height': int(height), 'fps': int(d.get('fps', 60)),
        'title': str(song or ''), 'artist': str(artist or ''),
        'bars': int(d.get('bars', 384)),
        'visualizer_enabled': bool(d.get('visualizer_enabled', True)),
        'spectrum_mapping': str(d.get('spectrum_mapping', 'Stepped')),
        'spectrum_style': str(d.get('spectrum_style', 'Classic bars')),
        'spectrum_mirrored': bool(d.get('spectrum_mirrored', True)),
        'spectrum_density': float(d.get('spectrum_density', 1.0)),
        'spectrum_fill': float(d.get('spectrum_fill', .58)),
        'spectrum_color': str(d.get('spectrum_color', '#f0f6ff')),
        'spectrum_color_end': str(d.get('spectrum_color_end', '#35a5ff')),
        'frequency_min': float(d.get('frequency_min', 50.0)),
        'frequency_max': float(d.get('frequency_max', 10584.0)),
        'frequency_scale': str(d.get('frequency_scale', 'Linear')),
        'spectrum_gain': float(d.get('spectrum_gain', 1.5)),
        'spectrum_width': float(d.get('spectrum_width', .8)),
        'spectrum_x': float(d.get('spectrum_x', .5)),
        'spectrum_y': float(d.get('spectrum_y', .9)),
        'spectrum_height': float(d.get('spectrum_height', .198)),
        'particles_enabled': bool(d.get('particles_enabled', True)),
        'particle_continuous': bool(d.get('particle_continuous', True)),
        'particle_speed': float(d.get('particle_speed', 20.0)),
        'particle_direction': str(d.get('particle_direction', 'Out')),
        'particle_reactive': bool(d.get('particle_reactive', True)),
        'particle_reactivity': str(d.get('particle_reactivity', 'Bass')),
        'particle_color': str(d.get('particle_color', '#ebeef7')),
        'dust_count': int(d.get('dust_count', 130)),
        'reactive_fraction': float(d.get('reactive_fraction', .24)),
        'sensitivity': float(d.get('sensitivity', 3.0)),
        'background': str(d.get('background', '') or ''),
        'gaussian_blur': float(d.get('gaussian_blur', 0.0)),
        'motion_blur': int(d.get('motion_blur', 0)),
        'motion_angle': int(d.get('motion_angle', 0)),
        'overlay_enabled': bool(d.get('overlay_enabled', False)),
        'overlay_path': str(d.get('overlay_path', '') or ''),
        'overlay_size': float(d.get('overlay_size', .2)),
        'overlay_x': float(d.get('overlay_x', .5)),
        'overlay_y': float(d.get('overlay_y', .5)),
        'overlay_opacity': float(d.get('overlay_opacity', 1.0)),
        'overlay_shape': str(d.get('overlay_shape', 'Original')),
        'title_size': float(d.get('title_size', .12)),
        'title_x': float(d.get('title_x', .5)), 'title_y': float(d.get('title_y', .42)),
        'title_font': str(d.get('title_font', 'Sans')),
        'title_bold': bool(d.get('title_bold', False)),
        'title_italic': bool(d.get('title_italic', False)),
        'title_uppercase': bool(d.get('title_uppercase', False)),
        'title_color': str(d.get('title_color', '#f8f9fd')),
        'artist_size': float(d.get('artist_size', .08)),
        'artist_x': float(d.get('artist_x', .5)), 'artist_y': float(d.get('artist_y', .585)),
        'artist_font': str(d.get('artist_font', 'Sans')),
        'artist_bold': bool(d.get('artist_bold', False)),
        'artist_italic': bool(d.get('artist_italic', False)),
        'artist_uppercase': bool(d.get('artist_uppercase', False)),
        'artist_color': str(d.get('artist_color', '#f8f9fd')),
        'export_encoder': str(d.get('export_encoder', 'Auto (GPU if available)')),
    }
    return Settings(**mapping)


def make_lyric_document(project):
    events = project.get('events') or []
    text = str(project.get('authoritative_lyrics') or '\n'.join(str(e[2]) for e in events))
    style = dict(STYLE_DEFAULTS)
    # Preserve the Sync karaoke styling used in the verified integration test.
    style.update(enabled=True, lyric_display_mode='classic_flow', classic_flow_lines=2, lyric_exit='Fade Out')
    # The integrated export must honor Sync's saved lyric appearance, not fixed bridge defaults.
    for key in STYLE_DEFAULTS:
        if key in project:
            style[key] = project[key]
    # The Visualizer's two-row layout is intentionally enforced for this export path.
    style['lyric_display_mode'] = 'classic_flow'
    style['classic_flow_lines'] = 2
    supplied = project.get('visualizer_lyric_style')
    if isinstance(supplied, dict): style.update({k:v for k,v in supplied.items() if k in STYLE_DEFAULTS})
    style['lyric_display_mode'] = 'classic_flow'
    style['classic_flow_lines'] = 2
    data = {'schema_version':1, 'authoritative_lyrics':text, 'events':events,
            'word_timings':project.get('word_timings') or {},
            'alignment_status':project.get('alignment_status') or {},
            'word_scores':project.get('word_scores') or {},
            'manual_overrides':project.get('manual_overrides') or {},
            'alignment_summary':{}, 'sync_inspector':{}, 'style':style}
    return LyricDocument(data)


def run_sync_export(project, settings_values, original_audio, instrumental, vocals,
                    use_stems, instrumental_gain, vocal_gain, output_path, ffmpeg,
                    progress=None, control=None, diagnostics_path=None, start_seconds=0.0, end_seconds=None):
    control = control or ExportControl()
    ffmpeg = str(Path(ffmpeg).resolve())
    os.environ['PATH'] = str(Path(ffmpeg).parent) + os.pathsep + os.environ.get('PATH','')
    if use_stems and instrumental and vocals and Path(instrumental).is_file() and Path(vocals).is_file():
        spec = mix_spec(instrumental, vocals, instrumental_gain, vocal_gain)
        audio_path = prepare_mix(spec, control)
    elif use_stems and instrumental and Path(instrumental).is_file():
        audio_path = instrumental
    else:
        audio_path = original_audio
    if not audio_path or not Path(audio_path).is_file():
        raise FileNotFoundError('The selected audio/stem file does not exist.')
    settings = make_settings(settings_values, project.get('song',''), project.get('artist',''))
    doc = make_lyric_document(project)
    report = ExportReport(settings)
    result = visualizer_export(audio_path, output_path, settings, ffmpeg=ffmpeg,
                               progress=progress, cancel=control, diagnostics=report,
                               lyric_document=doc.snapshot(),
                               start_seconds=start_seconds, end_seconds=end_seconds)
    if diagnostics_path:
        Path(diagnostics_path).write_text(json.dumps(report.data, indent=2), encoding='utf-8')
    return result, report.data
