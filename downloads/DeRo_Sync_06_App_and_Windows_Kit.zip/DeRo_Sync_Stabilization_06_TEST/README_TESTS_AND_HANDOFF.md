# DeRo Sync v0.2.1.04 maintenance

Run `py -3.12 run_regression_tests.py` or double-click `Run_Regression_Tests.bat`. This runner supports unittest classes and plain `test_*` functions without pytest. Nonzero exit code means a failure or test loading error.

The launcher checks Python 3.12 and required imports without automatically installing packages. It uses `py -3.12` by default; adapt the `PY` setting if you have a permanent Python environment. For missing dependencies, install `PySide6` and `requirements-visualizer.txt` into that environment. Audio separation/alignment may require additional packages at runtime.

Background Studio v0.2.29's **Send to DeRo Sync** writes `~/Documents/DeRo Background Studio/sync_handoff.json`. In Sync, choose **Use Background Studio** to import the PNG. Only schema version 1 is accepted. Background selection remains opt-in.

Tests are primarily source-level checks; Windows GUI and full MP4 export remain unverified.
