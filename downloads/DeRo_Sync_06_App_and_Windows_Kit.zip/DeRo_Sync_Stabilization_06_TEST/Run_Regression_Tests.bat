@echo off
cd /d "%~dp0"
py -3.12 run_regression_tests.py
if errorlevel 1 (echo TESTS FAILED & pause & exit /b 1)
echo TESTS PASSED
pause
