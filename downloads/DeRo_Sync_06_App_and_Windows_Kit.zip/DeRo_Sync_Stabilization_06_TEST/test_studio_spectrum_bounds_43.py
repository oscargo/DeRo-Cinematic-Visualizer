"""Real FFmpeg regressions: spectrum EOF must not generate unbounded duplicate frames."""
import unittest,subprocess,tempfile,time,types,shutil,json
from pathlib import Path
import psutil
import test_studio_export_pipeline_43 as studio_tests

class SpectrumBoundsTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):raise unittest.SkipTest('FFmpeg and ffprobe required')
 def run_case(self,particles,duration,start):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);audio=root/'tone.wav';ass=root/'lyrics.ass';target=root/'output.mp4'
   subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=duration=0.6',str(audio)],check=True,capture_output=True,timeout=15)
   ass.write_text('[Script Info]\nScriptType: v4.00+\nPlayResX: 320\nPlayResY: 180\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Default,Arial,24,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,1,0,5,10,10,10,1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:00.00,0:00:00.50,Default,,0,0,0,,Spectrum test\n')
   settings=studio_tests.StudioExportPipelineTests().settings(True,particles);settings['particle_count']=10
   command=studio_tests.load_export_method()(types.SimpleNamespace(encoder=studio_tests.Encoder(),project={}),shutil.which('ffmpeg'),ass,str(audio),str(target),320,180,duration,settings,clip_start=start)
   with tempfile.TemporaryFile() as errors:
    proc=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=errors);began=time.monotonic();peak=0;limited=None
    try:
     while proc.poll() is None:
      try:peak=max(peak,psutil.Process(proc.pid).memory_info().rss)
      except psutil.Error:pass
      if peak>512*1024**2:limited='spectrum exceeded 512 MiB regression budget';proc.kill();break
      if time.monotonic()-began>20:limited='spectrum timed out';proc.kill();break
      time.sleep(.01)
     proc.wait();errors.seek(0);error=errors.read().decode(errors='replace')[-1200:]
    finally:
     if proc.poll() is None:proc.kill();proc.wait()
   self.assertIsNone(limited,limited);self.assertEqual(proc.returncode,0,error)
   data=json.loads(subprocess.run(['ffprobe','-v','error','-count_frames','-show_entries','format=duration:stream=codec_type,nb_read_frames,r_frame_rate','-of','json',str(target)],check=True,capture_output=True,text=True,timeout=15).stdout)
   self.assertEqual({s['codec_type'] for s in data['streams']},{'audio','video'})
   video=next(s for s in data['streams'] if s['codec_type']=='video');self.assertEqual(int(video['nb_read_frames']),round(duration*60));self.assertEqual(video['r_frame_rate'],'60/1');self.assertAlmostEqual(float(data['format']['duration']),duration,delta=.06)
 def test_spectrum_only_finishes_with_bounded_frames(self):self.run_case(False,.5,0.)
 def test_spectrum_and_ten_particles_selected_range_finishes(self):self.run_case(True,.25,.1)
