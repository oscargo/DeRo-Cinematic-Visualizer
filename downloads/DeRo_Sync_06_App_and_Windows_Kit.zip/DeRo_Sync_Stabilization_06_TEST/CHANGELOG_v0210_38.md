# DeRo Sync v0.2.1.38 — Batch Section Testing

- Adds Test Section Settings popup on Batch Processing with draggable yellow handles, exact seconds, and independent audio audition controls.
- Adds Process Selected Section Only for the selected queue song; uses the original Demucs/WhisperX pipeline and original Visualizer renderer, then exports only the selected range.
- Keeps full batch processing unchanged and creates collision-protected TEST MP4/project names.
- Records test range in export history and audits MP4 duration against selected range.
- Does not change lyric alignment quality or original audio.

Testing: syntax and ZIP verification are possible here; real Windows GPU playback and export require user testing.
