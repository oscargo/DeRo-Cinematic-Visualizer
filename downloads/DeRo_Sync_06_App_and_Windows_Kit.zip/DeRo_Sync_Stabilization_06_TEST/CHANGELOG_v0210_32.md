# v0.2.1.32 — Restore Original Setup Layout

- Restore the v0.2.1.24 three-panel horizontal Setup arrangement permanently.
- Restore six Song Queue buttons to one horizontal row.
- Remove responsive vertical stacking; permit horizontal scrolling if window becomes narrow.
- Preserve all batch, export, visualizer, and celebration features from v0.2.1.31.
- Static checks passed; Windows GUI layout has not been runtime tested.
