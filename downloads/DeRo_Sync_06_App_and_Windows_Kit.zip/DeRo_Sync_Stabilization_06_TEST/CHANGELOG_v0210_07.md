DeRo Sync v0.2.1.07 — Static visualizer preview
- Uses the original Visualizer renderer to draw one reduced-resolution illustrative frame with spectrum and particles.
- Composites two lines of current lyrics over the frame.
- Refreshes on background and visualizer settings changes; no live animation.
- No production export or renderer changes.
- Includes remembered background folder and static lyric preview.
