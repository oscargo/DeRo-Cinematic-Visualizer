"""Regression guard for non-invasive Studio FFmpeg cancellation diagnostics."""
import ast
from pathlib import Path
import unittest

class CancellationDiagnosticTests(unittest.TestCase):
 def test_cancellation_paths_report_os_errors(self):
  path=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')
  tree=ast.parse(path.read_text(encoding='utf-8'))
  main=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Main')
  for name in ('run_cancellable_studio_command','cancel_studio_export','_force_studio_stop'):
   method=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name==name)
   handlers=[n for n in ast.walk(method) if isinstance(n,ast.ExceptHandler) and isinstance(n.type,ast.Name) and n.type.id=='OSError']
   self.assertTrue(handlers,name)
   for handler in handlers:
    self.assertTrue(any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='warning' for stmt in handler.body for n in ast.walk(stmt)), f'{name}: swallowed OSError')
 def test_no_change_to_cancel_api(self):
  path=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py')
  tree=ast.parse(path.read_text(encoding='utf-8'))
  main=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Main')
  names={n.name for n in main.body if isinstance(n,ast.FunctionDef)}
  self.assertTrue({'run_cancellable_studio_command','cancel_studio_export','_force_studio_stop','_finish_cancelled_close'} <= names)
