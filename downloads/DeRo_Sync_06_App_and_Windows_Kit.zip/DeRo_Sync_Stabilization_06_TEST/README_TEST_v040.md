# v0.2.1.40 Windows smoke test

1. Keep your v0.2.1.39 folder intact. Extract this ZIP to a NEW folder and run Launch_DeRo_Sync.bat.
2. For the fastest standalone test, open a known-good saved project and render a short preview/test export; NOTE: previews intentionally do NOT celebrate or generate a standalone audit. To verify both, use a real standalone Visualizer MP4 export.
3. After the standalone MP4 finishes, watch the top activity banner immediately for two confetti poppers and listen for the original four-note chime. The animation lasts approximately six seconds, not indefinitely.
4. In the MP4 output folder, verify a same-name `.export-audit.json` exists. Open Diagnostics and check `last_export_audit` is populated. Restart the app and check Diagnostics again.
5. Report the MP4 path, whether confetti/chime played, and the audit JSON or diagnostics ZIP.
6. Do NOT rerun Mrs. Officer expecting better sync: this release does not change WhisperX timing.
