# DeRo Sync v0.2.0.77

- Replaced the Song page's Project Overview panel with a Recent Music Folders browser.
- Remembers up to 12 previously selected music folders across app launches using QSettings.
- Lists supported audio files in the selected folder, with filename filtering and refresh.
- Supports adding folders, switching between recent folders, and loading a selected song by button or double-click.
- Reuses the existing song confirmation, unsaved-project protection, project reset, and automatic vocal-separation workflow when loading from the browser.
- Keeps the original Browse Audio dialog available.
- Preserves the v0.2.0.76 waveform clipboard and handle changes.
