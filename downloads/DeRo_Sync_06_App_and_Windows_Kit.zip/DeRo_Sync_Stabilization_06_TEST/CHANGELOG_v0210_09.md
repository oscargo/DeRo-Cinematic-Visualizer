# DeRo Sync v0.2.1.09 — Batch preparation UI (first incremental build)

- Preserves original v0.2.1.08 archive untouched.
- Adds Batch navigation between Visualizer and Export.
- Adds three Batch workspace stages: Setup, Lyrics, Processing (informational only).
- Adds multi-file audio selection, folder import, duplicate skipping, removal, reordering and clear-with-confirmation. No underlying audio files are deleted.
- Adds persistent per-song lyrics editing and batch queue using existing QSettings; last audio folder is remembered.
- Adds approved background folder browser and no-repeat shuffled preview across cycles.
- Adds independent Visualizer (off) and Particles (on) options; auto-open output folder preference (on).
- Batch processing is intentionally disabled until real end-to-end separation, alignment, rendering and export are implemented and tested.

## Testing and limitations
- Python syntax compilation passed.
- Qt runtime GUI smoke test could not run in this environment because PySide6 is not installed. Windows UI behavior is not yet verified.
- No automated batch exports, background assignments, audio processing or completed-video playback in this build.
- Existing single-song workflow was not intentionally modified beyond navigation and indicator index updates.
