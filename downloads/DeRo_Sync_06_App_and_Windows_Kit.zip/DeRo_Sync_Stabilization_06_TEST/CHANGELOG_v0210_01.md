# DeRo Sync v0.2.1.01 — Visualizer UI / ETA Fix

- Centered Stop Export button, fixed width 245 Qt logical pixels.
- Visualizer export progress bar now tracks frames and estimates remaining time and finish clock time from measured rendering speed. ETA is approximate; startup and encoder finalization may vary.
- Moved background image, bass-reactive particles, and stem selection to top of Visualizer settings.
- Independent left settings and right preview scrolling.
- Image background is displayed immediately after selection or editing, scales with preview size, and reports invalid paths. This is a static image preview, not an animated frame; Preview 8 seconds remains the motion test.
- Existing rendering engine and export logic retained without modifications.
- Original v0.2.1.00 release remains separate.
