# DeRo Sync v0.2.1.39 — Reusable Alignment Cache

- Short batch section tests reuse saved full-song WhisperX alignment for the same source audio, original pasted lyrics, Demucs model, vocals/instrumental stems, recognition model and language.
- On the first section test, full-song alignment runs and is saved before video export; later section tests skip alignment and render only the new selected range.
- Existing valid paired stems continue to be reused.
- Cache is stored in a hidden `.DeRo_Sync_Alignment_Cache` folder inside the selected batch output directory.
- Atomic writes, identity fingerprint checks and invalid-cache fallback; no source audio, stem, lyrics, or timing edits.
- Full batch processing continues to run normal alignment; cache reuse is only for the selected-section test mode.
- Existing synchronization quality checks and export decisions are unchanged.

## Testing
1. Extract into its own folder; do not merge with older releases.
2. Add one song and lyrics, set a short test range, process. Look for `Saved full-song alignment cache`.
3. Change the test range for the SAME song; process again. Look for `Reusing verified saved full-song alignment; skipping WhisperX`.
4. Confirm both test MP4s have their own ranges and names.
5. Change one word of lyrics; processing must say `No matching cache` and align again.
6. Send processing log, both export audits, and any errors.

This release is syntax and cache-unit tested; Windows GUI/GPU/FFmpeg export has NOT been tested here.
