# DeRo Sync v0.2.1.43 — Popper Direction Fix

- Corrected left and right party-popper cone geometry: mouths face upward and toward screen center, matching confetti trajectory.
- Mirrored the right popper from the left to ensure symmetric orientation.
- Preserved replay button, 0.7-second stagger, nine-second confetti, original chime, and export workflows.
- No synchronization or rendering changes.
