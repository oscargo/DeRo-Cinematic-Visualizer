import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)

class SuccessLifecycleTests(unittest.TestCase):
 def test_new_export_clears_previous_success(self):
  fn = next(n for n in ast.walk(TREE) if isinstance(n, ast.FunctionDef) and n.name == 'begin_job')
  body = ast.get_source_segment(SOURCE, fn)
  self.assertIn('if final_export:', body)
  self.assertIn('self._clear_export_congratulations()', body)

 def test_batch_clears_previous_success_after_validation(self):
  fn = next(n for n in ast.walk(TREE) if isinstance(n, ast.FunctionDef) and n.name == 'start_batch_processing')
  body = ast.get_source_segment(SOURCE, fn)
  self.assertLess(body.index('if not ws.songs'), body.index('self._clear_export_congratulations()'))
  self.assertLess(body.index('self._clear_export_congratulations()'), body.index('self._batch_running=True'))

 def test_replay_does_not_create_success(self):
  fn = next(n for n in ast.walk(TREE) if isinstance(n, ast.FunctionDef) and n.name == 'replay_celebration_test')
  body = ast.get_source_segment(SOURCE, fn)
  self.assertNotIn('celebrate_success(', body)
  self.assertNotIn('export_congratulations_label.setText', body)

 def test_no_lower_overlay_or_sparkles(self):
  self.assertNotIn('self.lower_celebration_effect=', SOURCE)
  self.assertNotIn('draw_sparkles(', SOURCE)

if __name__ == '__main__': unittest.main()
