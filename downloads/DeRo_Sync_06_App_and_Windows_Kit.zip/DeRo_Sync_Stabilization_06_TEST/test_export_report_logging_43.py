"""Protect best-effort export report diagnostics from silent failures."""
import ast
from pathlib import Path

def test_export_report_write_failure_is_logged():
    source = (Path(__file__).parent / "DeRo_Sync_v0210_43_Popper_Direction_Fix.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    matches = [n for n in ast.walk(tree) if isinstance(n, ast.Try) and any(isinstance(x, ast.Call) and isinstance(x.func, ast.Attribute) and x.func.attr == "write_text" for x in ast.walk(ast.Module(body=n.body, type_ignores=[]))) and "report_path" in ast.unparse(n)]
    assert matches, "Expected an export report write attempt"
    assert any(any(isinstance(x, ast.Call) and isinstance(x.func, ast.Attribute) and x.func.attr == "exception" for x in ast.walk(h)) for n in matches for h in n.handlers), "Export report write failures must be logged"
