# DeRo Sync v0.2.1.43 — stabilization candidate

This is a test candidate, not a verified stable Windows release.

## Targeted correction
- Clears a previous export congratulations label when a new final export is accepted.
- Clears a previous congratulations label when a new batch is accepted after input and dependency checks.
- Replay Celebration does not create a new success message.
- Upper poppers only; no sparkles; target 60 FPS, six seconds.
- No changes to lyric alignment, rendering, video encoding or particle effects.

## Verification
- 67 regression tests passed on Linux in this development environment.
- Main Python source compiles; archive CRC integrity checked.
- Windows/PySide6 GUI launch, actual exports, resize and 60 FPS delivery are NOT verified here.
- Before declaring stable: test launcher, real single-song export, visualizer export, batch success/failure, cancellation, and success label visibility on Windows.

## Version
- Public version remains v0.2.1.43. APP_BUILD remains 0.2.1.43-POPPER-DIRECTION-FIX (existing code identifier). This ZIP is marked as a stabilization TEST candidate.
