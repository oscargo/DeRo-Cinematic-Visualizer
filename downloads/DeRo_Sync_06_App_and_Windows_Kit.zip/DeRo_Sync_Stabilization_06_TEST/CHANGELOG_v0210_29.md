# v0.2.1.29 Export-only celebration
- Approved WAV and party-popper animation ONLY on successful final MP4 export or fully successful batch completion.
- No celebration or chime on project save, separation, alignment, previews, or other routine actions.
- Avoid duplicate chimes for individual songs inside a batch.
- No original files deleted.
