# v0.2.1.43 Export diagnostics maintenance

- Only the MP4 export report-writing fallback was changed in the application.
- An OS-level failure to write the optional JSON diagnostic report now calls `logging.exception` with the intended report path instead of silently passing.
- Export success/failure and report-write best-effort behavior remain unchanged.
- Added a regression assertion guarding the logging behavior.
- Does not claim Windows GUI or end-to-end MP4 verification.
