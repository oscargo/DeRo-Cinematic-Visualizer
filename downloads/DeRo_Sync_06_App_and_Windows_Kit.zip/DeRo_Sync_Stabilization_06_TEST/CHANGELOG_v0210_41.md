# v0.2.1.41 — Unified Export Completion

- Both successful standalone and full-batch exports navigate to 07 EXPORT.
- Original four-note completion sound remains unchanged.
- Original two-popper Qt celebration is shown in a large, foreground overlay with more confetti, lasting about 9 seconds.
- Auto-open output folder/video is delayed until after celebration to keep it visible.
- Intermediate batch songs retain their short tone. Selected-section tests remain excluded from full celebration.
- No synchronization or renderer algorithm changes.

Windows GUI/audio validation is still required.
