"""Non-destructive batch workspace with sequential processing controller."""
import json, random, re
from pathlib import Path
from PySide6.QtCore import Qt, QRect, QUrl, QTimer, Signal
from PySide6.QtGui import QPixmap, QColor, QFont, QDesktopServices
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QStackedWidget,
 QListWidget,QListWidgetItem,QPlainTextEdit,QFileDialog,QMessageBox,QFrame,QCheckBox,QComboBox,
 QLineEdit,QScrollArea,QGridLayout,QSplitter,QBoxLayout,QGroupBox,QProgressBar,QInputDialog,QDialog,QFormLayout,QStyledItemDelegate,QStyleOptionViewItem)

AUDIO={'.mp3','.wav','.flac','.m4a','.aac','.ogg','.opus','.wma'}
IMAGES={'.png','.jpg','.jpeg','.webp','.bmp'}

def clean_song_name(stem):
 name=re.sub(r'^\s*\d{1,4}\s*[-._]\s*','',stem).strip()
 name=re.sub(r'\s*[\[(]\s*(?:official\s+)?(?:hd\s+|4k\s+)?(?:music\s+)?(?:video|audio|lyrics?|visualizer)(?:\s+video)?\s*[\])]','',name,flags=re.I)
 return re.sub(r'\s{2,}',' ',name).strip(' -_') or stem


def button(label, fn):
 b=QPushButton(label);b.clicked.connect(fn);return b

def next_button(label, fn):
 b=button(label,fn)
 b.setObjectName('batchNextButton')
 b.setMinimumHeight(42)
 return b

def panel(title):
 w=QGroupBox(title);w.setObjectName('batchPanel');return w

class BatchLyricsStatusDelegate(QStyledItemDelegate):
 """Paint the status mark without replacing native QListWidget selection rows."""
 def paint(self, painter, option, index):
  opt=QStyleOptionViewItem(option)
  self.initStyleOption(opt,index)
  # Keep the original item background and selection painting intact.
  opt.rect=QRect(option.rect)
  opt.rect.setRight(max(opt.rect.left(),opt.rect.right()-36))
  super().paint(painter,opt,index)
  painter.save()
  painter.setPen(QColor('#20e65a') if index.data(Qt.UserRole) else QColor('#cbd4e7'))
  font=QFont(option.font)
  font.setBold(bool(index.data(Qt.UserRole)))
  font.setPointSize(max(11,font.pointSize()))
  painter.setFont(font)
  marker='✓' if index.data(Qt.UserRole) else '○'
  painter.drawText(QRect(option.rect.right()-34,option.rect.top(),30,option.rect.height()),Qt.AlignCenter,marker)
  painter.restore()

class BatchPasteEditor(QPlainTextEdit):
 """Signal only for actual clipboard paste, not normal typing or project restore."""
 pasted=Signal()
 def insertFromMimeData(self, source):
  if not source or not source.hasText() or not source.text().strip():
   return super().insertFromMimeData(source)
  super().insertFromMimeData(source)
  self.pasted.emit()

class BatchWorkspace(QWidget):
 def __init__(self,settings,metadata_reader=None,information_cleaner=None,favorite_sites_callback=None):
  super().__init__();self.settings=settings;self.metadata_reader=metadata_reader;self.information_cleaner=information_cleaner;self.favorite_sites_callback=favorite_sites_callback;self.songs=[];self.selected=-1;self.images=[];self.shuffle_bag=[];self.shuffle_history=[]
  self.setStyleSheet('QGroupBox#batchPanel{border:1px solid #3c4b6a;border-radius:10px;margin-top:12px;padding-top:10px;font-weight:700} QGroupBox#batchPanel::title{subcontrol-origin:margin;left:12px;padding:0 5px;color:#d9cbff} QPushButton#batchNextButton{background-color:#187a3c;color:#ffffff;border:1px solid #35aa62;border-radius:8px;font-weight:700;font-size:14px} QPushButton#batchNextButton:hover{background-color:#229b4e} QPushButton#batchNextButton:pressed{background-color:#12622f} QPushButton#batchStartButton{background-color:#178044;color:#ffffff;border:1px solid #3cc575;border-radius:8px;font-weight:700;font-size:14px;min-height:38px} QPushButton#batchStartButton:hover{background-color:#209d54} QPushButton#batchStartButton:pressed{background-color:#106334} QPushButton#batchStartButton:disabled{background-color:#3b465a;color:#a5afc2;border:1px solid #526078}')
  root=QVBoxLayout(self);root.setSpacing(9)
  head=QHBoxLayout();head.addWidget(QLabel('BATCH KARAOKE PROCESSING  ·  Sequential beta'));head.addStretch();self.count=QLabel('0 songs in queue');head.addWidget(self.count);root.addLayout(head)
  steps=QHBoxLayout();self.step_buttons=[]
  for i,name in enumerate(('1. Setup','2. Lyrics','3. Processing')):
   b=button(name,lambda _,n=i:self.change_step(n));steps.addWidget(b);self.step_buttons.append(b)
  root.addLayout(steps)
  self.stack=QStackedWidget();root.addWidget(self.stack,1)
  self.build_setup();self.build_lyrics();self.build_processing()
  self.restore();self.change_step(0)

 def make_queue(self, with_status=False):
  group=panel('Song Queue');layout=QVBoxLayout(group)
  # Full song list width; controls occupy their own row ABOVE the list, never beside it.
  # Original v0.2.1.24: all six queue actions in one horizontal row.
  controls=QHBoxLayout()
  controls.setSpacing(5)
  for name,fn in [('Add Songs',self.add_songs),('Add Folder',self.add_folder),('Remove Selected',self.remove_song),('Rename Song',self.rename_song),('Move Up',lambda:self.move(-1)),('Move Down',lambda:self.move(1))]:controls.addWidget(button(name,fn))
  layout.addLayout(controls)
  songs=QListWidget();songs.setItemDelegate(BatchLyricsStatusDelegate(songs));songs.setSelectionMode(QListWidget.SingleSelection);songs.currentRowChanged.connect(self.select_song);songs.itemDoubleClicked.connect(lambda _item:self.rename_song())
  layout.addWidget(songs,1)
  if with_status:layout.addWidget(QLabel('✓ Lyrics entered     ○ No lyrics — select a song to paste'))
  else:
   info=QHBoxLayout();info.addWidget(QLabel('Removing from this queue NEVER deletes audio files.'));info.addStretch();info.addWidget(button('Clear Queue',self.clear_queue));layout.addLayout(info)
  return group,songs
 def build_setup(self):
  # The entire Setup page scrolls; columns become full-width stacked panels
  # when the application is genuinely too narrow for three columns.
  page=QWidget();outer=QVBoxLayout(page);outer.setContentsMargins(0,0,0,0)
  self.setup_scroll=QScrollArea();self.setup_scroll.setWidgetResizable(True)
  self.setup_scroll.setFrameShape(QFrame.NoFrame)
  self.setup_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  outer.addWidget(self.setup_scroll)
  self.setup_content=QWidget()
  layout=QBoxLayout(QBoxLayout.LeftToRight,self.setup_content)
  layout.setContentsMargins(0,0,0,0);layout.setSpacing(9)
  self.setup_layout=layout
  queue,self.setup_list=self.make_queue();self.setup_queue_panel=queue
  layout.addWidget(queue,5)
  backgrounds=panel('Background Images — approved folder');bg=QVBoxLayout(backgrounds)
  folder=QHBoxLayout();self.bg_path=QLineEdit();self.bg_path.setReadOnly(True);folder.addWidget(self.bg_path,1);folder.addWidget(button('Select Folder',self.choose_backgrounds));bg.addLayout(folder)
  self.image_list=QListWidget();bg.addWidget(self.image_list,1)
  self.no_repeat=QCheckBox('Random images — no repeats until every image used');self.no_repeat.setChecked(True);bg.addWidget(self.no_repeat)
  bg.addWidget(button('Preview Next Background',self.preview_next_background));self.bg_preview=QLabel('Select your approved image folder');self.bg_preview.setAlignment(Qt.AlignCenter);self.bg_preview.setMinimumHeight(100);bg.addWidget(self.bg_preview)
  self.setup_background_panel=backgrounds
  layout.addWidget(backgrounds,5)
  settings=panel('Batch Settings');self.setup_settings_panel=settings
  opts=QVBoxLayout(settings)

  opts.setSpacing(9)
  opts.addWidget(next_button('Next: Lyrics →',lambda:self.change_step(1)))
  opts.addWidget(button('Select Output Folder',self.choose_output))
  # The chosen destination belongs immediately below its picker, always visible together.
  self.output_path=QLineEdit();self.output_path.setReadOnly(True)
  self.output_path.setPlaceholderText('No output folder selected')
  self.output_path.setToolTip('Selected batch output folder')
  opts.addWidget(self.output_path)
  opts.addWidget(QLabel('Output: 1920 × 1080 · 60 FPS'))
  opts.addWidget(QLabel('Processing: Sequential · one song at a time'))
  opts.addWidget(QLabel('Vocal stem: 20% default (when available)'))
  self.visualizer=QCheckBox('Use Visualizer');self.visualizer.setChecked(False);opts.addWidget(self.visualizer)
  self.particles=QCheckBox('Use Particles');self.particles.setChecked(True);opts.addWidget(self.particles)
  self.open_folder=QCheckBox('Open output folder when batch completes');self.open_folder.setChecked(True);opts.addWidget(self.open_folder)
  opts.addStretch()
  layout.addWidget(settings,4)
  self.setup_scroll.setWidget(self.setup_content)
  self.stack.addWidget(page)
  self._update_setup_layout()
 def _update_setup_layout(self):
  """Preserve the v0.2.1.24 three-column Setup at all desktop widths.

  Never rotate the columns into a vertical stack. If the app becomes narrow,
  the scroll area can scroll horizontally instead of rearranging controls.
  """
  if not hasattr(self,'setup_layout'):return
  self.setup_layout.setDirection(QBoxLayout.LeftToRight)
  for widget in (self.setup_queue_panel,self.setup_background_panel,self.setup_settings_panel):
   widget.setMinimumHeight(0)
  for i,weight in enumerate((5,5,4)):self.setup_layout.setStretch(i,weight)
  self.setup_content.updateGeometry()
 def resizeEvent(self,event):
  super().resizeEvent(event)
  self._update_setup_layout()
 def build_lyrics(self):
  page=QWidget();layout=QHBoxLayout(page)
  queue,self.lyrics_list=self.make_queue(True);layout.addWidget(queue,5)
  editor=panel('Lyrics — selected song');mid=QVBoxLayout(editor)
  header=QHBoxLayout();self.lyrics_title=QLabel('Select a song from the queue');header.addWidget(self.lyrics_title,1)
  self.favorite_sites_button=button('Favorite Lyrics Sites',self.open_favorite_sites)
  self.favorite_sites_button.setMinimumWidth(165);header.addWidget(self.favorite_sites_button)
  mid.addLayout(header)
  mid.addWidget(QLabel('Paste authoritative lyrics here. No processing starts during preparation.'))
  self.editor=BatchPasteEditor();self.editor.setPlaceholderText('Paste the complete lyrics for this song...');self.editor.textChanged.connect(self.lyrics_changed);self.editor.pasted.connect(self.advance_after_lyrics_paste);mid.addWidget(self.editor,1)
  layout.addWidget(editor,6)
  status=panel('Lyrics Status');side=QVBoxLayout(status);self.progress_label=QLabel('0 of 0 songs have lyrics');side.addWidget(self.progress_label)
  side.addWidget(next_button('Next: Processing →',lambda:self.change_step(2)))
  side.addWidget(button('← Back: Setup',lambda:self.change_step(0)))
  self.lyrics_progress=QProgressBar();side.addWidget(self.lyrics_progress);side.addStretch()
  layout.addWidget(status,3);self.stack.addWidget(page)
 def copy_selected_song_search(self):
  """Use Batch's selected song, not the separate single-song project fields."""
  if not (0 <= self.selected < len(self.songs)):
   return ''
  song=self.songs[self.selected]
  search=' '.join(str(song.get(k,'')).strip() for k in ('artist','title')).strip()
  if not search:
   return ''
  from PySide6.QtWidgets import QApplication
  clipboard=QApplication.clipboard()
  clipboard.setText(search,clipboard.Mode.Clipboard)
  return search if clipboard.text(clipboard.Mode.Clipboard)==search else ''
 def open_favorite_sites(self):
  if not callable(self.favorite_sites_callback):
   QMessageBox.warning(self,'Favorite Lyrics Sites','The shared favorite sites dialog is unavailable.')
   return
  if not (0 <= self.selected < len(self.songs)):
   QMessageBox.information(self,'Select a song','Select a song from the Batch queue first.')
   return
  self.favorite_sites_callback(search_provider=self.copy_selected_song_search)
 def build_processing(self):
  page=QWidget();layout=QVBoxLayout(page)
  layout.addWidget(QLabel('PROCESSING — Sequential karaoke export (beta)'))
  note=QLabel('Processes each queued song one at a time using Demucs, WhisperX and the original DeRo Visualizer renderer.\n'
   'Poorly aligned songs are marked failed; no existing MP4 or project is overwritten.\n'
   'This feature has not yet been validated on a Windows GPU. Test with one song first.')
  note.setWordWrap(True);layout.addWidget(note)
  self.process_summary=QLabel('');layout.addWidget(self.process_summary)
  self.start_callback=None
  self.section_settings_callback=None
  self.section_process_callback=None
  self.start_batch_button=QPushButton('Start Batch Processing')
  self.start_batch_button.setObjectName('batchStartButton')
  self.start_batch_button.clicked.connect(lambda:self.start_callback() if self.start_callback else None)
  actions=QHBoxLayout()
  actions.addStretch(1)
  actions.addWidget(self.start_batch_button)
  self.start_batch_button.setFixedWidth(250)
  self.open_batch_folder_button=QPushButton('Open Output Folder')
  self.open_batch_folder_button.setFixedWidth(180)
  self.open_batch_folder_button.clicked.connect(self.open_batch_output_folder)
  actions.addWidget(self.open_batch_folder_button)
  self.section_settings_button=QPushButton('Test Section Settings')
  self.section_settings_button.clicked.connect(lambda:self.section_settings_callback() if self.section_settings_callback else None)
  actions.addWidget(self.section_settings_button)
  self.section_process_button=QPushButton('Process Selected Section Only')
  self.section_process_button.clicked.connect(lambda:self.section_process_callback() if self.section_process_callback else None)
  actions.addWidget(self.section_process_button)
  actions.addStretch(1)
  layout.addLayout(actions)
  self.process_log=QPlainTextEdit();self.process_log.setReadOnly(True);self.process_log.setPlaceholderText('Per-song progress and failures appear here.');layout.addWidget(self.process_log,1)
  layout.addWidget(button('← Back to Lyrics',lambda:self.change_step(1)));self.stack.addWidget(page)
 def change_step(self,i):
  self.stack.setCurrentIndex(i)
  for j,b in enumerate(self.step_buttons):b.setChecked(i==j);b.setStyleSheet('background:#5b48a5' if i==j else '')
  self.refresh()
 def add_songs(self):
  start=self.settings.value('batch/last_audio_folder',str(Path.home()),type=str)
  files,_=QFileDialog.getOpenFileNames(self,'Add songs',start,'Audio files (*.mp3 *.wav *.flac *.m4a *.aac *.ogg *.opus *.wma)')
  if files:self.settings.setValue('batch/last_audio_folder',str(Path(files[0]).parent));self.insert_paths(files)
 def add_folder(self):
  folder=QFileDialog.getExistingDirectory(self,'Add audio folder',self.settings.value('batch/last_audio_folder',str(Path.home()),type=str))
  if folder:
   self.settings.setValue('batch/last_audio_folder',folder)
   self.insert_paths([str(p) for p in sorted(Path(folder).iterdir()) if p.is_file() and p.suffix.lower() in AUDIO])
 def insert_paths(self,paths):
  existing={str(Path(x['path']).resolve()).casefold() for x in self.songs};added=0
  for path in paths:
   p=Path(path)
   if not p.is_file() or p.suffix.lower() not in AUDIO:continue
   key=str(p.resolve()).casefold()
   if key in existing:continue
   title,artist=self.detect_information(p)
   self.songs.append({'path':str(p.resolve()),'lyrics':'','title':title,'artist':artist,'display_name':self.format_name(title,artist),'name_confirmed':False});existing.add(key);added+=1
  self.save();self.refresh()
  if not added and paths:QMessageBox.information(self,'Batch queue','No new songs added. Existing files were skipped.')
 def select_song(self,row):
  if row<0 or row>=len(self.songs):return
  self.selected=row
  self.editor.blockSignals(True);self.editor.setPlainText(self.songs[row]['lyrics']);self.editor.blockSignals(False)
  self.lyrics_title.setText('Lyrics — '+self.song_name(self.songs[row]))
  for widget in (self.setup_list,self.lyrics_list):
   if widget.currentRow()!=row:widget.blockSignals(True);widget.setCurrentRow(row);widget.blockSignals(False)
 def format_name(self,title,artist):
  return ' — '.join(x for x in (str(artist or '').strip(),str(title or '').strip()) if x)
 def detect_information(self,path):
  # Use the SAME Song-tab metadata reader and cleanup logic, passed by the host.
  if self.metadata_reader:
   try:title,artist=self.metadata_reader(str(path))
   except Exception:title,artist=path.stem,''
  else:title,artist=path.stem,''
  if self.information_cleaner:
   try:title,artist=self.information_cleaner(title,artist,str(path))
   except Exception:pass
  return (str(title or '').strip() or clean_song_name(path.stem),str(artist or '').strip())
 def song_name(self,s):
  if s.get('title'):
   return self.format_name(s['title'],s.get('artist',''))
  return s.get('display_name') or clean_song_name(Path(s['path']).stem)
 def rename_song(self):
  if not 0<=self.selected<len(self.songs):return
  song=self.songs[self.selected]
  path=Path(song['path'])
  detected_title,detected_artist=self.detect_information(path)
  original_title=song.get('title','')
  original_artist=song.get('artist','')
  if not original_title:
   # Migrate legacy one-field Batch names without losing the user's custom name.
   legacy=song.get('display_name','').strip()
   if legacy and song.get('name_confirmed'):
    original_title,original_artist=legacy,''
   elif legacy and legacy!=clean_song_name(path.stem):
    original_title,original_artist=legacy,''
   else:original_title,original_artist=detected_title,detected_artist
  dialog=QDialog(self);dialog.setWindowTitle('Confirm Song Information — Batch');dialog.resize(540,270)
  layout=QVBoxLayout(dialog)
  note=QLabel('Edit song title and artist separately. Only the Batch display information changes; the original audio file is untouched.')
  note.setWordWrap(True);layout.addWidget(note)
  form=QFormLayout();title_edit=QLineEdit(original_title);artist_edit=QLineEdit(original_artist)
  form.addRow('Song title',title_edit);form.addRow('Artist',artist_edit);layout.addLayout(form)
  info=QLabel('Detected using the Song tab metadata and filename cleanup rules.');info.setWordWrap(True);layout.addWidget(info)
  layout.addStretch();actions=QHBoxLayout();layout.addLayout(actions)
  def restore_detected():
   title_edit.setText(detected_title);artist_edit.setText(detected_artist)
  actions.addWidget(button('Restore Detected',restore_detected))
  actions.addWidget(button('Cancel',dialog.reject))
  actions.addWidget(button('OK — Save',dialog.accept))
  if dialog.exec()!=QDialog.Accepted:return
  title=title_edit.text().strip();artist=artist_edit.text().strip()
  if not title:
   QMessageBox.warning(self,'Song information','Song title cannot be empty.');return
  song.update(title=title,artist=artist,display_name=self.format_name(title,artist),name_confirmed=True)
  self.save();self.refresh()
 def advance_after_lyrics_paste(self):
  """Save first, then advance to the next unfilled song after a real paste."""
  row=self.selected
  if not (0<=row<len(self.songs)):return
  text=self.editor.toPlainText()
  if not text.strip():return
  self.songs[row]['lyrics']=text
  self.save()
  self.refresh(keep_selection=True)
  next_row=next((i for i in range(row+1,len(self.songs)) if not self.songs[i].get('lyrics','').strip()),None)
  if next_row is None:
   if self.songs and all(song.get('lyrics','').strip() for song in self.songs):
    QTimer.singleShot(0,self.show_lyrics_ready_popup)
   return
  # Deferred so the editor's paste handling has fully completed.
  QTimer.singleShot(0,lambda r=row,n=next_row:self._select_next_after_paste(r,n))
 def show_lyrics_ready_popup(self):
  """Offer review or processing only after every queued song has saved lyrics."""
  if not self.songs or not all(song.get('lyrics','').strip() for song in self.songs):
   return
  if self.stack.currentIndex()!=1:return
  dlg=QDialog(self)
  dlg.setWindowTitle('All Batch Lyrics Ready')
  dlg.setModal(True)
  dlg.setMinimumWidth(430)
  layout=QVBoxLayout(dlg)
  title=QLabel('✓ All lyrics pasted successfully!')
  title.setStyleSheet('color:#70df91;font-size:18px;font-weight:700')
  layout.addWidget(title)
  layout.addWidget(QLabel(f'{len(self.songs)} of {len(self.songs)} songs have saved lyrics.'))
  layout.addWidget(QLabel('Review your songs one last time, or continue to Processing.'))
  actions=QHBoxLayout()
  review=QPushButton('Close — Review Lyrics')
  review.clicked.connect(dlg.reject)
  proceed=next_button('Next: Processing →',dlg.accept)
  actions.addWidget(review)
  actions.addWidget(proceed)
  layout.addLayout(actions)
  if dlg.exec()==QDialog.Accepted:
   # Navigation only. Processing never starts without the Start button.
   if self.songs and all(song.get('lyrics','').strip() for song in self.songs):
    self.change_step(2)

 def _select_next_after_paste(self,previous,next_row):
  if self.selected!=previous or not (0<=next_row<len(self.songs)):return
  self.select_song(next_row)
  self.editor.setFocus()

 def lyrics_changed(self):
  if 0<=self.selected<len(self.songs):self.songs[self.selected]['lyrics']=self.editor.toPlainText();self.save();self.refresh(keep_selection=True)
 def remove_song(self):
  if not 0<=self.selected<len(self.songs):return
  self.songs.pop(self.selected);self.selected=min(self.selected,len(self.songs)-1);self.save();self.refresh()
 def clear_queue(self):
  if not self.songs:return
  if QMessageBox.question(self,'Clear batch queue','Remove all entries from the queue? Original audio files will NOT be deleted.',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
  self.songs=[];self.selected=-1;self.save();self.refresh()
 def move(self,direction):
  i=self.selected;j=i+direction
  if i<0 or j<0 or j>=len(self.songs):return
  self.songs[i],self.songs[j]=self.songs[j],self.songs[i];self.selected=j;self.save();self.refresh()
 def refresh(self,keep_selection=False):
  self.count.setText(f'{len(self.songs)} songs in queue')
  for widget in (self.setup_list,self.lyrics_list):
   widget.blockSignals(True);widget.clear()
   for i,s in enumerate(self.songs):
    label=('✓' if s['lyrics'].strip() else '○')
    item=QListWidgetItem(f'{i+1}.  {self.song_name(s)}')
    item.setData(Qt.UserRole,bool(s['lyrics'].strip()))
    widget.addItem(item)
   widget.setCurrentRow(self.selected);widget.blockSignals(False)
  if self.selected>=0 and self.selected<len(self.songs) and not keep_selection:self.select_song(self.selected)
  if not self.songs:self.editor.blockSignals(True);self.editor.clear();self.editor.blockSignals(False);self.lyrics_title.setText('Select a song from the queue')
  done=sum(bool(s['lyrics'].strip()) for s in self.songs)
  self.progress_label.setText(f'{done} of {len(self.songs)} songs have lyrics')
  self.lyrics_progress.setValue(round(100*done/len(self.songs)) if self.songs else 0)
  self.process_summary.setText(f"{len(self.songs)} songs queued · {done} with lyrics · {sum(s.get('batch_status')=='completed' for s in self.songs)} completed · {sum(s.get('batch_status')=='failed' for s in self.songs)} failed")
 def choose_backgrounds(self):
  folder=QFileDialog.getExistingDirectory(self,'Approved background images',self.bg_path.text() or str(Path.home()))
  if folder:self.bg_path.setText(folder);self.load_images();self.save()
 def load_images(self):
  p=Path(self.bg_path.text());self.images=[str(f) for f in sorted(p.iterdir()) if f.is_file() and f.suffix.lower() in IMAGES] if p.is_dir() else []
  # Retain the remaining shuffle cycle when rescanning the same approved folder.
  self.shuffle_bag=[x for x in self.shuffle_bag if x in self.images]
  self.shuffle_history=[x for x in self.shuffle_history if x in self.images]
  self.image_list.clear()
  for path in self.images:self.image_list.addItem(Path(path).name)
  self.bg_preview.setText(f'{len(self.images)} approved images found' if self.images else 'No supported images found')
 def preview_next_background(self):
  path=self.next_background_path()
  if not path:return
  pm=QPixmap(path)
  if not pm.isNull():self.bg_preview.setPixmap(pm.scaled(320,145,Qt.KeepAspectRatio,Qt.SmoothTransformation))
  self.image_list.setCurrentRow(self.images.index(path))

 def next_background_path(self):
  """Consume one approved image from the persistent no-repeat shuffle bag."""
  if not self.images:return None
  if not self.shuffle_bag:
   self.shuffle_bag=self.images.copy();random.shuffle(self.shuffle_bag)
   if len(self.images)>1 and self.shuffle_history and self.shuffle_bag[-1]==self.shuffle_history[-1]:
    self.shuffle_bag[0],self.shuffle_bag[-1]=self.shuffle_bag[-1],self.shuffle_bag[0]
  path=self.shuffle_bag.pop();self.shuffle_history.append(path)
  self.save()
  return path

 def background_for_song(self,index):
  """Assign once, reuse on retry; do not alter source images."""
  if not 0 <= index < len(self.songs):return None
  song=self.songs[index]
  previous=song.get('background')
  if previous and Path(previous).is_file():return previous
  path=self.next_background_path()
  if path:
   song['background']=path
   self.save()
  return path
 def open_batch_output_folder(self):
  folder=Path(self.output_path.text().strip()).expanduser()
  if not folder.is_dir():
   QMessageBox.warning(self,'Output folder unavailable',f'The selected output folder does not exist yet:\n{folder}\n\nSelect an existing output folder in Batch Setup.')
   return
  if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder.resolve()))):
   QMessageBox.warning(self,'Could not open folder',f'Windows could not open:\n{folder}')
 def choose_output(self):
  folder=QFileDialog.getExistingDirectory(self,'Batch output folder',self.output_path.text() or str(Path.home()))
  if folder:self.output_path.setText(folder);self.save()
 def save(self):
  data={'songs':self.songs,'background_folder':self.bg_path.text(),'output_folder':self.output_path.text(),
        'visualizer':self.visualizer.isChecked(),'particles':self.particles.isChecked(),
        'auto_open':self.open_folder.isChecked(),
        'shuffle_bag':self.shuffle_bag,'shuffle_history':self.shuffle_history}
  self.settings.setValue('batch/workspace',json.dumps(data,ensure_ascii=False))
 def restore(self):
  try:data=json.loads(self.settings.value('batch/workspace','{}'))
  except (ValueError,TypeError):data={}
  self.songs=[s for s in data.get('songs',[]) if isinstance(s,dict) and Path(s.get('path','')).is_file()]
  for song in self.songs:
   if 'title' not in song:
    path=Path(song['path']);detected_title,detected_artist=self.detect_information(path)
    legacy=song.get('display_name','').strip()
    if legacy and legacy!=clean_song_name(path.stem):
     song.update(title=legacy,artist='',name_confirmed=True)
    else:song.update(title=detected_title,artist=detected_artist,name_confirmed=False)
    song['display_name']=self.format_name(song['title'],song['artist'])
  self.bg_path.setText(data.get('background_folder',''));self.output_path.setText(data.get('output_folder',''))
  self.visualizer.setChecked(data.get('visualizer',False));self.particles.setChecked(data.get('particles',True));self.open_folder.setChecked(data.get('auto_open',True))
  for checkbox in (self.visualizer,self.particles,self.open_folder):checkbox.toggled.connect(self.save)
  self.load_images()
  # Restore only approved files that still exist; preserve the current cycle.
  self.shuffle_bag=[x for x in data.get('shuffle_bag',[]) if x in self.images]
  self.shuffle_history=[x for x in data.get('shuffle_history',[]) if x in self.images]
  self.selected=0 if self.songs else -1;self.refresh()
