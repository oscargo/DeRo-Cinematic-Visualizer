# v0.2.1.31 — Setup three-column layout fix

- Keep Setup in three columns on maximized desktop windows.
- Stack panels only when available width is under 1080 px.
- Arrange Song Queue controls in two rows of three, preventing buttons from forcing the queue panel excessively wide.
- Preserve v0.2.1.30 celebration and audio changes.
- No user project data or renderer changes.
- Windows GUI not tested in this environment.
