# DeRo Sync v0.2.1.43 — Export benchmark baseline

## Scope

Benchmarked the production `Main.studio_export_command` command generator through FFmpeg with synthetic 1-second sine-wave audio and ASS lyrics, 640×360 at 60 fps, libx264. Each measured output was checked with FFprobe for audio and video streams. Three repetitions per completed configuration.

| Visualizer | Particles | Median elapsed time |
|---|---|---:|
| OFF | OFF | 0.2539 s |
| OFF | ON | 0.2432 s |

These times are not predictive of full-length 1920×1080 NVIDIA NVENC performance. Small variations can be noise, and no speed improvement has been established. The production application source was not modified.

## Limitation

An attempted visualizer-ON benchmark was killed by the Linux test environment (FFmpeg exit -9, no diagnostic stderr). This is not evidence of a Windows app defect, and those cases are not included in the benchmark summary. Avoid drawing conclusions about the visualizer's performance until tested on a machine with sufficient resources.

## Regression

`python run_regression_tests.py`: 63 tests, all passing (4.353 seconds in this run).

## Next recommended test

Run equivalent baseline measurements on the user's Windows RTX 4080 machine, including 1080p60, NVENC, 15–30 second export sections, and all four visualizer/particles combinations. Record wall-clock time, output frames, dropped frames, audio/video synchronization, and visual fidelity before changing any export implementation.

## Reproduce

`python benchmark_export_43.py --runs 3 --output EXPORT_BENCHMARK_RESULTS.json`

This script deliberately measures only visualizer-OFF combinations because the visualizer-ON command exhausted this test environment. The original app and tests are unchanged.
