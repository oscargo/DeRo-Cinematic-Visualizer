"""Behavioral integration checks: cache I/O and real FFmpeg MP4 probe."""
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

import alignment_cache
import export_audit

class CacheRuntimeTests(unittest.TestCase):
    def test_cache_roundtrip_and_identity_invalidation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            audio = root / "song.wav"
            audio.write_bytes(b"RIFF" + b"\0" * 64)
            stems = root / "stems"
            stems.mkdir()
            for name in ("vocals.wav", "no_vocals.wav"):
                (stems / name).write_bytes(b"RIFF" + b"\0" * 64)
            identity = alignment_cache.make_identity(audio, "hello world", stems, "htdemucs", "tiny", "en")
            project = {"events": [1], "word_timings": [2], "alignment_status": "done"}
            self.assertIsNone(alignment_cache.load_cached_alignment(root, identity))
            path = alignment_cache.save_cached_alignment(root, identity, project, {"test": True})
            self.assertTrue(path.is_file())
            self.assertEqual(alignment_cache.load_cached_alignment(root, identity)["word_timings"], [2])
            other = alignment_cache.make_identity(audio, "changed lyrics", stems, "htdemucs", "tiny", "en")
            self.assertNotEqual(identity["key"], other["key"])
            self.assertIsNone(alignment_cache.load_cached_alignment(root, other))
            path.write_text("not json", encoding="utf-8")
            self.assertIsNone(alignment_cache.load_cached_alignment(root, identity))

    def test_incomplete_cache_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):
                alignment_cache.save_cached_alignment(tmp, {"key": "dummy", "identity": {}}, {"events": []}, {})

class Mp4RuntimeTests(unittest.TestCase):
    def test_real_generated_mp4_probe(self):
        ffmpeg = shutil.which("ffmpeg")
        ffprobe = shutil.which("ffprobe")
        if not ffmpeg or not ffprobe:
            self.skipTest("FFmpeg and ffprobe required for real container test")
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "test.mp4"
            cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "color=c=black:s=1920x1080:r=60:d=0.2", "-f", "lavfi", "-i", "sine=frequency=440:duration=0.2", "-c:v", "mpeg4", "-q:v", "12", "-c:a", "aac", "-shortest", str(output)]
            subprocess.run(cmd, check=True, capture_output=True, timeout=35)
            result = export_audit.verify_mp4(output, expected_duration=0.2)
            self.assertEqual(result["result"], "PASS", result)
            self.assertEqual(result["resolution"], [1920, 1080])
            self.assertEqual(result["frame_rate"], "60/1")
            self.assertGreater(result["bytes"], 1024)

    def test_missing_mp4_is_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = export_audit.verify_mp4(Path(tmp) / "missing.mp4")
            self.assertEqual(result["result"], "FAIL")
