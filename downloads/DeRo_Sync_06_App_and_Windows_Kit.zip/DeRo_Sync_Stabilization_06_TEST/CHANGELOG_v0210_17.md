# v0.2.1.17 — Batch Processing Beta

- Enabled sequential Batch Processing button and per-song progress log.
- Connected Demucs separation, WhisperX alignment and original DeRo Visualizer export in series.
- Skips low-confidence alignment, records failures and advances.
- Non-interactive batch save paths, collision-safe filenames, editable project JSON per successful export.
- Preserves interactive single-song dialogs and particle renderer.
- **Not tested on Windows/GPU or real songs. Test with one song first.**
