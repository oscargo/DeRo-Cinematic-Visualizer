# v0.2.1.23 — Batch Settings layout

- Output folder path appears directly below Select Output Folder.
- Settings panel scrolls vertically at smaller window sizes to avoid controls overlapping or clipping.
- Existing batch-processing behavior preserved.
- Windows GUI verification pending.
