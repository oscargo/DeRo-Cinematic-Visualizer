# v0.2.1.24 — Batch export duration fix

- Batch Visualizer exports now use the actual prepared audio duration instead of the original source duration, preventing false export-range rejection when the 100%/20% stem mix is shorter.
- Manual export selection remains unchanged.
- Retains batch and layout features from v0.2.1.23.
- Python syntax and static regression tests only; Windows rendering remains unverified.
