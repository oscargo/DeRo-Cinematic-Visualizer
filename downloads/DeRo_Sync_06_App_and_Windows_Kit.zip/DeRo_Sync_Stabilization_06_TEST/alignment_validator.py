"""DeRo Sync v0.2.1.36 — read-only synchronization quality diagnostics.
No timing modification, export blocking, or lyrics normalization.
"""
import json
import math
from pathlib import Path


def inspect_project(project):
    events = project.get('events') or []
    statuses = project.get('alignment_status') or {}
    word_timings = project.get('word_timings') or {}
    scores = project.get('word_scores') or {}
    findings = []
    counts = {key: sum(value == key for value in statuses.values()) for key in ('aligned', 'partial', 'estimated', 'failed')}
    total = len(events)
    def add(index, code, severity, detail):
        findings.append({'line': index + 1, 'code': code, 'severity': severity, 'detail': detail})
    previous_end = None
    for index, event in enumerate(events):
        if not isinstance(event, (list, tuple)) or len(event) < 3:
            add(index, 'malformed_event', 'critical', 'Event lacks start/end/text')
            continue
        try:
            start, end = float(event[0]), float(event[1])
        except (ValueError, TypeError):
            add(index, 'invalid_timestamp', 'critical', 'Non-numeric event timestamp')
            continue
        if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end <= start:
            add(index, 'invalid_span', 'critical', f'Invalid span {start}–{end}')
            continue
        words = str(event[2]).split()
        duration = end - start
        if words and duration < .12 * len(words):
            add(index, 'compressed_line', 'critical', f'{len(words)} words in {duration:.2f}s (below 0.12s/word)')
        elif words and duration < .20 * len(words):
            add(index, 'fast_line', 'warning', f'{len(words)} words in {duration:.2f}s (below 0.20s/word)')
        if len(words) <= 8 and duration > 15:
            add(index, 'long_short_line', 'warning', f'{len(words)} words assigned {duration:.1f}s')
        if previous_end is not None and start - previous_end > 15:
            add(index, 'large_gap', 'info', f'{start-previous_end:.1f}s gap before this line; may be instrumental')
        if previous_end is not None and previous_end - start > 1.0:
            add(index, 'overlap', 'warning', f'{previous_end-start:.2f}s overlap with previous event; may be backing vocals')
        previous_end = max(previous_end if previous_end is not None else end, end)
        entries = word_timings.get(str(index), []) if isinstance(word_timings, dict) else []
        if isinstance(entries, list):
            for entry in entries:
                if not isinstance(entry, (list, tuple)) or len(entry) < 2:
                    continue
                try:
                    a,b=float(entry[0]),float(entry[1])
                except (ValueError,TypeError):
                    continue
                if math.isfinite(a) and math.isfinite(b) and b <= a:
                    add(index,'invalid_word_span','critical',f'Word duration {b-a:.3f}s')
                    break
    estimated_ratio = counts['estimated'] / max(1, len(statuses))
    if estimated_ratio > .20:
        findings.append({'line': None, 'code': 'high_estimated_ratio', 'severity': 'critical', 'detail': f'{counts["estimated"]}/{len(statuses)} lines estimated ({estimated_ratio:.1%}); 20% diagnostic threshold'})
    if counts['failed']:
        findings.append({'line': None, 'code': 'failed_lines', 'severity': 'critical', 'detail': f'{counts["failed"]} lines marked failed'})
    severity_counts = {severity: sum(f['severity'] == severity for f in findings) for severity in ('critical','warning','info')}
    return {'schema': 1, 'validator_version': '0.2.1.36', 'mode': 'REPORT_ONLY', 'total_lines': total, 'alignment_counts': counts, 'estimated_ratio': round(estimated_ratio,4), 'finding_counts': severity_counts, 'findings': findings, 'interpretation': 'Diagnostic heuristics only; listen to the audio to establish actual correctness. Gaps and overlaps may be legitimate.'}


def save_report(project, path):
    report = inspect_project(project)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    return report


def main():
    import argparse
    parser=argparse.ArgumentParser(description='Read-only DeRo Sync karaoke JSON timing report')
    parser.add_argument('project',help='Path to .karaoke.json')
    parser.add_argument('--output',help='Output JSON report path (default: beside project)')
    args=parser.parse_args()
    source=Path(args.project)
    target=Path(args.output) if args.output else source.with_name(source.stem + '_alignment_report.json')
    report=save_report(json.loads(source.read_text(encoding='utf-8')), target)
    print('Report:', target)
    print('Lines:', report['total_lines'], 'Statuses:', report['alignment_counts'])
    print('Findings:', report['finding_counts'])
    print('No original files were modified.')

if __name__=='__main__':
    main()
