# DeRo Sync v0.2.1.11 — Shared Song metadata in Batch

- Batch imports use the existing Song tab metadata_from_audio and suggest_song_information functions.
- Separate editable Song title and Artist fields in Batch Rename Song and double-click.
- Restore Detected rereads the source and applies Song tab cleanup.
- Manual corrections are preserved across sessions; audio files are never renamed or edited.
- Existing Batch entries are migrated, retaining custom display names where distinguishable.
- Batch processing remains a preparation-only preview.
