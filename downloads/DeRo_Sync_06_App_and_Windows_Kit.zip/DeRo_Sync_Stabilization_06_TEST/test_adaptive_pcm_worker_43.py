"""Exercise the real QThread launch and bounded PCM decode, not only waveform source text."""
import importlib.util,unittest,tempfile,wave,math,struct,shutil
from pathlib import Path
try:
 from PySide6.QtWidgets import QApplication
 HAVE_QT=True
except ImportError:HAVE_QT=False
@unittest.skipUnless(HAVE_QT,'PySide6 required for actual adaptive waveform worker')
class AdaptiveWorkerTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  if not shutil.which('ffmpeg'):raise unittest.SkipTest('FFmpeg required')
  cls.qt=QApplication.instance() or QApplication([]);p=Path(__file__).with_name('DeRo_Sync_v0210_43_Popper_Direction_Fix.py');spec=importlib.util.spec_from_file_location('adaptive_worker_test_app',p);cls.m=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.m)
 def test_launch_decodes_selected_pcm_window(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'tone.wav'
   with wave.open(str(path),'wb') as wav:
    wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(48000);wav.writeframes(b''.join(struct.pack('<h',round(1000*math.sin(2*math.pi*440*i/48000))) for i in range(24000)))
   worker=self.m.AdaptivePcmWindowWorker(str(path),'fixture',.1,.3);results=[];worker.ready.connect(lambda *values:results.append(values))
   worker.start();self.assertTrue(worker.wait(5000),'PCM worker did not finish');self.qt.processEvents()
   self.assertEqual(len(results),1);key,result,error=results[0];self.assertEqual(key,'fixture');self.assertEqual(error,'');self.assertAlmostEqual(result[0],.1);self.assertAlmostEqual(result[1],.3,places=4);self.assertEqual(len(result[2]),1200);self.assertTrue(any(lo<0<hi for lo,hi in result[2]))
