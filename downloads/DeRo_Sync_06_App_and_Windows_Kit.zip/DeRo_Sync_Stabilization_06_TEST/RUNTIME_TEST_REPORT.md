# v0.2.1.43 Runtime Integration Test Report

New checks: alignment-cache write/read/invalidation/corrupt file, incomplete cache rejection, real FFmpeg-generated 1080p60 MP4 with audio and ffprobe audit, and missing MP4 handling.

Result: PASS

Batch favorite lyrics integration static checks passed
Batch static safety checks passed
Discovered 57 regression tests

.........................................................
----------------------------------------------------------------------
Ran 57 tests in 2.484s

OK


Limitations: generated MP4 does not exercise the full DeRo GUI/export pipeline or lyric rendering. Windows-specific testing remains necessary.
