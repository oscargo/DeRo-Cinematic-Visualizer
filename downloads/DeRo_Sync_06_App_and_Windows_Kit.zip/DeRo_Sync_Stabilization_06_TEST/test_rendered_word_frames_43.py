"""Render the production ASS word timing with libass and verify visible progression."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

from test_ass_word_timing_runtime_43 import production_renderer


class RenderedWordFramesTests(unittest.TestCase):
    def test_word_highlighting_changes_rendered_frames(self):
        ffmpeg = shutil.which('ffmpeg')
        if not ffmpeg:
            self.skipTest('FFmpeg unavailable')
        try:
            from PIL import Image, ImageChops
        except ImportError:
            self.skipTest('Pillow unavailable')
        project = {
            'events': [[0.0, 2.0, 'Hello world']],
            'word_timings': {'0': [[0.2, 0.7, 'Hello'], [1.1, 1.6, 'world']]},
            'lyric_display_mode': 'single', 'lyric_countdown': False,
            'opening_progress_enabled': False,
        }
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ass = root / 'words.ass'
            production_renderer()(project, ass, 640, 360)
            content = ass.read_text(encoding='utf-8-sig')
            self.assertIn(r'{\kf90}Hello ', content)
            self.assertIn(r'{\kf90}world', content)
            frames = []
            for index, seconds in enumerate((0.05, 0.5, 1.4)):
                output = root / f'frame_{index}.png'
                # FFmpeg's subtitles filter uses libass, matching the studio's export path.
                cmd = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-y',
                       '-f', 'lavfi', '-i', 'color=c=black:s=640x360:r=30:d=2',
                       '-vf', f'ass=filename={ass.as_posix()}', '-ss', str(seconds),
                       '-frames:v', '1', str(output)]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=25)
                if result.returncode != 0:
                    self.fail(f'FFmpeg/libass frame render failed: {result.stderr[-1500:]}')
                with Image.open(output) as image:
                    frames.append(image.convert('RGB').copy())
            def changed_pixels(a, b):
                diff = ImageChops.difference(a, b)
                return sum(1 for pixel in diff.getdata() if max(pixel) > 15)
            # A static background and text position make frame differences attributable
            # to karaoke color progression, not animation or moving elements.
            self.assertGreater(changed_pixels(frames[0], frames[1]), 50,
                               'First word onset did not visibly change highlighted pixels')
            self.assertGreater(changed_pixels(frames[1], frames[2]), 50,
                               'Second word onset did not visibly change highlighted pixels')

if __name__ == '__main__':
    unittest.main()
