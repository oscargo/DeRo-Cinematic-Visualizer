# Audio duration fallback diagnostics — v0.2.1.43 maintenance

- Record DEBUG traceback when Mutagen, SoundFile, ffprobe, or FFmpeg duration detection fails and the next method is tried.
- Record a WARNING when all duration detection methods fail.
- Preserve fallback order, return thresholds, subprocess commands, timeout values, and final user-visible error.
- Add a regression guard checking all four fallback handlers.
- No Windows GUI or real export validation performed.
