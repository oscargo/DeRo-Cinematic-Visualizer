# DeRo Sync v0.2.1.42 — Celebration Replay Test

- Adds a Replay Celebration button to the main toolbar.
- Replays the same full-size foreground double-popper/confetti effect and original four-note WAV without export.
- Does not modify export status, project, or timing data.
- Repeated presses restart the animation.
- Source based on v0.2.1.41; Windows GUI playback not tested here.
