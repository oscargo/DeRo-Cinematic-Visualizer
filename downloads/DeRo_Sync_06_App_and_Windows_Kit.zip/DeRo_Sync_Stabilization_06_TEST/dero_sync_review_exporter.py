"""Offline DeRo Sync review exporter. Stdlib + installed FFmpeg; no Qt imports."""
import base64
import json
import math
import subprocess
import zlib
from pathlib import Path
from html import escape

SAMPLE_RATE = 16000

def build_review_html(project, vocals_path, output_path, ffmpeg="ffmpeg", progress=None):
    """Create one self-contained HTML with 16kHz PCM audio, interactive waveform and exact word times."""
    vocals_path = Path(vocals_path)
    if not vocals_path.is_file():
        raise FileNotFoundError(f"Vocal track missing: {vocals_path}")
    # FFmpeg performs channel downmix and sample-rate conversion once. Preserve
    # original stored word times; never re-align, round or modify the project.
    cmd = [str(ffmpeg), "-nostdin", "-hide_banner", "-loglevel", "error",
           "-i", str(vocals_path), "-map", "0:a:0", "-vn",
           "-ac", "1", "-ar", str(SAMPLE_RATE), "-f", "s16le", "pipe:1"]
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"FFmpeg executable not found: {ffmpeg!s}. Install FFmpeg or provide its full executable path.") from exc
    if result.returncode != 0:
        raise RuntimeError("FFmpeg could not decode vocals: " +
                           result.stderr.decode("utf-8", "replace")[-1800:])
    pcm = result.stdout
    if not pcm or len(pcm) % 2:
        raise ValueError("No valid vocal PCM data returned by FFmpeg")
    if progress:
        progress("Compressing review audio and waveform...")
    packed = base64.b64encode(zlib.compress(pcm, 6)).decode("ascii")
    lines = []
    events = project.get("events", [])
    word_map = project.get("word_timings", {})
    statuses = project.get("alignment_status", {})
    overrides = project.get("manual_overrides", {})
    for i, event in enumerate(events):
        if not isinstance(event, (list, tuple)) or len(event) < 3:
            continue
        try:
            start, end = float(event[0]), float(event[1])
        except (TypeError, ValueError):
            continue
        if not (math.isfinite(start) and math.isfinite(end) and 0 <= start <= end):
            raise ValueError(f"Invalid lyric line timing at line {i+1}")
        words = []
        for w in word_map.get(str(i), []):
            if not isinstance(w, (list, tuple)) or len(w) < 3:
                continue
            try:
                a, b = float(w[0]), float(w[1])
            except (TypeError, ValueError):
                continue
            if math.isfinite(a) and math.isfinite(b) and 0 <= a <= b:
                words.append({"start": a, "end": b, "text": str(w[2])})
        lines.append({"index": i, "start": start, "end": end,
                      "text": str(event[2]), "status": str(statuses.get(str(i), "unknown")),
                      "manual": bool(overrides.get(str(i), False)), "words": words})
    payload = {"song": str(project.get("song", "Untitled")),
               "artist": str(project.get("artist", "")),
               "sampleRate": SAMPLE_RATE, "samples": len(pcm)//2,
               "duration": len(pcm)/(2*SAMPLE_RATE),
               "lines": lines}
    html = _template().replace("__PAYLOAD__", json.dumps(payload, ensure_ascii=False, allow_nan=False).replace("</", "<\\/"))
    html = html.replace("__PCM_BASE64__", packed)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    return {"path": str(output_path), "bytes": output_path.stat().st_size,
            "lines": len(lines), "words": sum(len(line["words"]) for line in lines),
            "duration": payload["duration"]}

def _template():
    return r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>DeRo Sync — Waveform Review</title>
<style>
:root{color-scheme:dark;font-family:Segoe UI,Arial,sans-serif}
*{box-sizing:border-box}body{margin:0;background:#0a1121;color:#e7edff}
header{padding:12px 18px;background:#17243e;display:flex;align-items:center;gap:14px;flex-wrap:wrap}
h1{font-size:19px;margin:0}button,input,select{font:inherit}button,select{background:#283a59;border:1px solid #526381;color:#f1f5ff;border-radius:7px;padding:7px 11px;cursor:pointer}
button:hover{background:#405678}input[type=range]{accent-color:#a588ff}
section{padding:12px 18px}.controls{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
#overview,#detail{width:100%;display:block;border:1px solid #344766;background:#0d192f;cursor:crosshair}
#overview{height:100px}#detail{height:410px;touch-action:pan-y}
#info{padding:10px 12px;background:#17243e;border-radius:8px;min-height:48px;font-variant-numeric:tabular-nums}
#lines{height:185px;overflow:auto;border:1px solid #344766;border-radius:8px}
.line{display:flex;gap:12px;padding:8px 12px;border-bottom:1px solid #243550;cursor:pointer}
.line:hover,.line.active{background:#33476e}.tag{min-width:88px;font-size:12px;color:#a9c5e6}
small{color:#b8c9e2}.hint{margin:8px 0;color:#aebfdc}
</style></head><body>
<header><h1>DeRo Sync — Full Song Review</h1><strong id="song"></strong><small id="meta"></small></header>
<section><div class="controls">
<button id="play">▶ Play / Pause</button><button id="zoomout">Zoom −</button>
<label>Zoom <input id="zoom" type="range" min="0" max="1000" value="230" style="width:200px"></label>
<button id="zoomin">Zoom +</button><button id="fit">Fit Song</button>
<label>Go to (seconds) <input id="goto" type="number" min="0" step="0.001" style="width:110px"></label><button id="jump">Go</button>
<button id="png">Save visible view as PNG</button><button id="json">Save exact timestamps JSON</button>
</div><p class="hint">Click a word box to inspect its exact stored start/end. Wheel over waveform to scroll; Ctrl+wheel to zoom. Drag to pan. Click the overview to jump. Selected word stays 25% from left when zooming.</p>
<canvas id="overview"></canvas></section>
<section style="padding-top:0"><canvas id="detail"></canvas><div id="info">Loading audio-derived waveform…</div></section>
<section style="padding-top:0"><strong>Lyric lines — click to jump</strong><div id="lines"></div></section>
<script>
const DATA=__PAYLOAD__;
const PACKED="__PCM_BASE64__";
const $=id=>document.getElementById(id);
$('song').textContent=DATA.song+' — '+DATA.artist;
$('meta').textContent=`${DATA.duration.toFixed(3)}s • ${DATA.lines.length} lines • ${DATA.lines.reduce((n,l)=>n+l.words.length,0)} words • original timestamps retained`;
let samples=null, audio=null, selected=null, start=0, span=DATA.duration, playhead=0, dragging=false, dragX=0, dragStart=0;
const words=DATA.lines.flatMap(l=>l.words.map((w,j)=>({...w,line:l.index,status:l.manual?'manual':l.status,idx:j})));
const colors={aligned:'#77d4b0',partial:'#ffce72',estimated:'#ff8c9d',manual:'#66dfc7',unknown:'#a8c5de'};
function fmt(t){const m=Math.floor(t/60);return `${String(m).padStart(2,'0')}:${(t%60).toFixed(3).padStart(6,'0')}`}
function clamp(x,a,b){return Math.max(a,Math.min(b,x))}
function resizeCanvas(c){const dpr=window.devicePixelRatio||1,w=Math.max(200,c.clientWidth),h=c.clientHeight;
 c.width=Math.round(w*dpr);c.height=Math.round(h*dpr);
 const ctx=c.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);return [ctx,w,h]}
function zoomSpan(){return clamp(DATA.duration*Math.pow(0.001,$('zoom').value/1000),0.12,DATA.duration)}
function syncSlider(){const r=clamp(Math.log(Math.max(0.12,span)/DATA.duration)/Math.log(.001),0,1);$('zoom').value=Math.round(r*1000)}
function setSpan(next){const anchor=selected?(selected.start+selected.end)/2:playhead;
 span=clamp(next,.12,DATA.duration);start=clamp(anchor-span*.25,0,Math.max(0,DATA.duration-span));syncSlider();render()}
function pan(to){start=clamp(to,0,Math.max(0,DATA.duration-span));render()}
function drawWave(ctx,w,top,height,from,seconds,color){
 if(!samples)return;
 const rate=DATA.sampleRate,mid=top+height/2;
 ctx.strokeStyle=color;ctx.lineWidth=1;ctx.beginPath();
 // Each column is independently derived from the original PCM, not stretched pixels.
 const step=seconds/w;
 for(let x=0;x<w;x++){
  const a=clamp(Math.floor((from+x*step)*rate),0,samples.length-1);
  const b=clamp(Math.ceil((from+(x+1)*step)*rate),a+1,samples.length);
  let lo=32767,hi=-32768;
  for(let k=a;k<b;k++){const v=samples[k];if(v<lo)lo=v;if(v>hi)hi=v}
  const scale=height/2/32768;
  ctx.moveTo(x,mid-hi*scale);ctx.lineTo(x,mid-lo*scale);
 }ctx.stroke();
}
function renderOverview(){
 const c=$('overview'),[ctx,w,h]=resizeCanvas(c);ctx.clearRect(0,0,w,h);
 drawWave(ctx,w,8,70,0,DATA.duration,'#8862d5');
 for(const l of DATA.lines){let x=l.start/DATA.duration*w;ctx.fillStyle=colors[l.manual?'manual':l.status]||colors.unknown;ctx.fillRect(x,82,Math.max(2,(l.end-l.start)/DATA.duration*w),5)}
 ctx.fillStyle='#c7b4ff44';ctx.fillRect(start/DATA.duration*w,0,span/DATA.duration*w,h);
 ctx.strokeStyle='#d8c6ff';ctx.strokeRect(start/DATA.duration*w+.5,.5,span/DATA.duration*w,h-1);
}
function renderDetail(){
 const c=$('detail'),[ctx,w,h]=resizeCanvas(c);ctx.clearRect(0,0,w,h);
 const x=t=>(t-start)/span*w;
 const unit=span<=1?.1:span<=5?.5:span<=20?2:span<=60?5:span<=180?15:30;
 ctx.font='12px Segoe UI';ctx.textBaseline='top';
 for(let t=Math.ceil(start/unit)*unit;t<=start+span;t+=unit){
  const xx=x(t);ctx.strokeStyle='#273c59';ctx.beginPath();ctx.moveTo(xx,24);ctx.lineTo(xx,h-16);ctx.stroke();
  ctx.fillStyle='#c3d2ee';ctx.fillText(fmt(t),xx+3,5)
 }
 drawWave(ctx,w,34,Math.max(75,h-190),start,span,'#a57bee');
 const boxY=h-125,boxH=46;
 for(const word of words){
  if(word.end<start||word.start>start+span)continue;
  const a=x(word.start),b=x(word.end),left=Math.max(0,a),right=Math.min(w,b);
  if(right<=left)continue;
  const active=selected===word;
  ctx.fillStyle=active?'#6f4dd7':'#304a70';ctx.fillRect(left,boxY,Math.max(1,right-left),boxH);
  ctx.strokeStyle=active?'#ffd269':colors[word.status]||colors.unknown;
  ctx.lineWidth=active?3:1;ctx.strokeRect(left+.5,boxY+.5,Math.max(1,right-left)-1,boxH-1);
  ctx.strokeStyle=colors[word.status]||colors.unknown;ctx.lineWidth=1;
  ctx.beginPath();ctx.moveTo(a,31);ctx.lineTo(a,boxY+boxH);ctx.moveTo(b,31);ctx.lineTo(b,boxY+boxH);ctx.stroke();
  ctx.fillStyle='#f6f7ff';ctx.textAlign='center';ctx.font='12px Segoe UI';
  if(right-left>15){ctx.save();ctx.beginPath();ctx.rect(left,boxY,right-left,boxH);ctx.clip();ctx.fillText(word.text,(left+right)/2,boxY+10);ctx.restore()}
  if(span<=12&&right-left>48){
   ctx.font='10px Segoe UI';ctx.fillStyle='#c9d7ef';ctx.fillText(`${word.start.toFixed(3)}–${word.end.toFixed(3)}`,(left+right)/2,boxY+28)
  }
 }
 ctx.textAlign='left';ctx.font='12px Segoe UI';ctx.fillStyle='#b9cbe6';
 ctx.fillText(`${fmt(start)} — ${fmt(start+span)}   •   ${Math.round(w/span)} px/s   •   PCM ${DATA.sampleRate.toLocaleString()} samples/s`,8,h-24);
 if(playhead>=start&&playhead<=start+span){ctx.strokeStyle='#ffdb70';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x(playhead),24);ctx.lineTo(x(playhead),h-15);ctx.stroke()}
}
function render(){renderOverview();renderDetail()}
function selectWord(word){
 selected=word;const line=DATA.lines.find(l=>l.index===word.line);
 $('info').textContent=`Line ${word.line+1} (${line?.status||'unknown'}) • "${word.text}" • START ${word.start.toFixed(6)} s • END ${word.end.toFixed(6)} s • DURATION ${(word.end-word.start).toFixed(6)} s`;
 if(word.start<start||word.end>start+span)pan(word.start-span*.25);
 document.querySelectorAll('.line').forEach(el=>el.classList.toggle('active',+el.dataset.index===word.line));
 render();
}
function pointerTime(e,c){return start+(e.offsetX/c.clientWidth)*span}
$('detail').addEventListener('pointerdown',e=>{dragging=true;dragX=e.clientX;dragStart=start;$('detail').setPointerCapture(e.pointerId)});
$('detail').addEventListener('pointermove',e=>{if(dragging&&Math.abs(e.clientX-dragX)>3)pan(dragStart-(e.clientX-dragX)/$('detail').clientWidth*span)});
$('detail').addEventListener('pointerup',e=>{
 if(Math.abs(e.clientX-dragX)<4){
  const t=pointerTime(e,$('detail'));const rect=$('detail').getBoundingClientRect();
  if(e.clientY-rect.top>rect.height-145&&e.clientY-rect.top<rect.height-70){
   const matches=words.filter(w=>w.start<=t&&w.end>=t);if(matches.length)selectWord(matches[0])
  }else{playhead=t;if(audio)audio.currentTime=t;render()}
 }dragging=false;
});
$('detail').addEventListener('wheel',e=>{e.preventDefault();if(e.ctrlKey)setSpan(span*(e.deltaY<0?.8:1.25));else pan(start+e.deltaY/$('detail').clientWidth*span)},{passive:false});
$('overview').addEventListener('pointerdown',e=>{pan(e.offsetX/$('overview').clientWidth*DATA.duration-span*.5)});
$('zoom').oninput=()=>setSpan(zoomSpan());
$('zoomin').onclick=()=>setSpan(span*.7);$('zoomout').onclick=()=>setSpan(span/0.7);
$('fit').onclick=()=>{span=DATA.duration;start=0;syncSlider();render()};
$('jump').onclick=()=>{const t=clamp(Number($('goto').value)||0,0,DATA.duration);playhead=t;if(audio)audio.currentTime=t;pan(t-span*.25)};
$('play').onclick=()=>{if(audio){if(audio.paused)audio.play();else audio.pause()}};
$('png').onclick=()=>{const c=$('detail'),a=document.createElement('a');a.download='DeRo_Sync_Review_'+start.toFixed(3)+'s.png';a.href=c.toDataURL('image/png');a.click()};
$('json').onclick=()=>{const blob=new Blob([JSON.stringify(DATA,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='DeRo_Sync_Exact_Timestamps.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
const lineList=$('lines');
for(const l of DATA.lines){const el=document.createElement('div');el.className='line';el.dataset.index=l.index;
 const tag=document.createElement('span');tag.className='tag';tag.textContent=`${l.index+1} ${l.manual?'MANUAL':l.status.toUpperCase()}`;
 const body=document.createElement('span');body.textContent=`${fmt(l.start)} — ${l.text}`;
 el.append(tag,body);el.onclick=()=>{const w=words.find(w=>w.line===l.index);if(w)selectWord(w);else pan(l.start-span*.25)};
 lineList.append(el)}
async function load(){
 try{
  const binary=atob(PACKED),bytes=new Uint8Array(binary.length);
  for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
  const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate'));
  const raw=await new Response(stream).arrayBuffer();
  samples=new Int16Array(raw);
  // Create a local WAV Blob for optional audio playback. No network requests.
  const wav=new ArrayBuffer(44+raw.byteLength),v=new DataView(wav);
  function txt(offset,text){for(let i=0;i<text.length;i++)v.setUint8(offset+i,text.charCodeAt(i))}
  txt(0,'RIFF');v.setUint32(4,36+raw.byteLength,true);txt(8,'WAVE');txt(12,'fmt ');
  v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);
  v.setUint32(24,DATA.sampleRate,true);v.setUint32(28,DATA.sampleRate*2,true);
  v.setUint16(32,2,true);v.setUint16(34,16,true);txt(36,'data');v.setUint32(40,raw.byteLength,true);
  new Uint8Array(wav,44).set(new Uint8Array(raw));
  audio=new Audio(URL.createObjectURL(new Blob([wav],{type:'audio/wav'})));
  audio.addEventListener('timeupdate',()=>{playhead=audio.currentTime;renderDetail()});
  $('info').textContent='Ready. Select any word box or lyric line to inspect exact stored timestamps.';
  render();
 }catch(err){$('info').textContent='Could not load embedded waveform: '+err.message}
}
window.addEventListener('resize',render);
syncSlider();load();
</script></body></html>"""

# ZIP packaging checksum padding: 00000002
