# DeRo Sync v0.2.1.00 — Integrated Visualizer

This is a separate integration build based on the supplied Sync v0.2.0.80 and Visualizer v0.1.45 archives. Neither source archive is modified.

## Architecture
- PySide6/Qt remains the application GUI.
- The Visualizer v0.1.45 renderer, audio analysis, lyric renderer and export pipeline are reused from `visualizer_engine/`.
- `visualizer_sync_bridge.py` maps Sync project events/word timings into the Visualizer `LyricDocument`, and maps Qt Visualizer settings into the original `Settings` dataclass.
- Export uses the Visualizer single-pass raw-frame-to-FFmpeg pipeline and NVENC auto-selection.
- Diagnostics identify this integrated build as `0.2.1.00-integrated-visualizer`.

## Run
Use `Launch_DeRo_Sync.bat` with Python 3.12. Install the Sync application's existing dependencies plus `requirements-visualizer.txt`. FFmpeg must be installed and discoverable by Sync's `find_ffmpeg()`.

## First-build scope and limitations
This first integration build replaces the Video Designer step with a native Qt Visualizer settings page and routes the final export button through the original Visualizer renderer. It includes core spectrum, particle, background, output, stem-mix and lyric styling controls. It does not yet expose every standalone Visualizer control (title/artist typography, overlay editor, blur/motion blur, all positioning controls, background video, or the full standalone preview editor). Those remain planned follow-on work after regression testing.

The renderer source files are copied from v0.1.45 without modification. The only engine source adjustment is the diagnostics APP_VERSION constant to prevent the known stale 0.1.33 label.

## Verified here
- Python syntax compilation for the main Qt app, bridge and copied engine modules.
- Bridge construction of the Visualizer `Settings` object.
- Sync event/word-timing conversion into `LyricDocument`.
- A 2-second end-to-end smoke export through the integrated bridge, including MP4 probing and diagnostics version verification.
- The PySide6 GUI itself could not be launched in this Linux build environment because PySide6 is not installed here. Windows GUI, full song, NVENC, and regression verification must be run on the user's Windows machine before treating this as a stable release.

## Safety
The original Sync v0.2.0.80 and Visualizer v0.1.45 archives are preserved separately. This build writes Visualizer settings into the Sync project under `visualizer_settings`; existing Sync project data is retained.


## v0.2.1.01
See CHANGELOG_v0210_01.md for UI and export ETA improvements.
