# DeRo Sync v0.2.0.79 — Play Next Word

- Added a **Play Next Word** button to the Word Sync waveform toolbar, between **Play Word** and **Play Next Line**.
- Plays the next synchronized word after the current selection.
- At the end of a lyric line, advances to the first timed word in the next line that contains word timings.
- Selects and brings the target word into view before auditioning it.
- Does not modify stored lyric or word timings.
- Preserves v0.2.0.78 and earlier features, including the recent music folder browser and Lyrics next-action emphasis.

Validation: Python syntax compilation, package integrity, and focused source-level regression checks. GUI playback still requires Windows with the app dependencies and an audio device.
