"""Compare actual word-timing documents; workflow-duration .timing.json is not accepted."""
import argparse,csv,json,math
from pathlib import Path

def document(path):
 d=json.loads(Path(path).read_text(encoding='utf-8-sig'))
 if not isinstance(d,dict):raise ValueError('Expected a JSON object')
 words=d.get('word_timings',d.get('final_word_timings'))
 if not isinstance(words,dict):raise ValueError('No word timings: use a karaoke project or Sync Inspector JSON, not a workflow-duration .timing.json file.')
 result={}
 for line,entries in words.items():
  for i,entry in enumerate(entries):
   if len(entry)!=3:raise ValueError('Malformed timed word')
   a,b=map(float,entry[:2])
   if not all(math.isfinite(v) for v in (a,b)) or a<0 or b<=a:raise ValueError('Invalid word timestamp')
   result[(int(line),i)]=(a,b,str(entry[2]))
 return d,result

def compare(before,after,threshold=.15):
 _,a=document(before);new,b=document(after);rows=[]
 statuses=new.get('alignment_status') or {}
 if not isinstance(statuses,dict):statuses={}
 for key in sorted(set(a)|set(b)):
  old=a.get(key);current=b.get(key);changed=old is None or current is None or old[2]!=current[2]
  da=current[0]-old[0] if old and current else None;db=current[1]-old[1] if old and current else None
  rows.append({'line':key[0]+1,'word':key[1]+1,'before_text':old[2] if old else None,'after_text':current[2] if current else None,'start_delta_ms':round(da*1000,3) if da is not None else None,'end_delta_ms':round(db*1000,3) if db is not None else None,'text_or_word_count_changed':changed,'moved_over_threshold':changed or abs(da)>threshold or abs(db)>threshold,'saved_status':statuses.get(str(key[0]),'unknown')})
 return rows

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('before',type=Path);p.add_argument('after',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--threshold-ms',type=float,default=150);a=p.parse_args()
 if not math.isfinite(a.threshold_ms) or a.threshold_ms<0:p.error('threshold must be finite and non-negative')
 try:rows=compare(a.before,a.after,a.threshold_ms/1000)
 except (OSError,ValueError,TypeError,KeyError) as exc:p.error(str(exc))
 a.output.parent.mkdir(parents=True,exist_ok=True)
 fields=['line','word','before_text','after_text','start_delta_ms','end_delta_ms','text_or_word_count_changed','moved_over_threshold','saved_status']
 with a.output.open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 print(json.dumps({'words_compared':len(rows),'flagged':sum(r['moved_over_threshold'] for r in rows),'scope':'Timestamp/text comparison only; listen to flagged lines to establish accuracy'}))
if __name__=='__main__':main()
