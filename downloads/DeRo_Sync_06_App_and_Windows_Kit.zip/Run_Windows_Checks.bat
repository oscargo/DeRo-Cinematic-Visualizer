@echo off
setlocal
cd /d "%~dp0"
py -3.12 "%~dp0Windows_Acceptance_Kit\acceptance_check.py" --app-dir "%~dp0DeRo_Sync_Stabilization_06_TEST" --output "%~dp0Acceptance_Results" --regression --gpu
if errorlevel 1 (
 echo Some checks failed or are unavailable. Read Acceptance_Results\Automatic_Results.json.
 echo A missing GPU/CUDA capability does not prove that CPU export is broken.
) else (
 echo Automatic checks completed. Manual acceptance is still pending.
)
echo Complete Acceptance_Results\Manual_Results.json after testing the app.
pause
