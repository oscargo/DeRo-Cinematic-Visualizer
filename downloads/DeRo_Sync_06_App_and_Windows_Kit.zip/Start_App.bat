@echo off
call "%~dp0DeRo_Sync_Stabilization_06_TEST\Launch_DeRo_Sync.bat"
